# Native compiler stabilization first batch

This directory contains the three sources, recipes and local review history.
Build paths below refer to this directory. The benchmark checkout extends the
maintained Cranelift packet.

| Snapshot | Source tree | Evidence |
| --- | --- | --- |
| Frozen | `frozen` at published PR #1000 pin `35784003b9149fe8059fa83dd5d0aff10dbcd631` | [Recipe and qualification references](evidence/frozen/identity.json) |
| Reconciled | `reconciled` at `5b9f252fc7e775bf8e4d850ca368da581e9f5386` | [Merge map](stack.tsv) · [Recipe](evidence/reconciled/recipe.json) |
| Configured | `configured` at the pin in its recipe | [Recipe](evidence/configured/recipe.json) · [Input compatibility](evidence/configured/native-compiler-inputs.md) · [Library contract](evidence/configured/native-closed-library.md) |

Frozen uses the previous winning configuration. Reconciled first integrates
the parent of #993 through #1000 and preserves duplicate canonical set
rejection, atomic publication and recovery. Configured captures native settings
and profile contents at entry and records optional compiler measurements.

## Materialize the local review refs

The two verified Git bundles use the published Frozen source and benchmark
checkpoint as prerequisites. Import them into the matching repositories.

```sh
git -C "$mech" fetch origin 35784003b9149fe8059fa83dd5d0aff10dbcd631
git -C "$mech" fetch "$handoff/native-first-batch.bundle" \
  refs/heads/codex/native-first-batch-reconciled:refs/heads/codex/native-first-batch-reconciled \
  refs/heads/codex/native-first-batch-configured:refs/heads/codex/native-first-batch-configured
git -C "$bench" fetch origin 77a56ebc15e5ab2426d95cea47afb3c24175a9e4
git -C "$bench" fetch "$handoff/native-first-batch-benchmarks.bundle" \
  refs/heads/codex/native-first-batch-benchmarks:refs/heads/codex/native-first-batch-benchmarks
```

Source changes and benchmark tooling are packaged as local commits for review.
The old-to-new merge map lists the incoming PR heads and the reconciled heads.
For a portable copy, create these worktrees in the handoff directory.

```sh
git -C "$mech" worktree add --detach "$handoff/frozen" 35784003b9149fe8059fa83dd5d0aff10dbcd631
git -C "$mech" worktree add --detach "$handoff/reconciled" codex/native-first-batch-reconciled
git -C "$mech" worktree add --detach "$handoff/configured" codex/native-first-batch-configured
git -C "$bench" worktree add --detach "$handoff/bench" codex/native-first-batch-benchmarks
```

## Correctness commands

Run the source test on Reconciled with the pinned nightly. The Wasm test
executes the generated Node package.

```sh
cargo +nightly-2026-03-03 test --locked -p mech-stdlib --no-default-features \
  --features full_compiler --test optional_set_table_source -- --test-threads=1
RUSTUP_TOOLCHAIN=nightly-2026-03-03 wasm-pack build src/wasm --dev --target nodejs \
  --out-dir /tmp/reconciled-set-wasm --locked --no-default-features --features base,u64
node src/wasm/tests/optional_set_table_runtime.cjs /tmp/reconciled-set-wasm/mech_wasm.js
```

Run native checks from Configured.

```sh
cargo +nightly-2026-03-03 test --locked -p mech-gpu --no-default-features \
  --features canonical-native-program --lib native_artifact:: -- --test-threads=1
python3 scripts/check-native-codegen-contract.py
python3 scripts/check-native-build-analysis-layout.py
```

## Rebuild and qualify on Apple Silicon

After materializing the source and benchmark refs, set `frozen_tree`,
`reconciled_tree` and `configured_tree` to their clean checkout paths,
`bench` to the maintained benchmark checkout and `evidence` to this
handoff's recipe directory. Set `silesia` to the exact corpus described
in the benchmark packet. Capture a separate output directory per hardware
configuration.

```sh
packet="$bench/experiments/mech/mechdeflate-cranelift-v1"
builds="$PWD/builds"
results="$PWD/results"
rebuild() {
  label=$1
  tree=$2
  shift 2
  python3 -B "$packet/rebuild.py" --recipe "$evidence/$label/recipe.json" \
    --mech-root "$tree" --output "$builds/$label" --build-repeats 3 "$@"
}
rebuild frozen "$frozen_tree"
rebuild reconciled "$reconciled_tree"
rebuild configured "$configured_tree" --with-host-report

compare() {
  control=$1
  candidate=$2
  python3 -B "$packet/compare_rebuilt.py" \
    --control "$control" --control-build "$builds/$control" \
    --control-recipe "$evidence/$control/recipe.json" \
    --candidate "$candidate" --candidate-build "$builds/$candidate" \
    --candidate-recipe "$evidence/$candidate/recipe.json" \
    --corpus "$silesia" --output "$results/$candidate-vs-$control"
}
compare frozen reconciled
compare reconciled configured
compare frozen configured
python3 -B "$packet/replay.py" --suite silesia --corpus "$silesia" \
  --build "$builds/configured" --recipe "$evidence/configured/recipe.json" \
  --output "$results/configured-silesia-references"
```

The rebuild requires exact object, bytecode and descriptor hashes. The report
run measures compiler process peak RSS and checks all three output hashes again.
Measure primary compilation latency on a quiet machine with the ordinary
driver. A separate configured driver built with `--features construction-census`
records construction counts in the same report schema.

The scripts in this handoff use the worktree names above and build outputs
named `frozen-build`, `reconciled-build` and `configured-final-build`.
Use those output names to run the expanded checks below. The resource probes
use the same allocator, object, adapter and fixtures as the retained gate.

```sh
python3 -B bench/experiments/mech/mechdeflate-81-v1/replay_timings.py \
  --prepare-only --output prepared-regression-controls
python3 -B measure-native-resources.py frozen
python3 -B measure-native-resources.py configured
python3 -B verify-full-configuration.py
python3 -B measure-compiler-processes.py --construction-census
sh run-comparisons.sh "$silesia"
```

The timed comparison binds source, profiles, runtime support, executables and
timing boundaries in its manifest. The 81-case controller compares both Mech
actors and the pinned reference actors within each of 96 balanced blocks.
The Silesia pair times the two Mech encoders on each whole input through the
same deployment call. The Silesia reference replay uses the same corpus and
existing comparator protocol.

See the [qualification record](qualification.md) for the M1 results and M3
status. The separate M1 observations archive contains the original runtime
blocks, primary compiler samples, and rebuilt worker snapshots. It uses a
`recorded-results` prefix so new qualification can write to `results`.
