"""Check worker invariance and in-flight profile stability on the pinned encoder."""

from pathlib import Path
from runpy import run_path
from shutil import copy2
import json
import os
import subprocess

ROOT = Path(__file__).resolve().parent
MEASURE = run_path(str(ROOT / "measure-compiler-processes.py"))
OUT = ROOT / "results/full-configuration"


def compile(compiler, source, source_tree, output, expected, flags):
    with output.with_suffix(".log").open("w") as log:
        subprocess.run([compiler, source, output, "compact"], cwd=source_tree,
                       env=dict(os.environ) | flags, stdout=log, stderr=subprocess.STDOUT, check=True)
    observed = {file: MEASURE["DIGEST"](output / file) for file in expected}
    assert observed == expected, {"observed": observed, "expected": expected}
    return observed


def copied_profiles(flags, folder):
    snapshots = {}
    for key in (*MEASURE["SUPPORT"]["PATH_SETTINGS"], "MECH_COMPACT_ROOT_TAIL_PROFILE"):
        original = flags.get(key)
        if original is None:
            continue
        entries = original.split(";")
        updated = []
        for entry in entries:
            symbol, separator, value = entry.partition("@")
            path = Path(value if separator else symbol)
            if path not in snapshots:
                temporary = folder / f"{len(snapshots)}-{path.name}"
                copy2(path, temporary)
                snapshots[path] = temporary
            updated.append(f"{symbol}@{snapshots[path]}" if separator else str(snapshots[path]))
        flags[key] = ";".join(updated)
    return list(snapshots.values())


def main():
    OUT.mkdir(parents=True)
    MEASURE["SUPPORT"]["remove_build_overrides"]()
    source_tree, source, compiler, role, flags, receipt = MEASURE["inputs"]("configured")
    frozen_workers = MEASURE["READ"](ROOT / "evidence/frozen/worker-count-artifacts.json")
    for expected in frozen_workers.values():
        assert expected["program.o"] == role["artifacts"]["program.o"]
        assert expected["program.mecb"] == role["artifacts"]["program.mecb"]
    results = {"workers": {}}
    for count in (0, 1, 2, 4):
        results["workers"][str(count)] = compile(
            compiler, source, source_tree, OUT / f"workers-{count}", frozen_workers[str(count)],
            flags | {"MECH_COMPACT_COMPILE_THREADS": str(count)},
        )
    driver = OUT / "compiler-driver"
    driver.mkdir()
    original = MEASURE["BUILDS"]["configured"][1] / "compiler-driver"
    for file in ("Cargo.toml", "Cargo.lock", "compile_profile.rs", "configured_profile.rs"):
        copy2(original / file, driver / file)
    module = driver / "configured_profile.rs"
    pattern = "let config = NativeCompilerConfiguration::from_legacy_environment();"
    old = module.read_text()
    assert old.count(pattern) == 1
    module.write_text(old.replace(pattern, pattern + '''
    let paths = std::fs::read_to_string(out.parent().unwrap().join("copied-profiles.txt")).unwrap();
    for (index, path) in paths.lines().enumerate() {
        if index % 2 == 0 {
            std::fs::write(path, b"changed after capture").unwrap();
        } else {
            std::fs::remove_file(path).unwrap();
        }
    }
'''))
    tools = MEASURE["READ"](MEASURE["BASE"] / "recipe.json")["compiler"]
    target = MEASURE["cargo_target"](receipt)
    command = ["cargo", "+" + tools["toolchain"], "build", *tools["cargo_options"],
               "--manifest-path", driver / "Cargo.toml", "--target-dir", target]
    with (OUT / "build.log").open("w") as log:
        subprocess.run(command, env=dict(os.environ) | tools["cargo_environment"], cwd=source_tree,
                       stdout=log, stderr=subprocess.STDOUT, check=True)
    folder = OUT / "profiles"
    folder.mkdir()
    profile_flags = flags.copy()
    copied = copied_profiles(profile_flags, folder)
    assert len(copied) >= 2
    (OUT / "copied-profiles.txt").write_text("".join(str(path) + "\n" for path in copied))
    results["changed_or_deleted_profiles"] = {str(path): MEASURE["DIGEST"](path) for path in copied}
    probe = target / "release/compile_profile"
    results["profile_harness_sha256"] = MEASURE["DIGEST"](probe)
    results["profile_harness_artifacts"] = compile(
        probe, source, source_tree, OUT / "profile-replay", role["artifacts"], profile_flags,
    )
    for index, path in enumerate(copied):
        assert path.read_bytes() == b"changed after capture" if index % 2 == 0 else not path.exists()
    (OUT / "summary.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
