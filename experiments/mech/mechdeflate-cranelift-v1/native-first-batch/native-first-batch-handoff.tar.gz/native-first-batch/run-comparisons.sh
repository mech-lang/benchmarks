#!/bin/sh
set -eu

cd "$(dirname "$0")"
packet="$PWD/bench/experiments/mech/mechdeflate-cranelift-v1"
corpus=${1:?Pass the pinned Silesia corpus directory}
mkdir -p results

compare() {
    control=$1
    control_build=$2
    candidate=$3
    candidate_build=$4
    pair="$candidate-vs-$control"
    python3 -B "$packet/compare_rebuilt.py" \
        --control "$control" --control-build "$control_build" \
        --control-recipe "evidence/$control/recipe.json" \
        --candidate "$candidate" --candidate-build "$candidate_build" \
        --candidate-recipe "evidence/$candidate/recipe.json" \
        --corpus "$corpus" --output "results/$pair" > "results/$pair.log" 2>&1
}

compare frozen frozen-build reconciled reconciled-build
compare reconciled reconciled-build configured configured-final-build
compare frozen frozen-build configured configured-final-build
python3 -B summarize-pairs.py
python3 -B "$packet/replay.py" --suite silesia --corpus "$corpus" \
    --build configured-final-build --recipe evidence/configured/recipe.json \
    --output results/configured-silesia-references > results/configured-silesia-references.log 2>&1
python3 -B measure-compiler-processes.py > results/compiler-processes.log 2>&1
