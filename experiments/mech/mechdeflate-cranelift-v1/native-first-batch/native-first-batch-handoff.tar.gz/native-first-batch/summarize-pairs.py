from math import exp, log
from pathlib import Path
from statistics import mean
import json

root = Path(__file__).resolve().parent
results = root / "results"
pairs = ("reconciled-vs-frozen", "configured-vs-reconciled", "configured-vs-frozen")
summary = {}
for label in pairs:
    path = results / label / "comparison.json"
    if not path.exists():
        continue
    comparison = json.loads(path.read_text())
    pair = summary[label] = {"comparison": str(path), "suites": {}}
    for suite, measurement in comparison["measurements"].items():
        orders = pair["suites"][suite] = {}
        for direction, sample in measurement["orders"].items():
            rows = sample["cases"]
            ratios = [row["candidate_x_control"] for row in rows]
            worst = max(rows, key=lambda row: row["candidate_x_control"])
            orders[direction] = {
                "cases": len(rows),
                "paired_geometric_mean_change_pct": 100.0 * (exp(mean(map(log, ratios))) - 1.0),
                "largest_candidate_time_pct": 100.0 * (worst["candidate_x_control"] - 1.0),
                "largest_candidate_time_case": worst["case"],
                "reference_comparator_wins": sample.get("reference_comparator_wins"),
            }
output = root / "evidence/comparison-summary.json"
output.write_text(json.dumps(summary, indent=2) + "\n")
