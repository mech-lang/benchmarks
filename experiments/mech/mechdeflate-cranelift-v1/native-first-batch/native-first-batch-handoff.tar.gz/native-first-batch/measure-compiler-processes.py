"""Collect balanced, ordinary-driver latency and process RSS for the preserved snapshot actors."""

from argparse import ArgumentParser
from itertools import permutations
from pathlib import Path
from runpy import run_path
from statistics import median
import json
import os
import re
import subprocess
import time

ROOT = Path(__file__).resolve().parent
BENCH = ROOT / "bench/experiments/mech"
PACKET = BENCH / "mechdeflate-cranelift-v1"
BASE = BENCH / "mechdeflate-81-v1"
OUTPUT = ROOT / "results/compiler-processes"
FROZEN = ROOT / "frozen"
BUILDS = {
    "frozen": (FROZEN, ROOT / "frozen-build"),
    "reconciled": (ROOT / "reconciled", ROOT / "reconciled-build"),
    "configured": (ROOT / "configured", ROOT / "configured-final-build"),
}
SUPPORT = run_path(str(BASE / "rebuild.py"))
READ = lambda path: json.loads(path.read_text())
DIGEST = SUPPORT["digest"]


def inputs(label):
    source, build = BUILDS[label]
    base = READ(BASE / "recipe.json")
    recipe_path = ROOT / "evidence" / label / "recipe.json"
    recipe = READ(recipe_path)
    base["source_commit"] = recipe["source_commit"]
    file = SUPPORT["check_checkout"](source, base)
    role = recipe["roles"][recipe["candidate_actor"]]
    flags = SUPPORT["load_flags"](base)
    profiles = role["profile_inputs_sha256"]
    for key, value in role["settings_delta"].items():
        if value is None:
            del flags[key]
        elif key == "MECH_COMPACT_ROOT_TAIL_PROFILE":
            path = PACKET / value
            assert DIGEST(path) == profiles[value]
            flags[key] = str(path)
        elif key in SUPPORT["PATH_SETTINGS"]:
            entries = []
            for binding in value.split(";"):
                symbol, relative = binding.split("@", 1)
                path = PACKET / relative
                assert DIGEST(path) == profiles[relative]
                entries.append(f"{symbol}@{path}")
            flags[key] = ";".join(entries)
        else:
            flags[key] = value
    receipt = READ(build / recipe["candidate_actor"] / "receipt.json")
    assert receipt["recipe_sha256"] == DIGEST(recipe_path)
    compiler = build / "compile_profile"
    assert DIGEST(compiler) == receipt["compiler_sha256"]
    return source, file, compiler, role, flags, receipt


def sample(folder, selected):
    source_tree, source, compiler, role, flags, receipt = selected
    folder.mkdir()
    log = folder / "process.log"
    compile = folder / "frontend"
    command = ["/usr/bin/time", "-l", compiler, source, compile, "compact"]
    with log.open("w") as stream:
        start = time.perf_counter()
        subprocess.run(command, cwd=source_tree, env=dict(os.environ) | flags, stdout=stream,
                       stderr=subprocess.STDOUT, check=True)
        duration = time.perf_counter() - start
    for file, expected in role["artifacts"].items():
        assert DIGEST(compile / file) == expected
    rss, = re.findall(r"(?m)^\s*(\d+)\s+maximum resident set size\s*$", log.read_text())
    record = READ(compile / "compile.json")
    return {
        "path": str(folder), "external_seconds": duration, "primary_driver_seconds": record["total_seconds"],
        "maximum_resident_bytes": int(rss), "compiler_sha256": receipt["compiler_sha256"],
        "input_configuration_sha256": receipt["configuration_sha256"],
    }


def cargo_target(receipt):
    dependency, = [arg.removeprefix("dependency=") for arg in receipt["worker_command"]
                   if arg.startswith("dependency=")]
    return Path(dependency).parents[1]


def construction_census():
    out = ROOT / "results/construction-census"
    out.mkdir(parents=True)
    source_tree, source, _, role, flags, receipt = inputs("configured")
    tools = READ(BASE / "recipe.json")["compiler"]
    target = cargo_target(receipt)
    driver = BUILDS["configured"][1] / "compiler-driver/Cargo.toml"
    command = ["cargo", "+" + tools["toolchain"], "build", *tools["cargo_options"],
               "--manifest-path", driver, "--target-dir", target, "--features", "construction-census"]
    with (out / "build.log").open("w") as error:
        subprocess.run(command, cwd=source_tree, env=dict(os.environ) | tools["cargo_environment"],
                       stdout=error, stderr=subprocess.STDOUT, check=True)
    compiler = target / "release/compile_profile"
    frontend = out / "frontend"
    with (out / "compiler.log").open("w") as log:
        subprocess.run([compiler, source, frontend, "compact", "--host-report"], cwd=source_tree,
                       env=dict(os.environ) | flags, stdout=log, stderr=subprocess.STDOUT, check=True)
    for file, expected in role["artifacts"].items():
        assert DIGEST(frontend / file) == expected
    report = READ(frontend / "host-report.json")
    assert report["construction"]["available"]
    report["compiler_sha256"] = DIGEST(compiler)
    report["scope"] = "separate construction census with a verified compact artifact"
    (out / "report.json").write_text(json.dumps(report, indent=2) + "\n")


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--construction-census", action="store_true", help="Collect a separate instrumented census")
    args = parser.parse_args()
    SUPPORT["remove_build_overrides"]()
    if args.construction_census:
        construction_census()
        return
    OUTPUT.mkdir(parents=True)
    selected = {name: inputs(name) for name in BUILDS}
    order = list(BUILDS)
    for name in order:
        sample(OUTPUT / f"{name}-warmup", selected[name])
    records = {name: [] for name in order}
    for block, sequence in enumerate(permutations(order)):
        for name in sequence:
            records[name].append(sample(OUTPUT / f"{name}-block-{block}", selected[name]))
    summary = {
        name: {key: median(row[key] for row in rows)
               for key in ("external_seconds", "primary_driver_seconds", "maximum_resident_bytes")}
        for name, rows in records.items()
    }
    (OUTPUT / "summary.json").write_text(json.dumps({"summary": summary, "samples": records}, indent=2) + "\n")


if __name__ == "__main__":
    main()
