#!/bin/sh
set -u
cd '/Users/coreymontella/.codex/worktrees/mech-native-route-stabilization.4xX2Ip/direct-m1' || exit 1
export PYTHONPATH='/Users/coreymontella/.codex/worktrees/mech-native-route-stabilization.4xX2Ip/direct-m1/experiments/mech/mechdeflate-cranelift-v1'
run='/Users/coreymontella/.codex/worktrees/mech-native-route-stabilization.4xX2Ip/direct-m1/experiments/mech/mechdeflate-cranelift-v1/stabilization/route-memory/3a66a014c853e082ad907ed4db1673c9dadf0c69/F-m1-direct-20261127T162006Z'
prior='/Users/coreymontella/.codex/worktrees/mech-native-route-stabilization.4xX2Ip/runtime-continuation/experiments/mech/mechdeflate-cranelift-v1/stabilization/route-memory/3a66a014c853e082ad907ed4db1673c9dadf0c69/F-m1-runtime-continuation-20261127T063331Z'
printf '%s\n' "Direct comparison started $(date -u +%Y-%m-%dT%H:%M:%SZ)" > "$run/commands/supervisor.log"
/usr/bin/caffeinate -is python3 -B "$run/commands/measure.py" "$run" "$prior" > "$run/commands/measurement.log" 2> "$run/commands/measurement.stderr"
result=$?
printf '%s\n' "$result" > "$run/commands/exit.txt"
printf '%s\n' "Direct comparison ended $(date -u +%Y-%m-%dT%H:%M:%SZ), exit $result" >> "$run/commands/supervisor.log"
exit "$result"
