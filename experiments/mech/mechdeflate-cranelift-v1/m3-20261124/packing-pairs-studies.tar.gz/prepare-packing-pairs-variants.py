from pathlib import Path
from hashlib import sha256
import json, shutil, subprocess
r=Path(__file__).resolve().parent
b=Path('/private/tmp/mech-m3-deflate-81-benchmarks/experiments/mech/mechdeflate-cranelift-v1')
mech=Path('/Users/cim310/.codex/worktrees/level12-compile-profile/mech')
o=r/'source-experiments/packing-pairs'; o.mkdir()
compiler=Path('/private/tmp/mech-m3-81-20261124/target/release/compile_profile'); shutil.copyfile(compiler,o/'compile_profile')
patch=subprocess.check_output(['git','diff'],cwd=mech,text=True)
paths=subprocess.check_output(['git','diff','--name-only'],cwd=mech,text=True).splitlines()
untracked=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=mech,text=True).splitlines()
for path in untracked:
 p=subprocess.run(['git','diff','--no-index','--','/dev/null',path],cwd=mech,text=True,stdout=subprocess.PIPE)
 assert p.returncode in (0,1)
 patch+=p.stdout
(o/'source.patch').write_text(patch)
for path in paths+untracked:
 target=o/path;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(mech/path,target)
(o/'source-receipt.json').write_text(json.dumps({'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=mech,text=True).strip(),'compiler_sha256':sha256(compiler.read_bytes()).hexdigest(),'source_patch_sha256':sha256(patch.encode()).hexdigest(),'focused_tests':16, 'native_differential_cases':2160,'append_test_modes':10,'scope':'Broaden existing admitted append-store pairing across up to eight explicitly whitelisted nontrapping scalar integer instructions. Combine with live-SSA previous-cell cost proof. Existing store-pair option; compressor source unchanged.'},indent=2)+'\n')
def run(*args):
 print('COMMAND',*map(str,args),flush=True);subprocess.run(list(map(str,args)),check=True)
def build(name,settings,capture=False):
 settings=settings.copy()
 if capture:
  c=r/('capture-'+name);c.mkdir();settings['MECH_INSPECT_PHASE_REGISTER_PROFILE']=str(c/(symbol+'.vcode'));settings['MECH_INSPECT_OPTIMIZED_PHASE_CLIF']=str(c/(symbol+'.clif'))
 p=r/'settings'/(name+'.json');p.write_text(json.dumps(settings,indent=2)+'\n');run('python3','-B',r/'build-variant.py',name,'--settings',p,'--support-build',r/'clean-build-paired-appends')
symbol='mech_compact_numeric_3009_no_growth_composed'
build('packing-pairs-default-parity',{})
assert json.loads((r/'variants/packing-pairs-default-parity/receipt.json').read_text())['artifacts']=={'program.o':'e4325602c6a5a4507ba637eee5d34ada9bda77bbb334fefb8ff53324d720e214','program.mecb':'c6529d934f020f07f8e59f13fab40927e066649e202269818ad3f009a942a8c3','metadata.json':'c2448f4197863733301810dca0e8d721d1932afa32b5172e933843b07e2464ef'}
base=json.loads((b/'word-mismatch-order/recipe.json').read_text())['roles']['word-mismatch-order']['settings_delta']
candidates=[]
for width in [2,4]:
 family='packing-pairs'+str(width)
 settings=base|{'MECH_FORWARD_PREVIOUS_CARRIER_COSTS':'1','MECH_COMPACT_GROUP_FOUR_LITERAL_APPENDS':'1' if width==4 else None,'MECH_COMPACT_PAIR_REGISTER_SPILLS':'1','MECH_COMPACT_PAIR_ADMITTED_APPEND_STORES':'1','MECH_COMPACT_CCMP_IMMEDIATES':None}
 for key in ['MECH_COMPACT_PHASE_REGISTER_WEIGHTS','MECH_COMPACT_PHASE_BLOCK_LAYOUT']:settings[key]=';'.join(v for v in settings[key].split(';') if not v.startswith(symbol+'@'))
 build(family+'-raw',settings,True)
 reg=r/'rebased-profiles'/(family+'-register.json');run('python3','-B',r/'transfer-register.py','--source',(r/'rebased-profiles/current-cost2-register.json' if width==2 else r/'current-cost4-count-profiles/suite-balanced.json'),'--capture',r/('capture-'+family+'-raw')/(symbol+'.vcode'),'--output',reg)
 settings['MECH_COMPACT_PHASE_REGISTER_WEIGHTS']+=';'+symbol+'@'+str(reg);build(family+'-weighted',settings,True)
 layout=r/'rebased-profiles'/(family+'-layout.json');run('python3','-B',r/'project-layout.py','--control',r/'variants'/('current-cost'+str(width)+'-weighted'),'--candidate',r/'variants'/(family+'-weighted'),'--old-capture',r/('capture-current-cost'+str(width)+'-weighted')/(symbol+'.vcode'),'--new-capture',r/('capture-'+family+'-weighted')/(symbol+'.vcode'),'--profile',r/'rebased-profiles'/('current-cost'+str(width)+'-edge-layout.json'),'--mapping',reg.with_suffix('.proof.json'),'--output',layout,'--symbol',symbol)
 edges=r/'rebased-profiles'/(family+'-edge-layout.json');run('python3','-B',r/'place-edge-copy-blocks-v2.py','--candidate',r/'variants'/(family+'-weighted'),'--profile',layout,'--output',edges)
 for suffix,p,ccmp in [('-edges',edges,False),('-ccmp-edges',edges,True)]:
  s=settings|{'MECH_COMPACT_PHASE_BLOCK_LAYOUT':settings['MECH_COMPACT_PHASE_BLOCK_LAYOUT']+';'+symbol+'@'+str(p)}
  if ccmp:
   s['MECH_COMPACT_CCMP_IMMEDIATES']='mech_compact_numeric_475_vector'
   for key,path in [('MECH_COMPACT_PHASE_REGISTER_WEIGHTS',r/'rebased-profiles/ccmp-immediates-register.json'),('MECH_COMPACT_PHASE_BLOCK_LAYOUT',r/'rebased-profiles/ccmp-immediates-fixed-extent.json')]:s[key]=';'.join('mech_compact_numeric_475_vector@'+str(path) if part.startswith('mech_compact_numeric_475_vector@') else part for part in s[key].split(';'))
  name=family+suffix;build(name,s);v=r/'variants'/name
  run('python3','-B','/private/tmp/mech-m3-81-20261124/smoke.py',v/'bound/mech-worker',v/'bound/metadata.json',o/(name+'-smoke.json'));candidates.append(name)
(o/'timing-candidates.json').write_text(json.dumps(candidates,indent=2)+'\n')
