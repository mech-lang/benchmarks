"""Prepare existing bit-field lowering settings with freshly validated profile keys."""
from pathlib import Path
import hashlib,json,subprocess
r=Path(__file__).resolve().parent
packet=Path('/private/tmp/mech-m3-deflate-81-benchmarks/experiments/mech/mechdeflate-cranelift-v1/word-mismatch-order/profiles')
symbols={'mech_compact_numeric_475_vector':('9240a4ff5e10851112e22ee5fd660e61b954c0f89450dda03003656aad92c426.json','a33a82846096fc7744a09a8712f19db227c800f61470c2db699736a61479266f.json','matcher-base-unlaid','capture-matcher-unlaid'),'mech_compact_numeric_3009_no_growth_composed':('c1acb158a41536816386146f55e5be5e2ea9e8607c1dc78df41f900e40671bcd.json','069b98a9e53752e75cbe56873ef6e370b7a280bb773aac195536b37d39dab6b7.json','scorer-base-capture','capture-scorer-unlaid')}
def run(cmd):subprocess.run(list(map(str,cmd)),check=True)
def build(name,s,inspect):
 s=s.copy();c=r/('capture-'+name);c.mkdir()
 s['MECH_INSPECT_PHASE_REGISTER_PROFILE']=str(c/(inspect+'.vcode'));s['MECH_INSPECT_OPTIMIZED_PHASE_CLIF']=str(c/(inspect+'.clif'))
 p=r/'settings'/(name+'.json');p.write_text(json.dumps(s,indent=2)+'\n');run(['python3','-B',r/'build-variant.py',name,'--settings',p]);return c,json.loads((r/'variants'/name/'receipt.json').read_text())['artifacts']
for stem,override in [('fields-copy',{'MECH_ARM64_INSERT_MASKED_FIELDS':'wide-copy'}),('fields-basic',{'MECH_ARM64_INSERT_MASKED_FIELDS':'1'}),('fields-plain',{'MECH_ARM64_INSERT_MASKED_FIELDS':None})]:
 print('PREPARE',stem,flush=True)
 settings=json.loads((r/'settings/root-forward.json').read_text())|override|{'MECH_COMPACT_PHASE_BLOCK_LAYOUT':None,'MECH_COMPACT_PHASE_REGISTER_WEIGHTS':None}
 weights=[];raw=[]
 for i,(symbol,(register,layout,control,oldcapture)) in enumerate(symbols.items()):
  name=f'{stem}-raw{i}';capture,artifacts=build(name,settings,symbol);raw.append(artifacts)
  profile=r/'rebased-profiles'/f'{stem}-{i}-register.json';run(['python3','-B',r/'transfer-register.py','--source',packet/register,'--capture',capture/(symbol+'.vcode'),'--output',profile]);weights.append(symbol+'@'+str(profile))
 assert raw[0]==raw[1],raw
 settings['MECH_COMPACT_PHASE_REGISTER_WEIGHTS']=';'.join(weights)
 layouts=[];weighted=[]
 for i,(symbol,(register,layout,control,oldcapture)) in enumerate(symbols.items()):
  name=f'{stem}-weighted{i}';capture,artifacts=build(name,settings,symbol);weighted.append(artifacts)
  projected=r/'rebased-profiles'/f'{stem}-{i}-layout.json';run(['python3','-B',r/'project-layout.py','--symbol',symbol,'--control',r/'variants'/control,'--candidate',r/'variants'/name,'--old-capture',r/oldcapture/(symbol+'.vcode'),'--new-capture',capture/(symbol+'.vcode'),'--profile',packet/layout,'--mapping',r/'rebased-profiles'/f'{stem}-{i}-register.proof.json','--output',projected]);layouts.append(symbol+'@'+str(projected))
 assert weighted[0]==weighted[1],weighted
 settings['MECH_COMPACT_PHASE_BLOCK_LAYOUT']=';'.join(layouts);name=stem+'-profiled';p=r/'settings'/(name+'.json');p.write_text(json.dumps(settings,indent=2)+'\n');run(['python3','-B',r/'build-variant.py',name,'--settings',p]);run(['python3','-B','/private/tmp/mech-m3-81-20261124/smoke.py',r/'variants'/name/'bound/mech-worker',r/'variants'/name/'bound/metadata.json',r/(name+'-smoke.json')])
