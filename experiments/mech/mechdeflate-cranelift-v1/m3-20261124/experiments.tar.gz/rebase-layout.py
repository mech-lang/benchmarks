"""Transfer byte coordinates only after exact ordered native CFG equality."""
import argparse
import hashlib
import json
from pathlib import Path
from struct import unpack_from


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--control', type=Path, required=True)
parser.add_argument('--candidate', type=Path, required=True)
parser.add_argument('--profile', type=Path, required=True)
parser.add_argument('--symbol', required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
prior = Path('/private/tmp/mech-m3-81-20261124/rebase-spill-layout.py')
code = prior.read_text().split('parser=argparse.ArgumentParser')[0]
namespace = {'__file__': str(prior)}
exec(compile(code, str(prior), 'exec'), namespace)
namespace['SYMBOL'] = args.symbol
a, b = namespace['shape'](args.control), namespace['shape'](args.candidate)
profile = json.loads(args.profile.read_text())
assert sorted(profile['order']) == a['heads']
assert profile['literal_offset'] == a['pool']

def trim_padding(folder, shape):
    result = {**shape, 'heads': list(shape['heads']), 'blocks': list(shape['blocks'])}
    removed = []
    macho = namespace['MACHO']
    data, sections, symbols = macho['load'](folder / 'frontend/program.o')
    names = macho['text_symbols'](sections, symbols)
    _, base, _, offset, *_ = sections[macho['TEXT']]
    begin = offset + names['_' + args.symbol] - base
    while len(result['heads']) > 1:
        index = len(result['heads']) - 1
        head = result['heads'][-1]
        if result['blocks'][-1] != (('trap', 0), None, None):
            break
        if any(index in block[1:] for block in result['blocks']):
            break
        if any(unpack_from('<I', data, begin + at)[0] not in [0, 0xd503201f]
               for at in range(head, result['code_end'], 4)):
            break
        removed.append(result['heads'].pop())
        result['blocks'].pop()
        result['code_end'] = head
    return result, removed

original_a, original_b = a, b
a, padding_a = trim_padding(args.control, a)
b, padding_b = trim_padding(args.candidate, b)
assert a['blocks'] == b['blocks'], 'Refuse changed CFG or branch opcodes'
assert len(a['heads']) == len(b['heads'])
assert 'object_tail' not in profile
mapping = dict(zip(a['heads'], b['heads'], strict=True))
translated = profile | {'order': [mapping[x] for x in profile['order'] if x not in padding_a] + list(reversed(padding_b)), 'literal_offset': b['pool']}
args.output.parent.mkdir(exist_ok=True, parents=True)
args.output.write_text(json.dumps(translated, indent=2) + '\n')
proof = {'control': original_a, 'candidate': original_b, 'normalized_control': a, 'normalized_candidate': b,
         'unreferenced_zero_alignment_heads': {'control': padding_a, 'candidate': padding_b},
         'prior_profile_sha256': hashlib.sha256(args.profile.read_bytes()).hexdigest(),
         'translated_profile_sha256': hashlib.sha256(args.output.read_bytes()).hexdigest(),
         'scope': 'Exact ordered native CFG and branch-opcode equality after excluding only unreferenced zero/NOP alignment after returns. Only validated block byte coordinates translate.'}
args.output.with_suffix('.proof.json').write_text(json.dumps(proof, indent=2) + '\n')
print('Proved layout translation:', len(mapping), 'blocks; literal pool:', b['pool'])
