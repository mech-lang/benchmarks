"""Instruction samples from the unchanged baseline native object; never primary timings."""
from pathlib import Path
import bisect,collections,hashlib,json,os,re,subprocess,time
root=Path(__file__).resolve().parent
folder=root/'pc-diagnostic'
entries=[]
for line in (folder/'symbols.txt').read_text().splitlines():
 m=re.match(r'([0-9a-f]+) \(__TEXT,__text\).* (_\S+)$',line)
 if m: entries.append((int(m[1],16),m[2]))
entries.sort();addresses=[x[0] for x in entries]
anchor=next(a for a,n in entries if n=='_mech_compact_closed_v2')
for case in ['mr','x-ray']:
 out=folder/case;out.mkdir()
 exe=folder/'silesia-encoder'
 with (out/'stderr').open('w') as err:
  child=subprocess.Popen([exe,root/'silesia-inputs'/case],env=os.environ|{'MECH_PC_SAMPLE_OUT':str(out/'pcs.csv')},stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err)
  records=[]
  try:
   assert child.stdout.readline()==b'READY\n'
   start=time.monotonic()
   while time.monotonic()-start<8:
    child.stdin.write(b'N');child.stdin.flush()
    ns,size=map(int,child.stdout.readline().split()); assert ns>0 and size>0
    records.append({'ns':ns,'bytes':size})
   child.stdin.write(b'Q');child.stdin.flush();assert child.wait(timeout=10)==0
  finally:
   if child.poll() is None: child.kill();child.wait()
 lines=(out/'pcs.csv').read_text().splitlines()
 slide=int(lines[0].split(',')[1],16)-anchor
 failures=int(lines[1].split(',')[1]);assert failures==0
 bins=collections.Counter(); pcs=collections.defaultdict(collections.Counter)
 for line in lines[2:]:
  pc,lr=[int(v,16) for v in line.split(',')];pc-=slide
  i=bisect.bisect_right(addresses,pc)-1
  if 0<=i<len(entries)-1:
   a,name=entries[i]
   bins[name]+=1
   pcs[name][pc-a]+=1
 summary={'scope':__doc__,'native_object_sha256':hashlib.sha256((root/'build/word-mismatch-order/bound/program.o').read_bytes()).hexdigest(),'worker_sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'counts':dict(bins.most_common()),'pcs':{name:dict(c.most_common()) for name,c in pcs.items() if name.startswith('_mech_compact')},'sampler_failures':failures,'invocations':records}
 (out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
 print(case,bins.most_common(7),flush=True)
 for name in ['_mech_compact_numeric_475_vector','_mech_compact_numeric_3009_no_growth_composed']:
  print(name,pcs[name].most_common(15),flush=True)
