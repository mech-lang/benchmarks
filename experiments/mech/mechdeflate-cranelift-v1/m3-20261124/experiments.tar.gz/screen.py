"""Diagnostic paired screens; these are not complete qualification runs."""
import argparse
import hashlib
import itertools
import json
import math
from pathlib import Path
import statistics
import subprocess
import sys
import zlib


def save(path, data):
    path.write_text(json.dumps(data, indent=2) + '\n')


def fixtures(root, candidate, out, cases):
    suite = root / 'baseline/suite81'
    original = (suite / 'controller.py').read_text()
    program = original
    lines = [line for line in program.splitlines() if line.startswith('selected = ')]
    assert len(lines) == 1
    program = program.replace(lines[0], 'selected = ' + repr(set(cases)))
    needle = 'orders = list(permutations(commands)) * 4'
    assert program.count(needle) == 1
    program = program.replace(needle, 'orders = list(permutations(commands))')
    controller = suite / ('controller-screen-' + out.name + '.py')
    controller.write_text(program)
    runs = []
    for order in ['forward', 'reverse']:
        folder = out / order
        command = [sys.executable, '-B', str(controller), str(folder),
                   str(root / 'build/word-mismatch-order/bound'), str(candidate / 'bound')]
        if order == 'reverse':
            command.append(order)
        with (out / (order + '.log')).open('w') as log:
            subprocess.run(command, stdout=log, stderr=log, check=True)
        rows = json.loads((folder / 'summary.json').read_text())
        complete = json.loads((folder / 'complete.json').read_text())
        assert len(rows) == len(cases) and complete['balanced_blocks_per_case'] == 24
        runs.append({'order': order, 'rows': rows})
        print(order, {row['case']: {'candidate_x_control': row['paired_x_roc']['mech-experiment'] / row['paired_x_roc']['mech-control'],
                                   'candidate_x_C': row['paired_x_libdeflate']['mech-experiment']} for row in rows}, flush=True)
    save(out / 'results.json', {'scope': 'Exploratory 24-block subset; qualification uses 81 cases and 96 blocks.',
                               'controller_sha256': hashlib.sha256(program.encode()).hexdigest(), 'runs': runs})


def corpus(root, candidate, out, cases):
    paths = {'control': root / 'build/word-mismatch-order/silesia-encoder',
             'candidate': candidate / 'silesia-encoder'}
    receipts = {}
    for case in cases:
        source = root / 'silesia-inputs' / case
        compressed = {}
        for actor, path in paths.items():
            compressed[actor] = subprocess.check_output([path, source, '--verify'])
            assert zlib.decompress(compressed[actor], -15) == source.read_bytes()
        assert compressed['control'] == compressed['candidate']
        workers = {actor: subprocess.Popen([path, source], stdin=subprocess.PIPE, stdout=subprocess.PIPE)
                   for actor, path in paths.items()}
        def sample(actor):
            child = workers[actor]
            child.stdin.write(b'N')
            child.stdin.flush()
            ns, size = map(int, child.stdout.readline().split())
            assert ns > 0 and size == len(compressed[actor])
            return ns
        try:
            for child in workers.values():
                assert child.stdout.readline() == b'READY\n'
            warmup = {actor: sample(actor) for actor in workers}
            orders = list(itertools.permutations(workers)) * 4
            rows = [{'order': list(order), 'ns': {actor: sample(actor) for actor in order}} for order in orders]
            ratio = math.exp(statistics.mean(math.log(row['ns']['candidate'] / row['ns']['control']) for row in rows))
            receipts[case] = {'paired_candidate_x_control': ratio, 'warmup_ns': warmup, 'blocks': rows,
                              'exact_stream_sha256': hashlib.sha256(compressed['candidate']).hexdigest(),
                              'independent_inflation': True}
            print(case, 'candidate/control', round(ratio, 6), flush=True)
        finally:
            for child in workers.values():
                if child.poll() is None:
                    child.stdin.write(b'Q')
                    child.stdin.flush()
                    assert child.wait(timeout=30) == 0
        save(out / 'results.json', {'scope': 'Exploratory balanced two-encoder screen; no peer win-count claim.',
                                   'executables': {a: {'path': str(p), 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for a, p in paths.items()},
                                   'cases': receipts})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--candidate', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--suite', choices=['fixtures', 'silesia'], required=True)
    parser.add_argument('--cases', nargs='+', required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    args.output.mkdir(parents=True)
    if args.suite == 'fixtures':
        fixtures(root, args.candidate, args.output, args.cases)
    else:
        corpus(root, args.candidate, args.output, args.cases)


if __name__ == '__main__':
    main()
