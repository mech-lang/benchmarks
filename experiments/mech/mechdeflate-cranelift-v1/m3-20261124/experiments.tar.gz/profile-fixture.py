"""Sample the original fixture worker outside qualification clocks."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import select
import subprocess
import threading
import time


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--suite', required=True, type=Path)
    parser.add_argument('--bound', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--cases', required=True, nargs='+')
    args = parser.parse_args()
    args.output.mkdir(parents=True)
    fixtures = args.suite / 'fixtures.json'
    cases = json.loads(fixtures.read_text())
    peers = json.loads((args.suite / 'pinned-peers/pins.json').read_text())['actors']
    commands = {p: peers[p]['command'] for p in ['roc', 'libdeflate']}
    commands['mech-current'] = [str(args.bound / 'mech-worker'),
                                str(args.bound / 'metadata.json'), str(fixtures)]
    records = []
    for case in args.cases:
        index = next(i for i, value in enumerate(cases) if value['name'] == case)
        for actor, command in commands.items():
            folder = args.output / f'{case}-{actor}'
            folder.mkdir()
            buffer = bytearray()
            with (folder / 'worker.stderr').open('wb') as stderr:
                child = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=stderr)
                def line():
                    while b'\n' not in buffer:
                        assert select.select([child.stdout], [], [], 90)[0]
                        data = os.read(child.stdout.fileno(), 65536)
                        assert data, (actor, child.poll())
                        buffer.extend(data)
                    at = buffer.index(b'\n')
                    result = bytes(buffer[:at]).decode()
                    del buffer[:at + 1]
                    return result
                def send(value):
                    child.stdin.write(value)
                    child.stdin.flush()
                try:
                    assert line() == 'SESSION_READY'
                    send(f'C\t{index}\t0\n'.encode())
                    assert line() == 'CASE_READY\t' + case
                    send(b'N')
                    initial = json.loads(line())
                    assert initial['warmup'] and initial['independent_inflation']
                    deadline = time.monotonic() + 6
                    warmups, errors = [], []
                    def feed():
                        try:
                            while time.monotonic() < deadline:
                                send(b'W')
                                result = line()
                                assert result.startswith('WARMUP_DONE\t' + case + '\t')
                                warmups.append(result)
                        except BaseException as error:
                            errors.append(repr(error))
                    thread = threading.Thread(target=feed)
                    thread.start()
                    sample = ['/usr/bin/sample', str(child.pid), '5', '1', '-file', str(folder / 'sample.txt')]
                    result = subprocess.run(sample, capture_output=True)
                    (folder / 'sample.stdout').write_bytes(result.stdout)
                    (folder / 'sample.stderr').write_bytes(result.stderr)
                    thread.join(timeout=90)
                    assert not thread.is_alive() and not errors, errors
                    assert result.returncode == 0 and warmups
                    send(b'N')
                    final = json.loads(line())
                    assert final['profile'] and final['independent_inflation']
                    assert line() == 'CASE_DONE\t' + case
                    send(b'Q\n')
                    assert child.wait(timeout=30) == 0
                finally:
                    if child.poll() is None:
                        child.kill()
                        child.wait()
            with Path(command[0]).open('rb') as stream:
                digest = hashlib.file_digest(stream, 'sha256').hexdigest()
            record = {'case': case, 'actor': actor, 'command': command, 'worker_sha256': digest,
                      'sample_command': sample, 'warmups': warmups, 'initial': initial, 'final': final,
                      'scope': 'Diagnostic repeated complete worker warmups, excluded from primary timing.'}
            (folder / 'receipt.json').write_text(json.dumps(record, indent=2) + '\n')
            records.append(record)
            print(case, actor, 'profile complete', len(warmups), flush=True)
    (args.output / 'index.json').write_text(json.dumps(records, indent=2) + '\n')


if __name__ == '__main__':
    main()
