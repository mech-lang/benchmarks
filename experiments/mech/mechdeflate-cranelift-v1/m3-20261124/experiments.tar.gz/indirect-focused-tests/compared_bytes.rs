use cranelift_codegen::{flowgraph::ControlFlowGraph,ir::{Function,Value,ValueDef}};
use std::collections::BTreeSet;
pub(super) fn current_value(f: &Function, cfg: &ControlFlowGraph, value: Value) -> Value {
    // First peel exact forwarding joins. If the eventual value is a dynamic
    // phi, retain that phi rather than each later transport parameter's name.
    let mut original = f.dfg.resolve_aliases(value);
    let mut transport = BTreeSet::new();
    while transport.len() < 128 && transport.insert(original) {
        let ValueDef::Param(block, slot) = f.dfg.value_def(original) else {
            break;
        };
        if Some(block) == f.layout.entry_block() {
            break;
        }
        let mut arguments = BTreeSet::new();
        for pred in cfg.pred_iter(block) {
            for call in f.dfg.insts[pred.inst]
                .branch_destination(&f.dfg.jump_tables, &f.dfg.exception_tables)
            {
                if call.block(&f.dfg.value_lists) == block {
                    let Some(value) = call
                        .args(&f.dfg.value_lists)
                        .nth(slot)
                        .and_then(|arg| arg.as_value())
                    else {
                        return original;
                    };
                    let value = f.dfg.resolve_aliases(value);
                    if value != original {
                        arguments.insert(value);
                    }
                }
            }
        }
        if arguments.len() != 1 {
            break;
        }
        let next = *arguments.first().expect("one forwarding value");
        if transport.contains(&next) {
            break;
        }
        original = next;
    }
    let mut pending = vec![original];
    let mut seen = BTreeSet::new();
    let mut leaves = BTreeSet::new();
    while let Some(value) = pending.pop() {
        let value = f.dfg.resolve_aliases(value);
        if !seen.insert(value) {
            continue;
        }
        if seen.len() > 128 {
            return original;
        }
        if let ValueDef::Param(block, slot) = f.dfg.value_def(value)
            && Some(block) != f.layout.entry_block()
        {
            let mut incoming = false;
            for pred in cfg.pred_iter(block) {
                for call in f.dfg.insts[pred.inst]
                    .branch_destination(&f.dfg.jump_tables, &f.dfg.exception_tables)
                {
                    if call.block(&f.dfg.value_lists) == block {
                        let Some(arg) = call
                            .args(&f.dfg.value_lists)
                            .nth(slot)
                            .and_then(|arg| arg.as_value())
                        else {
                            return original;
                        };
                        pending.push(arg);
                        incoming = true;
                    }
                }
            }
            if !incoming {
                return original;
            }
        } else {
            leaves.insert(value);
            if leaves.len() > 1 {
                return original;
            }
        }
    }
    leaves.first().copied().unwrap_or(original)
}

