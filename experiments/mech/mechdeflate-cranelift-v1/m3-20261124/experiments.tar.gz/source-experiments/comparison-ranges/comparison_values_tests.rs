use super::*;
use cranelift_codegen::Context;
use cranelift_codegen::ir::{AbiParam, types};
use cranelift_frontend::{FunctionBuilder, FunctionBuilderContext};
use cranelift_jit::{JITBuilder, JITModule};
use cranelift_module::{Linkage, Module, default_libcall_names};

#[derive(Clone, Copy, Debug)]
enum Form {
    Minimum,
    Raw,
    Signed,
    TruncatedCondition,
}

type Entry = unsafe extern "C" fn(u64, u64) -> u64;

fn fixture(module: &JITModule, form: Form) -> Context {
    let mut ctx = module.make_context();
    ctx.func.signature.params = vec![AbiParam::new(types::I64); 2];
    ctx.func.signature.returns = vec![AbiParam::new(types::I64)];
    let mut frontend = FunctionBuilderContext::new();
    let mut b = FunctionBuilder::new(&mut ctx.func, &mut frontend);
    let entry = b.create_block();
    let yes = b.create_block();
    let no = b.create_block();
    b.append_block_params_for_function_params(entry);
    b.switch_to_block(entry);
    let x = b.block_params(entry)[0];
    let y = b.block_params(entry)[1];
    let limit = b.ins().iconst(types::I64, 258);
    let selected = if matches!(form, Form::Raw) {
        x
    } else {
        let tested = if matches!(form, Form::TruncatedCondition) {
            b.ins().ireduce(types::I32, x)
        } else {
            x
        };
        let cc = if matches!(form, Form::Signed) {
            IntCC::SignedLessThan
        } else {
            IntCC::UnsignedLessThan
        };
        let condition = b.ins().icmp_imm(cc, tested, 258);
        b.ins().select(condition, x, limit)
    };
    let fits = b
        .ins()
        .icmp_imm(IntCC::UnsignedLessThanOrEqual, selected, -9);
    let unknown = b.ins().icmp_imm(IntCC::NotEqual, y, 0);
    let combined = b.ins().band(fits, unknown);
    b.ins().brif(combined, yes, &[], no, &[]);
    b.switch_to_block(yes);
    b.ins().return_(&[selected]);
    b.switch_to_block(no);
    let error = b.ins().iconst(types::I64, -1);
    b.ins().return_(&[error]);
    b.seal_all_blocks();
    b.finalize();
    ctx
}

#[test]
fn proved_comparison_components_preserve_the_unknown_guard() {
    let mut module = JITModule::new(JITBuilder::new(default_libcall_names()).unwrap());
    for form in [
        Form::Minimum,
        Form::Raw,
        Form::Signed,
        Form::TruncatedCondition,
    ] {
        let mut functions = Vec::new();
        for optimized in [false, true] {
            let mut ctx = fixture(&module, form);
            if optimized {
                ctx.compute_cfg();
                let expected = usize::from(matches!(form, Form::Minimum));
                assert_eq!(
                    fold_comparisons(&mut ctx.func, &ctx.cfg),
                    expected,
                    "{form:?}"
                );
                assert!(ctx.func.layout.blocks().any(|block| {
                    matches!(
                        ctx.func.dfg.insts[ctx.func.layout.last_inst(block).unwrap()],
                        Data::Brif { .. }
                    )
                }));
                ctx.verify(module.isa()).unwrap();
            }
            let name = format!("comparison_components_{form:?}_{optimized}");
            let id = module
                .declare_function(&name, Linkage::Local, &ctx.func.signature)
                .unwrap();
            module.define_function(id, &mut ctx).unwrap();
            module.finalize_definitions().unwrap();
            // Each fixture has this exact ABI and the owning module stays live.
            functions.push(unsafe {
                core::mem::transmute::<*const u8, Entry>(module.get_finalized_function(id))
            });
        }
        for x in [
            0,
            1,
            257,
            258,
            259,
            1 << 32,
            (1 << 32) + 1,
            1 << 63,
            u64::MAX - 8,
            u64::MAX,
        ] {
            let selected = match form {
                Form::Minimum => x.min(258),
                Form::Raw => x,
                Form::Signed => {
                    if (x as i64) < 258 {
                        x
                    } else {
                        258
                    }
                }
                Form::TruncatedCondition => {
                    if (x as u32) < 258 {
                        x
                    } else {
                        258
                    }
                }
            };
            for y in [0, 1, 2, u64::MAX] {
                let expected = if selected <= u64::MAX - 8 && y != 0 {
                    selected
                } else {
                    u64::MAX
                };
                assert_eq!(unsafe { functions[0](x, y) }, expected, "{form:?}/{x}/{y}");
                assert_eq!(unsafe { functions[1](x, y) }, expected, "{form:?}/{x}/{y}");
            }
        }
    }
}
