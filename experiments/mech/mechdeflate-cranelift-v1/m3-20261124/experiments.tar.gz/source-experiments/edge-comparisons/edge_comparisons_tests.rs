use crate::Context;
use crate::cursor::{Cursor, FuncCursor};
use crate::ir::{
    AbiParam, Function, InstBuilder, Signature, UserFuncName, condcodes::IntCC, types,
};
use crate::isa::{self, CallConv};
use crate::settings;
use cranelift_control::ControlPlane;

fn comparisons(enabled: bool, join: bool, change_operand: bool) -> usize {
    let mut signature = Signature::new(CallConv::AppleAarch64);
    signature.params = vec![AbiParam::new(types::I64); 2];
    signature.returns.push(AbiParam::new(types::I64));
    let mut f = Function::with_name_signature(UserFuncName::user(0, 0), signature);
    f.aarch64_reuse_edge_comparisons = enabled;
    let mut block = || {
        let block = f.dfg.make_block();
        f.layout.append_block(block);
        block
    };
    let entry = block();
    let next = block();
    let equal = block();
    let merged = join.then(&mut block);
    let a = f.dfg.append_block_param(entry, types::I64);
    let b = f.dfg.append_block_param(entry, types::I64);
    let mut cursor = FuncCursor::new(&mut f);
    cursor.goto_bottom(entry);
    let same = cursor.ins().icmp(IntCC::Equal, a, b);
    cursor.ins().brif(same, equal, &[], next, &[]);
    cursor.goto_bottom(equal);
    if let Some(merged) = merged {
        cursor.ins().jump(merged, &[]);
    } else {
        let result = cursor.ins().iconst(types::I64, 0);
        cursor.ins().return_(&[result]);
    }
    cursor.goto_bottom(next);
    if let Some(merged) = merged {
        cursor.ins().jump(merged, &[]);
        cursor.goto_bottom(merged);
    }
    let a = if change_operand {
        cursor.ins().iadd_imm(a, 1)
    } else {
        a
    };
    let less = cursor.ins().icmp(IntCC::UnsignedLessThan, a, b);
    let result = cursor.ins().uextend(types::I64, less);
    cursor.ins().return_(&[result]);
    let target = isa::lookup("aarch64-apple-darwin".parse().unwrap())
        .unwrap()
        .finish(settings::Flags::new(settings::builder()))
        .unwrap();
    let mut context = Context::for_function(f);
    let code = context
        .compile(&*target, &mut ControlPlane::default())
        .unwrap();
    code.code_buffer()
        .chunks_exact(4)
        .filter(|bytes| {
            let word = u32::from_le_bytes((*bytes).try_into().unwrap());
            // SUBS XZR, Xn, Xm: the unshifted 64-bit register comparison.
            word & 0xffe0_fc1f == 0xeb00_001f
        })
        .count()
}

#[test]
fn sole_predecessor_reuses_the_observed_comparison() {
    assert_eq!(comparisons(false, false, false), 2);
    assert_eq!(comparisons(true, false, false), 1);
}

#[test]
fn join_does_not_inherit_a_predecessors_flags() {
    assert_eq!(comparisons(false, true, false), 2);
    assert_eq!(comparisons(true, true, false), 2);
}

#[test]
fn changed_operand_keeps_its_comparison() {
    assert_eq!(comparisons(false, false, true), 2);
    assert_eq!(comparisons(true, false, true), 2);
}
