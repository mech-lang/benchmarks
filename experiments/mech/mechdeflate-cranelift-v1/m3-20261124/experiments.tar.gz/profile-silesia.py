"""Sample unchanged deployed encoders; diagnostic samples are outside qualification."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import threading
import time


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--binding', type=Path, required=True)
    parser.add_argument('--corpus', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--cases', nargs='+', required=True)
    parser.add_argument('--actors', nargs='+', default=['mech-candidate', 'libdeflate', 'roc'])
    parser.add_argument('--seconds', type=int, default=5)
    args = parser.parse_args()
    binding = json.loads(args.binding.read_text())['actors']
    args.output.mkdir(parents=True)
    records = []
    for case in args.cases:
        for actor in args.actors:
            source = Path(binding[actor]['path'])
            digest = hashlib.file_digest(source.open('rb'), 'sha256').hexdigest()
            assert digest == binding[actor]['sha256']
            folder = args.output / f'{case}-{actor}'
            folder.mkdir()
            timings, errors = [], []
            with (folder / 'worker.stderr').open('wb') as stderr:
                child = subprocess.Popen([source, args.corpus / case], stdin=subprocess.PIPE,
                                         stdout=subprocess.PIPE, stderr=stderr)
                try:
                    assert child.stdout.readline() == b'READY\n'
                    deadline = time.monotonic() + args.seconds + 1
                    def feed():
                        try:
                            while time.monotonic() < deadline:
                                child.stdin.write(b'N')
                                child.stdin.flush()
                                ns, size = map(int, child.stdout.readline().split())
                                assert ns > 0 and size > 0
                                timings.append({'elapsed_ns': ns, 'compressed_bytes': size})
                        except BaseException as error:
                            errors.append(repr(error))
                    worker = threading.Thread(target=feed)
                    worker.start()
                    command = ['/usr/bin/sample', str(child.pid), str(args.seconds), '1',
                               '-file', str(folder / 'sample.txt')]
                    sampled = subprocess.run(command, capture_output=True)
                    (folder / 'sample.stdout').write_bytes(sampled.stdout)
                    (folder / 'sample.stderr').write_bytes(sampled.stderr)
                    worker.join(timeout=120)
                    assert not worker.is_alive() and not errors, errors
                    child.stdin.write(b'Q')
                    child.stdin.flush()
                    assert child.wait(timeout=30) == 0
                    assert sampled.returncode == 0 and timings
                finally:
                    if child.poll() is None:
                        child.kill()
                        child.wait()
            record = {'case': case, 'actor': actor, 'executable': str(source),
                      'executable_sha256': digest, 'sample_command': command,
                      'scope': 'Diagnostic whole encoder process, including output release between invocations; excluded from qualification timings.',
                      'invocations': timings}
            (folder / 'receipt.json').write_text(json.dumps(record, indent=2) + '\n')
            records.append(record)
            print(case, actor, 'sample complete', len(timings), flush=True)
    (args.output / 'index.json').write_text(json.dumps(records, indent=2) + '\n')


if __name__ == '__main__':
    main()
