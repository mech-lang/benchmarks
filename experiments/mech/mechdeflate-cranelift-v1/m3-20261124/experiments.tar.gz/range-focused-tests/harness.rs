#![allow(dead_code)]
mod native_artifact { pub mod program {
 pub mod prepare { pub mod word_collections {
  #[path = "/Users/cim310/.codex/worktrees/level12-compile-profile/mech/hosts/gpu/src/native_artifact/program/prepare/word_collections/bounds.rs"] pub(crate) mod bounds;
 }}
 pub mod codegen { pub mod cfg_cleanup {
  #[path = "/private/tmp/mech-m3-cranelift-20261124/range-focused-tests/boolean_conditions.rs"] mod boolean_conditions;
  pub(super) use boolean_conditions::masked_integer_comparison;
  #[path = "/Users/cim310/.codex/worktrees/level12-compile-profile/mech/hosts/gpu/src/native_artifact/program/codegen/cfg_cleanup/word_ranges/mod.rs"] mod word_ranges;
  #[path = "/private/tmp/mech-m3-cranelift-20261124/range-focused-tests/selected_values.rs"] mod selected_values;
 }}
}}
