//! Execute masked comparisons, including shared observers and declined forms.
use cranelift_codegen::{
    ir::{AbiParam, InstBuilder, Type, condcodes::IntCC, types},
    isa::Aarch64CompilationOptions,
    settings::{self, Configurable},
};
use cranelift_frontend::{FunctionBuilder, FunctionBuilderContext};
use cranelift_jit::{JITBuilder, JITModule};
use cranelift_module::{Linkage, Module, default_libcall_names};

type Run = unsafe extern "C" fn(u64, u64, u64, *mut u64) -> u64;
const CONDITIONS: [IntCC; 10] = [
    IntCC::Equal,
    IntCC::NotEqual,
    IntCC::SignedLessThan,
    IntCC::SignedLessThanOrEqual,
    IntCC::SignedGreaterThan,
    IntCC::SignedGreaterThanOrEqual,
    IntCC::UnsignedLessThan,
    IntCC::UnsignedLessThanOrEqual,
    IntCC::UnsignedGreaterThan,
    IntCC::UnsignedGreaterThanOrEqual,
];
const MASKS: [u64; 8] = [
    0,
    1,
    255,
    65535,
    0xffffff,
    0xaaaa_aaaa_aaaa_aaaa,
    0xff00_ff00_ff00_ff00,
    u64::MAX,
];
const WORDS: [u64; 16] = [
    0,
    1,
    255,
    256,
    65535,
    65536,
    0xffffff,
    0x1000000,
    0x7fff_ffff,
    0x8000_0000,
    0xffff_ffff,
    0x1_0000_0000,
    i64::MAX as u64,
    i64::MIN as u64,
    u64::MAX - 1,
    u64::MAX,
];

fn compile(
    ty: Type,
    mask: u64,
    cc: IntCC,
    mode: u8,
    opt: &str,
    enabled: bool,
) -> (JITModule, Run, String) {
    let mut flags = settings::builder();
    flags.set("opt_level", opt).unwrap();
    flags.set("regalloc_checker", "true").unwrap();
    let isa = cranelift_native::builder()
        .unwrap()
        .finish_with_aarch64_compilation_options(
            settings::Flags::new(flags),
            Aarch64CompilationOptions {
                masked_equality: enabled,
                reuse_i32_add: true,
                ..Default::default()
            },
        )
        .unwrap();
    let mut module = JITModule::new(JITBuilder::with_isa(isa, default_libcall_names()));
    let mut context = module.make_context();
    context.set_disasm(true);
    context.func.signature.params = vec![AbiParam::new(types::I64); 4];
    context.func.signature.returns = vec![AbiParam::new(types::I64)];
    let mut storage = FunctionBuilderContext::new();
    {
        let mut b = FunctionBuilder::new(&mut context.func, &mut storage);
        let entry = b.create_block();
        b.append_block_params_for_function_params(entry);
        b.switch_to_block(entry);
        let [x, y, seed, output] = b.block_params(entry).try_into().unwrap();
        let x = if ty == types::I64 {
            x
        } else {
            b.ins().ireduce(ty, x)
        };
        let y = if ty == types::I64 {
            y
        } else {
            b.ins().ireduce(ty, y)
        };
        let k = b.ins().iconst(ty, mask as i64);
        let other = if mode == 5 {
            b.ins().iconst(ty, (mask ^ 1) as i64)
        } else {
            k
        };
        let a = b.ins().band(x, k);
        let z = b.ins().band(y, other);
        let cmp = b.ins().icmp(cc, a, z);
        if matches!(mode, 3 | 4) {
            let observed = if ty == types::I64 {
                a
            } else {
                b.ins().uextend(types::I64, a)
            };
            b.ins()
                .store(cranelift_codegen::ir::MemFlags::new(), observed, output, 0);
        }
        if mode == 3 {
            let observed = if ty == types::I64 {
                z
            } else {
                b.ins().uextend(types::I64, z)
            };
            b.ins()
                .store(cranelift_codegen::ir::MemFlags::new(), observed, output, 8);
        }
        if mode == 1 {
            let yes = b.create_block();
            let no = b.create_block();
            b.ins().brif(cmp, yes, &[], no, &[]);
            for (block, bias) in [(yes, 17), (no, -29)] {
                b.switch_to_block(block);
                let result = b.ins().iadd_imm(seed, bias);
                b.ins().return_(&[result]);
            }
        } else if mode == 2 {
            let yes = b.ins().iadd_imm(seed, 17);
            let no = b.ins().iadd_imm(seed, -29);
            let result = b.ins().select(cmp, yes, no);
            b.ins().return_(&[result]);
        } else {
            let result = b.ins().uextend(types::I64, cmp);
            b.ins().return_(&[result]);
        }
        b.seal_all_blocks();
        b.finalize();
    }
    let id = module
        .declare_function("masked_comparison", Linkage::Local, &context.func.signature)
        .unwrap();
    module.define_function(id, &mut context).unwrap();
    let code = context
        .compiled_code()
        .unwrap()
        .vcode
        .as_ref()
        .unwrap()
        .clone();
    module.finalize_definitions().unwrap();
    let run = unsafe { std::mem::transmute::<_, Run>(module.get_finalized_function(id)) };
    (module, run, code)
}

fn compare(cc: IntCC, a: u64, b: u64, ty: Type) -> bool {
    let shift = 64 - ty.bits();
    let signed = |x| ((x << shift) as i64) >> shift;
    match cc {
        IntCC::Equal => a == b,
        IntCC::NotEqual => a != b,
        IntCC::SignedLessThan => signed(a) < signed(b),
        IntCC::SignedLessThanOrEqual => signed(a) <= signed(b),
        IntCC::SignedGreaterThan => signed(a) > signed(b),
        IntCC::SignedGreaterThanOrEqual => signed(a) >= signed(b),
        IntCC::UnsignedLessThan => a < b,
        IntCC::UnsignedLessThanOrEqual => a <= b,
        IntCC::UnsignedGreaterThan => a > b,
        IntCC::UnsignedGreaterThanOrEqual => a >= b,
    }
}

#[test]
fn masked_comparisons_preserve_conditions_shared_values_and_all_consumers() {
    for opt in ["none", "speed"] {
        for ty in [types::I32, types::I64] {
            let width_mask = u64::MAX >> (64 - ty.bits());
            for mask in MASKS {
                for cc in CONDITIONS {
                    for mode in 0..6 {
                        let (_module, run, _) = compile(ty, mask, cc, mode, opt, true);
                        for x in WORDS {
                            for y in WORDS.into_iter().chain([x, x ^ !mask, x ^ mask]) {
                                let a = x & mask & width_mask;
                                let z = y & (if mode == 5 { mask ^ 1 } else { mask }) & width_mask;
                                let selected = compare(cc, a, z, ty);
                                let seed = x.wrapping_mul(0x1234_5678_9abc_def1).wrapping_add(y);
                                let expected = if matches!(mode, 1 | 2) {
                                    if selected {
                                        seed.wrapping_add(17)
                                    } else {
                                        seed.wrapping_sub(29)
                                    }
                                } else {
                                    u64::from(selected)
                                };
                                let mut observed = [0x1234_5678_9abc_def0, 0xfedc_ba98_7654_3210];
                                assert_eq!(
                                    unsafe { run(x, y, seed, observed.as_mut_ptr()) },
                                    expected,
                                    "{opt} {ty} mask={mask:x} {cc:?} mode={mode} {x:x} {y:x}"
                                );
                                assert_eq!(
                                    observed[0],
                                    if matches!(mode, 3 | 4) {
                                        a
                                    } else {
                                        0x1234_5678_9abc_def0
                                    }
                                );
                                assert_eq!(
                                    observed[1],
                                    if mode == 3 { z } else { 0xfedc_ba98_7654_3210 }
                                );
                            }
                        }
                    }
                }
            }
        }
    }
}

#[test]
fn masked_comparison_lowering_is_opt_in_and_declines_unprofitable_forms() {
    for ty in [types::I32, types::I64] {
        for cc in [IntCC::Equal, IntCC::NotEqual] {
            for mode in 0..3 {
                let (_module, _, code) = compile(ty, 0xffffff, cc, mode, "none", true);
                let code = code.split(";; REGALLOC_INPUT_BEGIN").next().unwrap();
                assert!(code.contains("eor") && code.contains("ands"), "{code}");
            }
        }
        for (cc, mode, enabled) in [
            (IntCC::Equal, 0, false),
            (IntCC::Equal, 3, true),
            (IntCC::Equal, 5, true),
            (IntCC::UnsignedLessThan, 0, true),
        ] {
            let (_module, _, code) = compile(ty, 0xffffff, cc, mode, "none", enabled);
            let code = code.split(";; REGALLOC_INPUT_BEGIN").next().unwrap();
            assert!(!code.contains("ands"), "{code}");
        }
    }
}
