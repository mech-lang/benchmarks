from pathlib import Path
from hashlib import file_digest
import json,tarfile,subprocess,shutil
r=Path(__file__).resolve().parent;p=Path('/private/tmp/mech-m3-deflate-81-benchmarks/experiments/mech/mechdeflate-cranelift-v1/m3-20261124');snap=r/'source-experiments/masked-equality'
for name in ['Cargo.toml','Cargo.lock','masked_equality_checks.rs','captured_comparison_inputs.rs']:
 out=snap/'focused-harness'/name;out.parent.mkdir(exist_ok=True);shutil.copyfile(Path('/private/tmp/mech-m3-current-compiler-tests')/name,out)
assembly={}
for name,obj in [('control',r/'clean-build-paired-appends/word-mismatch-order/frontend/program.o'),('profiled',r/'variants/masked-equality-profiled/frontend/program.o')]:
 text=subprocess.check_output(['/usr/bin/otool','-tvV',str(obj)],text=True);after=text.split('_mech_compact_numeric_475_vector:\n',1)[1];lines=[]
 for line in after.splitlines():
  if line.startswith('_') and line.endswith(':'):break
  lines.append(line)
 text='\n'.join(lines)+'\n';(snap/(name+'-matcher.asm.txt')).write_text(text)
 assembly[name]={op:sum('\t'+op+'\t' in line for line in lines) for op in ['and','tst','eor','cmp']}
(snap/'native-selection.json').write_text(json.dumps({'scope':'Static native mnemonic census of the matcher, not timing or dynamic instruction counts.','counts':assembly},indent=2)+'\n')
families=('masked-equality',);allowed={'.json','.jsonl','.rs','.py','.toml','.lock','.log','.txt','.csv','.c','.stderr','.stdout','.sha256','.patch','.vcode','.clif','.o','.mecb'}
shared={'build-variant.py','screen.py','run-quiet.py','transfer-register.py','project-layout.py'}
def digest(path):
 with path.open('rb') as f:return file_digest(f,'sha256').hexdigest()
files=[]
for f in sorted(r.rglob('*')):
 if not f.is_file():continue
 rel=f.relative_to(r);a=rel.parts;selected=False
 if a[0]=='source-experiments' and len(a)>1 and a[1]=='masked-equality':selected=True
 elif a[0] in ('variants','settings','screens','rebased-profiles') and len(a)>1 and a[1].startswith(families):selected=True
 elif a[0].startswith('capture-masked-equality'):selected=True
 elif len(a)==1 and (f.name in shared or f.name.startswith(('build-masked-equality','prepare-masked-equality','screen-masked-equality','masked-equality-','package-masked-equality'))):selected=True
 if selected and (f.suffix in allowed or f.name in ('mech-worker','silesia-encoder')):files.append(f)
rows=[{'path':str(f.relative_to(r)),'bytes':f.stat().st_size,'sha256':digest(f)} for f in files]
archive=p/'masked-equality-studies.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz',compresslevel=6,dereference=True) as tar:
 for f in files:tar.add(f,arcname=str(f.relative_to(r)),recursive=False)
with tarfile.open(archive) as tar:
 members=tar.getmembers();assert len(members)==len(rows)
 for m,row in zip(members,rows):assert m.name==row['path'] and file_digest(tar.extractfile(m),'sha256').hexdigest()==row['sha256']
(p/(archive.name+'.manifest.json')).write_text(json.dumps({'archive_sha256':digest(archive),'files':rows},indent=2)+'\n')
screens=[]
for f in files:
 a=f.relative_to(r).parts
 if len(a)==3 and a[0]=='screens' and f.name=='results.json':
  result=json.loads(f.read_text());orders=[]
  for order in result['runs']:
   misses=[{'case':x['case'],'candidate_x_libdeflate':x['paired_x_libdeflate']['mech-experiment']} for x in order['rows'] if x['paired_x_libdeflate']['mech-experiment']>=1]
   orders.append({'order':order['order'],'cases':len(order['rows']),'wins':len(order['rows'])-len(misses),'misses':misses})
  screens.append({'candidate':a[1],'orders':orders})
assert len(screens)==4 and all(any(x['misses'] for x in s['orders']) for s in screens)
summary={'selected':False,'reason':'Every masked-equality candidate misses protected fixture timings. No new full score or compile-time claim.','source_head':'71bb1f90b39ad0bceebf1b5871a375de19683ac8','source_scope':'Generic opt-in Cranelift AArch64 lowering of Eq/Ne with identical encodable AND masks to EOR plus TST. At least one mask must have a unique use; independent full observers and other integer conditions remain intact. Compressor source and canonical bytecode unchanged.','tests':{'focused_records':9,'native_differential_calls':583680,'default_m1_artifact_triple_parity':True,'each_timed_actor_codec_alias_boundary_checks':162},'profile_scope':'Register hints transferred through unchanged original IR block identities with exact VCode validation. Machine layouts retain all native blocks and are checked at emission. Root code grows from 47328 to 47376 bytes, so the earlier exact measured root padding is rejected and disabled. Ordinary and fixed matcher extents were separately screened.','timing_scope':'Ten-case, 24-balanced-block exploratory fixture screens, both orders, unchanged peers/protocol and fresh pinned host support. No builds or diagnostic profilers overlap timing. Preparation build observations excluded from primary compile-time comparisons.','static_native_mnemonics':assembly,'screens':screens,'archive':{'path':archive.name,'sha256':digest(archive),'files':len(files),'bytes':archive.stat().st_size}}
(p/'masked-equality-studies-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary['archive']),flush=True)
