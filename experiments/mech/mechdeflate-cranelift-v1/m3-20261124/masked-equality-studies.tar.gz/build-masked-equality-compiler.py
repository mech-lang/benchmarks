from pathlib import Path
import json,os,subprocess
r=Path(__file__).resolve().parent;mech=Path('/Users/cim310/.codex/worktrees/level12-compile-profile/mech');recipe=json.loads(Path('/private/tmp/mech-m3-deflate-81-benchmarks/experiments/mech/mechdeflate-81-v1/recipe.json').read_text())['compiler']
env=os.environ.copy();env.update(recipe['cargo_environment']);env['CARGO_TARGET_DIR']='/private/tmp/mech-m3-81-20261124/target'
def run(command,name):
 print('START',name,flush=True)
 with (r/(name+'.log')).open('w') as log:subprocess.run(command,cwd=mech,env=env,stdout=log,stderr=log,check=True)
 print('PASS',name,flush=True)
files=['hosts/gpu/src/native_artifact/codegen/compilation_inputs.rs','hosts/gpu/src/native_artifact/program/codegen/masked_equality_tests.rs','vendor/cranelift-codegen/src/isa/aarch64_compilation_options.rs','vendor/cranelift-codegen/src/isa/aarch64/lower/isle/mod.rs','vendor/cranelift-codegen/src/isa/aarch64/lower/isle/masked_equality.rs']
run(['rustfmt','+'+recipe['toolchain'],'--edition=2024','--config','skip_children=true',*files],'masked-equality-format')
run(['cargo','+'+recipe['toolchain'],'test','--locked','--manifest-path','/private/tmp/mech-m3-current-compiler-tests/Cargo.toml','--release','--config','profile.release.package.libmimalloc-sys.opt-level=1','--features','jit,canonical-native-program','--test','masked_equality_checks','--test','captured_comparison_inputs'],'masked-equality-focused-tests')
run(['cargo','+'+recipe['toolchain'],'build','--manifest-path',str(r/'clean-build-updated-ccmp/compiler-driver/Cargo.toml'),*recipe['cargo_options']],'masked-equality-compiler-build')
