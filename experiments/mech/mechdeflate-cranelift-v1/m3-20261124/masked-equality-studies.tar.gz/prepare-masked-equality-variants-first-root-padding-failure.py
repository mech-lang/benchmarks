from pathlib import Path
from hashlib import sha256
import json,shutil,subprocess
r=Path(__file__).resolve().parent;b=Path('/private/tmp/mech-m3-deflate-81-benchmarks/experiments/mech/mechdeflate-cranelift-v1');mech=Path('/Users/cim310/.codex/worktrees/level12-compile-profile/mech');symbol='mech_compact_numeric_475_vector'
o=r/'source-experiments/masked-equality';o.mkdir()
compiler=Path('/private/tmp/mech-m3-81-20261124/target/release/compile_profile');shutil.copyfile(compiler,o/'compile_profile')
patch=subprocess.check_output(['git','diff'],cwd=mech,text=True);paths=subprocess.check_output(['git','diff','--name-only'],cwd=mech,text=True).splitlines();untracked=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=mech,text=True).splitlines()
for path in untracked:
 p=subprocess.run(['git','diff','--no-index','--','/dev/null',path],cwd=mech,text=True,stdout=subprocess.PIPE);assert p.returncode in (0,1);patch+=p.stdout
(o/'source.patch').write_text(patch)
for path in paths+untracked:
 p=o/path;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(mech/path,p)
(o/'source-receipt.json').write_text(json.dumps({'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=mech,text=True).strip(),'compiler_sha256':sha256(compiler.read_bytes()).hexdigest(),'source_patch':'source.patch','source_patch_sha256':sha256(patch.encode()).hexdigest(),'scope':'Opt-in generic AArch64 Eq/Ne lowering for identically masked I32/I64 words. At least one mask must have a unique use. Pure preflight; EOR plus atomic TST/consumer lowering. Full shared observers and other integer conditions retain semantics. No compressor source changes.'},indent=2)+'\n')
def run(*args):
 print('COMMAND',*map(str,args),flush=True);subprocess.run(list(map(str,args)),check=True)
def build(name,settings,capture=False):
 settings=settings.copy()
 if capture:
  c=r/('capture-'+name);c.mkdir();settings['MECH_INSPECT_PHASE_REGISTER_PROFILE']=str(c/(symbol+'.vcode'));settings['MECH_INSPECT_OPTIMIZED_PHASE_CLIF']=str(c/(symbol+'.clif'))
 p=r/'settings'/(name+'.json');p.write_text(json.dumps(settings,indent=2)+'\n');run('python3','-B',r/'build-variant.py',name,'--settings',p,'--support-build',r/'clean-build-paired-appends')
def smoke(name):
 v=r/'variants'/name;run('python3','-B','/private/tmp/mech-m3-81-20261124/smoke.py',v/'bound/mech-worker',v/'bound/metadata.json',o/(name+'-smoke.json'))
def phases(value):
 if isinstance(value,dict):
  if value.get('symbol')==symbol:yield value
  for child in value.values():yield from phases(child)
 elif isinstance(value,list):
  for child in value:yield from phases(child)
build('masked-equality-default-parity',{})
expected={'program.o':'e4325602c6a5a4507ba637eee5d34ada9bda77bbb334fefb8ff53324d720e214','metadata.json':'c2448f4197863733301810dca0e8d721d1932afa32b5172e933843b07e2464ef','program.mecb':'c6529d934f020f07f8e59f13fab40927e066649e202269818ad3f009a942a8c3'}
actual=json.loads((r/'variants/masked-equality-default-parity/receipt.json').read_text())['artifacts'];assert actual==expected,(actual,expected)
(o/'default-parity.json').write_text(json.dumps(actual,indent=2)+'\n')
base=json.loads((b/'word-mismatch-order/recipe.json').read_text())['roles']['word-mismatch-order']['settings_delta'];candidates=[]
for ccmp in [False,True]:
 family='masked-equality'+('-ccmp' if ccmp else '')
 settings=base|{'MECH_ARM64_MASKED_EQUALITY':'1','MECH_COMPACT_PAIR_REGISTER_SPILLS':'1','MECH_COMPACT_PAIR_ADMITTED_APPEND_STORES':None,'MECH_COMPACT_CCMP_IMMEDIATES':symbol if ccmp else None}
 for key in ['MECH_COMPACT_PHASE_REGISTER_WEIGHTS','MECH_COMPACT_PHASE_BLOCK_LAYOUT']:settings[key]=';'.join(v for v in settings[key].split(';') if not v.startswith(symbol+'@'))
 build(family+'-raw',settings,True)
 reg=r/'rebased-profiles'/(family+'-register.json');run('python3','-B',r/'transfer-register.py','--source',b/'word-mismatch-order/profiles/9240a4ff5e10851112e22ee5fd660e61b954c0f89450dda03003656aad92c426.json','--capture',r/('capture-'+family+'-raw')/(symbol+'.vcode'),'--output',reg)
 settings['MECH_COMPACT_PHASE_REGISTER_WEIGHTS']+=';'+symbol+'@'+str(reg);build(family+'-weighted',settings,True)
 layout=r/'rebased-profiles'/(family+'-layout.json');run('python3','-B',r/'project-layout.py','--control',r/'variants/matcher-base-unlaid','--candidate',r/'variants'/(family+'-weighted'),'--old-capture',r/'capture-matcher-unlaid'/(symbol+'.vcode'),'--new-capture',r/('capture-'+family+'-weighted')/(symbol+'.vcode'),'--profile',b/'word-mismatch-order/profiles/a33a82846096fc7744a09a8712f19db227c800f61470c2db699736a61479266f.json','--mapping',reg.with_suffix('.proof.json'),'--output',layout,'--symbol',symbol)
 s=settings|{'MECH_COMPACT_PHASE_BLOCK_LAYOUT':settings['MECH_COMPACT_PHASE_BLOCK_LAYOUT']+';'+symbol+'@'+str(layout)}
 name=family+'-profiled';build(name,s);smoke(name);candidates.append(name)
 meta=json.loads((r/'variants'/name/'frontend/metadata.json').read_text());phase,=phases(meta);size=phase['code_bytes'];assert size<=5136,size
 if 0<5136-size<128:
  fixed=json.loads(layout.read_text())|{'object_tail':{'code_bytes':size,'reference_code_bytes':5136,'alignment':128}}
  path=r/'rebased-profiles'/(family+'-fixed-extent.json');path.write_text(json.dumps(fixed,indent=2)+'\n')
  s['MECH_COMPACT_PHASE_BLOCK_LAYOUT']=';'.join(symbol+'@'+str(path) if part.startswith(symbol+'@') else part for part in s['MECH_COMPACT_PHASE_BLOCK_LAYOUT'].split(';'))
  name=family+'-fixed-extent';build(name,s);smoke(name);candidates.append(name)
(o/'timing-candidates.json').write_text(json.dumps(candidates,indent=2)+'\n')
print('TIMING_CANDIDATES',json.dumps(candidates),flush=True)
