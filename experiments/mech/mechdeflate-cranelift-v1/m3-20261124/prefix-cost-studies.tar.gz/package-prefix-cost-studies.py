from pathlib import Path
from hashlib import file_digest
import json, tarfile, shutil
r=Path(__file__).resolve().parent
p=Path('/private/tmp/mech-m3-deflate-81-benchmarks/experiments/mech/mechdeflate-cranelift-v1/m3-20261124')
snap=r/'source-experiments/prefix-costs'
for name in ['Cargo.toml','Cargo.lock','carrier_cost_checks.rs','captured_comparison_inputs.rs','literal_pack_checks.rs']:
    out=snap/'focused-harness'/name
    out.parent.mkdir(exist_ok=True)
    shutil.copyfile(Path('/private/tmp/mech-m3-current-compiler-tests')/name,out)
allowed={'.json','.jsonl','.rs','.py','.toml','.lock','.log','.txt','.csv','.c','.stderr','.stdout','.sha256','.patch','.vcode','.clif','.o','.mecb'}
shared={'build-variant.py','screen.py','run-quiet.py','transfer-register.py','project-layout.py','place-edge-copy-v2.py','prepare-literal-pack-tests.py'}
def digest(path):
    with path.open('rb') as f:return file_digest(f,'sha256').hexdigest()
files=[]
for f in sorted(r.rglob('*')):
    if not f.is_file():continue
    rel=f.relative_to(r);a=rel.parts
    selected=(a[0]=='source-experiments' and len(a)>1 and a[1]=='prefix-costs') or (a[0] in ('variants','settings','screens','rebased-profiles') and len(a)>1 and a[1].startswith('prefix-cost')) or a[0].startswith('capture-prefix-cost') or (len(a)==1 and (f.name in shared or f.name.startswith(('build-prefix-cost','prepare-prefix-cost','screen-prefix-cost','prefix-cost-','package-prefix-cost'))))
    if selected and (f.suffix in allowed or f.name in ('mech-worker','silesia-encoder')):files.append(f)
rows=[{'path':str(f.relative_to(r)),'bytes':f.stat().st_size,'sha256':digest(f)} for f in files]
archive=p/'prefix-cost-studies.tar.gz'
assert not archive.exists()
with tarfile.open(archive,'w:gz',compresslevel=6,dereference=True) as tar:
    for f in files:tar.add(f,arcname=str(f.relative_to(r)),recursive=False)
with tarfile.open(archive) as tar:
    members=tar.getmembers();assert len(members)==len(rows)
    for m,row in zip(members,rows):assert m.name==row['path'] and file_digest(tar.extractfile(m),'sha256').hexdigest()==row['sha256']
(p/(archive.name+'.manifest.json')).write_text(json.dumps({'archive_sha256':digest(archive),'files':rows},indent=2)+'\n')
screens=[]
for f in files:
    a=f.relative_to(r).parts
    if len(a)==3 and a[0]=='screens' and f.name=='results.json':
        result=json.loads(f.read_text());orders=[]
        telemetry=json.loads((r/'screens'/(a[1]+'.telemetry.json')).read_text())
        assert telemetry['timing_eligible'] and not telemetry['external_build_overlap']
        for order in result['runs']:
            misses=[{'case':x['case'],'candidate_x_libdeflate':x['paired_x_libdeflate']['mech-experiment']} for x in order['rows'] if x['paired_x_libdeflate']['mech-experiment']>=1]
            orders.append({'order':order['order'],'cases':len(order['rows']),'wins':len(order['rows'])-len(misses),'misses':misses})
        screens.append({'candidate':a[1],'orders':orders})
assert len(screens)==4 and all(any(x['misses'] for x in s['orders']) for s in screens)
receipt=json.loads((r/'variants/prefix-cost-default-parity/receipt.json').read_text())
summary={'selected':False,'reason':'Every prefix-cost candidate misses protected fixture timings. No new full-suite score or compile-time claim.','source_head':'71bb1f90b39ad0bceebf1b5871a375de19683ac8','source_scope':'Compute wrapping two/four-item cost increments independently of the existing previous-cell state, preserving every intermediate packed output. Combined with the tested live-SSA cost proof. Compressor source and canonical bytecode unchanged.','tests':{'focused_test_records':13,'carrier_native_input_cases':2160,'append_modes':18,'default_m1_artifact_triple_parity':True,'each_timed_actor_codec_alias_boundary_checks':162},'native_selection':'VCode inspection confirms one carry-dependent ADD per two/four-item batch. This shorter recurrence did not establish a measured speedup.','profile_scope':'Existing register hints transferred mechanically, with CFG and VCode validation; existing edge-aware layouts projected onto new native blocks. Four variants cover two/four-item batches and the existing conditional-immediate option. No timing-protocol edits.','timing_scope':'Ten-case, 24-balanced-block fixture screens in both orders, unchanged peers and fresh pinned host support. Quiet telemetry is eligible for all four. Preparation times are excluded from primary compile-time claims.','screens':screens,'archive':{'path':archive.name,'sha256':digest(archive),'files':len(files),'bytes':archive.stat().st_size},'compiler_binary':'Compiler hash and source snapshot retained; the large local compiler binary is excluded from this evidence archive.'}
(p/'prefix-cost-studies-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary['archive']),flush=True)
