"""Transfer frequency hints by ordered original-IR identity; keep exact VCode validation."""
import argparse,difflib,hashlib,json,re
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__)
for key in ['source','capture','output']:p.add_argument('--'+key,type=Path,required=True)
a=p.parse_args();old=json.loads(a.source.read_text());new=a.capture.read_text();new=new[new.index('VCode {'):].split(';; REGALLOC_INPUT_END')[0]
def blocks(code):
 parts=re.split(r'(?m)^Block (\d+)\(',code)[1:];out=[]
 for i in range(0,len(parts),2):
  m=re.search(r'original IR block: (\w+)',parts[i+1]);out.append((int(parts[i]),m[1] if m else None))
 return out
before,after=blocks(old['expected_vcode']),blocks(new);matcher=difflib.SequenceMatcher(None,[x for i,x in before],[x for i,x in after],autojunk=False);mapping={}
for run in matcher.get_matching_blocks():
 for n in range(run.size):mapping[after[run.b+n][0]]=before[run.a+n][0]
unique={}
for i,origin in before:
 if origin is not None:unique.setdefault(origin,[]).append(i)
for i,origin in after:
 if i not in mapping and origin is not None and len(unique.get(origin,[]))==1:mapping[i]=unique[origin][0]
assert [i for i,o in after]==list(range(len(after)))
frequencies=[old['block_frequencies'][mapping[i]] if i in mapping else 1 for i,o in after]
profile={'expected_vcode':new,'block_frequencies':frequencies};a.output.write_text(json.dumps(profile,indent=2)+'\n')
proof={'method':__doc__+' These are transferred optimization hints, not newly measured M3 branch counts. Unmatched new blocks receive the conservative default weight 1.','source_profile_sha256':hashlib.sha256(a.source.read_bytes()).hexdigest(),'capture_sha256':hashlib.sha256(a.capture.read_bytes()).hexdigest(),'profile_sha256':hashlib.sha256(a.output.read_bytes()).hexdigest(),'mapping':sorted([[old,new] for new,old in mapping.items()]),'unmatched_new_blocks':[i for i,o in after if i not in mapping],'removed_ir_blocks':sorted(set(x for i,x in before if x)-set(x for i,x in after if x))}
a.output.with_suffix('.proof.json').write_text(json.dumps(proof,indent=2)+'\n');print('Mapped',len(mapping),'of',len(after),'blocks;',len(proof['unmatched_new_blocks']),'default hints')
