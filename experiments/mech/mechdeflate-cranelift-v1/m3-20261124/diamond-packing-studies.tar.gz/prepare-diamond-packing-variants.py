from pathlib import Path
from hashlib import sha256
import json,shutil,subprocess
r=Path(__file__).resolve().parent
b=Path('/private/tmp/mech-m3-deflate-81-benchmarks/experiments/mech/mechdeflate-cranelift-v1')
mech=Path('/Users/cim310/.codex/worktrees/level12-compile-profile/mech')
o=r/'source-experiments/diamond-packing';o.mkdir(exist_ok=True)
compiler=Path('/private/tmp/mech-m3-81-20261124/target/release/compile_profile');shutil.copyfile(compiler,o/'compile_profile')
patch=subprocess.check_output(['git','diff'],cwd=mech,text=True)
paths=subprocess.check_output(['git','diff','--name-only'],cwd=mech,text=True).splitlines()
untracked=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=mech,text=True).splitlines()
for path in untracked:
 p=subprocess.run(['git','diff','--no-index','--','/dev/null',path],cwd=mech,text=True,stdout=subprocess.PIPE);assert p.returncode in (0,1);patch+=p.stdout
(o/'source.patch').write_text(patch)
for path in paths+untracked:
 p=o/path;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(mech/path,p)
(o/'source-receipt.json').write_text(json.dumps({'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=mech,text=True).strip(),'compiler_sha256':sha256(compiler.read_bytes()).hexdigest(),'source_patch_sha256':sha256(patch.encode()).hexdigest(),'focused_test_records':9,'native_differential_calls':143360,'scope':'Post-egraph exact scalar expression sharing across a bounded diamond. Hoist only nontrapping I32/I64 operations with available operands. No load, store, ownership or guard motion. Explicit captured ISA setting; source and language unchanged.'},indent=2)+'\n')
def run(*args):
 print('COMMAND',*map(str,args),flush=True);subprocess.run(list(map(str,args)),check=True)
def build(name,settings,capture=None,root=False):
 if (r/'variants'/name/'receipt.json').exists():return
 settings=settings.copy()
 if capture:
  c=r/('capture-'+name);c.mkdir(exist_ok=True)
  settings['MECH_INSPECT_PHASE_REGISTER_PROFILE']=str(c/(capture+'.vcode'))
  settings['MECH_INSPECT_OPTIMIZED_PHASE_CLIF']=str(c/(capture+'.clif'))
 if root:
  c=r/('capture-'+name+'-root');c.mkdir(exist_ok=True);settings['MECH_COMPACT_ROUTE_DUMP']=str(c)
 p=r/'settings'/(name+'.json');p.write_text(json.dumps(settings,indent=2)+'\n')
 run('python3','-B',r/'build-variant.py',name,'--settings',p,'--support-build',r/'clean-build-paired-appends')
def artifacts(name):return json.loads((r/'variants'/name/'receipt.json').read_text())['artifacts']
base=json.loads((b/'word-mismatch-order/recipe.json').read_text())['roles']['word-mismatch-order']['settings_delta']
build('diamond-packing-default-parity',{})
expected={'program.o':'e4325602c6a5a4507ba637eee5d34ada9bda77bbb334fefb8ff53324d720e214','metadata.json':'c2448f4197863733301810dca0e8d721d1932afa32b5172e933843b07e2464ef','program.mecb':'c6529d934f020f07f8e59f13fab40927e066649e202269818ad3f009a942a8c3'}
assert artifacts('diamond-packing-default-parity')==expected
(o/'default-parity.json').write_text(json.dumps(expected,indent=2)+'\n')
matcher='mech_compact_numeric_475_vector';scorer='mech_compact_numeric_3009_no_growth_composed'
original={symbol:{'reg':b/('word-mismatch-order/profiles/'+reg+'.json'),'layout':b/('word-mismatch-order/profiles/'+layout+'.json'),'control':r/'variants'/control,'capture':r/capture/(symbol+'.vcode')} for symbol,reg,layout,control,capture in [(matcher,'9240a4ff5e10851112e22ee5fd660e61b954c0f89450dda03003656aad92c426','a33a82846096fc7744a09a8712f19db227c800f61470c2db699736a61479266f','matcher-base-unlaid','capture-matcher-unlaid'),(scorer,'c1acb158a41536816386146f55e5be5e2ea9e8607c1dc78df41f900e40671bcd','069b98a9e53752e75cbe56873ef6e370b7a280bb773aac195536b37d39dab6b7','scorer-base-unlaid','capture-scorer-unlaid')]}
candidates=[]
for ccmp in [False,True]:
 family='diamond-packing'+('-ccmp' if ccmp else '')
 s=base|{'MECH_ARM64_SHARE_DIAMOND_PACKING':'1','MECH_COMPACT_PAIR_REGISTER_SPILLS':'1','MECH_COMPACT_ROOT_TAIL_PROFILE':None,'MECH_COMPACT_CCMP_IMMEDIATES':matcher if ccmp else None,'MECH_COMPACT_PHASE_REGISTER_WEIGHTS':None,'MECH_COMPACT_PHASE_BLOCK_LAYOUT':None}
 build(family+'-raw-matcher',s,matcher)
 build(family+'-raw-scorer',s,scorer)
 assert artifacts(family+'-raw-matcher')==artifacts(family+'-raw-scorer')
 registers={}
 for symbol in [matcher,scorer]:
  reg=r/'rebased-profiles'/(family+'-'+('matcher' if symbol==matcher else 'scorer')+'-register.json')
  capture=r/('capture-'+family+('-raw-matcher' if symbol==matcher else '-raw-scorer'))/(symbol+'.vcode')
  run('python3','-B',r/'transfer-register.py','--source',original[symbol]['reg'],'--capture',capture,'--output',reg)
  registers[symbol]=reg
 s['MECH_COMPACT_PHASE_REGISTER_WEIGHTS']=';'.join(symbol+'@'+str(reg) for symbol,reg in registers.items())
 build(family+'-weighted',s,matcher)
 build(family+'-weighted-scorer',s,scorer)
 assert artifacts(family+'-weighted')==artifacts(family+'-weighted-scorer')
 layouts={}
 for symbol in [matcher,scorer]:
  layout=r/'rebased-profiles'/(family+'-'+('matcher' if symbol==matcher else 'scorer')+'-layout.json')
  old=original[symbol]
  capture=r/('capture-'+family+('-weighted' if symbol==matcher else '-weighted-scorer'))/(symbol+'.vcode')
  run('python3','-B',r/'project-layout.py','--control',old['control'],'--candidate',r/'variants'/(family+'-weighted'),'--old-capture',old['capture'],'--new-capture',capture,'--profile',old['layout'],'--mapping',registers[symbol].with_suffix('.proof.json'),'--output',layout,'--symbol',symbol)
  layouts[symbol]=layout
 s['MECH_COMPACT_PHASE_BLOCK_LAYOUT']=';'.join(symbol+'@'+str(layout) for symbol,layout in layouts.items())
 name=family+'-profiled';build(name,s)
 v=r/'variants'/name
 run('python3','-B','/private/tmp/mech-m3-81-20261124/smoke.py',v/'bound/mech-worker',v/'bound/metadata.json',o/(name+'-smoke.json'))
 candidates.append(name)
(o/'timing-candidates.json').write_text(json.dumps(candidates,indent=2)+'\n')
