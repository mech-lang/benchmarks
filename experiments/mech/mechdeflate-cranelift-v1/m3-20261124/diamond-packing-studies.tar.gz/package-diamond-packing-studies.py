from pathlib import Path
from hashlib import file_digest
import json, tarfile, shutil
r=Path(__file__).resolve().parent
p=Path('/private/tmp/mech-m3-deflate-81-benchmarks/experiments/mech/mechdeflate-cranelift-v1/m3-20261124')
snap=r/'source-experiments/diamond-packing'
for name in ['Cargo.toml','Cargo.lock','diamond_packing_checks.rs','diamond_packing_native.rs','captured_comparison_inputs.rs']:
    out=snap/'focused-harness'/name
    out.parent.mkdir(exist_ok=True)
    shutil.copyfile(Path('/private/tmp/mech-m3-current-compiler-tests')/name,out)
allowed={'.json','.jsonl','.rs','.py','.toml','.lock','.log','.txt','.csv','.c','.stderr','.stdout','.sha256','.patch','.vcode','.clif','.o','.mecb'}
shared={'build-variant.py','screen.py','run-quiet.py','transfer-register.py','project-layout.py','place-edge-copy-v2.py','prepare-literal-pack-tests.py'}
def digest(path):
    with path.open('rb') as f:return file_digest(f,'sha256').hexdigest()
files=[]
for f in sorted(r.rglob('*')):
    if not f.is_file():continue
    rel=f.relative_to(r);a=rel.parts
    selected=(a[0]=='source-experiments' and len(a)>1 and a[1] in ('diamond-packing','diamond-store-trees')) or (a[0] in ('variants','settings','screens','rebased-profiles') and len(a)>1 and a[1].startswith(('diamond-packing','diamond-store-trees'))) or a[0].startswith(('capture-diamond-packing','capture-diamond-store-trees','diamond-packing-native-checks','diamond-store-trees-native-checks')) or (len(a)==1 and (f.name in shared or f.name.startswith(('build-diamond-packing','prepare-diamond-packing','screen-diamond-packing','diamond-packing-','build-diamond-store-trees','prepare-diamond-store-trees','screen-diamond-store-trees','diamond-store-trees-','package-diamond-packing'))))
    if selected and (f.suffix in allowed or f.name in ('mech-worker','silesia-encoder')):files.append(f)
rows=[{'path':str(f.relative_to(r)),'bytes':f.stat().st_size,'sha256':digest(f)} for f in files]
archive=p/'diamond-packing-studies.tar.gz'
assert not archive.exists()
with tarfile.open(archive,'w:gz',compresslevel=6,dereference=True) as tar:
    for f in files:tar.add(f,arcname=str(f.relative_to(r)),recursive=False)
with tarfile.open(archive) as tar:
    members=tar.getmembers();assert len(members)==len(rows)
    for m,row in zip(members,rows):assert m.name==row['path'] and file_digest(tar.extractfile(m),'sha256').hexdigest()==row['sha256']
(p/(archive.name+'.manifest.json')).write_text(json.dumps({'archive_sha256':digest(archive),'files':rows},indent=2)+'\n')
screens=[]
for f in files:
    a=f.relative_to(r).parts
    if len(a)==3 and a[0]=='screens' and f.name=='results.json':
        result=json.loads(f.read_text());orders=[]
        telemetry=json.loads((r/'screens'/(a[1]+'.telemetry.json')).read_text())
        assert telemetry['timing_eligible'] and not telemetry['external_build_overlap']
        for order in result['runs']:
            misses=[{'case':x['case'],'candidate_x_libdeflate':x['paired_x_libdeflate']['mech-experiment']} for x in order['rows'] if x['paired_x_libdeflate']['mech-experiment']>=1]
            orders.append({'order':order['order'],'cases':len(order['rows']),'wins':len(order['rows'])-len(misses),'misses':misses})
        screens.append({'candidate':a[1],'orders':orders})
assert len(screens)==4 and all(any(x['misses'] for x in s['orders']) for s in screens)
receipt=json.loads((r/'variants/diamond-packing-default-parity/receipt.json').read_text())
versions={}
for name in ['diamond-packing','diamond-store-trees']:
    version=r/'source-experiments'/name
    versions[name]={'source':json.loads((version/'source-receipt.json').read_text()),'default_artifacts':json.loads((version/'default-parity.json').read_text()),'static_root_census':json.loads((version/'actual-root-census.json').read_text())}
summary={'selected':False,'reason':'All four timed diamond-sharing variants miss protected fixture comparisons. No new complete score or compile-time claim.','source_head':'71bb1f90b39ad0bceebf1b5871a375de19683ac8','source_scope':'Share exact nontrapping I32/I64 packing expressions across a small conditional-store diamond after egraph elaboration. Operands must be available before the branch; memory operations, guards and ownership actions stay in place. V2 restricts sharing to a complete tree written by the conditional store. Compressor source and bytecode unchanged.','tests':{'focused_records_per_version':9,'native_differential_calls_per_version':143360,'default_m1_artifact_triple_parity':True,'each_timed_actor_codec_alias_boundary_checks':162},'native_selection':'Both versions eliminate duplicated packing in the actual compressor. Static inspection also finds increased spill traffic; reduced arithmetic instruction counts do not establish a speedup. Full static counts are retained for both actual native roots.','profile_scope':'Existing matcher/scorer frequency hints transferred by original IR identity with exact VCode validation. Existing layouts projected onto the new allocated code. No workload, peer, ordering or timing-rule edits. The old exact root-tail profile is incompatible and disabled.','diagnostic_setup':'The initial root route-dump build changes the native root (48352 versus 47360 ordinary bytes) and failed artifact parity against a plain capture. It is excluded from timing. Plain matcher and scorer captures reproduce each other exactly; only ordinary actors enter the screens. An unused import in the focused harness was fixed before final tests.','timing_scope':'Ten-case, 24-balanced-block screens in both orders. Quiet telemetry is eligible for all four. These are subset screens, not full qualification. Preparation build times are excluded from primary compilation-time claims.','versions':versions,'screens':screens,'archive':{'path':archive.name,'sha256':digest(archive),'files':len(files),'bytes':archive.stat().st_size},'compiler_binary':'Compiler hashes and exact source snapshots are retained; large local compiler binaries are excluded from the archive.'}
(p/'diamond-packing-studies-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary['archive']),flush=True)
