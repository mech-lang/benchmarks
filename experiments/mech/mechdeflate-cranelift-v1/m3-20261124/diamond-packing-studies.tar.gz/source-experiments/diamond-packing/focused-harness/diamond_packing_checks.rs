#![allow(dead_code)]
extern crate alloc;
pub use cranelift_codegen::{Context,cursor,ir,isa,settings,flowgraph,dominator_tree};
#[path="/Users/cim310/.codex/worktrees/level12-compile-profile/mech/vendor/cranelift-codegen/src/diamond_packing.rs"]
mod diamond_packing;

#[path="diamond_packing_native.rs"]
mod native_checks;
