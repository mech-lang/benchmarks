use cranelift_codegen::{Context, ir::{types, AbiParam, InstBuilder}, isa::Aarch64CompilationOptions, settings::{self, Configurable}};
use cranelift_frontend::{FunctionBuilder,FunctionBuilderContext};
use cranelift_jit::{JITBuilder,JITModule};
use cranelift_module::{Linkage,Module,default_libcall_names};
fn body(context: &mut Context, control: u8) {
    context.func.signature.params = vec![AbiParam::new(types::I64); 5];
    context.func.signature.returns = vec![AbiParam::new(types::I64)];
    let mut fb = FunctionBuilderContext::new();
    let mut b = FunctionBuilder::new(&mut context.func, &mut fb);
    let entry = b.create_block();
    let taken = b.create_block();
    let join = b.create_block();
    b.append_block_params_for_function_params(entry);
    b.switch_to_block(entry);
    let [output, item, carry, bits, count] = *b.block_params(entry) else {
        unreachable!()
    };
    b.ins().brif(count, taken, &[], join, &[]);
    b.switch_to_block(taken);
    if control == 2 {
        b.ins()
            .load(types::I64, crate::ir::MemFlags::new(), output, 0);
    }
    let masked = b.ins().band_imm(bits, 63);
    let shifted = b.ins().ishl(item, masked);
    let word = b.ins().bor(carry, shifted);
    b.ins().store(crate::ir::MemFlags::new(), word, output, 0);
    b.ins().jump(join, &[]);
    b.switch_to_block(join);
    let masked = b.ins().band_imm(bits, if control == 1 { 31 } else { 63 });
    let shifted = b.ins().ishl(item, masked);
    let word = b.ins().bor(carry, shifted);
    let result = b.ins().ushr(word, count);
    b.ins().return_(&[result]);
    b.seal_all_blocks();
    b.finalize();
}

#[test]
fn native_packing_preserves_stores_and_full_width_results() {
    for level in ["none", "speed"] {
        let mut functions = Vec::new();
        let mut modules = Vec::new();
        for enabled in [false, true] {
            let mut flags = settings::builder();
            flags.set("opt_level", level).unwrap();
            let options = Aarch64CompilationOptions {
                share_diamond_packing: enabled,
                ..Default::default()
            };
            let isa = cranelift_native::builder()
                .unwrap()
                .finish_with_aarch64_compilation_options(settings::Flags::new(flags), options)
                .unwrap();
            let mut module = JITModule::new(JITBuilder::with_isa(isa, default_libcall_names()));
            let mut context = module.make_context();
            body(&mut context, 0);
            context.set_disasm(true);
            let id = module
                .declare_function("packing", Linkage::Export, &context.func.signature)
                .unwrap();
            module.define_function(id, &mut context).unwrap();
            if let Ok(directory) = std::env::var("DIAMOND_PACKING_EVIDENCE") {
                std::fs::write(
                    std::path::Path::new(&directory).join(format!("{level}-{enabled}.vcode")),
                    context
                        .compiled_code()
                        .unwrap()
                        .vcode
                        .as_deref()
                        .unwrap_or(""),
                )
                .unwrap();
                std::fs::write(
                    std::path::Path::new(&directory).join(format!("{level}-{enabled}.clif")),
                    context.func.display().to_string(),
                )
                .unwrap();
            }
            module.finalize_definitions().unwrap();
            let function = unsafe {
                std::mem::transmute::<_, extern "C" fn(*mut u64, u64, u64, u64, u64) -> u64>(
                    module.get_finalized_function(id),
                )
            };
            functions.push(function);
            modules.push(module);
        }
        let mut state = 0x9e37_79b9_7f4a_7c15_u64;
        for index in 0..512 {
            state ^= state << 13;
            state ^= state >> 7;
            state ^= state << 17;
            let item = match index {
                0 => 0,
                1 => u64::MAX,
                _ => state,
            };
            let carry = item.rotate_left(29) ^ 0xa5a5_5a5a_ffff_0000;
            for bits in [0, 1, 7, 8, 31, 32, 63, 64, 65, 127] {
                let word = carry | item.wrapping_shl(bits as u32);
                for count in [0, 1, 8, 9, 32, 64, 255] {
                    for function in &functions {
                        let mut output = [0x1234_5678_9abc_def0; 3];
                        assert_eq!(
                            function(
                                unsafe { output.as_mut_ptr().add(1) },
                                item,
                                carry,
                                bits,
                                count
                            ),
                            word.wrapping_shr(count as u32)
                        );
                        assert_eq!(output[0], 0x1234_5678_9abc_def0);
                        assert_eq!(output[2], 0x1234_5678_9abc_def0);
                        assert_eq!(
                            output[1],
                            if count == 0 {
                                0x1234_5678_9abc_def0
                            } else {
                                word
                            }
                        );
                    }
                }
            }
        }
    }
}
