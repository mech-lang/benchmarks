#![allow(dead_code)]
mod native_artifact {
    mod identity {
        // Same leaf helper as native_artifact/identity/mod.rs.
        pub(in crate::native_artifact) fn hex(bytes: &[u8]) -> String {
            bytes.iter().map(|byte| format!("{byte:02x}")).collect()
        }
    }
    pub mod codegen {
        #[path="/Users/cim310/.codex/worktrees/level12-compile-profile/mech/hosts/gpu/src/native_artifact/codegen/compilation_inputs.rs"]
        pub mod compilation_inputs;
    }
    #[path="/Users/cim310/.codex/worktrees/level12-compile-profile/mech/hosts/gpu/src/native_artifact/program/compact/phase_layout.rs"]
    pub mod phase_layout;
}
