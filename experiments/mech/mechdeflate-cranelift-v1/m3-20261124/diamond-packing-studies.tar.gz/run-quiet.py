"""Run a measurement after build tools stop; flag any overlapping external build."""
import argparse
import datetime
import json
from pathlib import Path
import subprocess
import sys
import time

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--record', type=Path, required=True)
parser.add_argument('--log', type=Path, required=True)
parser.add_argument('command', nargs=argparse.REMAINDER)
args = parser.parse_args()
assert args.command
if args.command[0] == '--':
    args.command.pop(0)
assert not args.record.exists()
names = {'cargo', 'rustc', 'clang', 'clang++', 'ld', 'sample', 'xctrace'}

def now():
    return datetime.datetime.now(datetime.UTC).isoformat()

def active(owned=None):
    table = []
    for line in subprocess.check_output(['ps', '-axo', 'pid,ppid,comm'], text=True).splitlines()[1:]:
        fields = line.strip().split(None, 2)
        if len(fields) == 3:
            table.append((int(fields[0]), int(fields[1]), fields[2]))
    descendants = {owned} if owned else set()
    while True:
        before = len(descendants)
        descendants.update(pid for pid, parent, _ in table if parent in descendants)
        if len(descendants) == before:
            break
    return [{'pid': pid, 'command': command} for pid, parent, command in table
            if pid not in descendants and Path(command).name in names]

observations = []
stable = None
while True:
    builds = active()
    observations.append({'utc': now(), 'phase': 'waiting', 'external_builds': builds})
    if builds:
        stable = None
    elif stable is None:
        stable = time.monotonic()
    elif time.monotonic() - stable >= 10:
        break
    time.sleep(2)
started = now()
with args.log.open('w') as stream:
    child = subprocess.Popen(args.command, stdout=stream, stderr=stream)
    while child.poll() is None:
        observations.append({'utc': now(), 'phase': 'running', 'external_builds': active(child.pid)})
        time.sleep(1)
status = child.wait()
overlaps = [row for row in observations if row['phase'] == 'running' and row['external_builds']]
record = {'command': args.command, 'started_utc': started, 'completed_utc': now(),
          'exit_code': status, 'external_build_overlap': bool(overlaps),
          'timing_eligible': not overlaps and status == 0, 'observations': observations}
args.record.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({key: value for key, value in record.items() if key != 'observations'}), flush=True)
sys.exit(status if status else 3 if overlaps else 0)
