"""Project existing layout hints through original IR block identities; emission validates the permutation."""
import argparse,bisect,hashlib,json,re
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__)
for name in ['control','candidate','old-capture','new-capture','profile','mapping','output']:p.add_argument('--'+name,type=Path,required=True)
p.add_argument('--symbol',default='mech_compact_numeric_475_vector')
a=p.parse_args()
prior=Path('/private/tmp/mech-m3-81-20261124/rebase-spill-layout.py')
ns={'__file__':str(prior)};exec(compile(prior.read_text().split('parser=argparse.ArgumentParser')[0],str(prior),'exec'),ns)
ns['SYMBOL']=a.symbol
old,new=ns['shape'](a.control),ns['shape'](a.candidate)
profile=json.loads(a.profile.read_text());assert sorted(profile['order'])==old['heads']
rank={at:i for i,at in enumerate(profile['order'])}
old_of_new={new:old for old,new in json.loads(a.mapping.read_text())['mapping']}
def offsets(path):
 return {int(i):int(at) for i,at in re.findall(r'^;; REGALLOC_BLOCK (\d+) offset=(\d+)',path.read_text(),re.M)}
oldoffset,new_offset=offsets(a.old_capture),offsets(a.new_capture)
assert all(i in new_offset for i in old_of_new)
byhead={}
for block,at in new_offset.items():
 if at not in new['heads'] or block not in old_of_new:continue
 oldat=oldoffset[old_of_new[block]]
 i=bisect.bisect_right(old['heads'],oldat)-1
 if i>=0:byhead.setdefault(at,[]).append(rank[old['heads'][i]])
order=sorted(new['heads'],key=lambda at:(at!=0,min(byhead.get(at,[len(rank)+at])),at))
out={'order':order,'literal_offset':new['pool'],'thread_jumps':True}
a.output.write_text(json.dumps(out,indent=2)+'\n')
receipt={'method':__doc__,'control':old,'candidate':new,'rank_candidates':byhead,'unmapped_heads':[at for at in order if at not in byhead],'inputs':{key:{'path':str(path),'sha256':hashlib.sha256((path if path.is_file() else path/'frontend/program.o').read_bytes()).hexdigest()} for key,path in vars(a).items() if key not in ['output','symbol']},'profile_sha256':hashlib.sha256(a.output.read_bytes()).hexdigest()}
a.output.with_suffix('.mapping.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('Projected layout',len(old['heads']),'to',len(new['heads']),'blocks; pool',new['pool'],'unmapped',receipt['unmapped_heads'])
