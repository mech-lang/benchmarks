from pathlib import Path
import hashlib,json
mech=Path('/Users/cim310/.codex/worktrees/level12-compile-profile/mech');root=mech/'hosts/gpu/src/native_artifact/program/codegen';d=Path('/private/tmp/mech-m3-current-compiler-tests');out=d/'literal-pack-source';out.mkdir(exist_ok=True)
parent=(root/'append_run.rs').read_text().split('pub(in crate::native_artifact) fn optimize(',1)[0]
parent=parent.replace('#[path = "append_previous.rs"]\nmod previous;\npub(in crate::native_artifact) use previous::Hint as Previous;\n','')
assert 'mod previous' not in parent and 'NoGrowth' not in parent
for name,path in [('packet_reloads',root/'packet_reloads.rs'),('pairs',root/'append_run_pairs.rs')]:
 old='#[path = "'+('append_run_pairs.rs' if name=='pairs' else 'packet_reloads.rs')+'"]';assert old in parent;parent=parent.replace(old,'#[path = '+json.dumps(str(path))+']')
trace=(root/'append_run_trace.rs').read_text().split('#[cfg(test)]\nmod tests {',1)[0];(out/'trace.rs').write_text(trace)
parent=parent.replace('#[path = "append_run_trace.rs"]','#[path = '+json.dumps(str(out/'trace.rs'))+']')
(out/'append_run.rs').write_text(parent)
source='''#![allow(dead_code, unused_imports)]
mod native_artifact {
 mod identity { pub(in crate::native_artifact) fn hex(bytes:&[u8])->String { bytes.iter().map(|byte|format!("{byte:02x}")).collect() } }
 pub mod codegen {
  #[path=COMPILATION_INPUTS]
  pub mod compilation_inputs;
 }
 pub mod program { pub mod codegen {
  mod cfg_cleanup {
   #[path=BOOLEAN_CONDITIONS]
   mod boolean_conditions;
   pub(super) use boolean_conditions::masked_integer_comparison;
  }
  #[path=APPEND_RUN]
  mod append_run;
 }}
}
'''
for name,path in [('COMPILATION_INPUTS',mech/'hosts/gpu/src/native_artifact/codegen/compilation_inputs.rs'),('BOOLEAN_CONDITIONS',root/'cfg_cleanup/boolean_conditions/mod.rs'),('APPEND_RUN',out/'append_run.rs')]:source=source.replace(name,json.dumps(str(path)))
boolean_path=root/'cfg_cleanup/boolean_conditions/mod.rs'
boolean_source=boolean_path.read_text().split('#[cfg(test)]',1)[0]
(out/'boolean_conditions.rs').write_text(boolean_source)
source=source.replace(json.dumps(str(boolean_path)),json.dumps(str(out/'boolean_conditions.rs')))
(d/'literal_pack_checks.rs').write_text(source)
p=d/'Cargo.toml';s=p.read_text()
if 'name="literal_pack_checks"' not in s:s+='\n[[test]]\nname="literal_pack_checks"\npath="literal_pack_checks.rs"\n';p.write_text(s)
(out/'extraction.json').write_text(json.dumps({'scope':'Existing paired-append recognition and native differential tests use the exact emitter/trace source. The unrelated NoGrowth driver and previous-value helper are omitted from this temporary consumer; production admission is verified separately by the full encoder and resource gates.','source_prefix_bytes':len(parent.encode()),'source_sha256':{str(p.relative_to(mech)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [root/'append_run.rs',root/'append_run_trace.rs',root/'append_run_pairs.rs',root/'append_run_pairs_tests.rs']}},indent=2)+'\n')
