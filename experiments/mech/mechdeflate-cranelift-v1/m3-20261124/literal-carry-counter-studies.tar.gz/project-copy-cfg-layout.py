"""Transfer layout hints through matching ordered CFGs, contracting only copy blocks for comparison."""
from pathlib import Path
from hashlib import sha256
import argparse,json,re,subprocess
p=argparse.ArgumentParser(description=__doc__)
for key in ['control','candidate','profile','output']:p.add_argument('--'+key,type=Path,required=True)
a=p.parse_args();prior=Path('/private/tmp/mech-m3-81-20261124/rebase-spill-layout.py');ns={'__file__':str(prior)};exec(compile(prior.read_text().split('parser=argparse.ArgumentParser')[0],str(prior),'exec'),ns);ns['SYMBOL']='mech_compact_numeric_3009_no_growth_composed'
def graph(folder):
 shape=ns['shape'](folder);heads=shape['heads'];table={};start=None;active=False
 for line in subprocess.check_output(['/usr/bin/otool','-tvV',str(folder/'frontend/program.o')],text=True).splitlines():
  if line.endswith(':'):active=line=='_mech_compact_numeric_3009_no_growth_composed:'
  elif active and (match:=re.match(r'^([0-9a-f]{16})\s+(\S+)',line)):
   pc=int(match[1],16)
   if start is None:start=pc
   table[pc-start]=match[2]
 copies=set()
 for i,((kind,target,fall),end) in enumerate(zip(shape['blocks'],heads[1:]+[shape['code_end']])):
  if i==0 or kind[0] not in ('jump','next'):continue
  body=range(heads[i],end-(4 if kind[0]=='jump' else 0),4)
  if all(table[pc] in {'mov','movk','fmov','uxtw','sxtw','nop'} for pc in body):copies.add(i)
 def successor(i):
  _,target,fall=shape['blocks'][i];return target if target is not None else fall
 # Retain cycles, including a self-loop. Matching never erases executable nodes.
 for i in list(copies):
  seen=[];node=i
  while node in copies:
   if node in seen:
    copies.difference_update(seen[seen.index(node):]);break
   seen.append(node);node=successor(node)
 def resolve(i):
  if i is None:return None
  seen=set()
  while i in copies:
   assert i not in seen;seen.add(i);i=successor(i)
  return i
 kept=[i for i in range(len(heads)) if i not in copies];ids={i:n for n,i in enumerate(kept)}
 reduced=[]
 for i in kept:
  kind,target,fall=shape['blocks'][i];reduced.append((kind[0],None if target is None else ids[resolve(target)],None if fall is None else ids[resolve(fall)]))
 return shape,copies,kept,reduced,resolve
old,oldcopies,oldkept,oldq,_=graph(a.control);new,newcopies,newkept,newq,resolve=graph(a.candidate)
proof={'method':__doc__+' Copy contraction is for matching only. Every new machine block remains in the permutation, and the backend validates and rewrites all branches.','control':old,'candidate':new,'old_copy_blocks':sorted(oldcopies),'new_copy_blocks':sorted(newcopies),'ordered_reduced_graphs_match':oldq==newq,'old_reduced_graph':oldq,'new_reduced_graph':newq}
a.output.with_suffix('.proof.json').write_text(json.dumps(proof,indent=2)+'\n')
assert oldq==newq, 'Reduced ordered CFGs differ; do not transfer this layout'
profile=json.loads(a.profile.read_text());assert sorted(profile['order'])==old['heads'];rank={at:i for i,at in enumerate(profile['order'])};rank_new={new_id:rank[old['heads'][old_id]] for old_id,new_id in zip(oldkept,newkept)}
preds={i:[] for i in range(len(new['heads']))}
for i,(kind,target,fall) in enumerate(new['blocks']):
 for dest in [target,fall]:
  if dest is not None:preds[dest].append(i)
def place(i):
 if i in rank_new:return float(rank_new[i])
 target=resolve(i);seen=set();node=i
 while node in newcopies and len(preds[node])==1:
  source=preds[node][0]
  if source in seen:break
  seen.add(source)
  kind,taken,fall=new['blocks'][source]
  if source in rank_new and kind[0] in ('jump','next'):
   return rank_new[source]+0.25+(new['heads'][i]-new['heads'][source])*1e-7
  node=source
 return rank_new[target]-0.25+new['heads'][i]*1e-7
order=sorted(range(len(new['heads'])),key=lambda i:(i!=0,place(i),i));out={'order':[new['heads'][i] for i in order],'literal_offset':new['pool'],'thread_jumps':True};assert sorted(out['order'])==new['heads'];a.output.write_text(json.dumps(out,indent=2)+'\n');proof['profile_sha256']=sha256(a.output.read_bytes()).hexdigest();proof['new_block_rank_hints']=[place(i) for i in range(len(new['heads']))];a.output.with_suffix('.proof.json').write_text(json.dumps(proof,indent=2)+'\n');print('Matched',len(old['heads']),'to',len(new['heads']),'through',len(oldq),'retained graph nodes')
