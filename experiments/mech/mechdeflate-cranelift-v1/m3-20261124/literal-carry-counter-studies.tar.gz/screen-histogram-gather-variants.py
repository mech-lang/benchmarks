from pathlib import Path
import subprocess
r=Path(__file__).resolve().parent
cases=['empty','one-stored','16384-distribution-change','prefix-natural-1024','reymont-prefix-1024','prefix-natural-65536','prefix-random-4096','prefix-random-1048576','heldout-random-65537','prefix-repeated-16384']
for name in ['histogram-gather2','histogram-gather4','histogram-gather2-ccmp-fixed','histogram-gather4-ccmp-fixed']:
 out=r/'screens'/(name+'-fixtures')
 subprocess.run(['python3','-B',str(r/'run-quiet.py'),'--record',str(out)+'.telemetry.json','--log',str(out)+'.log','--','python3','-B',str(r/'screen.py'),'--candidate',str(r/'variants'/name),'--control',str(r/'clean-build-paired-appends/word-mismatch-order'),'--output',str(out),'--suite','fixtures','--cases',*cases],check=True)
