from pathlib import Path
import json,subprocess
r=Path(__file__).resolve().parent;symbol='mech_compact_numeric_3009_no_growth_composed'
for family in ['separate-cost','separate-cost-tag']:
 layout=r/'rebased-profiles'/(family+'-edge-layout-v2.json')
 subprocess.run(['python3','-B',str(r/'place-edge-copy-blocks-v2.py'),'--candidate',str(r/'variants'/(family+'-weighted')),'--profile',str(r/'rebased-profiles'/(family+'-layout.json')),'--output',str(layout)],check=True)
 for old in [family+'-profiled',family+'-ccmp-fixed']:
  name=old+'-edges-v2';s=json.loads((r/'settings'/(old+'.json')).read_text());s['MECH_COMPACT_PHASE_BLOCK_LAYOUT']=';'.join(symbol+'@'+str(layout) if part.startswith(symbol+'@') else part for part in s['MECH_COMPACT_PHASE_BLOCK_LAYOUT'].split(';'));p=r/'settings'/(name+'.json');p.write_text(json.dumps(s,indent=2)+'\n')
  subprocess.run(['python3','-B',str(r/'build-variant.py'),name,'--settings',str(p),'--support-build',str(r/'clean-build-paired-appends')],check=True)
  v=r/'variants'/name;subprocess.run(['python3','-B','/private/tmp/mech-m3-81-20261124/smoke.py',str(v/'bound/mech-worker'),str(v/'bound/metadata.json'),str(r/'source-experiments/separate-cost-carry'/(name+'-smoke.json'))],check=True)
