"""Place register-copy blocks beside their current CFG edge, retaining all executable blocks."""
import argparse,json,re,subprocess
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__)
for key in ['candidate','profile','output']:p.add_argument('--'+key,type=Path,required=True)
a=p.parse_args();prior=Path('/private/tmp/mech-m3-81-20261124/rebase-spill-layout.py');ns={'__file__':str(prior)};exec(compile(prior.read_text().split('parser=argparse.ArgumentParser')[0],str(prior),'exec'),ns);ns['SYMBOL']='mech_compact_numeric_3009_no_growth_composed';g=ns['shape'](a.candidate);heads=g['heads'];blocks=g['blocks'];table={};start=None;active=False
for line in subprocess.check_output(['/usr/bin/otool','-tvV',str(a.candidate/'frontend/program.o')],text=True).splitlines():
 if line.endswith(':'):active=line=='_mech_compact_numeric_3009_no_growth_composed:'
 elif active and (m:=re.match(r'^([0-9a-f]{16})\s+(\S+)\s*(.*)',line)):
  pc=int(m[1],16)
  if start is None:start=pc
  table[pc-start]=(m[2],m[3])
copies=set();preds={i:[] for i in range(len(heads))}
for i,((kind,target,fall),end) in enumerate(zip(blocks,heads[1:]+[g['code_end']])):
 for dest in [target,fall]:
  if dest is not None:preds[dest].append(i)
 body=list(range(heads[i],end-(4 if kind[0]=='jump' else 0),4))
 if i and body and kind[0] in ('jump','next') and all(table[pc][0] in {'mov','fmov','mov.16b','uxtw','sxtw','nop'} and '#' not in table[pc][1] for pc in body):copies.add(i)
profile=json.loads(a.profile.read_text());assert sorted(profile['order'])==heads;rank={heads.index(at):i for i,at in enumerate(profile['order'])};changes={}
def successor(i):
 _,target,fall=blocks[i];return target if target is not None else fall
pure={i:target for i,((kind,target,_),end) in enumerate(zip(blocks,heads[1:]+[g['code_end']])) if i and kind[0]=='jump' and end==heads[i]+4}
def target(i):
 seen=set()
 while i in pure or i in copies:
  if i in seen:return None
  seen.add(i);i=successor(i)
 return i
for i in copies:
 if len(preds[i])!=1:continue
 parent=preds[i][0];kind,taken,fall=blocks[parent];dest=target(i)
 if dest is None or parent in copies:continue
 other=[d for d in [taken,fall] if d is not None and d!=i]
 backward=any((t:=target(d)) is not None and heads[t]<=heads[parent] for d in other)
 if kind[0] in ('jump','next') or backward:changes[i]=rank[parent]+0.25
 elif dest!=0:changes[i]=rank[dest]-0.25
order=sorted(range(len(heads)),key=lambda i:(i!=0,changes.get(i,rank[i]),i));result=profile|{'order':[heads[i] for i in order]};a.output.write_text(json.dumps(result,indent=2)+'\n');a.output.with_suffix('.proof.json').write_text(json.dumps({'method':__doc__+' These are placement hints, not measured frequencies. Constant/error-code blocks and shared copy blocks retain their old positions. No machine block is omitted. Backend permutation/branch validation remains enabled.','shape':g,'register_copy_blocks':[heads[i] for i in sorted(copies)],'changed_rank_hints':{heads[i]:rank for i,rank in changes.items()},'old_order':profile['order'],'new_order':result['order']},indent=2)+'\n');print('Adjusted',len(changes),'register-copy block placements')
