//! Overlap counter reads inside a fully admitted, disjoint histogram chunk.
use cranelift_codegen::cursor::FuncCursor;
use cranelift_codegen::ir::{InstBuilder, MemFlags, Value, condcodes::IntCC, types};

pub(super) fn batch(c: &mut FuncCursor<'_>, bins: Value, keys: &[Value], width: usize) {
    assert!(matches!(width, 2 | 4));
    let flags = MemFlags::new().with_notrap();
    for keys in keys.chunks(width) {
        let counters = keys
            .iter()
            .map(|&key| {
                let offset = c.ins().ishl_imm(key, 2);
                let address = c.ins().iadd(bins, offset);
                let count = c.ins().load(types::I32, flags, address, 0);
                (address, count)
            })
            .collect::<Vec<_>>();
        for (at, &(address, count)) in counters.iter().enumerate() {
            let mut updated = c.ins().iadd_imm(count, 1);
            // Every read preceded this batch's stores. Equal keys therefore
            // need exactly one extra wrapping increment per earlier visit.
            // Stores retain source order, including when every key collides.
            for &earlier in &keys[..at] {
                let equal = c.ins().icmp(IntCC::Equal, keys[at], earlier);
                let next = c.ins().iadd_imm(updated, 1);
                updated = c.ins().select(equal, next, updated);
            }
            c.ins().store(flags, updated, address, 0);
        }
    }
}

#[cfg(test)]
#[path = "grouped_histogram_increments_tests.rs"]
mod tests;
