from pathlib import Path
import hashlib,json,shutil,subprocess
r=Path(__file__).resolve().parent;b=Path('/private/tmp/mech-m3-deflate-81-benchmarks/experiments/mech/mechdeflate-cranelift-v1');mech=Path('/Users/cim310/.codex/worktrees/level12-compile-profile/mech');symbol='mech_compact_numeric_3009_no_growth_composed';o=r/'source-experiments/literal-pack-cost-first';o.mkdir()
compiler=Path('/private/tmp/mech-m3-81-20261124/target/release/compile_profile');shutil.copyfile(compiler,o/'compile_profile');(o/'tracked.patch').write_text(subprocess.check_output(['git','diff'],cwd=mech,text=True));(o/'source-receipt.json').write_text(json.dumps({'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=mech,text=True).strip(),'compiler_sha256':hashlib.sha256(compiler.read_bytes()).hexdigest(),'focused_tests':6,'scope':'Three existing native paired-append differential/refusal tests expanded to cover the new cost-first packing mode, plus three captured-input tests. Scalar reference, wrapping costs, ordered failures and alias fallbacks are retained.'},indent=2)+'\n')
for path in subprocess.check_output(['git','diff','--name-only'],cwd=mech,text=True).splitlines():
 dest=o/path;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(mech/path,dest)
def run(*args):print('COMMAND',*map(str,args),flush=True);subprocess.run(list(map(str,args)),check=True)
def build(name,settings,capture=False):
 settings=settings.copy()
 if capture:
  d=r/('capture-'+name);d.mkdir();settings['MECH_INSPECT_PHASE_REGISTER_PROFILE']=str(d/(symbol+'.vcode'));settings['MECH_INSPECT_OPTIMIZED_PHASE_CLIF']=str(d/(symbol+'.clif'))
 path=r/'settings'/(name+'.json');path.write_text(json.dumps(settings,indent=2)+'\n');run('python3','-B',r/'build-variant.py',name,'--settings',path,'--support-build',r/'clean-build-paired-appends')
build('literal-pack-default-parity',{})
assert json.loads((r/'variants/literal-pack-default-parity/receipt.json').read_text())['artifacts']['program.o']=='e4325602c6a5a4507ba637eee5d34ada9bda77bbb334fefb8ff53324d720e214'
s=json.loads((b/'word-mismatch-order/recipe.json').read_text())['roles']['word-mismatch-order']['settings_delta'].copy();s|={'MECH_PAIR_PACK_LITERAL_COST_FIRST':'1','MECH_COMPACT_PAIR_REGISTER_SPILLS':'1','MECH_COMPACT_PAIR_ADMITTED_APPEND_STORES':None,'MECH_COMPACT_CCMP_IMMEDIATES':None}
for key in ['MECH_COMPACT_PHASE_REGISTER_WEIGHTS','MECH_COMPACT_PHASE_BLOCK_LAYOUT']:s[key]=';'.join(v for v in s[key].split(';') if not v.startswith(symbol+'@'))
build('literal-pack-raw',s,True)
capture=r/'capture-literal-pack-raw'/(symbol+'.vcode');text=capture.read_text();new=text.split(';; REGALLOC_INPUT_BEGIN\n',1)[1].split(';; REGALLOC_INPUT_END',1)[0];old=json.loads((b/'word-mismatch-order/profiles/c1acb158a41536816386146f55e5be5e2ea9e8607c1dc78df41f900e40671bcd.json').read_text())['expected_vcode']
if new==old:
 (o/'decision.json').write_text(json.dumps({'status':'rejected before timing','reason':'The exact lowered allocation input is identical to the original scorer. The IR reassociation did not remove work.'},indent=2)+'\n');print('NO LOWERED-CODE CHANGE',flush=True);raise SystemExit(0)
reg=r/'rebased-profiles/literal-pack-register.json';run('python3','-B',r/'transfer-register.py','--source',b/'word-mismatch-order/profiles/c1acb158a41536816386146f55e5be5e2ea9e8607c1dc78df41f900e40671bcd.json','--capture',capture,'--output',reg)
s['MECH_COMPACT_PHASE_REGISTER_WEIGHTS']+=';'+symbol+'@'+str(reg);build('literal-pack-weighted',s,True)
layout=r/'rebased-profiles/literal-pack-layout.json';run('python3','-B',r/'project-layout.py','--control',r/'variants/scorer-base-unlaid','--candidate',r/'variants/literal-pack-weighted','--old-capture',r/'capture-scorer-unlaid'/(symbol+'.vcode'),'--new-capture',r/'capture-literal-pack-weighted'/(symbol+'.vcode'),'--profile',b/'word-mismatch-order/profiles/069b98a9e53752e75cbe56873ef6e370b7a280bb773aac195536b37d39dab6b7.json','--mapping',reg.with_suffix('.proof.json'),'--output',layout,'--symbol',symbol)
s['MECH_COMPACT_PHASE_BLOCK_LAYOUT']+=';'+symbol+'@'+str(layout)
for name,ccmp,fixed in [('literal-pack-profiled',False,False),('literal-pack-ccmp',True,False),('literal-pack-ccmp-fixed',True,True)]:
 settings=s.copy()
 if ccmp:
  settings['MECH_COMPACT_CCMP_IMMEDIATES']='mech_compact_numeric_475_vector'
  settings['MECH_COMPACT_PHASE_REGISTER_WEIGHTS']=';'.join('mech_compact_numeric_475_vector@'+str(r/'rebased-profiles/ccmp-immediates-register.json') if part.startswith('mech_compact_numeric_475_vector@') else part for part in settings['MECH_COMPACT_PHASE_REGISTER_WEIGHTS'].split(';'))
  settings['MECH_COMPACT_PHASE_BLOCK_LAYOUT']=';'.join('mech_compact_numeric_475_vector@'+str(r/('rebased-profiles/ccmp-immediates-fixed-extent.json' if fixed else 'rebased-profiles/ccmp-immediates-layout.json')) if part.startswith('mech_compact_numeric_475_vector@') else part for part in settings['MECH_COMPACT_PHASE_BLOCK_LAYOUT'].split(';'))
 build(name,settings)
 v=r/'variants'/name;run('python3','-B','/private/tmp/mech-m3-81-20261124/smoke.py',v/'bound/mech-worker',v/'bound/metadata.json',o/(name+'-smoke.json'))
