#include <mach/mach.h>
#include <mach/arm/thread_status.h>
#include <pthread.h>
#include <stdatomic.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
typedef struct { uintptr_t pc, lr; } Row;
static Row rows[16384];
static size_t used;
static unsigned failures;
static _Atomic int stopped, active;
static thread_act_t main_thread;
static pthread_t sampler;
static void *anchor;
static int started;
static void *collect(void *unused) {
 (void)unused;
 while(!atomic_load_explicit(&stopped,memory_order_relaxed)) {
  usleep(500);
  if(!atomic_load_explicit(&active,memory_order_relaxed) || used==16384) continue;
  if(thread_suspend(main_thread)!=KERN_SUCCESS){failures++;continue;}
  arm_thread_state64_t state;
  mach_msg_type_number_t n=ARM_THREAD_STATE64_COUNT;
  kern_return_t status=thread_get_state(main_thread,ARM_THREAD_STATE64,(thread_state_t)&state,&n);
  if(status==KERN_SUCCESS){rows[used++]=(Row){(uintptr_t)arm_thread_state64_get_pc(state),(uintptr_t)arm_thread_state64_get_lr(state)};}
  else failures++;
  if(thread_resume(main_thread)!=KERN_SUCCESS) abort();
 }
 return NULL;
}
void mech_profile_start(void *native_anchor) {
 if(started || !getenv("MECH_PC_SAMPLE_OUT")) return;
 anchor=native_anchor;
 main_thread=mach_thread_self();
 if(pthread_create(&sampler,NULL,collect,NULL)) abort();
 started=1;
}
void mech_profile_active(int enabled){atomic_store_explicit(&active,enabled,memory_order_relaxed);}
__attribute__((destructor)) static void finish(void) {
 if(!started)return;
 atomic_store_explicit(&stopped,1,memory_order_relaxed);
 if(pthread_join(sampler,NULL))abort();
 FILE *f=fopen(getenv("MECH_PC_SAMPLE_OUT"),"w");if(!f)abort();
 fprintf(f,"anchor,%lx\nfailures,%u\n",(unsigned long)anchor,failures);
 for(size_t i=0;i<used;i++)fprintf(f,"%lx,%lx\n",(unsigned long)rows[i].pc,(unsigned long)rows[i].lr);
 fclose(f);mach_port_deallocate(mach_task_self(),main_thread);
}
