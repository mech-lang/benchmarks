from pathlib import Path
import json,subprocess
r=Path(__file__).resolve().parent;symbol='mech_compact_numeric_3009_no_growth_composed';out=r/'current-cost4-count-profiles'
base=json.loads((r/'settings/current-cost4-suite-balanced-unlaid.json').read_text());base={k:v for k,v in base.items() if not k.startswith('MECH_INSPECT_')}
for name,layout,ccmp in [('counted-cost4-reference-layout',r/'rebased-profiles/current-cost4-edge-layout.json',False),('counted-cost4-count-layout',r/'current-cost4-count-layout.json',False),('counted-cost4-count-layout-ccmp',r/'current-cost4-count-layout.json',True)]:
 settings=base|{'MECH_COMPACT_PHASE_BLOCK_LAYOUT':base['MECH_COMPACT_PHASE_BLOCK_LAYOUT']+';'+symbol+'@'+str(layout)}
 if ccmp:
  settings['MECH_COMPACT_CCMP_IMMEDIATES']='mech_compact_numeric_475_vector'
  for key,p in [('MECH_COMPACT_PHASE_REGISTER_WEIGHTS',r/'rebased-profiles/ccmp-immediates-register.json'),('MECH_COMPACT_PHASE_BLOCK_LAYOUT',r/'rebased-profiles/ccmp-immediates-fixed-extent.json')]:settings[key]=';'.join('mech_compact_numeric_475_vector@'+str(p) if v.startswith('mech_compact_numeric_475_vector@') else v for v in settings[key].split(';'))
 p=r/'settings'/(name+'.json');p.write_text(json.dumps(settings,indent=2)+'\n')
 subprocess.run(['python3','-B',str(r/'build-variant.py'),name,'--settings',str(p),'--support-build',str(r/'clean-build-paired-appends')],check=True)
 v=r/'variants'/name;subprocess.run(['python3','-B','/private/tmp/mech-m3-81-20261124/smoke.py',str(v/'bound/mech-worker'),str(v/'bound/metadata.json'),str(out/(name+'-smoke.json'))],check=True)
