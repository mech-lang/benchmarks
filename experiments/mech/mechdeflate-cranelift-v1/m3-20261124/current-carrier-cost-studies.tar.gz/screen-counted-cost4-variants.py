from pathlib import Path
import json,subprocess,datetime
r=Path(__file__).resolve().parent
cases=['empty','one-stored','16384-distribution-change','prefix-natural-1024','reymont-prefix-1024','prefix-natural-65536','prefix-random-4096','prefix-random-1048576','heldout-random-65537','prefix-repeated-16384']
names=['counted-cost4-constrained-layout-ccmp','counted-cost4-constrained-layout','counted-cost4-count-layout-ccmp','counted-cost4-reference-layout']
for name in names:
 out=r/'screens'/(name+'-fixtures')
 p=r/'state.json';v=json.loads(p.read_text());v.update(active_script=str(Path(__file__)),active_log=str(out)+'.log',status='Quiet 24-block fixture screen for '+name+'; no complete score established.',updated_utc=datetime.datetime.now(datetime.UTC).isoformat());p.write_text(json.dumps(v,indent=2)+'\n')
 subprocess.run(['python3','-B',str(r/'run-quiet.py'),'--record',str(out)+'.telemetry.json','--log',str(out)+'.log','--','python3','-B',str(r/'screen.py'),'--candidate',str(r/'variants'/name),'--control',str(r/'clean-build-paired-appends/word-mismatch-order'),'--output',str(out),'--suite','fixtures','--cases',*cases],check=True)
