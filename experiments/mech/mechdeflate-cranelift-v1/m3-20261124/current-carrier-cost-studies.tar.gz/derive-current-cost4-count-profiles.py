from pathlib import Path
from hashlib import sha256
import bisect,json,re,subprocess
r=Path(__file__).resolve().parent
symbol='mech_compact_numeric_3009_no_growth_composed'
counter=r/'current-cost4-exact-counts';data=json.loads((counter/'counts.json').read_text());heads=data['leaders']
vpath=r/'capture-current-cost4-weighted'/(symbol+'.vcode');text=vpath.read_text();expected=text.split(';; REGALLOC_INPUT_BEGIN\n',1)[1].split(';; REGALLOC_INPUT_END\n',1)[0]
labels=[(int(i),int(at)) for i,at in re.findall(r'^;; REGALLOC_BLOCK (\d+) offset=(\d+)',text,re.M)]
assert [i for i,at in labels]==list(range(len(labels)))
receipt=json.loads((r/'variants/current-cost4-weighted/receipt.json').read_text());assert receipt['artifacts']['program.o']==data['source_object_sha256']
case_vectors={name:[b['visits'] for b in case['blocks']] for name,case in data['cases'].items()}
for case in data['cases'].values():assert [b['offset'] for b in case['blocks']]==heads
training_corpus={'silesia-dickens','silesia-mozilla','silesia-mr','silesia-x-ray'}
fixtures=[n for n,v in case_vectors.items() if any(v) and not n.startswith(('silesia-','heldout-'))]
corpus=[n for n,v in case_vectors.items() if any(v) and n in training_corpus]
assert len(corpus)==4
suites=[fixtures,corpus];heldout=[n for n in case_vectors if n.startswith('heldout-') or (n.startswith('silesia-') and n not in training_corpus)]
node_balanced=[sum(0.5*sum(case_vectors[name][i]/sum(case_vectors[name]) for name in names)/len(names) for names in suites) for i in range(len(heads))]
node_sum=[sum(case_vectors[name][i] for names in suites for name in names) for i in range(len(heads))]
label_map=[bisect.bisect_right(heads,at)-1 if at<data['literal_offset'] else None for _,at in labels]
o=r/'current-cost4-count-profiles';o.mkdir()
for name,nodes in [('suite-balanced',node_balanced),('invocation-sum',node_sum)]:
 weights=[nodes[i] if i is not None else 0 for i in label_map];peak=max(weights)
 profile={'expected_vcode':expected,'block_frequencies':[max(1,round(4096*n/peak)) for n in weights],'scope':'Allocation hints derived from output-verified native block-entry counts. Empty VCode aliases inherit the containing machine block count; these are allocation hints rather than exact IR block counts. Diagnostic timings are excluded.','aggregation':name,'training_cases':fixtures+corpus,'heldout_from_profile':heldout,'native_counts_sha256':sha256((counter/'counts.json').read_bytes()).hexdigest(),'training_object_sha256':data['source_object_sha256']}
 (o/(name+'.json')).write_text(json.dumps(profile,indent=2)+'\n')
proof={'source_object_sha256':data['source_object_sha256'],'vcode_sha256':sha256(vpath.read_bytes()).hexdigest(),'label_to_native_block':label_map,'training_suites':suites,'heldout_cases':heldout,'all_counted_cases':list(case_vectors),'policy':'Half the normalized allocation weight goes to equally weighted active non-heldout fixtures. The other half goes equally to Dickens, Mozilla, MR and X-ray. Named heldout fixtures and the other eight corpus files are excluded from allocation training. Invocation-sum is a separate aggregation over the same training cases. Both have a 4096 peak and cold floor one.'}
(o/'proof.json').write_text(json.dumps(proof,indent=2)+'\n')
base=json.loads((r/'settings/current-cost4-edges.json').read_text())
for aggregation in ['suite-balanced','invocation-sum']:
 name='current-cost4-'+aggregation+'-unlaid';settings=base.copy();settings['MECH_COMPACT_PHASE_REGISTER_WEIGHTS']=';'.join(symbol+'@'+str(o/(aggregation+'.json')) if part.startswith(symbol+'@') else part for part in settings['MECH_COMPACT_PHASE_REGISTER_WEIGHTS'].split(';'));settings['MECH_COMPACT_PHASE_BLOCK_LAYOUT']=';'.join(p for p in settings['MECH_COMPACT_PHASE_BLOCK_LAYOUT'].split(';') if not p.startswith(symbol+'@'))
 c=r/('capture-'+name);c.mkdir();settings['MECH_INSPECT_PHASE_REGISTER_PROFILE']=str(c/(symbol+'.vcode'));settings['MECH_INSPECT_OPTIMIZED_PHASE_CLIF']=str(c/(symbol+'.clif'))
 p=r/'settings'/(name+'.json');p.write_text(json.dumps(settings,indent=2)+'\n');subprocess.run(['python3','-B',str(r/'build-variant.py'),name,'--settings',str(p),'--support-build',str(r/'clean-build-paired-appends')],check=True)
 v=r/'variants'/name;subprocess.run(['python3','-B','/private/tmp/mech-m3-81-20261124/smoke.py',str(v/'bound/mech-worker'),str(v/'bound/metadata.json'),str(o/(name+'-smoke.json'))],check=True)
print(json.dumps({'training_fixture_cases':len(fixtures),'training_corpus_files':corpus,'heldout':heldout}),flush=True)
