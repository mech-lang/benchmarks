"""Choose a path-cover layout without increasing predicted branches on training cases."""
from pathlib import Path
from collections import defaultdict
from hashlib import sha256
import json,sys,time
import numpy as np
import scipy
from scipy.optimize import Bounds,LinearConstraint,milp
r=Path(__file__).resolve().parent
# Reuse the checked integer-flow inference and branch model, without rerunning producers.
ns={'__file__':str(r/'derive-current-cost4-count-layout.py')}
exec(compile((r/'derive-current-cost4-count-layout.py').read_text(),str(r/'derive-current-cost4-count-layout.py'),'exec'),ns)
heads,blocks,n,thread,collapse,bycase,suites,old,dynamic_branches,nodefreq=[ns[k] for k in ['heads','blocks','n','thread','collapse','bycase','suites','old','dynamic_branches','nodefreq']]
nodes=[i for i in range(n) if i not in thread]
links=[]
for i in nodes:
 kind,taken,fall=blocks[i]
 if kind[0]=='condition':dests={collapse(taken),collapse(fall)}
 elif kind[0] in ('next','jump'):dests={collapse(taken if taken is not None else fall)}
 else:dests=set()
 links.extend((i,j) for j in sorted(dests) if j!=i and j!=0)
assert len(set(links))==len(links)
ne=len(links);nv=ne+len(nodes);positions={i:ne+p for p,i in enumerate(nodes)}
reward={};constant={}
for name,(counts,known) in bycase.items():
 assert len(known)==len(ns['edges']),name
 values=[];base=0
 for i in nodes:
  kind,taken,fall=blocks[i]
  if kind[0]=='condition':
   a,b=collapse(taken),collapse(fall)
   base+=counts[i] if a==b else counts[i]+known[i,1]
  elif kind[0] in ('next','jump'):base+=counts[i]
 for i,j in links:
  kind,taken,fall=blocks[i]
  if kind[0]=='condition':
   a,b=collapse(taken),collapse(fall)
   values.append(counts[i] if a==b else known[i,1])
  else:values.append(counts[i])
 reward[name]=np.asarray(values,dtype=np.float64);constant[name]=base
# Objective uses only the recorded training sets, never held-out outcomes.
objective=np.zeros(nv)
for suite in suites:
 for name in suite:
  counts,_=bycase[name]
  objective[:ne]-=reward[name]*(0.5/len(suite)/sum(counts))
rows=[];lower=[];upper=[]
def add(coeff,lo=-np.inf,hi=np.inf):
 row=np.zeros(nv)
 for j,v in coeff.items():row[j]=v
 rows.append(row);lower.append(lo);upper.append(hi)
for node in nodes:
 add({p:1 for p,(a,b) in enumerate(links) if a==node},hi=1)
 add({p:1 for p,(a,b) in enumerate(links) if b==node},hi=1)
for p,(a,b) in enumerate(links):add({positions[a]:1,positions[b]:-1,p:len(nodes)},hi=len(nodes)-1)
old_order=[heads.index(at) for at in old['order'] if heads.index(at) not in thread]
old_adj=set(zip(old_order,old_order[1:]));old_chosen=np.array([(a,b) in old_adj for a,b in links])
for suite in suites:
 for name in suite:
  before,bad=dynamic_branches(old,*bycase[name]);assert not bad
  budget=constant[name]-before
  assert int(reward[name]@old_chosen)==budget,(name,budget,reward[name]@old_chosen)
  scale=max(1.0,float(np.max(reward[name])))
  add({p:v/scale for p,v in enumerate(reward[name]) if v},lo=budget/scale)
lb=np.zeros(nv);ub=np.array([1.0]*ne+[len(nodes)-1]*len(nodes));ub[positions[0]]=0
start=time.monotonic()
result=milp(objective,integrality=np.array([1]*ne+[0]*len(nodes)),bounds=Bounds(lb,ub),constraints=LinearConstraint(np.array(rows),np.array(lower),np.array(upper)),options={'time_limit':30,'mip_rel_gap':0})
print('solver',result.message,'seconds',time.monotonic()-start,flush=True)
assert result.x is not None
chosen=[links[p] for p in range(ne) if result.x[p]>0.5]
assert all(abs(result.x[p]-round(result.x[p]))<1e-5 for p in range(ne))
following=dict(chosen);previous={b:a for a,b in chosen};assert len(following)==len(previous)==len(chosen)
chains=[]
for node in nodes:
 if node in previous:continue
 chain=[];at=node
 while True:
  assert at not in chain
  chain.append(at)
  if at not in following:break
  at=following[at]
 chains.append(chain)
assert sorted(i for chain in chains for i in chain)==nodes
entry=next(chain for chain in chains if chain[0]==0);chains.remove(entry)
chains.sort(key=lambda chain:(-sum(nodefreq[i] for i in chain)/max(1,sum((heads[i+1] if i+1<n else ns['shape']['code_end'])-heads[i] for i in chain)),heads[chain[0]]))
order=entry+[i for chain in chains for i in chain]+sorted(thread)
profile={'order':[heads[i] for i in order],'literal_offset':ns['shape']['pool'],'thread_jumps':True}
assert profile['order'][0]==0 and sorted(profile['order'])==heads
predictions={}
for name,(counts,known) in bycase.items():
 before,bad1=dynamic_branches(old,counts,known);after,bad2=dynamic_branches(profile,counts,known)
 assert not bad1 and not bad2
 selected_saving=int(reward[name]@np.array([(a,b) in set(chosen) for a,b in links]))
 assert after<=constant[name]-selected_saving
 if any(name in suite for suite in suites):assert after<=before,(name,before,after)
 predictions[name]={'reference_dynamic_branches':before,'constrained_layout_dynamic_branches':after,'change':after-before,'training_case':any(name in suite for suite in suites)}
out=r/'current-cost4-constrained-layout.json';out.write_text(json.dumps(profile,indent=2)+'\n')
proof={'method':__doc__+' Binary adjacency path cover with degree constraints and MTZ acyclicity. Objective gives half the normalized weight to each training suite and equal weight per input. Every training case constrains predicted branches to its reference-or-better count. Held-out cases are used only for validation predictions. Physical block count transfer was separately checked by CFG and label equality. No primary timing claims follow from this model.','scipy_version':scipy.__version__,'solver_status':int(result.status),'solver_message':result.message,'mip_gap':float(result.mip_gap),'solve_seconds':time.monotonic()-start,'training_suites':suites,'heldout_cases':ns['training']['heldout_cases'],'counts_sha256':sha256((r/'current-cost4-exact-counts/counts.json').read_bytes()).hexdigest(),'profile_sha256':sha256(out.read_bytes()).hexdigest(),'selected_adjacencies':[[heads[a],heads[b]] for a,b in chosen],'predicted_dynamic_branches':predictions}
(r/'current-cost4-constrained-layout-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
for name in ['prefix-natural-1024','16384-distribution-change','silesia-mr']:
 print(name,predictions[name],flush=True)
print('all training cases non-regressing',len([x for suite in suites for x in suite]),'selected',len(chosen),'links',ne,flush=True)
