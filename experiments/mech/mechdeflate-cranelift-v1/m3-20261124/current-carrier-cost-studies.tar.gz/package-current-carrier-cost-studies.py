from pathlib import Path
from hashlib import file_digest
import json,tarfile,shutil,subprocess
r=Path(__file__).resolve().parent
p=Path('/private/tmp/mech-m3-deflate-81-benchmarks/experiments/mech/mechdeflate-cranelift-v1/m3-20261124')
snapshot=r/'source-experiments/current-carrier-costs'
for source in Path('/private/tmp/mech-m3-81-20261124/support/pure-counters').glob('*'):
 if source.is_file():
  out=snapshot/'counter-tools'/source.name;out.parent.mkdir(exist_ok=True);shutil.copyfile(source,out)
for source in Path('/private/tmp/mech-m3-current-compiler-tests').glob('*'):
 if source.is_file() and source.suffix in ('.rs','.toml','.lock'):
  out=snapshot/'focused-harness'/source.name;out.parent.mkdir(exist_ok=True);shutil.copyfile(source,out)
for name in ['fixtures.json','counter-clock.c']:
 source=r/'root-exact-counts-current-v2'/name
 shutil.copyfile(source,snapshot/name)
shutil.copyfile(r/'layout-solver-wheels/manifest.json',snapshot/'layout-solver-wheel-hashes.json')
(snapshot/'decision.json').write_text(json.dumps({'selected':False,'reason':'All ten timed live-SSA carrier-cost and refreshed-profile variants miss at least one protected fixture in at least one order. Counts and branch model improvements did not establish a latency improvement. Compiler prototype will be restored after archive verification.','failed_setup':'The earlier saved-value-ID prototype panicked after value compaction. Its full source and failed logs are retained separately as carrier-costs.','tests':'13 focused records, including 2160 differential native input cases (4320 calls); final ten timing actors each passed 162 codec/alias/boundary checks.','default_parity':'M1 object, metadata and canonical bytecode match when the prototype flag is absent.','primary_timing_scope':'Ten original fixtures, 24 balanced blocks per order, forward and reverse, unchanged peers/control and fresh pinned support; no full score or compile-time claim.','count_scope':'Two output-verified deterministic observations of all 81 fixtures and all 12 full corpus files. Diagnostic instrumented timings are excluded.','profile_training':'66 active non-heldout fixtures and Dickens, Mozilla, MR and X-ray; named heldout fixtures and eight other corpus files excluded from training.','layout_solver':'Offline SciPy/HiGHS analysis only, no project or compiler dependency. Constrained layout reduces predicted dynamic branches for every training case but regresses measured 16 KB latency.'},indent=2)+'\n')
families=('carrier-cost','current-cost','counted-cost4')
source_names={'carrier-costs','current-carrier-costs'}
allowed={'.json','.jsonl','.rs','.py','.toml','.lock','.log','.txt','.csv','.c','.stderr','.stdout','.sha256','.patch','.vcode','.clif','.o','.mecb','.bin'}
root_prefixes=('build-carrier-cost','carrier-cost','prepare-carrier-cost','prepare-current-carrier','screen-current-carrier','count-current-cost4','current-cost4-','derive-current-cost4','prepare-counted-cost4','prepare-constrained-cost4','screen-counted-cost4','solve-current-cost4')
shared={'build-variant.py','screen.py','run-quiet.py','transfer-register.py','project-layout.py','place-edge-copy-blocks-v2.py','count-current-root.py','prepare-literal-pack-tests.py','package-current-carrier-cost-studies.py'}
def digest(path):
 with path.open('rb') as stream:return file_digest(stream,'sha256').hexdigest()
files=[]
for f in sorted(r.rglob('*')):
 if not f.is_file():continue
 rel=f.relative_to(r);parts=rel.parts;selected=False
 if parts[0]=='source-experiments' and len(parts)>1 and parts[1] in source_names:selected=True
 elif parts[0] in ('variants','settings','screens','rebased-profiles') and len(parts)>1 and parts[1].startswith(families):selected=True
 elif parts[0].startswith(('capture-carrier-cost','capture-current-cost','current-cost4-count-profiles','current-cost4-exact-counts')):selected=True
 elif len(parts)==1 and (f.name in shared or f.name.startswith(root_prefixes)):selected=True
 if selected and (f.suffix in allowed or f.name in ('mech-worker','silesia-encoder','counter-worker','counter-encoder')):files.append(f)
rows=[{'path':str(f.relative_to(r)),'bytes':f.stat().st_size,'sha256':digest(f)} for f in files]
archive=p/'current-carrier-cost-studies.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz',compresslevel=6,dereference=True) as tar:
 for f in files:tar.add(f,arcname=str(f.relative_to(r)),recursive=False)
with tarfile.open(archive) as tar:
 members=tar.getmembers();assert len(members)==len(rows)
 for m,row in zip(members,rows):
  assert m.name==row['path'] and file_digest(tar.extractfile(m),'sha256').hexdigest()==row['sha256']
(p/(archive.name+'.manifest.json')).write_text(json.dumps({'archive_sha256':digest(archive),'files':rows},indent=2)+'\n')
screens=[]
for f in files:
 rel=f.relative_to(r)
 if len(rel.parts)==3 and rel.parts[0]=='screens' and f.name=='results.json':
  result=json.loads(f.read_text());orders=[]
  for order in result['runs']:
   rows2=order['rows'];misses=[]
   for row in rows2:
    ratio=row['paired_x_libdeflate']['mech-experiment']
    if ratio>=1:misses.append({'case':row['case'],'candidate_x_libdeflate':ratio})
   orders.append({'order':order['order'],'libdeflate_wins':len(rows2)-len(misses),'cases':len(rows2),'misses':misses})
  screens.append({'candidate':rel.parts[1],'orders':orders})
assert len(screens)==10,len(screens)
assert all(any(order['misses'] for order in screen['orders']) for screen in screens)
summary=json.loads((snapshot/'decision.json').read_text())|{'source_head':'71bb1f90b39ad0bceebf1b5871a375de19683ac8','compiler_sha256':json.loads((snapshot/'source-receipt.json').read_text())['compiler_sha256'],'screens':screens,'archive':{'path':archive.name,'sha256':digest(archive),'files':len(files),'bytes':archive.stat().st_size}}
(p/'current-carrier-cost-studies-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary['archive']),flush=True)
