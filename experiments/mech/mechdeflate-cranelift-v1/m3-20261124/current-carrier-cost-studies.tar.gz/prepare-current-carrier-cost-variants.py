from pathlib import Path
from hashlib import sha256
import json, shutil, subprocess
r=Path(__file__).resolve().parent
b=Path('/private/tmp/mech-m3-deflate-81-benchmarks/experiments/mech/mechdeflate-cranelift-v1')
mech=Path('/Users/cim310/.codex/worktrees/level12-compile-profile/mech')
o=r/'source-experiments/current-carrier-costs'; o.mkdir()
compiler=Path('/private/tmp/mech-m3-81-20261124/target/release/compile_profile'); shutil.copyfile(compiler,o/'compile_profile')
patch=subprocess.check_output(['git','diff'],cwd=mech,text=True)
paths=subprocess.check_output(['git','diff','--name-only'],cwd=mech,text=True).splitlines()
untracked=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=mech,text=True).splitlines()
for path in untracked:
 p=subprocess.run(['git','diff','--no-index','--','/dev/null',path],cwd=mech,text=True,stdout=subprocess.PIPE)
 assert p.returncode in (0,1)
 patch+=p.stdout
(o/'source.patch').write_text(patch)
for path in paths+untracked:
 target=o/path;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(mech/path,target)
(o/'source-receipt.json').write_text(json.dumps({'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=mech,text=True).strip(),'compiler_sha256':sha256(compiler.read_bytes()).hexdigest(),'source_patch_sha256':sha256(patch.encode()).hexdigest(),'focused_tests':13, 'native_differential_cases':2160,'scope':'Discover current attached I64 block parameters with low32 consumers, prove their last-append identity on every incoming edge, and reuse the existing seeded I32 previous-cell state. No saved value IDs, additional loop state, memory operations or unchecked paths. Preserve full-width consumers; remove only dead private values. Default disabled.'},indent=2)+'\n')
def run(*args):
 print('COMMAND',*map(str,args),flush=True);subprocess.run(list(map(str,args)),check=True)
def build(name,settings,capture=False):
 settings=settings.copy()
 if capture:
  c=r/('capture-'+name);c.mkdir();settings['MECH_INSPECT_PHASE_REGISTER_PROFILE']=str(c/(symbol+'.vcode'));settings['MECH_INSPECT_OPTIMIZED_PHASE_CLIF']=str(c/(symbol+'.clif'))
 p=r/'settings'/(name+'.json');p.write_text(json.dumps(settings,indent=2)+'\n');run('python3','-B',r/'build-variant.py',name,'--settings',p,'--support-build',r/'clean-build-paired-appends')
symbol='mech_compact_numeric_3009_no_growth_composed'
build('current-cost-default-parity',{})
assert json.loads((r/'variants/current-cost-default-parity/receipt.json').read_text())['artifacts']['program.o']=='e4325602c6a5a4507ba637eee5d34ada9bda77bbb334fefb8ff53324d720e214'
base=json.loads((b/'word-mismatch-order/recipe.json').read_text())['roles']['word-mismatch-order']['settings_delta']
candidates=[]
for width in [2,4]:
 family='current-cost'+str(width)
 settings=base|{'MECH_FORWARD_PREVIOUS_CARRIER_COSTS':'1','MECH_COMPACT_GROUP_FOUR_LITERAL_APPENDS':'1' if width==4 else None,'MECH_COMPACT_PAIR_REGISTER_SPILLS':'1','MECH_COMPACT_PAIR_ADMITTED_APPEND_STORES':None,'MECH_COMPACT_CCMP_IMMEDIATES':None}
 for key in ['MECH_COMPACT_PHASE_REGISTER_WEIGHTS','MECH_COMPACT_PHASE_BLOCK_LAYOUT']:settings[key]=';'.join(v for v in settings[key].split(';') if not v.startswith(symbol+'@'))
 build(family+'-off-unlaid',settings|{'MECH_FORWARD_PREVIOUS_CARRIER_COSTS':None},True)
 build(family+'-raw',settings,True)
 off=json.loads((r/'variants'/(family+'-off-unlaid')/'receipt.json').read_text())['artifacts'];on=json.loads((r/'variants'/(family+'-raw')/'receipt.json').read_text())['artifacts']
 if off==on:
  (o/(family+'-no-effect.json')).write_text(json.dumps({'status':'No generated artifact changes; not selected for timing.','off':off,'on':on},indent=2)+'\n');print('NO GENERATED CHANGE',family,flush=True);continue
 reg=r/'rebased-profiles'/(family+'-register.json');run('python3','-B',r/'transfer-register.py','--source',b/'word-mismatch-order/profiles/c1acb158a41536816386146f55e5be5e2ea9e8607c1dc78df41f900e40671bcd.json','--capture',r/('capture-'+family+'-raw')/(symbol+'.vcode'),'--output',reg)
 settings['MECH_COMPACT_PHASE_REGISTER_WEIGHTS']+=';'+symbol+'@'+str(reg);build(family+'-weighted',settings,True)
 layout=r/'rebased-profiles'/(family+'-layout.json');run('python3','-B',r/'project-layout.py','--control',r/'variants/scorer-base-unlaid','--candidate',r/'variants'/(family+'-weighted'),'--old-capture',r/'capture-scorer-unlaid'/(symbol+'.vcode'),'--new-capture',r/('capture-'+family+'-weighted')/(symbol+'.vcode'),'--profile',b/'word-mismatch-order/profiles/069b98a9e53752e75cbe56873ef6e370b7a280bb773aac195536b37d39dab6b7.json','--mapping',reg.with_suffix('.proof.json'),'--output',layout,'--symbol',symbol)
 edges=r/'rebased-profiles'/(family+'-edge-layout.json');run('python3','-B',r/'place-edge-copy-blocks-v2.py','--candidate',r/'variants'/(family+'-weighted'),'--profile',layout,'--output',edges)
 for suffix,p,ccmp in [('-profiled',layout,False),('-edges',edges,False),('-ccmp-edges',edges,True)]:
  s=settings|{'MECH_COMPACT_PHASE_BLOCK_LAYOUT':settings['MECH_COMPACT_PHASE_BLOCK_LAYOUT']+';'+symbol+'@'+str(p)}
  if ccmp:
   s['MECH_COMPACT_CCMP_IMMEDIATES']='mech_compact_numeric_475_vector'
   for key,path in [('MECH_COMPACT_PHASE_REGISTER_WEIGHTS',r/'rebased-profiles/ccmp-immediates-register.json'),('MECH_COMPACT_PHASE_BLOCK_LAYOUT',r/'rebased-profiles/ccmp-immediates-fixed-extent.json')]:s[key]=';'.join('mech_compact_numeric_475_vector@'+str(path) if part.startswith('mech_compact_numeric_475_vector@') else part for part in s[key].split(';'))
  name=family+suffix;build(name,s);v=r/'variants'/name
  run('python3','-B','/private/tmp/mech-m3-81-20261124/smoke.py',v/'bound/mech-worker',v/'bound/metadata.json',o/(name+'-smoke.json'));candidates.append(name)
(o/'timing-candidates.json').write_text(json.dumps(candidates,indent=2)+'\n')
