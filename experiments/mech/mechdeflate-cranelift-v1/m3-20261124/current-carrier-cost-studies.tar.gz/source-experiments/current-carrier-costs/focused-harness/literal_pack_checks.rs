#![allow(dead_code, unused_imports)]
mod native_artifact {
 mod identity { pub(in crate::native_artifact) fn hex(bytes:&[u8])->String { bytes.iter().map(|byte|format!("{byte:02x}")).collect() } }
 pub mod codegen {
  #[path="/Users/cim310/.codex/worktrees/level12-compile-profile/mech/hosts/gpu/src/native_artifact/codegen/compilation_inputs.rs"]
  pub mod compilation_inputs;
 }
 pub mod program { pub mod codegen {
  mod cfg_cleanup {
   #[path="/private/tmp/mech-m3-current-compiler-tests/literal-pack-source/boolean_conditions.rs"]
   mod boolean_conditions;
   pub(super) use boolean_conditions::masked_integer_comparison;
  }
  #[path="/private/tmp/mech-m3-current-compiler-tests/literal-pack-source/append_run.rs"]
  mod append_run;
 }}
}
