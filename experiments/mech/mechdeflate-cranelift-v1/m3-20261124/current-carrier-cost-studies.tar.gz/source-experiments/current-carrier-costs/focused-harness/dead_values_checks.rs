mod native_artifact { pub mod program { pub mod codegen { pub mod cfg_cleanup { #[path="/private/tmp/mech-m3-current-compiler-tests/late-dead-values-production.rs"] pub mod dead_values; } } } }
