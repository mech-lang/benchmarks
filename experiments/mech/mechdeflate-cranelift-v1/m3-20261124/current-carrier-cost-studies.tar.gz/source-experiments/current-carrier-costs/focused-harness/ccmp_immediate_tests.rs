#[path = "/Users/cim310/.codex/worktrees/level12-compile-profile/mech/hosts/gpu/src/native_artifact/program/codegen/ccmp_immediate_tests.rs"]
mod cases;
