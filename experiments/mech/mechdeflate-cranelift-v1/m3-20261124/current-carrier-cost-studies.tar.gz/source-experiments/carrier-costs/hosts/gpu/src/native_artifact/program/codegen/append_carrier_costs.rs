//! Reuse the admitted previous-cell state for proved low-word consumers.
use cranelift_codegen::cursor::{Cursor, FuncCursor};
use cranelift_codegen::flowgraph::ControlFlowGraph;
use cranelift_codegen::ir::{
    Block, Function, Inst, InstBuilder, InstructionData as Data, Opcode, Value, ValueDef, types,
};
use std::collections::{BTreeMap, BTreeSet};

pub(super) fn prove(
    f: &Function,
    cfg: &ControlFlowGraph,
    stores: &BTreeSet<Inst>,
    carriers: &[Value],
) -> Vec<(Block, Value)> {
    let last = f
        .layout
        .blocks()
        .filter_map(|block| {
            f.layout
                .block_insts(block)
                .filter(|inst| stores.contains(inst))
                .last()
                .map(|inst| (block, f.dfg.resolve_aliases(f.dfg.inst_args(inst)[0])))
        })
        .collect::<BTreeMap<_, _>>();
    carriers
        .iter()
        .filter_map(|&value| {
            let value = f.dfg.resolve_aliases(value);
            let ValueDef::Param(block, _) = f.dfg.value_def(value) else {
                return None;
            };
            if f.dfg.value_type(value) != types::I64 {
                return None;
            }
            let mut seen = BTreeSet::new();
            let mut budget = 4096;
            known(f, cfg, &last, block, value, &mut seen, &mut budget).then_some((block, value))
        })
        .collect()
}

fn known(
    f: &Function,
    cfg: &ControlFlowGraph,
    last: &BTreeMap<Block, Value>,
    block: Block,
    value: Value,
    seen: &mut BTreeSet<(Block, Value)>,
    budget: &mut usize,
) -> bool {
    if *budget == 0 || Some(block) == f.layout.entry_block() {
        return false;
    }
    *budget -= 1;
    let value = f.dfg.resolve_aliases(value);
    // Cyclic obligations are inductive. Every reachable entry route must
    // terminate at an equal recorded append rather than an uninitialized entry.
    if !seen.insert((block, value)) {
        return true;
    }
    let position = f.dfg.block_params(block).iter().position(|&v| v == value);
    let mut incoming = 0;
    for edge in cfg.pred_iter(block) {
        for call in
            f.dfg.insts[edge.inst].branch_destination(&f.dfg.jump_tables, &f.dfg.exception_tables)
        {
            if call.block(&f.dfg.value_lists) != block {
                continue;
            }
            incoming += 1;
            let argument = if let Some(position) = position {
                let Some(value) = call
                    .args(&f.dfg.value_lists)
                    .nth(position)
                    .and_then(|arg| arg.as_value())
                else {
                    return false;
                };
                f.dfg.resolve_aliases(value)
            } else {
                value
            };
            if let Some(&stored) = last.get(&edge.block) {
                if argument != stored {
                    return false;
                }
            } else if !known(f, cfg, last, edge.block, argument, seen, budget) {
                return false;
            }
        }
    }
    incoming != 0
}

pub(super) fn rewrite(f: &mut Function, replacements: &[(Value, Value)]) -> usize {
    let replacements = replacements.iter().copied().collect::<BTreeMap<_, _>>();
    if replacements.is_empty() {
        return 0;
    }
    let insts = f
        .layout
        .blocks()
        .flat_map(|b| f.layout.block_insts(b))
        .collect::<Vec<_>>();
    let mut changed = 0;
    for inst in insts {
        let (input, narrow) = match f.dfg.insts[inst] {
            Data::Unary {
                opcode: Opcode::Ireduce,
                arg,
            } if f.dfg.value_type(f.dfg.first_result(inst)) == types::I32 => (arg, true),
            Data::BinaryImm64 {
                opcode: Opcode::BandImm,
                arg,
                imm,
            } if imm.bits() as u64 == u64::from(u32::MAX) => (arg, false),
            Data::Binary {
                opcode: Opcode::Band,
                args,
            } => {
                let candidate = args.into_iter().enumerate().find_map(|(i, value)| {
                    let ValueDef::Result(def, 0) = f.dfg.value_def(f.dfg.resolve_aliases(value)) else { return None };
                    matches!(f.dfg.insts[def], Data::UnaryImm { opcode: Opcode::Iconst, imm } if imm.bits() as u64 == u64::from(u32::MAX)).then_some(args[1-i])
                });
                let Some(input) = candidate else { continue };
                (input, false)
            }
            _ => continue,
        };
        let input = f.dfg.resolve_aliases(input);
        let Some(&cost) = replacements.get(&input) else {
            continue;
        };
        let result = f.dfg.first_result(inst);
        if f.dfg.value_type(input) != types::I64
            || f.dfg.value_type(cost) != types::I32
            || (!narrow && f.dfg.value_type(result) != types::I64)
        {
            continue;
        }
        let replacement = if narrow {
            cost
        } else {
            let mut c = FuncCursor::new(f).at_inst(inst);
            c.ins().uextend(types::I64, cost)
        };
        f.layout.remove_inst(inst);
        f.dfg.clear_results(inst);
        f.dfg.change_to_alias(result, replacement);
        changed += 1;
    }
    changed
}

#[cfg(test)]
#[path = "append_carrier_costs_tests.rs"]
mod tests;
