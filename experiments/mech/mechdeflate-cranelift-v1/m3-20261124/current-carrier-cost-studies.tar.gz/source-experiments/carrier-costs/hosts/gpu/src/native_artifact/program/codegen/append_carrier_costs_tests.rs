use super::*;
use cranelift_codegen::{
    Context,
    ir::{AbiParam, BlockArg, condcodes::IntCC},
};
use cranelift_frontend::{FunctionBuilder, FunctionBuilderContext};
use cranelift_jit::{JITBuilder, JITModule};
use cranelift_module::{Linkage, Module, default_libcall_names};

type Run = unsafe extern "C" fn(u64, u64, u64, *mut u64) -> u64;

fn fixture(module: &JITModule, mode: u8, observe_high: bool) -> (Context, Value, Value, Vec<Inst>) {
    let mut ctx = module.make_context();
    ctx.func.signature.params = vec![AbiParam::new(types::I64); 4];
    ctx.func.signature.returns = vec![AbiParam::new(types::I64)];
    let mut storage = FunctionBuilderContext::new();
    let mut b = FunctionBuilder::new(&mut ctx.func, &mut storage);
    let [entry, header, body, copy, done] = [(); 5].map(|_| b.create_block());
    b.append_block_params_for_function_params(entry);
    for block in [header, copy] {
        for ty in [types::I64, types::I64, types::I32] {
            b.append_block_param(block, ty);
        }
    }
    b.switch_to_block(entry);
    let [seed, count, step, output] = b.block_params(entry).try_into().unwrap();
    let mut stores = Vec::new();
    if mode != 4 {
        stores.push(
            b.ins()
                .store(cranelift_codegen::ir::MemFlags::new(), seed, output, 0),
        );
    }
    let first = if mode == 2 {
        b.ins().bxor_imm(seed, 1)
    } else {
        seed
    };
    let low_seed = b.ins().ireduce(types::I32, seed);
    let zero = b.ins().iconst(types::I64, 0);
    b.ins()
        .jump(header, &[zero.into(), first.into(), low_seed.into()]);

    b.switch_to_block(header);
    let [ordinal, wide, cached] = b.block_params(header).try_into().unwrap();
    let more = b.ins().icmp(IntCC::UnsignedLessThan, ordinal, count);
    b.ins().brif(more, body, &[], done, &[]);
    b.switch_to_block(body);
    let a = b.ins().ireduce(types::I32, wide);
    let masked = b.ins().band_imm(wide, i64::from(u32::MAX));
    let c = b.ins().ireduce(types::I32, masked);
    let mask = b.ins().iconst(types::I64, i64::from(u32::MAX));
    let masked = b.ins().band(mask, wide);
    let d = b.ins().ireduce(types::I32, masked);
    let low = b.ins().iadd(a, c);
    let low = b.ins().iadd(low, d);
    let increment = b.ins().ireduce(types::I32, step);
    let low = b.ins().iadd(low, increment);
    let high = if observe_high {
        b.ins().ushr_imm(wide, 32)
    } else {
        ordinal
    };
    let high = b.ins().bxor_imm(high, 0x98765432);
    let high = b.ins().ishl_imm(high, 32);
    let low64 = b.ins().uextend(types::I64, low);
    let word = b.ins().bor(high, low64);
    let next = b.ins().iadd_imm(ordinal, 1);
    let displacement = b.ins().ishl_imm(next, 3);
    let address = b.ins().iadd(output, displacement);
    stores.push(
        b.ins()
            .store(cranelift_codegen::ir::MemFlags::new(), word, address, 0),
    );
    let carried = if mode == 1 {
        b.ins().bxor_imm(word, 1)
    } else {
        word
    };
    let actual = if mode == 3 {
        let actual = b.ins().bxor_imm(word, 1);
        stores.push(
            b.ins()
                .store(cranelift_codegen::ir::MemFlags::new(), actual, address, 0),
        );
        b.ins().ireduce(types::I32, actual)
    } else {
        low
    };
    b.ins().jump(
        if mode == 5 { copy } else { header },
        &[next.into(), carried.into(), actual.into()],
    );
    if mode == 5 {
        b.switch_to_block(copy);
        let args = b
            .block_params(copy)
            .iter()
            .copied()
            .map(BlockArg::Value)
            .collect::<Vec<_>>();
        b.ins().jump(header, &args);
    }
    b.switch_to_block(done);
    let result = if observe_high {
        wide
    } else {
        b.ins().uextend(types::I64, cached)
    };
    b.ins().return_(&[result]);
    b.seal_all_blocks();
    b.finalize();
    ctx.compute_cfg();
    ctx.compute_domtree();
    (ctx, wide, cached, stores)
}

fn compile(mode: u8, observe_high: bool, optimize: bool) -> (JITModule, Run) {
    let mut module = JITModule::new(
        JITBuilder::with_flags(
            &[("opt_level", "speed"), ("regalloc_checker", "true")],
            default_libcall_names(),
        )
        .unwrap(),
    );
    let (mut ctx, wide, cached, stores) = fixture(&module, mode, observe_high);
    let proof = prove(&ctx.func, &ctx.cfg, &stores.into_iter().collect(), &[wide]);
    assert_eq!(!proof.is_empty(), matches!(mode, 0 | 5), "mode={mode}");
    if optimize && !proof.is_empty() {
        assert_eq!(rewrite(&mut ctx.func, &[(wide, cached)]), 3);
    }
    ctx.verify(module.isa()).unwrap();
    let id = module
        .declare_function("previous_carrier", Linkage::Local, &ctx.func.signature)
        .unwrap();
    module.define_function(id, &mut ctx).unwrap();
    module.finalize_definitions().unwrap();
    // Run exactly matches the declared signature and the module owns its code.
    let run = unsafe { core::mem::transmute::<*const u8, Run>(module.get_finalized_function(id)) };
    (module, run)
}

#[test]
fn carrier_costs_preserve_full_words_wrapping_and_refuse_invalid_lineage() {
    let mut calls = 0;
    for mode in 0..6 {
        for observe_high in [false, true] {
            let (_old, control) = compile(mode, observe_high, false);
            let (_new, candidate) = compile(mode, observe_high, true);
            for seed in [
                0,
                1,
                u64::MAX,
                0xabcdef01_ffff_fffe,
                0x80000000_80000000,
                0x12345678_00000000,
            ] {
                for count in [0, 1, 2, 7, 16, 31] {
                    for step in [0, 1, u32::MAX as u64, 0x80000000, u64::MAX] {
                        let mut a = [0xfeedface_deadbeef; 34];
                        let mut b = a;
                        // Both buffers contain all source stores plus sentinels.
                        let expected = unsafe { control(seed, count, step, a.as_mut_ptr()) };
                        let actual = unsafe { candidate(seed, count, step, b.as_mut_ptr()) };
                        assert_eq!(
                            (actual, b),
                            (expected, a),
                            "mode={mode} high={observe_high}"
                        );
                        calls += 1;
                    }
                }
            }
        }
    }
    assert_eq!(calls, 2160);
}
