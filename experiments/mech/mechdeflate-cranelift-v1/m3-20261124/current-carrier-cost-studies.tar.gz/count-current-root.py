"""Untimed root counters, with separately checked direct-call relocations.

The archived leaf instrumenter remains unchanged. This implementation accepts
direct relocated calls and unchanged register calls, preserves IP registers/NZCV, and expands local
conditional branches to avoid changing their range when counters are inserted.
"""
from pathlib import Path
from types import SimpleNamespace
from struct import pack, pack_into, unpack_from
from hashlib import sha256
import ast, bisect, json, re, runpy, shutil, subprocess, time

r = Path('/private/tmp/mech-m3-cranelift-20261124')
d = r / 'root-exact-counts-current-v2'
d.mkdir()
tools = Path('/private/tmp/mech-m3-81-20261124/support/pure-counters')
sha = lambda p: sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_text())

def extract(path, names, scope):
    source = Path(path).read_text()
    nodes = [n for n in ast.parse(source).body if isinstance(n, ast.FunctionDef) and n.name in names]
    assert {n.name for n in nodes} == set(names)
    exec(compile(ast.Module(body=nodes, type_ignores=[]), str(path), 'exec'), scope)
    return SimpleNamespace(**{n: scope[n] for n in names})

macho = SimpleNamespace(**runpy.run_path(str(tools / 'reachability-census.py')))
text, constant = macho.TEXT, (b'__TEXT', b'__const')
obj = extract(tools / 'compact_object.py', ['tables', 'relocs'], {'unpack_from': unpack_from})
layout = SimpleNamespace(obj=obj)
scope = globals() | {'counter_name': b'_mech_root_block_counts\0'}
replace_source = (tools / 'count-matcher-instructions.py').read_text()
replace_node = next(n for n in ast.parse(replace_source).body if isinstance(n, ast.FunctionDef) and n.name == 'replace_atom')
replace_source = ast.get_source_segment(replace_source, replace_node)
# The root's following symbol need not sit on the section's maximum alignment.
# Preserve its existing alignment by making the inserted delta a multiple of
# that maximum, rather than requiring the two original bounds to be aligned.
before = 'assert start % alignment == extent % alignment == 0 and alignment >= 4'
assert replace_source.count(before)==1
replace_source = replace_source.replace(before, 'assert start % 4 == extent % 4 == 0 and alignment >= 4')
before = 'padding = (-len(body)) % alignment'
assert replace_source.count(before)==1
replace_source = replace_source.replace(before, 'padding = (extent - start - len(body)) % alignment')
before = 'delta = len(body) + padding - (extent - start)'
assert replace_source.count(before)==1
replace_source = replace_source.replace(before,before+'\n    assert delta % alignment == 0')
exec(compile(replace_source,'<root-preserving-delta>','exec'),scope)
replace_atom=scope['replace_atom']
(d/'replace-atom-adaptation.py').write_text(replace_source+'\n')
normal = extract(tools / 'canonical-counter-input.py', ['normalize'], {
    'm': macho.__dict__, 'text': text, 'const': constant,
    'unpack_from': unpack_from, 'pack_into': pack_into, 'sha': sha,
    'align': lambda n, a: (n+a-1)&-a,
})
front = d / 'frontend'
front.mkdir()
source = r / 'variants/shift-counts'
normalization = normal.normalize(source / 'frontend/program.o', front / 'program.o')
for name in ['program.mecb', 'metadata.json']:
    shutil.copyfile(source / 'frontend' / name, front / name)
(d / 'normalization.json').write_text(json.dumps(normalization, indent=2)+'\n')
path = front / 'program.o'
base, sections, symbols = macho.load(path)
_, address, text_size, text_offset, _, _ = sections[text]
assert address == 0
names = macho.text_symbols(sections, symbols)
start = names['_mech_compact_closed_checked']
final = start + read(front/'metadata.json')['code_bytes']
extent = min((v for v in names.values() if v > start), default=text_size)
assert final <= extent
relocs = [(at, info) for at, info in obj.relocs(base, sections[text]) if start <= at < extent]
relocated = {at: info for at, info in relocs}
assert len(relocated) == len(relocs)
assert all(info >> 28 in (2, 3, 4, 5, 6) for _, info in relocs)
asm = {}
for line in subprocess.check_output(['/usr/bin/otool', '-tvV', str(path)], text=True).splitlines():
    match = re.fullmatch(r'([0-9a-f]{16})\s+(\S+)\s*(.*)', line)
    if match and start <= (pc := int(match[1], 16)) < final:
        op, operands = match[2], match[3]
        assert op not in {'adr','br','braa','brab','blraa','blrab','bti'}, (hex(pc), op)
        asm[pc] = (op, operands)
assert list(asm) == list(range(start, final, 4))
raw = {pc: unpack_from('<I', base, text_offset+pc)[0] for pc in asm}
def field(word):
    if word & 0x7c000000 == 0x14000000: return 0,26
    if word & 0xff000010 == 0x54000000 or word & 0x7e000000 == 0x34000000: return 5,19
    if word & 0x7e000000 == 0x36000000: return 5,14
def target(pc, word, shape):
    low, width = shape
    delta = (word >> low) & ((1<<width)-1)
    if delta>>(width-1): delta -= 1<<width
    return pc+4*delta
def branch(pc, to):
    assert (to-pc)%4 == 0 and -(1<<25) <= (to-pc)//4 < 1<<25
    return 0x14000000 | (((to-pc)//4)&0x3ffffff)
leaders = {start}
edges = {}
calls = []
register_calls = []
for pc, (op, _) in asm.items():
    w = raw[pc]
    assert w & 0x3b000000 != 0x18000000, ('Unexpected root literal load', hex(pc))
    if op == 'adrp': assert pc in relocated and pc+4 in relocated
    if (shape := field(w)) is not None:
        if pc in relocated:
            assert relocated[pc]>>28 == 2 and shape==(0,26)
            assert op in {'b','bl'}
            if op=='bl': calls.append(pc)
        else:
            assert op != 'bl', ('Unrelocated call', hex(pc))
            to = target(pc,w,shape)
            assert to in asm
            edges[pc] = to, shape
            leaders.add(to)
        if pc+4 < final: leaders.add(pc+4)
    elif op == 'blr':
        # BLR has no PC-relative operand. Leaving its word intact preserves
        # the original target and all arguments; LR points at the relocated
        # continuation, which starts with a register/flags-preserving counter.
        assert w & 0xfffffc1f == 0xd63f0000 and pc not in relocated
        register_calls.append(pc)
        if pc+4 < final: leaders.add(pc+4)
    elif op in {'ret','retab','udf','brk'} and pc+4 < final:
        leaders.add(pc+4)
leaders = sorted(leaders)
assert len(leaders) <= 4096
assert asm[final-4][0] in {'ret','retab','udf','brk','b'}
mapped, targets, counters = {}, {}, {}
output, new_relocs, patches = [], [], []
n = len(symbols)
for pc in asm:
    if pc in leaders:
        at = start+len(output)*4
        targets[pc] = at
        index = len(counters)
        counters[pc] = index
        new_relocs += [(at+4,0x5d000000|n),(at+8,0x6c000000|n)]
        output += [0xa9bf47f0,0x90000010,0xf9400210,0xf9400211|(index<<10),
                   0x91000631,0xf9000211|(index<<10),0xa8c147f0]
    mapped[pc] = start+len(output)*4
    if pc in edges:
        to, shape = edges[pc]
        if shape != (0,26):
            low,width = shape
            mask=((1<<width)-1)<<low
            inverse = raw[pc] ^ (1 if raw[pc]&0xff000010==0x54000000 else 1<<24)
            output.append((inverse&~mask)|(2<<low))
        patches.append((len(output),to))
        output.append(0x14000000)
    else: output.append(raw[pc])
for ix,to in patches: output[ix]=branch(start+ix*4,targets[to])
body=b''.join(pack('<I',w) for w in output)
instrumented=d/'instrumented.o'
replace_atom(path,instrumented,start,extent,body,new_relocs,b'_mech_root_block_counts\0',
             {at:mapped[at] for at in relocated})
metadata=read(front/'metadata.json');metadata['stack_bytes']+=16;metadata['code_bytes']=len(body)
(front/'metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
reference=source/'bound'
worker_source=(reference/'mech-worker.rs').read_text()
edits=[('use serde::Deserialize;', 'use serde::Deserialize;\n#[unsafe(no_mangle)]\npub static mut mech_root_block_counts: [u64; 4096] = [0; 4096];'),
       ('let start = Instant::now();', 'unsafe { std::ptr::addr_of_mut!(mech_root_block_counts).write([0; 4096]); }\nlet start = Instant::now();'),
       ('serde_json::json!({"case":case.name,','let counts = unsafe { std::ptr::addr_of!(mech_root_block_counts).read() };\nserde_json::json!({"block_counts": &counts[..], "case":case.name,')]
for old,new in edits:
    assert worker_source.count(old)==1,old
    worker_source=worker_source.replace(old,new)
worker=d/'counter-worker.rs'
worker.write_text(worker_source)
shutil.copyfile(reference/'pinned_allocator.rs',d/'pinned_allocator.rs')
command=read(source/'receipt.json')['worker_command']
replacements={str(reference/'mech-worker.rs'):str(worker),str(reference/'mech-worker'):str(d/'counter-worker'),
              'link-arg='+str(reference/'program.o'):'link-arg='+str(instrumented)}
assert set(replacements)<=set(command)
subprocess.run([replacements.get(a,a) for a in command],check=True)
# This is an untimed training panel: unchanged 81 fixtures plus all 12 whole corpus files.
import zlib
cases=read(r/'baseline/suite81/fixtures.json')
empty=d/'empty-prefix';empty.write_bytes(b'')
corpus_cases=[]
manifest=read(r/'silesia-inputs/corpus.json')['files']
for name in manifest:
    path=r/'silesia-inputs'/name
    assert sha(path)==manifest[name]['sha256'] and path.stat().st_size==manifest[name]['bytes']
    expected=d/(name+'.expected')
    stream=subprocess.check_output([r/'build/word-mismatch-order/silesia-encoder',path,'--verify'])
    assert zlib.decompress(stream,-15)==path.read_bytes()
    expected.write_bytes(stream)
    # Match the deployed encoder's empty output loan, which starts at capacity zero.
    corpus_cases.append({'name':'silesia-'+name,'input':str(path),'prefix':str(empty),'expected':str(expected),'capacity':0})
cases+=corpus_cases
fixtures=d/'fixtures.json';fixtures.write_text(json.dumps(cases,indent=2)+'\n')
indices={v['name']:i for i,v in enumerate(cases)}
selected=list(indices)
report={}
for case in selected:
    result=subprocess.run([str(d/'counter-worker'),str(front/'metadata.json'),str(fixtures)],
                          input=f'C\t{indices[case]}\t0\nNNQ\n',text=True,capture_output=True,check=True)
    assert result.stderr.endswith('CLEANUP private_payload_bytes=0 live_owner_records=0\n')
    (d/(case+'.stdout')).write_text(result.stdout)
    rows=[json.loads(l) for l in result.stdout.splitlines() if l.startswith('{')]
    assert len(rows)==2
    assert all(row['exact_reference'] and row['independent_inflation'] and row['input_alias_unchanged']
               and row['borrowed_output_alias_unchanged'] for row in rows)
    visits,other=[row['block_counts'] for row in rows]
    assert visits==other and visits[0] in (0,1) and not any(visits[len(leaders):])
    assert visits[0] or not any(visits)
    report[case]={'invocations':1,'observations':2,'root_called':bool(visits[0]),'input_bytes':rows[0]['input_bytes'],'blocks':[
        {'offset':pc-start,'visits':visits[i]} for i,pc in enumerate(leaders)]}
    print(case,'deterministic root counts',len(leaders),'blocks',flush=True)
(d/'counts.json').write_text(json.dumps({'source_object_sha256':sha(source/'frontend/program.o'),
    'instrumented_sha256':sha(instrumented),'symbol':'_mech_compact_closed_checked','root_bytes':final-start,'diagnostic_stack_overhead_bytes':16,'diagnostic_only':True,'training_cases':len(selected),
    'leaders':[pc-start for pc in leaders],'direct_relocated_calls':len(calls),'unchanged_register_calls':len(register_calls),'cases':report,
    'scope':'Untimed exact root block-entry counts. Direct calls retain their original external relocations; register-call instructions remain byte-identical. Indirect jumps are not admitted. Every local conditional edge is expanded with an inverse condition and an in-range unconditional branch. X16, X17, SP and NZCV are preserved at every counter.'},indent=2)+'\n')
