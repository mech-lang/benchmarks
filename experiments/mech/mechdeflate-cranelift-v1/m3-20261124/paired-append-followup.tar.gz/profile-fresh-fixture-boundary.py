"""Untimed PC samples of the exact fresh fixture boundary, including heap setup and cleanup."""
from pathlib import Path
from hashlib import sha256
import bisect,collections,json,os,re,shutil,subprocess,time
r=Path(__file__).resolve().parent;build=r/'clean-build-paired-appends';out=r/'fresh-fixture-boundary-profile';out.mkdir();sha=lambda p:sha256(Path(p).read_bytes()).hexdigest()
c=(r/'pc-diagnostic/sample.c').read_text()
c=c.replace('if(status==KERN_SUCCESS){rows[used++]=', 'if(status==KERN_SUCCESS && atomic_load_explicit(&active,memory_order_relaxed)){rows[used++]=')
c=c.replace('else failures++;','else if(status!=KERN_SUCCESS) failures++;')
(out/'sample.c').write_text(c)
cc=['/usr/bin/clang','-arch','arm64','-mmacosx-version-min=15.0','-O2','-std=c17','-Wall','-Wextra','-Werror','-c',str(out/'sample.c'),'-o',str(out/'sample.o')];subprocess.run(cc,check=True)
fixtures=r/'baseline/suite81/fixtures.json';cases=json.loads(fixtures.read_text());case='16384-distribution-change';index=next(i for i,c in enumerate(cases) if c['name']==case)
for role in ['word-mismatch-order','m3-paired-append-stores']:
 d=out/role;d.mkdir();v=build/role;receipt=json.loads((v/'receipt.json').read_text());source=(v/'bound/mech-worker.rs').read_text()
 edits=[('unsafe extern "C" {','unsafe extern "C" {\n    fn mech_profile_start(anchor: *mut std::ffi::c_void);\n    fn mech_profile_active(enabled: i32);'),('let start = Instant::now();','unsafe { mech_profile_active(1); }\n        let start = Instant::now();'),('let seconds = start.elapsed().as_secs_f64();','let seconds = start.elapsed().as_secs_f64();\n        unsafe { mech_profile_active(0); }'),('println!("SESSION_READY");','unsafe { mech_profile_start(mech_compact_closed_v2 as *const () as *mut std::ffi::c_void); }\n    println!("SESSION_READY");')]
 for a,b in edits:assert source.count(a)==1;source=source.replace(a,b)
 worker=d/'worker.rs';worker.write_text(source);shutil.copyfile(v/'bound/pinned_allocator.rs',d/'pinned_allocator.rs')
 command=receipt['worker_command'].copy();changes={str(v/'bound/mech-worker.rs'):str(worker),str(v/'bound/mech-worker'):str(d/'worker')};assert set(changes)<=set(command);command=[changes.get(arg,arg) for arg in command]+['-C','link-arg='+str(out/'sample.o')]
 with (d/'link.log').open('w') as log:subprocess.run(command,stdout=log,stderr=log,check=True)
 symbols=subprocess.check_output(['/usr/bin/nm','-nm',str(d/'worker')],text=True);(d/'symbols.txt').write_text(symbols)
 entries=[]
 for line in symbols.splitlines():
  m=re.match(r'([0-9a-f]+) \(__TEXT,__text\).* (_\S+)$',line)
  if m:entries.append((int(m[1],16),m[2]))
 entries.sort();addresses=[a for a,n in entries];anchor=next(a for a,n in entries if n=='_mech_compact_closed_v2')
 with (d/'stderr.log').open('w') as err:
  child=subprocess.Popen([str(d/'worker'),str(v/'bound/metadata.json'),str(fixtures)],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err,text=True,env=os.environ|{'MECH_PC_SAMPLE_OUT':str(d/'pcs.csv')})
  try:
   assert child.stdout.readline()=='SESSION_READY\n';child.stdin.write(f'C\t{index}\t0\n');child.stdin.flush();assert child.stdout.readline()==f'CASE_READY\t{case}\n'
   start=time.monotonic();calls=0;warmups=[]
   while time.monotonic()-start<10:
    child.stdin.write('W');child.stdin.flush();line=child.stdout.readline();assert line.startswith('WARMUP_DONE\t'+case+'\t'),line;warmups.append(line);calls+=int(line.split('\t')[2])
   child.stdin.write('NN');child.stdin.flush();rows=[json.loads(child.stdout.readline()) for _ in range(2)];assert child.stdout.readline()==f'CASE_DONE\t{case}\n';child.stdin.write('Q\n');child.stdin.flush();assert child.wait(timeout=20)==0
  finally:
   if child.poll() is None:child.kill();child.wait()
 assert (d/'stderr.log').read_text().endswith('CLEANUP private_payload_bytes=0 live_owner_records=0\n')
 assert all(row['exact_reference'] and row['independent_inflation'] and row['input_alias_unchanged'] and row['borrowed_output_alias_unchanged'] for row in rows)
 (d/'final-observations.json').write_text(json.dumps(rows,indent=2)+'\n');(d/'warmups.log').write_text(''.join(warmups))
 lines=(d/'pcs.csv').read_text().splitlines();slide=int(lines[0].split(',')[1],16)-anchor;assert lines[1]=='failures,0'
 bins=collections.Counter();pcs=collections.defaultdict(collections.Counter)
 for line in lines[2:]:
  pc,lr=[int(x,16) for x in line.split(',')];pc-=slide;i=bisect.bisect_right(addresses,pc)-1
  if 0<=i<len(entries)-1:
   a,name=entries[i];bins[name]+=1;pcs[name][pc-a]+=1
 report={'scope':__doc__+' Validation and inflation are outside the sample window. No diagnostic timings are performance evidence.','source_commit':receipt['source_commit'],'role':role,'case':cases[index],'native_object_sha256':sha(v/'bound/program.o'),'worker_sha256':sha(d/'worker'),'sampler_source_sha256':sha(out/'sample.c'),'diagnostic_link_command':command,'checked_invocations':calls+2,'sampler_failures':0,'counts':dict(bins.most_common()),'pcs':{name:dict(value.most_common()) for name,value in pcs.items()}}
 (d/'summary.json').write_text(json.dumps(report,indent=2)+'\n');print(role,bins.most_common(10),flush=True)
