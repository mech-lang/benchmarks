from pathlib import Path
import json,subprocess
r=Path(__file__).resolve().parent;bench=Path('/private/tmp/mech-m3-deflate-81-benchmarks/experiments/mech/mechdeflate-cranelift-v1');role=json.loads((bench/'word-mismatch-order/recipe.json').read_text())['roles']['word-mismatch-order'];s=role['settings_delta'].copy();symbol='mech_compact_numeric_3009_no_growth_composed'
for key,path in [('MECH_COMPACT_PHASE_REGISTER_WEIGHTS',r/'rebased-profiles/append-pairs-register.json'),('MECH_COMPACT_PHASE_BLOCK_LAYOUT',r/'rebased-profiles/append-pairs-layout.json')]:s[key]=';'.join(symbol+'@'+str(path) if v.startswith(symbol+'@') else v for v in s[key].split(';'))
s['MECH_COMPACT_PAIR_ADMITTED_APPEND_STORES']='1';s['MECH_COMPACT_PAIR_REGISTER_SPILLS']='1';s['MECH_COMPACT_CCMP_IMMEDIATES']=None
p=r/'settings/append-pairs-original-matcher.json';p.write_text(json.dumps(s,indent=2)+'\n')
subprocess.run(['python3','-B',str(r/'build-variant.py'),'append-pairs-original-matcher','--settings',str(p),'--support-build',str(r/'clean-build-paired-appends')],check=True)
v=r/'variants/append-pairs-original-matcher'
subprocess.run(['python3','-B','/private/tmp/mech-m3-81-20261124/smoke.py',str(v/'bound/mech-worker'),str(v/'bound/metadata.json'),str(v/'smoke.json')],check=True)
cases=['empty','one-stored','16384-distribution-change','prefix-natural-1024','reymont-prefix-1024','prefix-natural-65536','prefix-random-4096','prefix-random-1048576','heldout-random-65537','prefix-repeated-16384']
# Only actor bindings differ; the original fixture protocol and reference programs remain pinned.
for name,candidate in [('append-pairs-original-matcher',v),('append-pairs-fresh-support',r/'clean-build-paired-appends/m3-paired-append-stores')]:
 out=r/'screens'/(name+'-fixtures')
 subprocess.run(['python3','-B',str(r/'run-quiet.py'),'--record',str(out)+'.telemetry.json','--log',str(out)+'.log','--','python3','-B',str(r/'screen.py'),'--candidate',str(candidate),'--control',str(r/'clean-build-paired-appends/word-mismatch-order'),'--output',str(out),'--suite','fixtures','--cases',*cases],check=True)
