"""Reuse the archived native stack and injected-allocation-failure gates."""
from pathlib import Path
import json,runpy
r=Path(__file__).resolve().parent;b=Path('/private/tmp/mech-m3-deflate-81-benchmarks/experiments/mech/mechdeflate-cranelift-v1');build=r/'clean-build-paired-appends';role='m3-paired-append-stores';out=r/'paired-append-resources';out.mkdir()
ns=runpy.run_path(str(r/'resource-support/measure-native-resources.py'))
ns['INPUTS']=r/'baseline/suite81/fixtures.json';ns['SUPPORT']=r/'resource-support/probe-support'
# Functions retain the run_path globals dictionary; set those explicitly too.
for function in ['build_probe','execute']:
 ns[function].__globals__.update(INPUTS=ns['INPUTS'],SUPPORT=ns['SUPPORT'])
read=lambda p:json.loads(p.read_text());fixtures=read(ns['INPUTS']);expected=read(b/'native-first-batch/evidence/frozen/native-checks.json');faults={row['case']:row for row in read(ns['SUPPORT']/'checked-failures.json')}
stack=out/'stack';stack.mkdir();exe,descriptor=ns['build_probe'](stack,build,role,'stack','stack-worker.rs')
rows=ns['execute'](exe,descriptor,''.join(f'C\t{i}\t0\nNN' for i in range(len(fixtures)))+'Q\n')
assert len(rows)==162 and all(row['exact_reference'] and row['independent_inflation'] and row['input_alias_unchanged'] and row['borrowed_output_alias_unchanged'] for row in rows)
observations={}
for line in (stack/'stderr.log').read_text().splitlines():
 if line.startswith('STACK '):
  _,case,sample,depth=line.split();observations.setdefault(case,{})[sample]=int(depth)
peak=max(v for row in observations.values() for v in row.values());assert peak<=5280
# Equal stack-frame descriptors should retain the existing per-case high-water marks.
assert observations==expected['stack_observations']
recovery=out/'recovery';recovery.mkdir();exe,descriptor=ns['build_probe'](recovery,build,role,'recovery','fault_worker.rs')
rows=ns['execute'](exe,descriptor,''.join(f'C\t{i}\t2\nNNNN' for i,row in enumerate(fixtures) if row['name'] in faults)+'Q\n')
failures=[row for row in rows if 'status' in row];successes=[row for row in rows if row.get('exact_reference')]
assert len(failures)==12 and all(row==faults[row['case']] for row in failures)
assert len(successes)==12 and all(row['independent_inflation'] and row['input_alias_unchanged'] and row['borrowed_output_alias_unchanged'] for row in successes)
summary={'source_commit':read(build/role/'receipt.json')['source_commit'],'stack_bytes':peak,'stack_ceiling_bytes':5280,'per_case_stack_matches_recorded_reference':True,'exact_success_observations':162,'failed_calls':12,'exact_recoveries':12,'cleanup_zero':True}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary),flush=True)
