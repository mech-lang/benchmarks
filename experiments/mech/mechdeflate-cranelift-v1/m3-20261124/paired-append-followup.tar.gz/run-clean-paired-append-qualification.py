from pathlib import Path
import json,subprocess
r=Path(__file__).resolve().parent;bench=Path('/private/tmp/mech-m3-deflate-81-benchmarks');p=bench/'experiments/mech/mechdeflate-cranelift-v1';mech=Path('/Users/cim310/.codex/worktrees/level12-compile-profile/mech');recipe=p/'m3-20261124/append-store-pairs-recipe.json';build=r/'clean-build-paired-appends'
def run(*args):print('COMMAND',*map(str,args),flush=True);subprocess.run(list(map(str,args)),check=True)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=mech,text=True).strip()==json.loads(recipe.read_text())['source_commit']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=mech)
run('python3','-B',p/'rebuild.py','--recipe',recipe,'--mech-root',mech,'--output',build,'--target-dir','/private/tmp/mech-m3-81-20261124/target','--bench-root',bench,'--with-host-report')
for name in ['word-mismatch-order','m3-paired-append-stores']:
 v=build/name;run('python3','-B','/private/tmp/mech-m3-81-20261124/smoke.py',v/'bound/mech-worker',v/'bound/metadata.json',v/'smoke.json')
run('python3','-B',r/'measure-paired-append-resources.py')
commands=[('paired-appends-source-to-executable',['python3','-B',p/'m3-20261124/time-encoder-builds.py','--recipe',recipe,'--build',build,'--output',r/'primary-paired-append-build-times','--repeats','3','--mech-root',mech,'--bench-root',bench]),('paired-appends-complete-suites',['python3','-B',p/'replay.py','--recipe',recipe,'--build',build,'--bench-root',bench,'--corpus',r/'silesia-inputs','--suite','all','--output',r/'qualification-paired-appends'])]
for name,command in commands:run('python3','-B',r/'run-quiet.py','--record',r/(name+'.telemetry.json'),'--log',r/(name+'.log'),'--',*command)
print('COMPLETE paired append qualification',flush=True)
