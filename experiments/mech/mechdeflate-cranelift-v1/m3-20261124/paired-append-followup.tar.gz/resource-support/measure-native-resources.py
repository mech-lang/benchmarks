"""Rerun the archived stack and allocation-recovery gates on the rebuilt compact object."""

from hashlib import file_digest
from argparse import ArgumentParser
from pathlib import Path
from shutil import copy2
import json
import subprocess

ROOT = Path(__file__).resolve().parent
PACKET = ROOT / "bench/experiments/mech/mechdeflate-cranelift-v1"
INPUTS = ROOT / "prepared-regression-controls/fixtures.json"
RECORDS = ROOT / "evidence/frozen/native-checks.json"
SUPPORT = ROOT / "probe-support"
OUTPUT = ROOT / "results/native-resources"
BUILDS = {
    "frozen": ROOT / "frozen-build",
    "configured": ROOT / "configured-final-build",
}


def read(path):
    return json.loads(path.read_text())


def sha(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def build_probe(folder, build, role, kind, file):
    receipt = read(build / role / "receipt.json")
    command = receipt["worker_command"].copy()
    for name in (file, "pinned_allocator.rs" if kind == "stack" else "fault_allocator.rs"):
        copy2(SUPPORT / name, folder / name)
    sources = [at for at, arg in enumerate(command) if arg.endswith("/mech-worker.rs")]
    assert len(sources) == 1
    command[sources[0]] = str(folder / file)
    executable = folder / kind
    command[command.index("-o") + 1] = str(executable)
    if kind == "stack":
        command.extend(("-C", "link-arg=" + str(SUPPORT / "stack.o")))
    with (folder / "link.log").open("w") as log:
        subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, check=True)
    artifacts = build / role / "bound"
    for item, digest in receipt["artifacts"].items():
        assert sha(artifacts / item) == digest
    pin = {
        "source_commit": receipt["source_commit"], "artifacts": receipt["artifacts"],
        "runtime_sha256": receipt["runtime_sha256"], "configuration_sha256": receipt["configuration_sha256"],
        "probe_sha256": sha(executable), "link_command": command,
    }
    (folder / "binding.json").write_text(json.dumps(pin, indent=2) + "\n")
    return executable, artifacts / "metadata.json"


def execute(executable, descriptor, input_commands):
    folder = executable.parent
    with (folder / "stdout.log").open("w") as stdout, (folder / "stderr.log").open("w") as stderr:
        subprocess.run([executable, descriptor, INPUTS], input=input_commands, text=True, stdout=stdout,
                       stderr=stderr, check=True)
    assert (folder / "stderr.log").read_text().endswith("CLEANUP private_payload_bytes=0 live_owner_records=0\n")
    return [json.loads(line) for line in (folder / "stdout.log").read_text().splitlines() if line.startswith("{")]


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("build", choices=tuple(BUILDS))
    selected = parser.parse_args().build
    fixtures = read(INPUTS)
    expected = read(RECORDS)
    faults = {}
    for row in read(SUPPORT / "checked-failures.json"):
        assert row == faults.setdefault(row["case"], row)
    assert len(fixtures) == 81 and len(faults) == expected["recovery"]["cases"]
    summaries = {}
    for label, build in ((selected, BUILDS[selected]),):
        recipe = read(ROOT / "evidence" / label / "recipe.json")
        role = recipe["candidate_actor"]
        stack = OUTPUT / label / "stack"
        stack.mkdir(parents=True)
        executable, descriptor = build_probe(stack, build, role, "stack", "stack-worker.rs")
        input_commands = "".join(f"C\t{index}\t0\nNN" for index in range(len(fixtures))) + "Q\n"
        successes = execute(executable, descriptor, input_commands)
        assert len(successes) == expected["exact_success_observations"]
        observations = {}
        for line in (stack / "stderr.log").read_text().splitlines():
            if line.startswith("STACK "):
                _, case, sample, depth = line.split()
                observations.setdefault(case, {})[sample] = int(depth)
        assert observations == expected["stack_observations"]
        peak = max(depth for samples in observations.values() for depth in samples.values())
        recovery = OUTPUT / label / "recovery"
        recovery.mkdir()
        executable, descriptor = build_probe(recovery, build, role, "recovery", "fault_worker.rs")
        input_commands = "".join(f"C\t{index}\t2\nNNNN" for index, row in enumerate(fixtures)
                                 if row["name"] in faults) + "Q\n"
        rows = execute(executable, descriptor, input_commands)
        observed_faults = [row for row in rows if "status" in row]
        assert len(observed_faults) == expected["recovery"]["observations"]
        assert all(row == faults[row["case"]] for row in observed_faults)
        recoveries = [row for row in rows if row.get("exact_reference")]
        assert len(recoveries) == expected["recovery"]["exact_recoveries"]
        summaries[label] = {"stack_bytes": peak, "stack_ceiling_bytes": 5280,
                            "exact_success_observations": len(successes), "failed_calls": len(observed_faults),
                            "exact_recoveries": len(recoveries)}
        assert peak <= summaries[label]["stack_ceiling_bytes"]
    (OUTPUT / selected / "summary.json").write_text(json.dumps(summaries, indent=2) + "\n")


if __name__ == "__main__":
    main()
