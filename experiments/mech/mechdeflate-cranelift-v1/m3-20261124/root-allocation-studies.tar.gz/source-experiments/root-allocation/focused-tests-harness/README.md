This consumer ran nine focused tests against clean Mech revision
8e68da6afa7983a307c8389f0682283fbc90789a. Replace the recorded absolute Mech
checkout prefix in Cargo.toml and captured_comparison_inputs.rs when replaying.
The production modules are imported directly. The copied identity helper is a
leaf formatting function. The validation_driver name prevents this test consumer
from overwriting the timed compile_profile executable in the shared target.

Run with the pinned nightly and the published lockfile:

    cargo test --offline --locked --release --config 'profile.release.package.libmimalloc-sys.opt-level=1' --features jit,canonical-native-program --test ccmp_immediate_tests --test captured_comparison_inputs

The test log is current-compiler-tests.log in this archive. Cargo compilation
and these tests ran separately from runtime measurements.
