from pathlib import Path
import json,os,runpy,subprocess,sys
r=Path(__file__).resolve().parent
b=Path('/private/tmp/mech-m3-deflate-81-benchmarks/experiments/mech')
o=r/'source-experiments/root-allocation'
def run(*args):
    print('COMMAND',*map(str,args),flush=True)
    subprocess.run(list(map(str,args)),check=True)
run('python3','-B',r/'build-variant.py','no-write-prefetch-raw','--settings',r/'settings/no-write-prefetch-raw.json','--inspect',r/'capture-no-write-prefetch-raw')
reg=r/'rebased-profiles/no-write-prefetch-register.json'
run('python3','-B',r/'transfer-register.py','--source',r/'rebased-profiles/ccmp-immediates-register.json','--capture',r/'capture-no-write-prefetch-raw/mech_compact_numeric_475_vector.vcode','--output',reg)
s=json.loads((r/'settings/no-write-prefetch-raw.json').read_text())
s.pop('MECH_INSPECT_OPTIMIZED_PHASE_CLIF',None)
s['MECH_COMPACT_PHASE_REGISTER_WEIGHTS']+=';mech_compact_numeric_475_vector@'+str(reg)
(r/'settings/no-write-prefetch-weighted.json').write_text(json.dumps(s,indent=2)+'\n')
run('python3','-B',r/'build-variant.py','no-write-prefetch-weighted','--settings',r/'settings/no-write-prefetch-weighted.json','--inspect',r/'capture-no-write-prefetch-weighted')
layout=r/'rebased-profiles/no-write-prefetch-layout.json'
run('python3','-B',r/'project-layout.py','--control',r/'variants/ccmp-immediates-weighted','--candidate',r/'variants/no-write-prefetch-weighted','--old-capture',r/'capture-ccmp-immediates-weighted/mech_compact_numeric_475_vector.vcode','--new-capture',r/'capture-no-write-prefetch-weighted/mech_compact_numeric_475_vector.vcode','--profile',r/'rebased-profiles/ccmp-immediates-layout.json','--mapping',reg.with_suffix('.proof.json'),'--output',layout)
s['MECH_COMPACT_PHASE_BLOCK_LAYOUT']+=';mech_compact_numeric_475_vector@'+str(layout)
(r/'settings/no-write-prefetch-profiled.json').write_text(json.dumps(s,indent=2)+'\n')
run('python3','-B',r/'build-variant.py','no-write-prefetch-profiled','--settings',r/'settings/no-write-prefetch-profiled.json')
v=r/'variants/no-write-prefetch-profiled'
run('python3','-B','/private/tmp/mech-m3-81-20261124/smoke.py',v/'bound/mech-worker',v/'bound/metadata.json',o/'smoke.json')
