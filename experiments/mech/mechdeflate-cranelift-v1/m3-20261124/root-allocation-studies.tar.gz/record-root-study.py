from pathlib import Path
import json, shutil
r=Path(__file__).resolve().parent
p=Path('/private/tmp/mech-m3-deflate-81-benchmarks/experiments/mech/mechdeflate-cranelift-v1/m3-20261124')
h=r/'source-experiments/root-allocation/focused-tests-harness'
h.mkdir(exist_ok=True)
for f in Path('/private/tmp/mech-m3-current-compiler-tests').iterdir():
 if f.is_file(): shutil.copy2(f,h/f.name)
(h/'README.md').write_text('''This consumer ran nine focused tests against clean Mech revision
8e68da6afa7983a307c8389f0682283fbc90789a. Replace the recorded absolute Mech
checkout prefix in Cargo.toml and captured_comparison_inputs.rs when replaying.
The production modules are imported directly. The copied identity helper is a
leaf formatting function. The validation_driver name prevents this test consumer
from overwriting the timed compile_profile executable in the shared target.

Run with the pinned nightly and the published lockfile:

    cargo test --offline --locked --release --config 'profile.release.package.libmimalloc-sys.opt-level=1' --features jit,canonical-native-program --test ccmp_immediate_tests --test captured_comparison_inputs

The test log is current-compiler-tests.log in this archive. Cargo compilation
and these tests ran separately from runtime measurements.
''')
(r/'screens/shipped-m1-fixtures/attempt-path-collision.json').write_text(json.dumps({
 'eligible':False,
 'reason':'A new attempt reused an existing output directory and failed before timing. Its log and telemetry describe the failed attempt; existing results predate it. Use shipped-m1-fixtures-v2 for the completed fresh run.',
 'replacement':'screens/shipped-m1-fixtures-v2/results.json'
},indent=2)+'\n')
labels=[
 ('root-sample-balanced-damped','root-sample-balanced-damped-fixtures','root-sample-balanced-damped-corpus'),
 ('root-sample-small-damped','root-sample-small-damped-fixtures',None),
 ('root-sample-balanced-direct','root-sample-balanced-direct-fixtures',None),
 ('root-sample-small-direct','root-sample-small-direct-fixtures',None),
 ('root-prior-blend','root-prior-blend-fixtures','root-prior-blend-corpus'),
 ('root-prior-boost','root-prior-boost-fixtures',None),
 ('root-prior-blend-tail','root-prior-blend-tail-fixtures',None),
 ('no-write-prefetch-profiled','no-write-prefetch-profiled-fixtures','no-write-prefetch-corpus'),
 ('shipped-m1','shipped-m1-fixtures-v2',None),
]
rows=[]
for name,fixture,corpus in labels:
 d=json.loads((r/'screens'/fixture/'results.json').read_text())
 telemetry=json.loads((r/'screens'/f'{fixture}.telemetry.json').read_text())
 assert telemetry['timing_eligible'] and telemetry['exit_code']==0
 row={'variant':name,'scope':d['scope'],'fixture_screen':f'screens/{fixture}',
      'orders':{},'promoted':False}
 for run in d['runs']:
  row['orders'][run['order']]={}
  for actor in ('mech-control','mech-experiment'):
   rs=run['rows']; misses=[{'case':x['case'],'ratio':x['paired_x_libdeflate'][actor]} for x in rs if x['paired_x_libdeflate'][actor]>=1]
   row['orders'][run['order']][actor]={'cases':len(rs),'wins_vs_libdeflate':len(rs)-len(misses),'wins_vs_roc':sum(x['paired_x_roc'][actor]<1 for x in rs),'libdeflate_misses':misses}
 if corpus:
  c=json.loads((r/'screens'/corpus/'results.json').read_text())
  t=json.loads((r/'screens'/f'{corpus}.telemetry.json').read_text());assert t['timing_eligible'] and t['exit_code']==0
  row['two_actor_corpus_screen']={k:v['paired_candidate_x_control'] for k,v in c['cases'].items()}
  row['corpus_screen']=f'screens/{corpus}'
 receipt=r/'variants'/name/'receipt.json'
 if receipt.exists():
  q=json.loads(receipt.read_text())
  row['receipt']=str(receipt.relative_to(r));row['source_commit']=q['source_commit'];row['source_diff']=q.get('source_diff', 'Not recorded in this preparation receipt; see pinned source and separate validation.')
 rows.append(row)
summary={
 'source_commit':'8e68da6afa7983a307c8389f0682283fbc90789a',
 'codec_source_sha256':'653597f08f889908c48610e90aa65e94a77847fb34500d0cc3a046f83cd3d299',
 'status':'Exploratory only. No variant has qualified for the complete M3 target. Production recipe unchanged.',
 'method':'Ten protected fixture cases at 24 balanced blocks in each order. Corpus screens use eight balanced blocks of control and candidate, not peers. Complete qualification uses all 81 fixtures at 96 blocks and all 12 corpus files in both orders.',
 'weight_provenance':'Current M3 samples of the Cranelift baseline, mapped to captured VCode. Sampled instruction cost is not a measured branch count. A structural-only 4^loop_depth control reproduced the baseline artifacts exactly.',
 'decisions':[
  'Direct sample-only allocation weights disturbed the structural loop prior and did not clear all protected cases.',
  'Geometric blend with the structural prior was the closest pilot: 10/10 forward and 8/10 reverse vs libdeflate, with MR 0.988939 and x-ray 0.995693 relative to control. Still unqualified.',
  'Restoring root extent with unreachable padding did not remove the misses.',
  'Removing matcher write-prefetch hints regressed protected cases; rejected.',
  'The fixed-extent no-prefetch variant was prepared but not timed or qualified.',
  'The unchanged shipped M1 executable also missed protected cases on M3. This subset is not a complete score.'
 ],
 'screens':rows
}
(p/'root-allocation-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(r/'source-experiments/root-allocation/decision.json').write_text(json.dumps(summary,indent=2)+'\n')
readme=p/'README.md'
text=readme.read_text()
marker='\n## Additional root allocation studies\n'
assert marker not in text
text+='''
## Additional root allocation studies

The current compiler's optional root-weight hook was tested against the M3
instruction samples. The structural-only control reproduced the baseline
object, descriptor and bytecode exactly. Sample costs were then tested alone
and blended with the allocator's existing loop estimate. These are allocation
cost hints, not measured branch frequencies.

No new setting was promoted. The closest pilot, the geometric blend with the
loop estimate, won all ten protected cases against libdeflate in forward order
and eight in reverse. Its two-encoder screens measured MR at 0.988939 times
control and x-ray at 0.995693. Those screens do not establish a peer score or a
full-suite improvement. Changing root padding did not clear the remaining
misses. Removing the matcher's write-prefetch hints regressed protected cases
and was rejected. A fixed-extent no-prefetch variant was prepared but not timed.

A fresh check of the unchanged shipped M1 executable also missed protected
cases on M3: 9/10 forward and 6/10 reverse against libdeflate. The complete M3
result remains the conditional-immediate experiment above. An attempted rerun
that reused an existing output directory failed before timing; it is excluded
and the fresh `shipped-m1-fixtures-v2` record is used instead.

[Subset summary and decisions](root-allocation-summary.json) ·
[Root allocation profiles, instruction records, test harness and raw observations](root-allocation-studies.tar.gz) ·
[Verified member hashes](root-allocation-studies.tar.gz.manifest.json)
'''
readme.write_text(text)
state=json.loads((r/'state.json').read_text())
state.update({'source_head':summary['source_commit'],'benchmarks_head_before_root_archive':'d0e9f0fc97d798124f7466de105776e51f21f09b','root_studies_complete':True,'root_candidate_qualified':False,'active_measurements':[]})
(r/'state.json').write_text(json.dumps(state,indent=2)+'\n')
print('recorded',len(rows),'completed subset screens')
