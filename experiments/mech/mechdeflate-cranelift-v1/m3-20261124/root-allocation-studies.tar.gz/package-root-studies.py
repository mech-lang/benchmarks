from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).resolve().parent
p=Path('/private/tmp/mech-m3-deflate-81-benchmarks/experiments/mech/mechdeflate-cranelift-v1/m3-20261124')
allowed={'.json','.jsonl','.log','.stderr','.rs','.py','.toml','.lock','.clif','.vcode','.asm','.md','.txt','.gz','.patch'}
files=[]
for f in sorted(r.rglob('*')):
 if not f.is_file() or f.suffix not in allowed:continue
 rel=f.relative_to(r);parts=rel.parts
 selected=parts[0] in {'clean-build-updated-ccmp','capture-root-alloc','root-sample-weights','root-prior-weights'}
 selected|=len(parts)>1 and parts[0]=='source-experiments' and parts[1]=='root-allocation'
 selected|=len(parts)>1 and parts[0] in {'variants','settings','screens'} and parts[1].startswith(('root-','no-write-prefetch','shipped-m1-fixtures'))
 selected|=len(parts)==1 and rel.name.startswith(('root-','no-prefetch','derive-root-','blend-root-','prepare-no-prefetch','record-root-study','package-root-studies','screen-root','screen-no-prefetch','current-compiler-tests'))
 selected|=parts[0]=='rebased-profiles' and rel.name.startswith(('ccmp-immediates-','no-write-prefetch-'))
 selected|=parts[0]=='m3-register-profile' and f.suffix=='.json'
 if selected:files.append(f)
def sha(f):
 with f.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
rows=[{'path':str(f.relative_to(r)),'bytes':f.stat().st_size,'sha256':sha(f)} for f in files]
f=p/'root-allocation-studies.tar.gz'
with tarfile.open(f,'w:gz',compresslevel=6,dereference=True) as archive:
 for path in files:archive.add(path,arcname=str(path.relative_to(r)),recursive=False)
with tarfile.open(f,'r:gz') as archive:
 members=archive.getmembers();assert len(members)==len(rows)
 for member,row in zip(members,rows):
  assert member.name==row['path'] and member.isfile()
  assert hashlib.file_digest(archive.extractfile(member),'sha256').hexdigest()==row['sha256']
(p/'root-allocation-studies.tar.gz.manifest.json').write_text(json.dumps({'archive_sha256':sha(f),'files':rows},indent=2)+'\n')
print(f.stat().st_size,len(rows))
