"""Preserve the allocator's structural loop estimate while adding sampled costs."""
from pathlib import Path
import collections,json,math,re
r=Path(__file__).resolve().parent
text=(r/'capture-root-alloc/native-vcode.asm').read_text()
rows=re.findall(r'^;; REGALLOC_BLOCK (\d+) offset=\d+ ir=.* successors=\[(.*)\]$',text,re.M)
succ=[list(map(int,re.findall(r'Block\((\d+)\)',raw))) for i,raw in rows]
n=len(succ);assert [int(i) for i,raw in rows]==list(range(n))
pred=[[] for _ in succ]
for i,targets in enumerate(succ):
 for j in targets:pred[j].append(i)
seen={0};post=[];pending=[(0,0)]
while pending:
 node,index=pending[-1]
 if index==len(succ[node]):post.append(node);pending.pop();continue
 target=succ[node][index];pending[-1]=(node,index+1)
 if target not in seen:seen.add(target);pending.append((target,0))
rpo=list(reversed(post));rank={node:i for i,node in enumerate(rpo)}
allbits=sum(1<<i for i in seen);dom=[allbits if i in seen else 0 for i in range(n)];dom[0]=1
changed=True
while changed:
 changed=False
 for node in rpo[1:]:
  parents=[p for p in pred[node] if p in seen]
  mask=allbits
  for parent in parents:mask&=dom[parent]
  mask|=1<<node
  if mask!=dom[node]:dom[node]=mask;changed=True
headers=collections.defaultdict(list);reducible=True
for node in post:
 for target in succ[node]:
  if rank[target]>rank[node]:continue
  if not dom[node]>>target&1:reducible=False;break
  headers[target].append(node)
depth=[0]*n;loops={}
if reducible:
 for header,latches in headers.items():
  members={header};pending=list(latches)
  while pending:
   node=pending.pop()
   if node in members:continue
   members.add(node);pending.extend(pred[node])
  for node in members:depth[node]+=1
  loops[header]=len(members)
else:
 incoming=[0]*n;outgoing=[0]*n
 for node,targets in enumerate(succ):
  for target in targets:
   if target<=node:incoming[target]+=1;outgoing[node]+=1
 stack=[];current=0
 for node in range(n):
  if incoming[node]:current+=1;stack.append(incoming[node])
  depth[node]=current
  while stack and outgoing[node]:
   outgoing[node]-=1;stack[-1]-=1
   if stack[-1]==0:current-=1;stack.pop()
static=[4**min(d,10) for d in depth]
base=json.loads((r/'root-sample-weights/balanced-damped.json').read_text())
assert len(base['block_frequencies'])==n
out=r/'root-prior-weights';out.mkdir(exist_ok=True)
for name,weights in [('static',static),('blend',[max(1,round(math.sqrt(a*b))) for a,b in zip(static,base['block_frequencies'])]),('boost',[max(1,round(a*(1+3*math.sqrt((b-1)/63)))) for a,b in zip(static,base['block_frequencies'])])]:
 f=out/(name+'.json');f.write_text(json.dumps({'expected_vcode':base['expected_vcode'],'block_frequencies':weights},indent=2)+'\n');print(name,'blocks',n,'peak',max(weights))
(out/'proof.json').write_text(json.dumps({'method':__doc__,'reducible':reducible,'reachable_blocks':len(seen),'blocks':n,'max_loop_depth':max(depth),'natural_loop_sizes':loops,'loop_depths':depth},indent=2)+'\n')
