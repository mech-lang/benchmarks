from pathlib import Path
from hashlib import sha256
import json, shutil, subprocess
r=Path(__file__).resolve().parent
b=Path('/private/tmp/mech-m3-deflate-81-benchmarks/experiments/mech/mechdeflate-cranelift-v1')
mech=Path('/Users/cim310/.codex/worktrees/level12-compile-profile/mech')
o=r/'source-experiments/conditional-single-use'; o.mkdir()
compiler=Path('/private/tmp/mech-m3-81-20261124/target/release/compile_profile'); shutil.copyfile(compiler,o/'compile_profile')
patch=subprocess.check_output(['git','diff'],cwd=mech,text=True)
paths=subprocess.check_output(['git','diff','--name-only'],cwd=mech,text=True).splitlines()
untracked=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=mech,text=True).splitlines()
for path in untracked:
 p=subprocess.run(['git','diff','--no-index','--','/dev/null',path],cwd=mech,text=True,stdout=subprocess.PIPE)
 assert p.returncode in (0,1)
 patch+=p.stdout
(o/'source.patch').write_text(patch)
for path in paths+untracked:
 target=o/path;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(mech/path,target)
(o/'source-receipt.json').write_text(json.dumps({'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=mech,text=True).strip(),'compiler_sha256':sha256(compiler.read_bytes()).hexdigest(),'source_patch_sha256':sha256(patch.encode()).hexdigest(),'focused_native_calls':2880000, 'histogram_native_calls':60928,'scope':'Fuse only single-use ICMP and extension into AArch64 conditional increment, avoiding duplicated shared comparisons. Counter gathering has no extra runtime memory and uses exact wrapping collision corrections. All new options disabled by default.'},indent=2)+'\n')
def run(*args):
 print('COMMAND',*map(str,args),flush=True);subprocess.run(list(map(str,args)),check=True)
def build(name,settings):
 p=r/'settings'/(name+'.json');p.write_text(json.dumps(settings,indent=2)+'\n');run('python3','-B',r/'build-variant.py',name,'--settings',p,'--support-build',r/'clean-build-paired-appends')
build('single-use-default-parity',{})
assert json.loads((r/'variants/single-use-default-parity/receipt.json').read_text())['artifacts']['program.o']=='e4325602c6a5a4507ba637eee5d34ada9bda77bbb334fefb8ff53324d720e214'
base=json.loads((b/'word-mismatch-order/recipe.json').read_text())['roles']['word-mismatch-order']['settings_delta']
cases=[]
def finish(name,settings):
 build(name,settings);v=r/'variants'/name
 run('python3','-B','/private/tmp/mech-m3-81-20261124/smoke.py',v/'bound/mech-worker',v/'bound/metadata.json',o/(name+'-smoke.json'))
 cases.append(name)
common={'MECH_COMPACT_PAIR_REGISTER_SPILLS':'1','MECH_COMPACT_PAIR_ADMITTED_APPEND_STORES':None}
finish('single-use-base',base|common|{'MECH_ARM64_CONDITIONAL_INCREMENT':'1'})
if json.loads((r/'variants/single-use-base/receipt.json').read_text())['artifacts']==json.loads((r/'variants/single-use-default-parity/receipt.json').read_text())['artifacts']:cases.remove('single-use-base')
for width,enabled,ccmp in [(2,False,False),(2,True,False),(4,False,False),(4,True,False),(2,True,True),(4,True,True)]:
 name='single-use-gather'+str(width)+('-cinc' if enabled else '-boolean')+('-ccmp' if ccmp else '')
 settings=base|common|{'MECH_GROUP_PACKED_HISTOGRAM_GATHER_COUNTERS':str(width),'MECH_ARM64_CONDITIONAL_INCREMENT':'1' if enabled else None,'MECH_COMPACT_CCMP_IMMEDIATES':None}
 if ccmp:
  settings['MECH_COMPACT_CCMP_IMMEDIATES']='mech_compact_numeric_475_vector'
  for key,path in [('MECH_COMPACT_PHASE_REGISTER_WEIGHTS',r/'rebased-profiles/ccmp-immediates-register.json'),('MECH_COMPACT_PHASE_BLOCK_LAYOUT',r/'rebased-profiles/ccmp-immediates-fixed-extent.json')]:
   settings[key]=';'.join('mech_compact_numeric_475_vector@'+str(path) if part.startswith('mech_compact_numeric_475_vector@') else part for part in settings[key].split(';'))
 finish(name,settings)
(o/'timing-candidates.json').write_text(json.dumps(cases,indent=2)+'\n')
