from pathlib import Path
import json,subprocess
r=Path(__file__).resolve().parent
b=Path('/private/tmp/mech-m3-deflate-81-benchmarks/experiments/mech/mechdeflate-cranelift-v1')
p=b/'word-mismatch-order/profiles'
base=json.loads((b/'word-mismatch-order/recipe.json').read_text())['roles']['word-mismatch-order']['settings_delta']
symbols={
 'mech_compact_numeric_475_vector':('9240a4ff5e10851112e22ee5fd660e61b954c0f89450dda03003656aad92c426.json','a33a82846096fc7744a09a8712f19db227c800f61470c2db699736a61479266f.json','matcher-base-unlaid','capture-matcher-unlaid'),
 'mech_compact_numeric_3009_no_growth_composed':('c1acb158a41536816386146f55e5be5e2ea9e8607c1dc78df41f900e40671bcd.json','069b98a9e53752e75cbe56873ef6e370b7a280bb773aac195536b37d39dab6b7.json','scorer-base-unlaid','capture-scorer-unlaid')}
def run(*args):print('COMMAND',*map(str,args),flush=True);subprocess.run(list(map(str,args)),check=True)
def build(name,s,inspect=None):
 s=s.copy();c=r/('capture-'+name)
 if inspect:
  c.mkdir();s['MECH_INSPECT_PHASE_REGISTER_PROFILE']=str(c/(inspect+'.vcode'));s['MECH_INSPECT_OPTIMIZED_PHASE_CLIF']=str(c/(inspect+'.clif'))
 f=r/'settings'/(name+'.json');f.write_text(json.dumps(s,indent=2)+'\n');run('python3','-B',r/'build-variant.py',name,'--settings',f,'--support-build',r/'clean-build-paired-appends');return c,json.loads((r/'variants'/name/'receipt.json').read_text())['artifacts']
for family,ccmp in [('conditional-inc-v2',False),('conditional-inc-ccmp-v2',True)]:
 settings=base|{'MECH_ARM64_CONDITIONAL_INCREMENT':'1','MECH_COMPACT_CCMP_IMMEDIATES':'mech_compact_numeric_475_vector' if ccmp else None,'MECH_GROUP_PACKED_HISTOGRAM_GATHER_COUNTERS':None,'MECH_COMPACT_PAIR_REGISTER_SPILLS':'1','MECH_COMPACT_PAIR_ADMITTED_APPEND_STORES':None,'MECH_COMPACT_PHASE_REGISTER_WEIGHTS':None,'MECH_COMPACT_PHASE_BLOCK_LAYOUT':None}
 weights=[];raw=[]
 for i,(symbol,(reg,layout,control,oldcap)) in enumerate(symbols.items()):
  name=family+'-raw'+str(i);capture,art=build(name,settings,symbol);raw.append(art)
  target=r/'rebased-profiles'/(family+'-'+str(i)+'-register.json');run('python3','-B',r/'transfer-register.py','--source',p/reg,'--capture',capture/(symbol+'.vcode'),'--output',target);weights.append(symbol+'@'+str(target))
 assert raw[0]==raw[1]
 settings['MECH_COMPACT_PHASE_REGISTER_WEIGHTS']=';'.join(weights);layouts=[];weighted=[]
 for i,(symbol,(reg,layout,control,oldcap)) in enumerate(symbols.items()):
  name=family+'-weighted'+str(i);capture,art=build(name,settings,symbol);weighted.append(art)
  target=r/'rebased-profiles'/(family+'-'+str(i)+'-layout.json');run('python3','-B',r/'project-layout.py','--symbol',symbol,'--control',r/'variants'/control,'--candidate',r/'variants'/name,'--old-capture',r/oldcap/(symbol+'.vcode'),'--new-capture',capture/(symbol+'.vcode'),'--profile',p/layout,'--mapping',r/'rebased-profiles'/(family+'-'+str(i)+'-register.proof.json'),'--output',target);layouts.append(symbol+'@'+str(target))
 assert weighted[0]==weighted[1]
 settings['MECH_COMPACT_PHASE_BLOCK_LAYOUT']=';'.join(layouts)
 preliminary=family+'-profiled';build(preliminary,settings)
 meta=json.loads((r/'variants'/preliminary/'bound/metadata.json').read_text());code=next(x for x in meta['numeric_phases'] if x['header']==475)['vector_variant']['code_bytes']
 if ccmp and code<=5136:
  path=r/'rebased-profiles'/(family+'-0-layout.json');layout=json.loads(path.read_text());layout['object_tail']={'code_bytes':code,'reference_code_bytes':5136,'alignment':128};fixed=path.with_name(family+'-0-layout-fixed.json');fixed.write_text(json.dumps(layout,indent=2)+'\n');settings['MECH_COMPACT_PHASE_BLOCK_LAYOUT']=settings['MECH_COMPACT_PHASE_BLOCK_LAYOUT'].replace(str(path),str(fixed))
 for width in [0,2,4]:
  name=family+('-gather'+str(width) if width else '')+'-final';s=settings|{'MECH_GROUP_PACKED_HISTOGRAM_GATHER_COUNTERS':str(width) if width else None};build(name,s)
  v=r/'variants'/name;run('python3','-B','/private/tmp/mech-m3-81-20261124/smoke.py',v/'bound/mech-worker',v/'bound/metadata.json',r/'source-experiments/conditional-increment'/(name+'-smoke.json'))
