"""Emit an opt-in Cranelift variant against the pinned local baseline support."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import runpy
import shutil
import subprocess
import time


def read(path):
    return json.loads(path.read_text())


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('name')
    parser.add_argument('--settings', type=Path, required=True)
    parser.add_argument('--inspect', type=Path)
    parser.add_argument('--support-build', type=Path)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    mech = Path('/Users/cim310/.codex/worktrees/level12-compile-profile/mech')
    packets = Path('/private/tmp/mech-m3-deflate-81-benchmarks/experiments/mech')
    package = packets / 'mechdeflate-cranelift-v1'
    base = read(packets / 'mechdeflate-81-v1/recipe.json')
    recipe = read(package / 'word-mismatch-order/recipe.json')
    helpers = runpy.run_path(str(packets / 'mechdeflate-81-v1/rebuild.py'))
    flags = helpers['load_flags'](base)
    settings = recipe['roles']['word-mismatch-order']['settings_delta'] | read(args.settings)
    for key, value in settings.items():
        if value is None:
            flags.pop(key, None)
        elif key == 'MECH_COMPACT_ROOT_TAIL_PROFILE':
            flags[key] = str(package / value) if not Path(value).is_absolute() else value
        elif key in helpers['PATH_SETTINGS']:
            entries = []
            for entry in value.split(';'):
                symbol, path = entry.split('@', 1)
                entries.append(symbol + '@' + str(package / path))
            flags[key] = ';'.join(entries)
        else:
            flags[key] = value
    if args.inspect:
        args.inspect.mkdir(parents=True)
        flags['MECH_INSPECT_PHASE_REGISTER_PROFILE'] = str(args.inspect / 'mech_compact_numeric_475_vector.vcode')
        flags['MECH_INSPECT_OPTIMIZED_PHASE_CLIF'] = str(args.inspect / 'mech_compact_numeric_3009_no_growth_composed.clif')
        flags['MECH_INSPECT_FP_SPILL_CACHE'] = str(args.inspect / 'fp-spills')
    variant = root / 'variants' / args.name
    variant.mkdir(parents=True)
    bound, frontend = variant / 'bound', variant / 'frontend'
    bound.mkdir()
    compiler = Path('/private/tmp/mech-m3-81-20261124/target/release/compile_profile')
    source = mech / 'hosts/gpu/tests/fixtures/native/compact-compiler-regression.mec'
    command = [compiler, source, frontend, 'compact']
    env = {key: value for key, value in os.environ.items() if not key.startswith('MECH_')} | flags
    before = time.perf_counter()
    with (variant / 'encoder-build.log').open('w') as log:
        subprocess.run(command, env=env, cwd=mech, stdout=log, stderr=log, check=True)
    object_done = time.perf_counter()
    support_root = args.support_build or (root / 'build')
    old = support_root / 'word-mismatch-order'
    receipt = read(old / 'receipt.json')
    for name in ['program.o', 'program.mecb', 'metadata.json']:
        shutil.copyfile(frontend / name, bound / name)
    for name in ['mech-worker.rs', 'pinned_allocator.rs']:
        shutil.copyfile(package / 'support' / name, bound / name)
    link = [part.replace(str(old), str(variant)) for part in receipt['worker_command']]
    with (variant / 'worker-link.log').open('w') as log:
        subprocess.run(link, cwd=mech, stdout=log, stderr=log, check=True)
    executable_done = time.perf_counter()
    support = support_root / 'silesia-support'
    whole = ['/usr/bin/clang', '-arch', 'arm64', '-mmacosx-version-min=15.0', '-Wl,-dead_strip',
             support / 'clock.o', support / 'libmech_silesia.a', bound / 'program.o',
             package / 'support/mimalloc-2.1.7.o', '-o', variant / 'silesia-encoder']
    with (variant / 'silesia-link.log').open('w') as log:
        subprocess.run(whole, cwd=mech, stdout=log, stderr=log, check=True)
    record = {'source_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=mech, text=True).strip(),
              'source_diff': subprocess.check_output(['git', 'diff'], cwd=mech, text=True),
              'source_sha256': digest(source), 'compiler_sha256': digest(compiler), 'flags': flags,
              'artifacts': {p: digest(bound / p) for p in ['program.o', 'program.mecb', 'metadata.json']},
              'worker_sha256': digest(bound / 'mech-worker'),
              'silesia_actor_sha256': digest(variant / 'silesia-encoder'),
              'measurements': [{'source_through_executable_seconds': executable_done - before,
                                'source_through_object_seconds': object_done - before,
                                'worker_link_seconds': executable_done - object_done}],
              'encoder_command': list(map(str, command)), 'worker_command': link,
              'silesia_link_command': list(map(str, whole)), 'settings_override': settings}
    (variant / 'receipt.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps({'name': args.name, 'artifacts': record['artifacts'],
                      'measurements': record['measurements']}), flush=True)


if __name__ == '__main__':
    main()
