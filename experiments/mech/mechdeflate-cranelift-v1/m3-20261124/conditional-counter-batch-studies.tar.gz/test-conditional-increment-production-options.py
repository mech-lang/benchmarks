from pathlib import Path
import json,os,subprocess,time
r=Path(__file__).resolve().parent;mech=Path('/Users/cim310/.codex/worktrees/level12-compile-profile/mech');recipe=json.loads(Path('/private/tmp/mech-m3-deflate-81-benchmarks/experiments/mech/mechdeflate-81-v1/recipe.json').read_text())['compiler']
env=os.environ.copy();env.update(recipe['cargo_environment']);env['CARGO_TARGET_DIR']='/private/tmp/mech-m3-81-20261124/target'
def run(command,name):
 print('START',name,flush=True)
 with (r/(name+'.log')).open('w') as log:subprocess.run(command,cwd=mech,env=env,stdout=log,stderr=log,check=True)
 print('PASS',name,flush=True)
run(['cargo','+'+recipe['toolchain'],'test','--locked','--manifest-path','/private/tmp/mech-m3-current-compiler-tests/Cargo.toml','--release','--config','profile.release.package.libmimalloc-sys.opt-level=1','--features','jit,canonical-native-program','--test','conditional_increment_checks'],'conditional-increment-production-options-tests')
