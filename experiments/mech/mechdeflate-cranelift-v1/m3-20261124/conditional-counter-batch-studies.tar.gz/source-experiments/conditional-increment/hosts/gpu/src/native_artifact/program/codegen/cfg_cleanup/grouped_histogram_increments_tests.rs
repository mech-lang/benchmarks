use super::*;
use cranelift_codegen::cursor::Cursor;
use cranelift_codegen::ir::AbiParam;
use cranelift_jit::{JITBuilder, JITModule};
use cranelift_module::{Linkage, Module, default_libcall_names};

type Run = unsafe extern "C" fn(*mut u32, *const u64);

fn compile(width: usize, visits: usize) -> (JITModule, Run) {
    let mut module = JITModule::new(
        JITBuilder::with_flags(
            &[("opt_level", "speed"), ("regalloc_checker", "true")],
            default_libcall_names(),
        )
        .unwrap(),
    );
    let mut ctx = module.make_context();
    ctx.func.signature.params = vec![AbiParam::new(types::I64); 2];
    let entry = ctx.func.dfg.make_block();
    ctx.func.layout.append_block(entry);
    let bins = ctx.func.dfg.append_block_param(entry, types::I64);
    let input = ctx.func.dfg.append_block_param(entry, types::I64);
    let mut c = FuncCursor::new(&mut ctx.func).at_bottom(entry);
    let keys = (0..visits)
        .map(|at| {
            c.ins()
                .load(types::I64, MemFlags::new(), input, at as i32 * 8)
        })
        .collect::<Vec<_>>();
    batch(&mut c, bins, &keys, width);
    c.ins().return_(&[]);
    ctx.compute_cfg();
    ctx.verify(module.isa()).unwrap();
    let id = module
        .declare_function(
            "histogram_increment_batch",
            Linkage::Export,
            &ctx.func.signature,
        )
        .unwrap();
    module.define_function(id, &mut ctx).unwrap();
    module.finalize_definitions().unwrap();
    // The JIT signature above is exactly Run and remains owned by the module.
    let run = unsafe { core::mem::transmute::<*const u8, Run>(module.get_finalized_function(id)) };
    (module, run)
}

#[test]
fn gathered_counter_reads_preserve_collisions_wrapping_and_batch_boundaries() {
    let mut calls = 0;
    for visits in [1, 2, 3, 4, 5, 7, 8] {
        let compiled = [2, 4].map(|width| compile(width, visits));
        for pattern in 0..4352u64 {
            let mut random = pattern.wrapping_mul(0x9e3779b97f4a7c15).wrapping_add(1);
            let keys = (0..visits)
                .map(|at| {
                    random ^= random << 13;
                    random ^= random >> 7;
                    random ^= random << 17;
                    if pattern < 256 {
                        // All equality partitions of four visits, repeated
                        // across batches to exercise intervening stores.
                        (pattern >> (2 * (at % 4))) & 3
                    } else {
                        random & 511
                    }
                })
                .collect::<Vec<_>>();
            let seed = if pattern & 1 == 0 {
                u32::MAX - 3
            } else {
                pattern as u32
            };
            let initial = (0..512u32)
                .map(|at| seed.wrapping_add(at.wrapping_mul(0xfedcba97)))
                .collect::<Vec<_>>();
            let mut expected = initial.clone();
            for &key in &keys {
                expected[key as usize] = expected[key as usize].wrapping_add(1);
            }
            for (_, run) in &compiled {
                // A four-byte-aligned view need not be eight-byte aligned.
                let guard = 0xabcdef01;
                let mut actual = vec![guard; 514];
                actual[1..513].copy_from_slice(&initial);
                // Every key is within the live initialized 512-counter view.
                unsafe { run(actual[1..].as_mut_ptr(), keys.as_ptr()) };
                assert_eq!(&actual[1..513], &expected);
                assert_eq!((actual[0], actual[513]), (guard, guard));
                calls += 1;
            }
        }
    }
    assert_eq!(calls, 60_928);
}
