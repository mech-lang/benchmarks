//! Execute the conditional increment at both widths and all integer conditions.
use cranelift_codegen::ir::{AbiParam, InstBuilder, Type, condcodes::IntCC, types};
use cranelift_codegen::isa::Aarch64CompilationOptions;
use cranelift_codegen::settings::{self, Configurable};
use cranelift_frontend::{FunctionBuilder, FunctionBuilderContext};
use cranelift_jit::{JITBuilder, JITModule};
use cranelift_module::{Linkage, Module, default_libcall_names};

type Run = unsafe extern "C" fn(u64, u64, u64) -> u64;
const CONDITIONS: [IntCC; 10] = [
    IntCC::Equal,
    IntCC::NotEqual,
    IntCC::SignedLessThan,
    IntCC::SignedLessThanOrEqual,
    IntCC::SignedGreaterThan,
    IntCC::SignedGreaterThanOrEqual,
    IntCC::UnsignedLessThan,
    IntCC::UnsignedLessThanOrEqual,
    IntCC::UnsignedGreaterThan,
    IntCC::UnsignedGreaterThanOrEqual,
];
const WORDS: [u64; 20] = [
    0,
    1,
    31,
    127,
    128,
    255,
    256,
    0x7fff,
    0x8000,
    0xffff,
    0x1_0000,
    0x7fff_ffff,
    0x8000_0000,
    0xffff_ffff,
    0x1_0000_0000,
    i64::MAX as u64,
    i64::MIN as u64,
    u64::MAX - 31,
    u64::MAX - 1,
    u64::MAX,
];

fn compare(cc: IntCC, a: u64, b: u64, ty: Type) -> bool {
    let shift = 64 - ty.bits();
    let mask = u64::MAX >> shift;
    let (a, b) = (a & mask, b & mask);
    let signed = |value| ((value << shift) as i64) >> shift;
    match cc {
        IntCC::Equal => a == b,
        IntCC::NotEqual => a != b,
        IntCC::SignedLessThan => signed(a) < signed(b),
        IntCC::SignedLessThanOrEqual => signed(a) <= signed(b),
        IntCC::SignedGreaterThan => signed(a) > signed(b),
        IntCC::SignedGreaterThanOrEqual => signed(a) >= signed(b),
        IntCC::UnsignedLessThan => a < b,
        IntCC::UnsignedLessThanOrEqual => a <= b,
        IntCC::UnsignedGreaterThan => a > b,
        IntCC::UnsignedGreaterThanOrEqual => a >= b,
    }
}

fn compile(
    sum: Type,
    input: Type,
    cc: IntCC,
    commute: bool,
    opt: &str,
    enabled: bool,
) -> (JITModule, Run, String) {
    let mut flags = settings::builder();
    flags.set("opt_level", opt).unwrap();
    flags.set("regalloc_checker", "true").unwrap();
    let isa = cranelift_native::builder()
        .unwrap()
        .finish_with_aarch64_compilation_options(
            settings::Flags::new(flags),
            Aarch64CompilationOptions {
                conditional_increment: enabled,
                ..Default::default()
            },
        )
        .unwrap();
    let mut module = JITModule::new(JITBuilder::with_isa(isa, default_libcall_names()));
    let mut ctx = module.make_context();
    ctx.set_disasm(true);
    ctx.func.signature.params = vec![AbiParam::new(types::I64); 3];
    ctx.func.signature.returns = vec![AbiParam::new(types::I64)];
    let mut storage = FunctionBuilderContext::new();
    let mut b = FunctionBuilder::new(&mut ctx.func, &mut storage);
    let entry = b.create_block();
    b.append_block_params_for_function_params(entry);
    b.switch_to_block(entry);
    let [seed, left, right] = b.block_params(entry).try_into().unwrap();
    let (left, right) = if input == types::I64 {
        (left, right)
    } else {
        (b.ins().ireduce(input, left), b.ins().ireduce(input, right))
    };
    let condition = b.ins().icmp(cc, left, right);
    let increment = b.ins().uextend(sum, condition);
    let seed = if sum == types::I64 {
        seed
    } else {
        b.ins().ireduce(sum, seed)
    };
    let value = if commute {
        b.ins().iadd(increment, seed)
    } else {
        b.ins().iadd(seed, increment)
    };
    let value = if sum == types::I64 {
        value
    } else {
        b.ins().uextend(types::I64, value)
    };
    b.ins().return_(&[value]);
    b.seal_all_blocks();
    b.finalize();
    let id = module
        .declare_function("conditional_increment", Linkage::Local, &ctx.func.signature)
        .unwrap();
    module.define_function(id, &mut ctx).unwrap();
    let code = ctx.compiled_code().unwrap().vcode.as_ref().unwrap().clone();
    module.finalize_definitions().unwrap();
    // Run has exactly the declared native signature; the module owns its code.
    let run = unsafe { core::mem::transmute::<*const u8, Run>(module.get_finalized_function(id)) };
    (module, run, code)
}

#[test]
fn conditional_increment_preserves_comparisons_wrapping_and_zero_extension() {
    let mut calls = 0;
    for opt in ["none", "speed"] {
        for sum in [types::I32, types::I64] {
            for input in [types::I8, types::I16, types::I32, types::I64] {
                for cc in CONDITIONS {
                    for commute in [false, true] {
                        let (_module, run, code) = compile(sum, input, cc, commute, opt, true);
                        assert!(
                            code.split(";; REGALLOC_INPUT_BEGIN")
                                .next()
                                .unwrap()
                                .contains("cinc ")
                        );
                        for seed in WORDS {
                            for left in WORDS {
                                for right in WORDS {
                                    let value = seed
                                        .wrapping_add(u64::from(compare(cc, left, right, input)));
                                    let expected = if sum == types::I32 {
                                        u64::from(value as u32)
                                    } else {
                                        value
                                    };
                                    assert_eq!(
                                        unsafe { run(seed, left, right) },
                                        expected,
                                        "{sum} {input} {cc:?} {opt} commute={commute} seed={seed:x} left={left:x} right={right:x}"
                                    );
                                    calls += 1;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    assert_eq!(calls, 2_560_000);
}

#[test]
fn conditional_increment_stays_disabled_by_default() {
    for sum in [types::I32, types::I64] {
        let (_module, run, code) = compile(sum, types::I64, IntCC::Equal, false, "speed", false);
        assert!(
            !code
                .split(";; REGALLOC_INPUT_BEGIN")
                .next()
                .unwrap()
                .contains("cinc ")
        );
        assert_eq!(unsafe { run(u64::MAX, 7, 7) }, 0);
        assert_eq!(unsafe { run(19, 7, 8) }, 19);
    }
}
