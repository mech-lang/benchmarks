from pathlib import Path
from hashlib import file_digest,sha256
import json,subprocess
r=Path(__file__).resolve().parent;b=Path('/private/tmp/mech-m3-deflate-81-benchmarks/experiments/mech/mechdeflate-cranelift-v1');o=r/'source-experiments/group-four-appends';o.mkdir()
compiler=r/'clean-build-paired-appends/compile_profile'
with compiler.open('rb') as f:h=file_digest(f,'sha256').hexdigest()
receipt=json.loads((r/'clean-build-paired-appends/word-mismatch-order/receipt.json').read_text());assert h==receipt['compiler_sha256']
(o/'source.patch').write_text('');provenance={'source_head':receipt['source_commit'],'compiler_sha256':h,'source_patch':'source.patch','source_patch_sha256':sha256(b'').hexdigest(),'scope':'The clean, previously reproduced compiler from committed Mech source. Uses its existing four-literal append option. No uncommitted compiler prototype is used for these builds.'};pp=o/'compiler-source-receipt.json';pp.write_text(json.dumps(provenance,indent=2)+'\n')
symbol='mech_compact_numeric_3009_no_growth_composed'
def run(*args):print('COMMAND',*map(str,args),flush=True);subprocess.run(list(map(str,args)),check=True)
def build(name,s,capture=False,smoke=False):
 s=s.copy()
 if capture:
  c=r/('capture-'+name);c.mkdir();s['MECH_INSPECT_PHASE_REGISTER_PROFILE']=str(c/(symbol+'.vcode'));s['MECH_INSPECT_OPTIMIZED_PHASE_CLIF']=str(c/(symbol+'.clif'))
 p=r/'settings'/(name+'.json');p.write_text(json.dumps(s,indent=2)+'\n');run('python3','-B',r/'build-variant.py',name,'--settings',p,'--support-build',r/'clean-build-paired-appends','--compiler',compiler,'--compiler-provenance',pp)
 if smoke:
  v=r/'variants'/name;run('python3','-B','/private/tmp/mech-m3-81-20261124/smoke.py',v/'bound/mech-worker',v/'bound/metadata.json',o/(name+'-smoke.json'))
build('group-four-pinned-default-parity',{})
assert json.loads((r/'variants/group-four-pinned-default-parity/receipt.json').read_text())['artifacts']==receipt['artifacts']
base=json.loads((b/'word-mismatch-order/recipe.json').read_text())['roles']['word-mismatch-order']['settings_delta'];s=base|{'MECH_COMPACT_GROUP_FOUR_LITERAL_APPENDS':'1','MECH_COMPACT_PAIR_REGISTER_SPILLS':'1','MECH_COMPACT_PAIR_ADMITTED_APPEND_STORES':None,'MECH_COMPACT_CCMP_IMMEDIATES':None}
for key in ['MECH_COMPACT_PHASE_REGISTER_WEIGHTS','MECH_COMPACT_PHASE_BLOCK_LAYOUT']:s[key]=';'.join(x for x in s[key].split(';') if not x.startswith(symbol+'@'))
build('group-four-pinned-raw',s,True,True)
reg=r/'rebased-profiles/group-four-pinned-register.json';run('python3','-B',r/'transfer-register.py','--source',b/'word-mismatch-order/profiles/c1acb158a41536816386146f55e5be5e2ea9e8607c1dc78df41f900e40671bcd.json','--capture',r/'capture-group-four-pinned-raw'/(symbol+'.vcode'),'--output',reg);s['MECH_COMPACT_PHASE_REGISTER_WEIGHTS']+=';'+symbol+'@'+str(reg);build('group-four-pinned-weighted',s,True)
layout=r/'rebased-profiles/group-four-pinned-layout.json';run('python3','-B',r/'project-layout.py','--control',r/'variants/scorer-base-unlaid','--candidate',r/'variants/group-four-pinned-weighted','--old-capture',r/'capture-scorer-unlaid'/(symbol+'.vcode'),'--new-capture',r/'capture-group-four-pinned-weighted'/(symbol+'.vcode'),'--profile',b/'word-mismatch-order/profiles/069b98a9e53752e75cbe56873ef6e370b7a280bb773aac195536b37d39dab6b7.json','--mapping',reg.with_suffix('.proof.json'),'--output',layout,'--symbol',symbol)
edges=r/'rebased-profiles/group-four-pinned-edge-layout.json';run('python3','-B',r/'place-edge-copy-blocks-v2.py','--candidate',r/'variants/group-four-pinned-weighted','--profile',layout,'--output',edges)
for suffix,path,ccmp in [('-profiled',layout,False),('-edges',edges,False),('-ccmp-edges',edges,True)]:
 settings=s|{'MECH_COMPACT_PHASE_BLOCK_LAYOUT':s['MECH_COMPACT_PHASE_BLOCK_LAYOUT']+';'+symbol+'@'+str(path)}
 if ccmp:
  settings['MECH_COMPACT_CCMP_IMMEDIATES']='mech_compact_numeric_475_vector'
  for key,p in [('MECH_COMPACT_PHASE_REGISTER_WEIGHTS',r/'rebased-profiles/ccmp-immediates-register.json'),('MECH_COMPACT_PHASE_BLOCK_LAYOUT',r/'rebased-profiles/ccmp-immediates-fixed-extent.json')]:settings[key]=';'.join('mech_compact_numeric_475_vector@'+str(p) if part.startswith('mech_compact_numeric_475_vector@') else part for part in settings[key].split(';'))
 build('group-four-pinned'+suffix,settings,False,True)
