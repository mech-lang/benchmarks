from pathlib import Path
from hashlib import sha256
import json,shutil,subprocess
r=Path(__file__).resolve().parent;b=Path('/private/tmp/mech-m3-deflate-81-benchmarks/experiments/mech/mechdeflate-cranelift-v1');mech=Path('/Users/cim310/.codex/worktrees/level12-compile-profile/mech');symbol='mech_compact_numeric_3009_no_growth_composed';o=r/'source-experiments/group-four-appends';o.mkdir()
compiler=Path('/private/tmp/mech-m3-81-20261124/target/release/compile_profile');shutil.copyfile(compiler,o/'compile_profile');(o/'tracked.patch').write_text(subprocess.check_output(['git','diff'],cwd=mech,text=True))
for path in subprocess.check_output(['git','diff','--name-only'],cwd=mech,text=True).splitlines():
 target=o/path;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(mech/path,target)
(o/'source-receipt.json').write_text(json.dumps({'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=mech,text=True).strip(),'compiler_sha256':sha256(compiler.read_bytes()).hexdigest(),'focused_tests':'Existing append-run native mode matrix includes the four-visit option','scope':'Existing four-literal append loop, enabled on M3 with new source snapshots and conservative transferred profiles. Compressor source unchanged.'},indent=2)+'\n')
def run(*args):print('COMMAND',*map(str,args),flush=True);subprocess.run(list(map(str,args)),check=True)
def build(name,settings,capture=False):
 settings=settings.copy()
 if capture:
  d=r/('capture-'+name);d.mkdir();settings['MECH_INSPECT_PHASE_REGISTER_PROFILE']=str(d/(symbol+'.vcode'));settings['MECH_INSPECT_OPTIMIZED_PHASE_CLIF']=str(d/(symbol+'.clif'))
 p=r/'settings'/(name+'.json');p.write_text(json.dumps(settings,indent=2)+'\n');run('python3','-B',r/'build-variant.py',name,'--settings',p,'--support-build',r/'clean-build-paired-appends')
base=json.loads((b/'word-mismatch-order/recipe.json').read_text())['roles']['word-mismatch-order']['settings_delta']
for family in ['group-four-appends']:
 s=base.copy();s|={'MECH_COMPACT_GROUP_FOUR_LITERAL_APPENDS':'1','MECH_COMPACT_PAIR_REGISTER_SPILLS':'1','MECH_COMPACT_PAIR_ADMITTED_APPEND_STORES':None,'MECH_COMPACT_CCMP_IMMEDIATES':None}
 for key in ['MECH_COMPACT_PHASE_REGISTER_WEIGHTS','MECH_COMPACT_PHASE_BLOCK_LAYOUT']:s[key]=';'.join(v for v in s[key].split(';') if not v.startswith(symbol+'@'))
 build(family+'-raw',s,True)
 reg=r/'rebased-profiles'/(family+'-register.json');run('python3','-B',r/'transfer-register.py','--source',b/'word-mismatch-order/profiles/c1acb158a41536816386146f55e5be5e2ea9e8607c1dc78df41f900e40671bcd.json','--capture',r/('capture-'+family+'-raw')/(symbol+'.vcode'),'--output',reg)
 s['MECH_COMPACT_PHASE_REGISTER_WEIGHTS']+=';'+symbol+'@'+str(reg);build(family+'-weighted',s,True)
 layout=r/'rebased-profiles'/(family+'-layout.json');run('python3','-B',r/'project-layout.py','--control',r/'variants/scorer-base-unlaid','--candidate',r/'variants'/(family+'-weighted'),'--old-capture',r/'capture-scorer-unlaid'/(symbol+'.vcode'),'--new-capture',r/('capture-'+family+'-weighted')/(symbol+'.vcode'),'--profile',b/'word-mismatch-order/profiles/069b98a9e53752e75cbe56873ef6e370b7a280bb773aac195536b37d39dab6b7.json','--mapping',reg.with_suffix('.proof.json'),'--output',layout,'--symbol',symbol)
 s['MECH_COMPACT_PHASE_BLOCK_LAYOUT']+=';'+symbol+'@'+str(layout)
 for suffix,ccmp in [('-profiled',False),('-ccmp-fixed',True)]:
  settings=s.copy()
  if ccmp:
   settings['MECH_COMPACT_CCMP_IMMEDIATES']='mech_compact_numeric_475_vector'
   for key,path in [('MECH_COMPACT_PHASE_REGISTER_WEIGHTS',r/'rebased-profiles/ccmp-immediates-register.json'),('MECH_COMPACT_PHASE_BLOCK_LAYOUT',r/'rebased-profiles/ccmp-immediates-fixed-extent.json')]:settings[key]=';'.join('mech_compact_numeric_475_vector@'+str(path) if part.startswith('mech_compact_numeric_475_vector@') else part for part in settings[key].split(';'))
  name=family+suffix;build(name,settings);v=r/'variants'/name
  run('python3','-B','/private/tmp/mech-m3-81-20261124/smoke.py',v/'bound/mech-worker',v/'bound/metadata.json',o/(name+'-smoke.json'))
