"""Derive root allocation cost hints from untimed M3 instruction samples."""
import argparse, bisect, collections, difflib, hashlib, json, re, struct
from pathlib import Path

p=argparse.ArgumentParser(description=__doc__)
for name in ['normal','capture','vcode','samples','output']:p.add_argument('--'+name,type=Path,required=True)
p.add_argument('--equivalent',type=Path,action='append',default=[])
a=p.parse_args();a.output.mkdir(parents=True)
symbol='_mech_compact_closed_checked'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def body(path):
    data=path.read_bytes()
    magic,_,_,_,ncmds,_,_,_=struct.unpack_from('<8I',data)
    assert magic==0xfeedfacf
    sections=[];symtab=None;at=32
    for _ in range(ncmds):
        cmd,size=struct.unpack_from('<II',data,at)
        if cmd==0x19:
            nsects=struct.unpack_from('<I',data,at+64)[0]
            for i in range(nsects):
                raw=struct.unpack_from('<16s16sQQ8I',data,at+72+80*i)
                sections.append({'name':raw[0].split(b'\0')[0], 'seg':raw[1].split(b'\0')[0],
                                 'addr':raw[2],'bytes':raw[3],'offset':raw[4],
                                 'reloff':raw[6],'nreloc':raw[7]})
        elif cmd==2:symtab=struct.unpack_from('<4I',data,at+8)
        at+=size
    assert symtab is not None
    syms=[];symoff,count,stroff,_=symtab
    for i in range(count):
        name,ty,sect,desc,value=struct.unpack_from('<IBBHQ',data,symoff+16*i)
        start=stroff+name;end=data.index(0,start)
        syms.append((data[start:end].decode(),ty,sect,value))
    section_index,sec=next((i+1,s) for i,s in enumerate(sections) if s['name']==b'__text' and s['seg']==b'__TEXT')
    start=next(value for name,ty,sect,value in syms if name==symbol and sect==section_index)
    length=json.loads(path.with_name('metadata.json').read_text())['code_bytes']
    assert length%4==0
    rel=collections.defaultdict(list)
    for i in range(sec['nreloc']):
        offset,info=struct.unpack_from('<iI',data,sec['reloff']+8*i)
        assert offset>=0
        offset+=sec['addr']
        if start<=offset<start+length:
            target=syms[info&0xffffff][0] if info>>27&1 else info&0xffffff
            rel[(offset-start)//4].append((info>>24,target))
    tokens=[]
    for i in range(length//4):
        word=struct.unpack_from('<I',data,sec['offset']+start-sec['addr']+4*i)[0]
        if word&0x7c000000==0x14000000:word&=~0x3ffffff
        elif word&0xff000010==0x54000000 or word&0x7e000000==0x34000000 or word&0x3b000000==0x18000000:word&=~(0x7ffff<<5)
        elif word&0x7e000000==0x36000000:word&=~(0x3fff<<5)
        tokens.append((word,tuple(sorted(rel[i],key=str))))
    return tokens
normal,capture=body(a.normal),body(a.capture)
equivalent={sha(a.normal)}
for other in a.equivalent:
    assert body(other)==normal, 'Instruction/relocation identity required for every sample source'
    equivalent.add(sha(other))
matches=difflib.SequenceMatcher(None,normal,capture,autojunk=False).get_matching_blocks()
mapping={4*(x+i):4*(y+i) for x,y,n in matches for i in range(n)}
assert len(mapping)>=0.95*len(normal),(len(mapping),len(normal))
vc=a.vcode.read_text();expected=vc.split(';; REGALLOC_INPUT_BEGIN\n',1)[1].split(';; REGALLOC_INPUT_END\n',1)[0]
labels=[(int(i),int(offset)) for i,offset in re.findall(r'^;; REGALLOC_BLOCK (\d+) offset=(\d+) ',vc,re.M)]
assert [i for i,_ in labels]==list(range(len(labels)))
heads=sorted(set(offset for i,offset in labels))
def group(offset):return heads[max(0,bisect.bisect_right(heads,offset)-1)]
sites=collections.Counter(group(offset) for offset in mapping.values())
case_weights={'prefix-natural-1024':0.25,'16384-distribution-change':0.25,'mr':0.25,'x-ray':0.25}
case_costs={};evidence={}
for case,weight in case_weights.items():
    path=a.samples/case/'summary.json';report=json.loads(path.read_text())
    assert report['native_object_sha256'] in equivalent
    pcs={int(k):n for k,n in report['pcs'][symbol].items()}
    total=sum(pcs.values());assert total>0
    covered=sum(n for offset,n in pcs.items() if offset in mapping)
    assert covered>=0.95*total,(case,covered,total)
    costs=collections.defaultdict(float)
    for offset,n in pcs.items():
        if offset in mapping:costs[group(mapping[offset])]+=n/total
    case_costs[case]=costs
    evidence[case]={'source_sha256':sha(path),'samples':total,'mapped_samples':covered}
for name,weights in [('representative',case_weights),('short-weighted',{'prefix-natural-1024':0.35,'16384-distribution-change':0.35,'mr':0.2,'x-ray':0.1})]:
    density=[sum(weight*case_costs[case].get(group(offset),0) for case,weight in weights.items())/max(1,sites[group(offset)]) for i,offset in labels]
    peak=max(density);assert peak>0
    for scale,power,suffix in [(4096,1.0,'direct'),(64,0.5,'damped')]:
        freq=[max(1,round(scale*(x/peak)**power)) for x in density]
        profile={'expected_vcode':expected,'block_frequencies':freq}
        target=a.output/(name+'-'+suffix+'.json');target.write_text(json.dumps(profile,indent=2)+'\n')
        print(target.name,len(freq),sha(target))
proof={'method':__doc__+' These are sampled instruction-cost hints, not measured branch-entry frequencies. Branch displacements are normalized when matching the ordinary and inspected machine bodies. Empty block aliases inherit their shared instruction region. No historical LLVM-path data is used.',
       'equivalent_object_sha256':sorted(equivalent),'normal_object_sha256':sha(a.normal),'capture_object_sha256':sha(a.capture),'vcode_sha256':sha(a.vcode),
       'normal_words':len(normal),'mapped_words':len(mapping),'capture_words':len(capture),'blocks':len(labels),
       'sample_evidence':evidence,'normal_to_inspected_offsets':sorted(mapping.items())}
(a.output/'proof.json').write_text(json.dumps(proof,indent=2)+'\n')
