from pathlib import Path
from hashlib import sha256
import json,shutil,subprocess
r=Path(__file__).resolve().parent;mech=Path('/Users/cim310/.codex/worktrees/level12-compile-profile/mech')
o=r/'source-experiments/backedge-inversion';o.mkdir()
compiler=Path('/private/tmp/mech-m3-81-20261124/target/release/compile_profile');shutil.copyfile(compiler,o/'compile_profile')
(o/'tracked.patch').write_text(subprocess.check_output(['git','diff'],cwd=mech,text=True))
for path in ['hosts/gpu/src/native_artifact/program/codegen/cfg_cleanup/shift_counts.rs','hosts/gpu/src/native_artifact/program/codegen/cfg_cleanup/shift_counts/tests.rs']:
 dest=o/'untracked'/path;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(mech/path,dest)
(o/'source-receipt.json').write_text(json.dumps({'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=mech,text=True).strip(),'compiler_sha256':sha256(compiler.read_bytes()).hexdigest(),'new_backend_tests':3,'existing_backend_layout_tests':3,'focused_tests':11,'default_profile_remains_off':True},indent=2)+'\n')
# Confirm disabled new options still preserve the published CCMP artifact triple.
subprocess.run(['python3','-B',str(r/'build-variant.py'),'backedge-default-parity','--settings',str(r/'settings/ccmp-immediates-profiled.json')],check=True)
assert json.loads((r/'variants/backedge-default-parity/receipt.json').read_text())['artifacts']['program.o']=='02dc6f4bf03fbaa141d3e21e39ad04553c81b7af4d09c4cad13621057c0561b2'
b=Path('/private/tmp/mech-m3-deflate-81-benchmarks/experiments/mech/mechdeflate-cranelift-v1/word-mismatch-order/profiles/069b98a9e53752e75cbe56873ef6e370b7a280bb773aac195536b37d39dab6b7.json')
profile=r/'scorer-backedge-layout.json';profile.write_text(json.dumps(json.loads(b.read_text())|{'prefer_backedges':True},indent=2)+'\n')
for name,parent in [('scorer-backedge','ccmp-immediates-profiled'),('root-blend-backedge','root-prior-blend')]:
 settings=json.loads((r/'settings'/(parent+'.json')).read_text());symbol='mech_compact_numeric_3009_no_growth_composed'
 settings['MECH_COMPACT_PHASE_BLOCK_LAYOUT']=';'.join(symbol+'@'+str(profile) if p.startswith(symbol+'@') else p for p in settings['MECH_COMPACT_PHASE_BLOCK_LAYOUT'].split(';'))
 path=r/'settings'/(name+'.json');path.write_text(json.dumps(settings,indent=2)+'\n')
 subprocess.run(['python3','-B',str(r/'build-variant.py'),name,'--settings',str(path)],check=True)
 v=r/'variants'/name;subprocess.run(['python3','-B','/private/tmp/mech-m3-81-20261124/smoke.py',str(v/'bound/mech-worker'),str(v/'bound/metadata.json'),str(o/(name+'-smoke.json'))],check=True)
