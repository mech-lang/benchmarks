from pathlib import Path
import json,subprocess
r=Path(__file__).resolve().parent;o=r/'source-experiments/shift-counts'
for name,symbols in [('shift-inline-4879','mech_compact_numeric_4879'),('shift-inline-4673','mech_compact_numeric_4673_vector'),('shift-inline-none',None)]:
 s=json.loads((r/'settings/shift-counts.json').read_text())
 if symbols is None:s['MECH_COMPACT_INLINE_SINGLE_CALLS']=None
 else:s['MECH_COMPACT_INLINE_SYMBOLS']=symbols
 p=r/'settings'/(name+'.json');p.write_text(json.dumps(s,indent=2)+'\n')
 subprocess.run(['python3','-B',str(r/'build-variant.py'),name,'--settings',str(p)],check=True)
 v=r/'variants'/name
 subprocess.run(['python3','-B','/private/tmp/mech-m3-81-20261124/smoke.py',str(v/'bound/mech-worker'),str(v/'bound/metadata.json'),str(o/(name+'-smoke.json'))],check=True)
 d=json.loads((v/'frontend/metadata.json').read_text());print(name,'root code/frame',d['code_bytes'],d['stack_bytes'],flush=True)
