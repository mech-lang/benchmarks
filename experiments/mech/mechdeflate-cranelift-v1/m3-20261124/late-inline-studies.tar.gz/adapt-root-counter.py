from pathlib import Path
r=Path(__file__).resolve().parent
s=Path('/private/tmp/mech-m3-81-20261124/count-root.py').read_text()
a=s.index("r = Path('/private/tmp/mech-m3-81-20261124')");b=s.index("d = r / 'root-exact-counts'",a)
s=s[:a]+"r = Path('/private/tmp/mech-m3-cranelift-20261124')\n"+s[b:]
s=s.replace("d = r / 'root-exact-counts'","d = r / 'root-exact-counts-current'")
s=s.replace("tools = r / 'support/pure-counters'","tools = Path('/private/tmp/mech-m3-81-20261124/support/pure-counters')")
s=s.replace("source = r / 'final-aligned64'","source = r / 'variants/shift-counts'")
a=s.index("subprocess.run(['python3', '-B', str(r/'link-worker.py')");b=s.index("path = front / 'program.o'",a);s=s[:a]+s[b:]
s=s.replace("reference=d/'bound'","reference=source/'bound'")
s=s.replace("command=read(reference/'runtime.json')['command']","command=read(source/'receipt.json')['worker_command']")
a=s.index("cases=read(r/'comparison/fixtures.json')");b=s.index('report={}',a)
s=s[:a]+'''# This is an untimed training panel: unchanged 81 fixtures plus all 12 whole corpus files.
import zlib
cases=read(r/'baseline/suite81/fixtures.json')
empty=d/'empty-prefix';empty.write_bytes(b'')
corpus_cases=[]
for item in read(r/'silesia-inputs/corpus.json')['files']:
    name=item.get('name',item.get('filename'))
    path=r/'silesia-inputs'/name
    expected=d/(name+'.expected')
    stream=subprocess.check_output([r/'build/word-mismatch-order/silesia-encoder',path,'--verify'])
    assert zlib.decompress(stream,-15)==path.read_bytes()
    expected.write_bytes(stream)
    # Match the deployed encoder's empty output loan, which starts at capacity zero.
    corpus_cases.append({'name':'silesia-'+name,'input':str(path),'prefix':str(empty),'expected':str(expected),'capacity':0})
cases+=corpus_cases
fixtures=d/'fixtures.json';fixtures.write_text(json.dumps(cases,indent=2)+'\\n')
indices={v['name']:i for i,v in enumerate(cases)}
selected=list(indices)
'''+s[b:]
s=s.replace("str(reference/'metadata.json'),str(r/'comparison/fixtures.json')","str(front/'metadata.json'),str(fixtures)")
s=s.replace("assert visits==other and visits[0]==1 and not any(visits[len(leaders):])","assert visits==other and visits[0] in (0,1) and not any(visits[len(leaders):])\n    assert visits[0] or not any(visits)")
s=s.replace("report[case]={'invocations':1,'observations':2,", "report[case]={'invocations':1,'observations':2,'root_called':bool(visits[0]),'input_bytes':rows[0]['input_bytes'],")
needle="reference=source/'bound'"
s=s.replace(needle,"metadata=read(front/'metadata.json');metadata['stack_bytes']+=16;metadata['code_bytes']=len(body)\n(front/'metadata.json').write_text(json.dumps(metadata,indent=2)+'\\n')\n"+needle)
s=s.replace("'root_bytes':final-start,","'root_bytes':final-start,'diagnostic_stack_overhead_bytes':16,'diagnostic_only':True,'training_cases':len(selected),")
(r/'count-current-root.py').write_text(s)
print('adapted script')
