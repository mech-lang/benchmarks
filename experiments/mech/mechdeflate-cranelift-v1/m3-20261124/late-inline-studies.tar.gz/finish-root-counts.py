from pathlib import Path
from hashlib import sha256
import json, os, struct, subprocess, zlib
r=Path('/private/tmp/mech-m3-cranelift-20261124')
d=r/'root-exact-counts-current-v2'
shape_dir=r/'root-exact-count-shape'
src=(r/'count-current-root.py').read_text().split("reference=source/'bound'",1)[0]
assert src.count("d = r / 'root-exact-counts-current-v2'")==1
src=src.replace("d = r / 'root-exact-counts-current-v2'", "d = r / 'root-exact-count-shape'")
scope={}
exec(compile(src,'<regenerate-counter-shape>','exec'),scope)
sha=lambda p:sha256(Path(p).read_bytes()).hexdigest()
assert sha(shape_dir/'instrumented.o')==sha(d/'instrumented.o')
leaders=scope['leaders']; start=scope['start']; final=scope['final']
shape={'leaders':[pc-start for pc in leaders], 'root_bytes':final-start, 'direct_relocated_calls':len(scope['calls']),
       'unchanged_register_calls':len(scope['register_calls']), 'source_object_sha256':sha(r/'variants/shift-counts/frontend/program.o'),
       'instrumented_sha256':sha(d/'instrumented.o'), 'instrumentation_regenerated_identically':True}
(d/'shape.json').write_text(json.dumps(shape,indent=2)+'\n')
original=Path('/private/tmp/mech-m3-deflate-81-benchmarks/experiments/mech/mechdeflate-silesia-v1/timed_deployment.c')
c=original.read_text().replace('extern int deploy_encode', 'uint64_t mech_root_block_counts[4096] = {0};\n\nextern int deploy_encode')
c=c.replace('uint64_t start = now_ns();', 'memset(mech_root_block_counts, 0, sizeof(mech_root_block_counts));\n    uint64_t start = now_ns();')
c=c.replace('    int failed = 0;', '''    const char *counter_path = getenv("MECH_ROOT_COUNTER_OUT");
    if (!counter_path) return 7;
    FILE *counter_file = fopen(counter_path, "wb");
    if (!counter_file) return 7;
    size_t count_written = fwrite(mech_root_block_counts, sizeof(uint64_t), 4096, counter_file);
    int counter_close = fclose(counter_file);
    if (count_written != 4096 || counter_close != 0) return 7;
    int failed = 0;''')
(d/'counter-clock.c').write_text(c)
subprocess.run(['/usr/bin/clang','-arch','arm64','-mmacosx-version-min=15.0','-O2','-Wall','-Wextra','-Werror','-c',str(d/'counter-clock.c'),'-o',str(d/'counter-clock.o')],check=True)
receipt=json.loads((r/'variants/shift-counts/receipt.json').read_text())
command=receipt['silesia_link_command']
replacements={str(r/'build/silesia-support/clock.o'):str(d/'counter-clock.o'),str(r/'variants/shift-counts/bound/program.o'):str(d/'instrumented.o'),str(r/'variants/shift-counts/silesia-encoder'):str(d/'counter-encoder')}
assert set(replacements)<=set(command)
command=[replacements.get(a,a) for a in command]
subprocess.run(command,check=True)
(d/'corpus-counter-build.json').write_text(json.dumps({'command':command,'source_sha256':sha(d/'counter-clock.c'), 'encoder_sha256':sha(d/'counter-encoder'),'original_driver_sha256':sha(original),'diagnostic_only':True},indent=2)+'\n')
cases=json.loads((d/'fixtures.json').read_text())
report={}
for case in cases[:81]:
    rows=[json.loads(l) for l in (d/(case['name']+'.stdout')).read_text().splitlines() if l.startswith('{')]
    assert len(rows)==2
    assert all(row['exact_reference'] and row['independent_inflation'] and row['input_alias_unchanged'] and row['borrowed_output_alias_unchanged'] for row in rows)
    visits, other=[row['block_counts'] for row in rows]
    assert visits==other and visits[0] in (0,1) and not any(visits[len(leaders):])
    assert visits[0] or not any(visits)
    report[case['name']]={'invocations':1,'observations':2,'root_called':bool(visits[0]),'input_bytes':rows[0]['input_bytes'],'interface':'original fixture worker','blocks':[{'offset':pc-start,'visits':visits[i]} for i,pc in enumerate(leaders)]}
for case in cases[81:]:
    name=case['name']; expected=Path(case['expected']).read_bytes(); input_data=Path(case['input']).read_bytes()
    assert zlib.decompress(expected,-15)==input_data
    observations=[]
    for sample in range(2):
        counter_path=d/(name+f'.{sample}.counts.bin')
        env=os.environ.copy();env['MECH_ROOT_COUNTER_OUT']=str(counter_path)
        result=subprocess.run([str(d/'counter-encoder'),case['input'],'--verify'],env=env,capture_output=True)
        (d/(name+f'.{sample}.stderr')).write_bytes(result.stderr)
        assert result.returncode==0,(name,result.returncode,result.stderr)
        assert result.stdout==expected and zlib.decompress(result.stdout,-15)==input_data
        visits=list(struct.unpack('<4096Q',counter_path.read_bytes()))
        assert visits[0]==1 and not any(visits[len(leaders):])
        observations.append(visits)
    assert observations[0]==observations[1]
    visits=observations[0]
    report[name]={'invocations':1,'observations':2,'root_called':True,'input_bytes':len(input_data),'interface':'original deployed encoder, empty output loan','exact_reference':True,'independent_inflation':True,'blocks':[{'offset':pc-start,'visits':visits[i]} for i,pc in enumerate(leaders)]}
    print(name,'deterministic, exact and independently inflated',flush=True)
report_data=shape|{'symbol':'_mech_compact_closed_checked','diagnostic_stack_overhead_bytes':16,'diagnostic_only':True,'training_cases':len(report),'cases':report,
    'scope':'Untimed exact native root block-entry counts. Direct calls retain original external relocations; register-call instructions remain byte-identical. Local conditional edges expand with inverse condition and unconditional branch. Counters preserve x16, x17, SP, NZCV. The 81 fixture counts are recovered from successful recorded observations before an excluded corpus fixture-capacity assertion; corpus counts use the deployed encoder interface. Counts are never performance samples.',
    'excluded_attempts':[{'case':'silesia-dickens','worker':'fixture counter-worker','reason':'fixture worker requires returned output capacity to equal prepared capacity; corpus deployment intentionally starts with an empty output loan and grows it; use deployed encoder instead'}]}
(d/'counts.json').write_text(json.dumps(report_data,indent=2)+'\n')
print('complete',len(report),'cases; 186 verified observations',flush=True)
