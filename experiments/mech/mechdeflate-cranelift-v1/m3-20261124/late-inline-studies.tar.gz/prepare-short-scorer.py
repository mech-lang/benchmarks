from pathlib import Path
import json,subprocess
r=Path(__file__).resolve().parent
b=Path('/private/tmp/mech-m3-deflate-81-benchmarks/experiments/mech/mechdeflate-cranelift-v1')
symbol='mech_compact_numeric_3009_no_growth_composed'
o=r/'source-experiments/short-scorer';o.mkdir(exist_ok=True)
def run(*args):
 print('COMMAND',*map(str,args),flush=True);subprocess.run(list(map(str,args)),check=True)
variants=[('scorer-defer',{'MECH_ORDERED_PACK_WINNER_AT_EXIT':'1'}),('scorer-pair-tail',{'MECH_ORDERED_PAIRED_CONTINUATION':'sequential-tail'}),('scorer-pair-tail-defer',{'MECH_ORDERED_PAIRED_CONTINUATION':'sequential-tail','MECH_ORDERED_PACK_WINNER_AT_EXIT':'1'})]
for name,options in variants:
 s=json.loads((r/'settings/root-prior-blend.json').read_text())|options
 for key in ['MECH_COMPACT_PHASE_REGISTER_WEIGHTS','MECH_COMPACT_PHASE_BLOCK_LAYOUT']:
  s[key]=';'.join(x for x in s[key].split(';') if not x.startswith(symbol+'@'))
 def build(suffix,settings,capture=False):
  full=name+suffix;ss=settings.copy()
  if capture:
   d=r/('capture-'+full);d.mkdir()
   ss['MECH_INSPECT_PHASE_REGISTER_PROFILE']=str(d/(symbol+'.vcode'))
   ss['MECH_INSPECT_OPTIMIZED_PHASE_CLIF']=str(d/(symbol+'.clif'))
  path=r/'settings'/(full+'.json');path.write_text(json.dumps(ss,indent=2)+'\n')
  run('python3','-B',r/'build-variant.py',full,'--settings',path)
 build('-raw',s,True)
 reg=r/'rebased-profiles'/(name+'-register.json')
 run('python3','-B',r/'transfer-register.py','--source',b/'word-mismatch-order/profiles/c1acb158a41536816386146f55e5be5e2ea9e8607c1dc78df41f900e40671bcd.json','--capture',r/('capture-'+name+'-raw')/(symbol+'.vcode'),'--output',reg)
 s['MECH_COMPACT_PHASE_REGISTER_WEIGHTS']+=';'+symbol+'@'+str(reg)
 build('-weighted',s,True)
 layout=r/'rebased-profiles'/(name+'-layout.json')
 run('python3','-B',r/'project-layout.py','--control',r/'variants/scorer-base-unlaid','--candidate',r/'variants'/(name+'-weighted'),'--old-capture',r/'capture-scorer-unlaid'/(symbol+'.vcode'),'--new-capture',r/('capture-'+name+'-weighted')/(symbol+'.vcode'),'--profile',b/'word-mismatch-order/profiles/069b98a9e53752e75cbe56873ef6e370b7a280bb773aac195536b37d39dab6b7.json','--mapping',reg.with_suffix('.proof.json'),'--output',layout,'--symbol',symbol)
 s['MECH_COMPACT_PHASE_BLOCK_LAYOUT']+=';'+symbol+'@'+str(layout)
 build('-profiled',s)
 v=r/'variants'/(name+'-profiled')
 run('python3','-B','/private/tmp/mech-m3-81-20261124/smoke.py',v/'bound/mech-worker',v/'bound/metadata.json',o/(name+'-smoke.json'))
