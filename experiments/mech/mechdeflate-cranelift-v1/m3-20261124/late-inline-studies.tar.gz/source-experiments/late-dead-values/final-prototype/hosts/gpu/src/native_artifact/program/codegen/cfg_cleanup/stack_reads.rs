//! Recover the accessibility of fixed stack packets after private call inlining.
use cranelift_codegen::ir::{
    Function, InstructionData, Opcode, StackSlot, StackSlotKind, Value, ValueDef, types,
};

const ADDRESS_DEPTH: usize = 8;

#[derive(Clone, Copy, Eq, Ord, PartialEq, PartialOrd)]
pub(super) struct Window {
    pub slot: StackSlot,
    pub start: u32,
    pub bytes: u32,
}

pub(super) fn window(
    function: &Function,
    pointer: Value,
    offset: i32,
    bytes: u32,
) -> Option<Window> {
    let (slot, base) = address(function, pointer, ADDRESS_DEPTH)?;
    let data = function.sized_stack_slots.get(slot)?;
    if data.kind != StackSlotKind::ExplicitSlot || bytes == 0 {
        return None;
    }
    let start = base.checked_add(i64::from(offset))?;
    let end = start.checked_add(i64::from(bytes))?;
    (start >= 0 && end <= i64::from(data.size)).then_some(Window {
        slot,
        start: start as u32,
        bytes,
    })
}

fn constant(function: &Function, value: Value) -> Option<i64> {
    let value = function.dfg.resolve_aliases(value);
    if function.dfg.value_type(value) != types::I64 {
        return None;
    }
    let ValueDef::Result(inst, 0) = function.dfg.value_def(value) else {
        return None;
    };
    match function.dfg.insts[inst] {
        InstructionData::UnaryImm {
            opcode: Opcode::Iconst,
            imm,
            ..
        } => Some(imm.bits()),
        _ => None,
    }
}

fn address(function: &Function, value: Value, depth: usize) -> Option<(StackSlot, i64)> {
    if depth == 0 {
        return None;
    }
    let value = function.dfg.resolve_aliases(value);
    if function.dfg.value_type(value) != types::I64 {
        return None;
    }
    let ValueDef::Result(inst, 0) = function.dfg.value_def(value) else {
        return None;
    };
    let (base, delta) = match function.dfg.insts[inst] {
        InstructionData::StackLoad {
            opcode: Opcode::StackAddr,
            stack_slot,
            offset,
        } => {
            return Some((stack_slot, i64::from(i32::from(offset))));
        }
        InstructionData::BinaryImm64 {
            opcode: Opcode::IaddImm,
            arg,
            imm,
        } => (arg, imm.bits()),
        InstructionData::Binary {
            opcode: Opcode::Iadd,
            args: [left, right],
        } => {
            if let Some(delta) = constant(function, right) {
                (left, delta)
            } else {
                (right, constant(function, left)?)
            }
        }
        _ => return None,
    };
    let (slot, offset) = address(function, base, depth - 1)?;
    Some((slot, offset.checked_add(delta)?))
}

/// A fixed explicit slot is accessible for its declared extent, just as for
/// StackLoad. Recover only that fact, without assuming immutable contents,
/// extending a packet's lifetime, or changing any checks on external memory.
pub(in crate::native_artifact::program) fn accessible(
    function: &Function,
    inst: cranelift_codegen::ir::Inst,
) -> bool {
    let InstructionData::Load {
        opcode: Opcode::Load,
        arg,
        offset,
        ..
    } = function.dfg.insts[inst]
    else {
        return false;
    };
    let ty = function.dfg.value_type(function.dfg.first_result(inst));
    if ty.is_dynamic_vector() {
        return false;
    }
    window(function, arg, i32::from(offset), ty.bytes()).is_some()
}

pub(in crate::native_artifact::program) fn admit(function: &mut Function) -> usize {
    let mut admitted = Vec::new();
    for block in function.layout.blocks() {
        for inst in function.layout.block_insts(block) {
            if matches!(function.dfg.insts[inst], InstructionData::Load {flags, ..} if !flags.notrap())
                && accessible(function, inst)
            {
                admitted.push(inst);
            }
        }
    }
    for &inst in &admitted {
        let InstructionData::Load { flags, .. } = &mut function.dfg.insts[inst] else {
            unreachable!();
        };
        flags.set_notrap();
    }
    admitted.len()
}

#[cfg(test)]
#[path = "stack_reads/tests.rs"]
mod tests;
