use super::*;
use cranelift_codegen::{
    Context,
    ir::{AbiParam, InstBuilder, MemFlags, StackSlotData, StackSlotKind, condcodes::IntCC, types},
};
use cranelift_frontend::{FunctionBuilder, FunctionBuilderContext};
use cranelift_jit::{JITBuilder, JITModule};
use cranelift_module::{Linkage, Module, default_libcall_names};

fn module() -> JITModule {
    module_with_opt("speed")
}

fn module_with_opt(opt: &str) -> JITModule {
    JITModule::new(
        JITBuilder::with_flags(
            &[
                ("opt_level", opt),
                ("enable_verifier", "true"),
                ("regalloc_checker", "true"),
            ],
            default_libcall_names(),
        )
        .unwrap(),
    )
}

fn define(module: &mut JITModule, function: Function, name: &str) -> cranelift_module::FuncId {
    let mut context = Context::for_function(function);
    context.verify(module.isa()).unwrap();
    let id = module
        .declare_function(name, Linkage::Local, &context.func.signature)
        .unwrap();
    module.define_function(id, &mut context).unwrap();
    id
}

#[test]
fn forwarded_stack_reads_preserve_overlap_endianness_and_unknown_stores() {
    // AArch64 lowering does not implement opposite-endian Load. Check that
    // this pass retains that IR, and execute native-endian reads at speed.
    for (opt, read_endian, expected_forwarded) in [
        ("none", Endianness::Big, 2),
        ("speed", Endianness::Little, 3),
    ] {
        let mut module = module_with_opt(opt);
        let mut function = module.make_context().func;
        function.signature.params = vec![AbiParam::new(types::I64); 2];
        function.signature.returns.push(AbiParam::new(types::I64));
        let mut scratch = FunctionBuilderContext::new();
        let mut b = FunctionBuilder::new(&mut function, &mut scratch);
        let entry = b.create_block();
        let next = b.create_block();
        b.append_block_params_for_function_params(entry);
        b.switch_to_block(entry);
        let [external, input] = b.block_params(entry)[..] else {
            panic!()
        };
        let slot =
            b.create_sized_stack_slot(StackSlotData::new(StackSlotKind::ExplicitSlot, 32, 3));
        let base = b.ins().stack_addr(types::I64, slot, 0);
        let little = MemFlags::new().with_endianness(Endianness::Little);
        b.ins().store(little, input, base, 0);
        b.ins().jump(next, &[]);
        b.switch_to_block(next);
        let a = b.ins().load(types::I64, little, base, 0);
        let low = b.ins().ireduce(types::I32, input);
        b.ins().store(little, low, base, 4);
        let c = b.ins().load(types::I64, little, base, 0);
        let d = b.ins().load(types::I64, little, base, 0);
        b.ins().store(little, input, external, 0);
        let e = b.ins().load(types::I64, little, base, 0);
        b.ins().store(little, input, base, 16);
        let f = b.ins().load(
            types::I64,
            MemFlags::new().with_endianness(read_endian),
            base,
            16,
        );
        let c = b.ins().imul_imm(c, 3);
        let d = b.ins().imul_imm(d, 5);
        let e = b.ins().imul_imm(e, 7);
        let sum = b.ins().iadd(a, c);
        let sum = b.ins().iadd(sum, d);
        let sum = b.ins().iadd(sum, e);
        let sum = b.ins().iadd(sum, f);
        b.ins().return_(&[sum]);
        b.seal_all_blocks();
        b.finalize();
        let original_function = function.clone();
        assert_eq!(
            forward(&mut function, Endianness::Little),
            expected_forwarded
        );
        if read_endian == Endianness::Big {
            let retained = function.layout.blocks().flat_map(|block| function.layout.block_insts(block)).filter(|&inst| matches!(function.dfg.insts[inst], InstructionData::Load {flags, ..} if flags.endianness(Endianness::Little) == Endianness::Big)).count();
            assert_eq!(retained, 1);
            Context::for_function(function)
                .verify(module.isa())
                .unwrap();
            continue;
        }
        let original = define(&mut module, original_function, "stack_original");
        let optimized = define(&mut module, function, "stack_forwarded");
        module.finalize_definitions().unwrap();
        type Entry = unsafe extern "C" fn(*mut u64, u64) -> u64;
        // SAFETY: both finalized functions have this exact native signature.
        let calls = [original, optimized].map(|id| unsafe {
            std::mem::transmute::<*const u8, Entry>(module.get_finalized_function(id))
        });
        for value in [0, 1, 0x0123456789abcdef, 1u64 << 63, u64::MAX] {
            let packed = (value as u32 as u64).wrapping_mul(0x100000001);
            let expected = value.wrapping_add(packed.wrapping_mul(15)).wrapping_add(
                if read_endian == Endianness::Big {
                    value.swap_bytes()
                } else {
                    value
                },
            );
            for call in calls {
                let mut external = 0;
                // SAFETY: the external word is live and writable for the call.
                assert_eq!(unsafe { call(&mut external, value) }, expected);
                assert_eq!(external, value);
            }
        }
    }
}

extern "C" fn change(word: *mut u64) {
    // SAFETY: the generated caller passes its live, initialized stack word.
    unsafe {
        *word ^= 0x315a8e6f7b4c2901;
    }
}

#[test]
fn joins_and_calls_discard_cached_stack_values() {
    let mut module = module();
    let mut function = module.make_context().func;
    function.signature.params = vec![AbiParam::new(types::I64); 3];
    function.signature.returns.push(AbiParam::new(types::I64));
    let mut call_signature = module.make_signature();
    call_signature.params.push(AbiParam::new(types::I64));
    let call_signature = function.import_signature(call_signature);
    let mut scratch = FunctionBuilderContext::new();
    let mut b = FunctionBuilder::new(&mut function, &mut scratch);
    let entry = b.create_block();
    let left = b.create_block();
    let right = b.create_block();
    let join = b.create_block();
    b.append_block_params_for_function_params(entry);
    b.switch_to_block(entry);
    let [input, branch, callback] = b.block_params(entry)[..] else {
        panic!()
    };
    let slot = b.create_sized_stack_slot(StackSlotData::new(StackSlotKind::ExplicitSlot, 8, 3));
    let base = b.ins().stack_addr(types::I64, slot, 0);
    b.ins().store(MemFlags::new(), input, base, 0);
    b.ins().brif(branch, left, &[], right, &[]);
    b.switch_to_block(left);
    b.ins().jump(join, &[]);
    b.switch_to_block(right);
    b.ins().jump(join, &[]);
    b.switch_to_block(join);
    let first = b.ins().load(types::I64, MemFlags::new(), base, 0);
    b.ins().call_indirect(call_signature, callback, &[base]);
    let second = b.ins().load(types::I64, MemFlags::new(), base, 0);
    let third = b.ins().load(types::I64, MemFlags::new(), base, 0);
    let sum = b.ins().iadd(first, second);
    let sum = b.ins().iadd(sum, third);
    b.ins().return_(&[sum]);
    b.seal_all_blocks();
    b.finalize();
    assert_eq!(forward(&mut function, Endianness::Little), 1);
    let id = define(&mut module, function, "stack_calls");
    module.finalize_definitions().unwrap();
    // SAFETY: the live generated entry has this native signature.
    let call: unsafe extern "C" fn(u64, u64, usize) -> u64 =
        unsafe { std::mem::transmute(module.get_finalized_function(id)) };
    for value in [0, 1, 0x0123456789abcdef, u64::MAX] {
        for branch in [0, 1] {
            let expected = value.wrapping_add((value ^ 0x315a8e6f7b4c2901).wrapping_mul(2));
            // SAFETY: change is the exact callback accepted by this entry.
            assert_eq!(
                unsafe { call(value, branch, change as *const () as usize) },
                expected
            );
        }
    }
}

#[test]
fn loop_headers_do_not_reuse_a_previous_iteration() {
    let mut module = module();
    let mut function = module.make_context().func;
    function.signature.params = vec![AbiParam::new(types::I64); 2];
    function.signature.returns.push(AbiParam::new(types::I64));
    let mut scratch = FunctionBuilderContext::new();
    let mut b = FunctionBuilder::new(&mut function, &mut scratch);
    let entry = b.create_block();
    let header = b.create_block();
    let body = b.create_block();
    let done = b.create_block();
    b.append_block_params_for_function_params(entry);
    b.append_block_param(header, types::I64);
    b.switch_to_block(entry);
    let [input, count] = b.block_params(entry)[..] else {
        panic!()
    };
    let slot = b.create_sized_stack_slot(StackSlotData::new(StackSlotKind::ExplicitSlot, 8, 3));
    let base = b.ins().stack_addr(types::I64, slot, 0);
    b.ins().store(MemFlags::new(), input, base, 0);
    let zero = b.ins().iconst(types::I64, 0);
    b.ins().jump(header, &[zero.into()]);
    b.switch_to_block(header);
    let index = b.block_params(header)[0];
    let current = b.ins().load(types::I64, MemFlags::new(), base, 0);
    let more = b.ins().icmp(IntCC::UnsignedLessThan, index, count);
    b.ins().brif(more, body, &[], done, &[]);
    b.switch_to_block(body);
    let next = b.ins().iadd_imm(current, 1);
    b.ins().store(MemFlags::new(), next, base, 0);
    let index = b.ins().iadd_imm(index, 1);
    b.ins().jump(header, &[index.into()]);
    b.switch_to_block(done);
    b.ins().return_(&[current]);
    b.seal_all_blocks();
    b.finalize();
    assert_eq!(forward(&mut function, Endianness::Little), 0);
    let id = define(&mut module, function, "stack_loop");
    module.finalize_definitions().unwrap();
    // SAFETY: the live generated entry has this native signature.
    let call: unsafe extern "C" fn(u64, u64) -> u64 =
        unsafe { std::mem::transmute(module.get_finalized_function(id)) };
    for value in [0, 1, u64::MAX] {
        for count in 0..5 {
            // SAFETY: this entry accesses only its own initialized stack word.
            assert_eq!(unsafe { call(value, count) }, value.wrapping_add(count));
        }
    }
}
