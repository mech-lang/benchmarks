//! Forward fixed private stack cells along already processed single-predecessor edges.
use super::stack_reads::{Window, window};
use cranelift_codegen::{
    flowgraph::ControlFlowGraph,
    ir::{Endianness, Function, InstructionData, Opcode, Type, Value},
};
use std::{collections::BTreeMap, rc::Rc};

const MAX_CELLS: usize = 128;

#[derive(Clone, Copy)]
struct Stored {
    value: Value,
    ty: Type,
    endian: Endianness,
}

fn remember(state: &mut Rc<BTreeMap<Window, Stored>>, cell: Window, value: Stored) {
    let state = Rc::make_mut(state);
    if state.len() >= MAX_CELLS && !state.contains_key(&cell) {
        state.clear();
    }
    state.insert(cell, value);
}

pub(in crate::native_artifact::program) fn forward(
    function: &mut Function,
    native_endian: Endianness,
) -> usize {
    if function.layout.blocks().any(|block| {
        function
            .layout
            .block_insts(block)
            .any(|inst| function.dfg.insts[inst].exception_table().is_some())
    }) {
        return 0;
    }
    let cfg = ControlFlowGraph::with_function(function);
    let empty = Rc::new(BTreeMap::new());
    let mut exits = vec![None::<Rc<BTreeMap<Window, Stored>>>; function.dfg.num_blocks()];
    let mut forwarded = 0;
    for block in function.layout.blocks().collect::<Vec<_>>() {
        let mut predecessors = cfg.pred_iter(block);
        let unique = predecessors
            .next()
            .filter(|_| predecessors.next().is_none());
        let mut state = unique
            .and_then(|pred| exits[pred.block.as_u32() as usize].clone())
            .unwrap_or_else(|| empty.clone());
        for inst in function.layout.block_insts(block).collect::<Vec<_>>() {
            let data = function.dfg.insts[inst];
            match data {
                InstructionData::Load {
                    opcode: Opcode::Load,
                    flags,
                    arg,
                    offset,
                } => {
                    let result = function.dfg.first_result(inst);
                    let ty = function.dfg.value_type(result);
                    if ty.is_dynamic_vector() {
                        continue;
                    }
                    let Some(cell) = window(function, arg, i32::from(offset), ty.bytes()) else {
                        continue;
                    };
                    let endian = flags.endianness(native_endian);
                    if let Some(stored) = state
                        .get(&cell)
                        .filter(|stored| stored.ty == ty && stored.endian == endian)
                    {
                        let value = function.dfg.resolve_aliases(stored.value);
                        function.dfg.detach_inst_results(inst);
                        function.dfg.change_to_alias(result, value);
                        function.layout.remove_inst(inst);
                        forwarded += 1;
                    } else {
                        remember(
                            &mut state,
                            cell,
                            Stored {
                                value: result,
                                ty,
                                endian,
                            },
                        );
                    }
                }
                InstructionData::Store {
                    opcode: Opcode::Store,
                    flags,
                    args: [value, pointer],
                    offset,
                } => {
                    let ty = function.dfg.value_type(value);
                    let cell = (!ty.is_dynamic_vector())
                        .then(|| window(function, pointer, i32::from(offset), ty.bytes()))
                        .flatten();
                    if let Some(cell) = cell {
                        Rc::make_mut(&mut state).retain(|other, _| {
                            other.slot != cell.slot
                                || other.start + other.bytes <= cell.start
                                || cell.start + cell.bytes <= other.start
                        });
                        remember(
                            &mut state,
                            cell,
                            Stored {
                                value,
                                ty,
                                endian: flags.endianness(native_endian),
                            },
                        );
                    } else {
                        state = empty.clone();
                    }
                }
                _ if data.opcode().is_call()
                    || data.opcode().can_store()
                    || data.opcode().other_side_effects() =>
                {
                    state = empty.clone()
                }
                _ => {}
            }
        }
        exits[block.as_u32() as usize] = Some(state);
    }
    forwarded
}

#[cfg(test)]
#[path = "stack_forwarding/tests.rs"]
mod tests;
