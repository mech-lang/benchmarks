use super::*;
use cranelift_codegen::ir::{AbiParam, InstBuilder, MemFlags, StackSlotData, types};
use cranelift_frontend::{FunctionBuilder, FunctionBuilderContext};

#[test]
fn only_complete_fixed_stack_windows_gain_accessibility() {
    let mut function = Function::new();
    function.signature.params = vec![AbiParam::new(types::I64); 2];
    let mut state = FunctionBuilderContext::new();
    let mut b = FunctionBuilder::new(&mut function, &mut state);
    let entry = b.create_block();
    b.append_block_params_for_function_params(entry);
    b.switch_to_block(entry);
    let args = b.block_params(entry).to_vec();
    let slot = b.create_sized_stack_slot(StackSlotData::new(StackSlotKind::ExplicitSlot, 32, 3));
    let base = b.ins().stack_addr(types::I64, slot, 0);
    let mut cases = Vec::new();
    let narrow_pointer = b.ins().stack_addr(types::I32, slot, 0);
    cases.push((b.ins().load(types::I64, MemFlags::new(), narrow_pointer, 0), false));
    cases.push((b.ins().load(types::I64, MemFlags::new(), base, 0), true));
    cases.push((b.ins().load(types::I32, MemFlags::new(), base, 28), true));
    cases.push((b.ins().load(types::I64, MemFlags::new(), base, 28), false));
    cases.push((b.ins().load(types::I64, MemFlags::new(), base, -1), false));
    let shifted = b.ins().iadd_imm(base, 24);
    cases.push((b.ins().load(types::I64, MemFlags::new(), shifted, 0), true));
    let eight = b.ins().iconst(types::I64, 8);
    let commuted = b.ins().iadd(eight, base);
    cases.push((
        b.ins().load(types::I64, MemFlags::new(), commuted, 16),
        true,
    ));
    let overflow = b.ins().iadd_imm(base, i64::MAX);
    let overflow = b.ins().iadd_imm(overflow, 1);
    cases.push((
        b.ins().load(types::I64, MemFlags::new(), overflow, 0),
        false,
    ));
    cases.push((b.ins().load(types::I64, MemFlags::new(), args[0], 0), false));
    let dynamic = b.ins().iadd(base, args[1]);
    cases.push((b.ins().load(types::I64, MemFlags::new(), dynamic, 0), false));
    let mut deep = base;
    for _ in 0..ADDRESS_DEPTH {
        deep = b.ins().iadd_imm(deep, 0);
    }
    cases.push((b.ins().load(types::I64, MemFlags::new(), deep, 0), false));
    cases.push((b.ins().load(types::I8X16, MemFlags::new(), base, 16), true));
    b.ins().return_(&[]);
    b.seal_all_blocks();
    b.finalize();

    assert_eq!(
        admit(&mut function),
        cases.iter().filter(|(_, yes)| *yes).count()
    );
    for (value, expected) in cases {
        let ValueDef::Result(inst, 0) = function.dfg.value_def(value) else {
            panic!()
        };
        let InstructionData::Load { flags, .. } = function.dfg.insts[inst] else {
            panic!()
        };
        assert_eq!(flags.notrap(), expected, "{value}");
        assert!(!flags.readonly());
    }
    assert_eq!(admit(&mut function), 0);
}

#[test]
fn inlined_packet_reads_retire_without_changing_live_results() {
    use cranelift_codegen::{
        inline::{Inline, InlineCommand},
        ir::{ExternalName, FuncRef, Inst},
    };
    use cranelift_jit::{JITBuilder, JITModule};
    use cranelift_module::{Linkage, Module, default_libcall_names};
    use std::borrow::Cow;

    struct Body(Function);
    impl Inline for Body {
        fn inline(
            &mut self,
            _: &Function,
            _: Inst,
            _: Opcode,
            _: FuncRef,
            _: &[Value],
        ) -> InlineCommand<'_> {
            InlineCommand::Inline {
                callee: Cow::Borrowed(&self.0),
                visit_callee: false,
            }
        }
    }
    let mut module = JITModule::new(
        JITBuilder::with_flags(
            &[
                ("opt_level", "speed"),
                ("enable_verifier", "true"),
                ("regalloc_checker", "true"),
            ],
            default_libcall_names(),
        )
        .unwrap(),
    );
    let mut body = Function::new();
    body.signature = module.make_signature();
    body.signature.params.push(AbiParam::new(types::I64));
    body.signature.returns = vec![AbiParam::new(types::I64); 2];
    let mut scratch = FunctionBuilderContext::new();
    let mut b = FunctionBuilder::new(&mut body, &mut scratch);
    let entry = b.create_block();
    b.append_block_params_for_function_params(entry);
    b.switch_to_block(entry);
    let packet = b.block_params(entry)[0];
    let first = b.ins().load(types::I64, MemFlags::new(), packet, 0);
    let unused = b.ins().load(types::I64, MemFlags::new(), packet, 8);
    b.ins().return_(&[first, unused]);
    b.seal_all_blocks();
    b.finalize();

    let mut context = module.make_context();
    context
        .func
        .signature
        .params
        .push(AbiParam::new(types::I64));
    context
        .func
        .signature
        .returns
        .push(AbiParam::new(types::I64));
    let signature = context.func.import_signature(body.signature.clone());
    let callee = context
        .func
        .import_function(cranelift_codegen::ir::ExtFuncData {
            name: ExternalName::testcase("packet"),
            signature,
            colocated: true,
            patchable: false,
        });
    let mut scratch = FunctionBuilderContext::new();
    let mut b = FunctionBuilder::new(&mut context.func, &mut scratch);
    let entry = b.create_block();
    b.append_block_params_for_function_params(entry);
    b.switch_to_block(entry);
    let input = b.block_params(entry)[0];
    let slot = b.create_sized_stack_slot(StackSlotData::new(StackSlotKind::ExplicitSlot, 16, 3));
    b.ins().stack_store(input, slot, 0);
    b.ins().stack_store(input, slot, 8);
    let packet = b.ins().stack_addr(types::I64, slot, 0);
    let call = b.ins().call(callee, &[packet]);
    let value = b.inst_results(call)[0];
    b.ins().return_(&[value]);
    b.seal_all_blocks();
    b.finalize();

    assert!(context.inline(Body(body)).unwrap());
    assert_eq!(admit(&mut context.func), 2);
    let removed = super::super::dead_values::eliminate(&mut context.func);
    assert_eq!(removed.loads, 1);
    context.verify(module.isa()).unwrap();
    let id = module
        .declare_function(
            "inlined_stack_packet",
            Linkage::Local,
            &context.func.signature,
        )
        .unwrap();
    module.define_function(id, &mut context).unwrap();
    module.finalize_definitions().unwrap();
    // SAFETY: the live module owns this exact native signature.
    let call: unsafe extern "C" fn(u64) -> u64 =
        unsafe { std::mem::transmute(module.get_finalized_function(id)) };
    for value in [0, 1, 7, u32::MAX as u64, 1u64 << 63, u64::MAX] {
        // SAFETY: this entry takes one scalar and dereferences only its own stack packet.
        assert_eq!(unsafe { call(value) }, value);
    }
}
