//! Recover the accessibility of fixed stack packets after private call inlining.
use cranelift_codegen::ir::{
    Function, InstructionData, Opcode, StackSlot, StackSlotKind, Value, ValueDef, types,
};

const ADDRESS_DEPTH: usize = 8;

fn constant(function: &Function, value: Value) -> Option<i64> {
    let value = function.dfg.resolve_aliases(value);
    if function.dfg.value_type(value) != types::I64 {
        return None;
    }
    let ValueDef::Result(inst, 0) = function.dfg.value_def(value) else {
        return None;
    };
    match function.dfg.insts[inst] {
        InstructionData::UnaryImm {
            opcode: Opcode::Iconst,
            imm,
            ..
        } => Some(imm.bits()),
        _ => None,
    }
}

fn address(function: &Function, value: Value, depth: usize) -> Option<(StackSlot, i64)> {
    if depth == 0 {
        return None;
    }
    let value = function.dfg.resolve_aliases(value);
    if function.dfg.value_type(value) != types::I64 {
        return None;
    }
    let ValueDef::Result(inst, 0) = function.dfg.value_def(value) else {
        return None;
    };
    let (base, delta) = match function.dfg.insts[inst] {
        InstructionData::StackLoad {
            opcode: Opcode::StackAddr,
            stack_slot,
            offset,
        } => {
            return Some((stack_slot, i64::from(i32::from(offset))));
        }
        InstructionData::BinaryImm64 {
            opcode: Opcode::IaddImm,
            arg,
            imm,
        } => (arg, imm.bits()),
        InstructionData::Binary {
            opcode: Opcode::Iadd,
            args: [left, right],
        } => {
            if let Some(delta) = constant(function, right) {
                (left, delta)
            } else {
                (right, constant(function, left)?)
            }
        }
        _ => return None,
    };
    let (slot, offset) = address(function, base, depth - 1)?;
    Some((slot, offset.checked_add(delta)?))
}

/// A fixed explicit slot is accessible for its declared extent, just as for
/// StackLoad. Recover only that fact, without assuming immutable contents,
/// extending a packet's lifetime, or changing any checks on external memory.
pub(in crate::native_artifact::program) fn admit(function: &mut Function) -> usize {
    let mut admitted = Vec::new();
    for block in function.layout.blocks() {
        for inst in function.layout.block_insts(block) {
            let InstructionData::Load {
                opcode: Opcode::Load,
                flags,
                arg,
                offset,
            } = function.dfg.insts[inst]
            else {
                continue;
            };
            if flags.notrap() {
                continue;
            }
            let Some((slot, base)) = address(function, arg, ADDRESS_DEPTH) else {
                continue;
            };
            let Some(data) = function.sized_stack_slots.get(slot) else {
                continue;
            };
            if data.kind != StackSlotKind::ExplicitSlot {
                continue;
            }
            let ty = function.dfg.value_type(function.dfg.first_result(inst));
            if ty.is_dynamic_vector() {
                continue;
            }
            let width = i64::from(ty.bytes());
            let start = base.checked_add(i64::from(i32::from(offset)));
            if width != 0
                && start.is_some_and(|start| {
                    start >= 0
                        && start
                            .checked_add(width)
                            .is_some_and(|end| end <= i64::from(data.size))
                })
            {
                admitted.push(inst);
            }
        }
    }
    for &inst in &admitted {
        let InstructionData::Load { flags, .. } = &mut function.dfg.insts[inst] else {
            unreachable!();
        };
        flags.set_notrap();
    }
    admitted.len()
}

#[cfg(test)]
#[path = "stack_reads/tests.rs"]
mod tests;
