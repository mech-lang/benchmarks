//! Integer shifts already reduce their count modulo the shifted word's width.
use cranelift_codegen::ir::{Function, InstructionData, Opcode, Value, ValueDef, types};

fn constant(function: &Function, value: Value) -> Option<u64> {
    let value = function.dfg.resolve_aliases(value);
    let ValueDef::Result(inst, 0) = function.dfg.value_def(value) else {
        return None;
    };
    match function.dfg.insts[inst] {
        InstructionData::UnaryImm {
            opcode: Opcode::Iconst,
            imm,
            ..
        } => Some(imm.bits() as u64),
        _ => None,
    }
}

fn unmask(function: &Function, value: Value, low_bits: u64) -> Option<Value> {
    let value = function.dfg.resolve_aliases(value);
    let ValueDef::Result(inst, 0) = function.dfg.value_def(value) else {
        return None;
    };
    let (source, mask) = match function.dfg.insts[inst] {
        InstructionData::BinaryImm64 {
            opcode: Opcode::BandImm,
            arg,
            imm,
        } => (arg, imm.bits() as u64),
        InstructionData::Binary {
            opcode: Opcode::Band,
            args: [left, right],
        } => {
            if let Some(mask) = constant(function, right) {
                (left, mask)
            } else {
                (right, constant(function, left)?)
            }
        }
        _ => return None,
    };
    (mask & low_bits == low_bits).then_some(source)
}

pub(in crate::native_artifact::program) fn simplify(function: &mut Function) -> usize {
    let mut changed = 0;
    for block in function.layout.blocks().collect::<Vec<_>>() {
        for inst in function.layout.block_insts(block).collect::<Vec<_>>() {
            let InstructionData::Binary {
                opcode: Opcode::Ishl | Opcode::Ushr | Opcode::Sshr,
                args: [_, mut count],
            } = function.dfg.insts[inst]
            else {
                continue;
            };
            let ty = function.dfg.value_type(function.dfg.first_result(inst));
            if !matches!(ty, types::I32 | types::I64) {
                continue;
            }
            let bits = ty.bits();
            let mut removed = 0;
            for _ in 0..8 {
                let Some(source) = unmask(function, count, u64::from(bits - 1)) else {
                    break;
                };
                count = source;
                removed += 1;
            }
            if removed != 0 {
                let InstructionData::Binary { args, .. } = &mut function.dfg.insts[inst] else {
                    unreachable!();
                };
                args[1] = count;
                changed += removed;
            }
        }
    }
    changed
}

#[cfg(test)]
#[path = "shift_counts/tests.rs"]
mod tests;
