use super::*;
use cranelift_codegen::ir::{AbiParam, InstBuilder, MemFlags, Type, types};
use cranelift_frontend::{FunctionBuilder, FunctionBuilderContext};
use cranelift_jit::{JITBuilder, JITModule};
use cranelift_module::{Linkage, Module, default_libcall_names};

fn reference(ty: Type, op: Opcode, value: u64, count: u64, mask: i64) -> (u64, u64) {
    let bits = ty.bits();
    let word_mask = u64::MAX >> (64 - bits);
    let value = value & word_mask;
    let masked = (count & word_mask) & (mask as u64 & word_mask);
    let shift = (masked & u64::from(bits - 1)) as u32;
    let result = match op {
        Opcode::Ishl => value.wrapping_shl(shift),
        Opcode::Ushr => value.wrapping_shr(shift),
        Opcode::Sshr => {
            let signed = ((value << (64 - bits)) as i64) >> (64 - bits);
            (signed >> shift) as u64
        }
        _ => unreachable!(),
    };
    (result & word_mask, masked)
}

#[test]
fn shift_masks_preserve_wrapping_signedness_shared_uses_and_narrow_controls() {
    type Run = unsafe extern "C" fn(u64, u64, *mut u64) -> u64;
    for opt in ["none", "speed"] {
        let mut module = JITModule::new(
            JITBuilder::with_flags(
                &[
                    ("opt_level", opt),
                    ("enable_verifier", "true"),
                    ("regalloc_checker", "true"),
                ],
                default_libcall_names(),
            )
            .unwrap(),
        );
        let mut functions = Vec::new();
        let mut serial = 0;
        for ty in [types::I8, types::I16, types::I32, types::I64] {
            let low = i64::from(ty.bits() - 1);
            for op in [Opcode::Ishl, Opcode::Ushr, Opcode::Sshr] {
                for mask in [low, low | 0x100, -1, low & !1, 0] {
                    for form in 0..3 {
                        for shared in [false, true] {
                            let mut context = module.make_context();
                            context.func.signature.params = vec![AbiParam::new(types::I64); 3];
                            context
                                .func
                                .signature
                                .returns
                                .push(AbiParam::new(types::I64));
                            let mut scratch = FunctionBuilderContext::new();
                            let mut b = FunctionBuilder::new(&mut context.func, &mut scratch);
                            let entry = b.create_block();
                            b.append_block_params_for_function_params(entry);
                            b.switch_to_block(entry);
                            let [value, count, output] = b.block_params(entry)[..] else {
                                panic!()
                            };
                            let value = if ty == types::I64 {
                                value
                            } else {
                                b.ins().ireduce(ty, value)
                            };
                            let count = if ty == types::I64 {
                                count
                            } else {
                                b.ins().ireduce(ty, count)
                            };
                            let masked = if form == 0 {
                                b.ins().band_imm(count, mask)
                            } else {
                                let literal = b.ins().iconst(ty, mask);
                                if form == 1 {
                                    b.ins().band(count, literal)
                                } else {
                                    b.ins().band(literal, count)
                                }
                            };
                            let result = match op {
                                Opcode::Ishl => b.ins().ishl(value, masked),
                                Opcode::Ushr => b.ins().ushr(value, masked),
                                Opcode::Sshr => b.ins().sshr(value, masked),
                                _ => unreachable!(),
                            };
                            if shared {
                                let saved = if ty == types::I64 {
                                    masked
                                } else {
                                    b.ins().uextend(types::I64, masked)
                                };
                                b.ins().store(MemFlags::new(), saved, output, 0);
                            }
                            let result = if ty == types::I64 {
                                result
                            } else {
                                b.ins().uextend(types::I64, result)
                            };
                            b.ins().return_(&[result]);
                            b.seal_all_blocks();
                            b.finalize();
                            let expected = usize::from(
                                matches!(ty, types::I32 | types::I64)
                                    && mask as u64 & low as u64 == low as u64,
                            );
                            assert_eq!(simplify(&mut context.func), expected);
                            assert_eq!(simplify(&mut context.func), 0);
                            context.verify(module.isa()).unwrap();
                            let id = module
                                .declare_function(
                                    &format!("shift_count_{serial}"),
                                    Linkage::Local,
                                    &context.func.signature,
                                )
                                .unwrap();
                            serial += 1;
                            module.define_function(id, &mut context).unwrap();
                            functions.push((id, ty, op, mask, shared));
                        }
                    }
                }
            }
        }
        module.finalize_definitions().unwrap();
        for (id, ty, op, mask, shared) in functions {
            // SAFETY: the finalized entry has the signature above and the module stays live.
            let call: Run = unsafe { std::mem::transmute(module.get_finalized_function(id)) };
            for value in [
                0,
                1,
                0x0123456789abcdef,
                u32::MAX as u64,
                i64::MAX as u64,
                i64::MIN as u64,
                u64::MAX,
            ] {
                for count in [
                    0,
                    1,
                    7,
                    8,
                    15,
                    16,
                    31,
                    32,
                    33,
                    63,
                    64,
                    65,
                    127,
                    128,
                    u32::MAX as u64,
                    i64::MIN as u64,
                    u64::MAX,
                ] {
                    let (result, saved) = reference(ty, op, value, count, mask);
                    let mut output = 0xdeadbeef;
                    // SAFETY: output is a live writable U64 and all other inputs are scalars.
                    assert_eq!(
                        unsafe { call(value, count, &mut output) },
                        result,
                        "{ty} {op:?} mask={mask} value={value} count={count}"
                    );
                    assert_eq!(output, if shared { saved } else { 0xdeadbeef });
                }
            }
        }
    }
}

#[test]
fn nested_count_masks_are_bounded_and_leave_other_operations_intact() {
    let mut function = Function::new();
    function.signature.params = vec![AbiParam::new(types::I64); 2];
    function.signature.returns.push(AbiParam::new(types::I64));
    let mut scratch = FunctionBuilderContext::new();
    let mut b = FunctionBuilder::new(&mut function, &mut scratch);
    let entry = b.create_block();
    b.append_block_params_for_function_params(entry);
    b.switch_to_block(entry);
    let [value, mut count] = b.block_params(entry)[..] else {
        panic!()
    };
    for _ in 0..12 {
        count = b.ins().band_imm(count, 63);
    }
    let result = b.ins().ushr(value, count);
    b.ins().return_(&[result]);
    b.seal_all_blocks();
    b.finalize();
    assert_eq!(simplify(&mut function), 8);
    assert_eq!(simplify(&mut function), 4);
    assert_eq!(simplify(&mut function), 0);
}
