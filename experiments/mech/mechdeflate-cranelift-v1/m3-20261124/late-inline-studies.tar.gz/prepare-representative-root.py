from pathlib import Path
import json,math,subprocess
r=Path(__file__).resolve().parent;o=r/'representative-root-weights';o.mkdir()
static=json.loads((r/'root-prior-weights/static.json').read_text());summary=[]
for name,cost,prior in [('representative-half','representative-damped',0.5),('representative-prior','representative-damped',0.75),('short-weighted-half','short-weighted-damped',0.5)]:
 sample=json.loads((r/'representative-root-costs'/(cost+'.json')).read_text());assert sample['expected_vcode']==static['expected_vcode'];assert len(sample['block_frequencies'])==len(static['block_frequencies'])
 freq=[max(1,round(s**prior*p**(1-prior))) for s,p in zip(static['block_frequencies'],sample['block_frequencies'])]
 profile={'expected_vcode':static['expected_vcode'],'block_frequencies':freq};path=o/(name+'.json');path.write_text(json.dumps(profile,indent=2)+'\n')
 summary.append({'name':name,'structural_exponent':prior,'sample_cost_profile':cost,'peak_weight':max(freq),'blocks':len(freq)})
 s=json.loads((r/'settings/root-prior-blend.json').read_text());s['MECH_COMPACT_PHASE_REGISTER_WEIGHTS']=';'.join(x for x in s['MECH_COMPACT_PHASE_REGISTER_WEIGHTS'].split(';') if not x.startswith('mech_compact_closed_checked@'));s['MECH_COMPACT_PHASE_REGISTER_WEIGHTS']+=';mech_compact_closed_checked@'+str(path)
 settings=r/'settings'/('root-'+name+'.json');settings.write_text(json.dumps(s,indent=2)+'\n')
 subprocess.run(['python3','-B',str(r/'build-variant.py'),'root-'+name,'--settings',str(settings)],check=True)
 v=r/'variants'/('root-'+name);subprocess.run(['python3','-B','/private/tmp/mech-m3-81-20261124/smoke.py',str(v/'bound/mech-worker'),str(v/'bound/metadata.json'),str(o/(name+'-smoke.json'))],check=True)
 d=json.loads((v/'frontend/metadata.json').read_text());summary[-1]|={'root_code_bytes':d['code_bytes'],'root_frame_bytes':d['stack_bytes']}
(o/'method.json').write_text(json.dumps({'scope':'Allocation cost hints from representative Cranelift instruction samples, regularized by the reproduced structural loop prior; not branch-entry counts.','variants':summary},indent=2)+'\n')
