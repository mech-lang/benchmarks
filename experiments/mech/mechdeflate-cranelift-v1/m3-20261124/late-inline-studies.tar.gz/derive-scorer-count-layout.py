"""Derive a checked leaf layout from output-verified native block counts."""
from pathlib import Path
from collections import defaultdict
from hashlib import sha256
import json
r=Path(__file__).resolve().parent
data=json.loads((r/'scorer-exact-counts-current/counts.json').read_text())
shape=json.loads((r/'scorer-layout-shape.json').read_text());heads=shape['heads'];blocks=shape['blocks'];n=len(heads)
assert heads==data['leaders'] and shape['object_sha256']==data['source_object_sha256']
read=lambda p:json.loads(p.read_text())
old_path=Path('/private/tmp/mech-m3-deflate-81-benchmarks/experiments/mech/mechdeflate-cranelift-v1/word-mismatch-order/profiles/069b98a9e53752e75cbe56873ef6e370b7a280bb773aac195536b37d39dab6b7.json')
old=read(old_path);assert sorted(old['order'])==heads
edges={};ins=defaultdict(list);outs=defaultdict(list)
for i,(kind,taken,fall) in enumerate(blocks):
 for slot,dest in enumerate([taken,fall]):
  if dest is not None:
   edge=(i,slot);edges[edge]=dest;outs[i].append(edge);ins[dest].append(edge)
def infer(case):
 counts=[block['visits'] for block in case['blocks']];known={}
 for e,dest in edges.items():
  if not counts[e[0]] or not counts[dest]:known[e]=0
 while True:
  before=len(known)
  for node,adj in outs.items():
   unknown=[e for e in adj if e not in known];remaining=counts[node]-sum(known.get(e,0) for e in adj)
   assert remaining>=0
   if len(unknown)==1:known[unknown[0]]=remaining
  for node,adj in ins.items():
   unknown=[e for e in adj if e not in known];remaining=counts[node]-(case['invocations'] if node==0 else 0)-sum(known.get(e,0) for e in adj)
   assert remaining>=0,(node,remaining)
   if len(unknown)==1:known[unknown[0]]=remaining
  if before==len(known):break
 return counts,known
bycase={name:infer(case) for name,case in data['cases'].items()}
active=[name for name,(counts,_) in bycase.items() if sum(counts)]
suites=[[name for name in active if not name.startswith('silesia-')],[name for name in active if name.startswith('silesia-')]]
nodefreq=[0.0]*n;edgefreq=defaultdict(float);unknown=[]
for cases in suites:
 for name in cases:
  counts,known=bycase[name];weight=0.5/len(cases)/sum(counts)
  for i,count in enumerate(counts):nodefreq[i]+=weight*count
  for e,dest in edges.items():
   if e in known:edgefreq[e]+=weight*known[e]
   else:
    # Explicit estimate only for flows underdetermined by block-entry counts.
    edgefreq[e]+=weight*min(counts[e[0]],counts[dest])/len(outs[e[0]])
    unknown.append((name,e))
thread={heads.index(int(at)):heads.index(dest) for at,dest in shape['one_hop_threading'].items()}
collapse=lambda node:thread.get(node,node)
score=defaultdict(float)
for e,dest in edges.items():
 source=e[0]
 if source in thread:continue
 dest=collapse(dest)
 if source!=dest:score[source,dest]+=edgefreq[e]
# In a conditional self-loop, the exit's adjacency removes an unconditional
# backedge on every continuing iteration. Score that saving by loop traffic.
for i,(kind,taken,fall) in enumerate(blocks):
 if kind[0]=='condition':
  a,b=collapse(taken),collapse(fall)
  if a==i and b!=i:score[i,b]=max(score[i,b],nodefreq[i])
  if b==i and a!=i:score[i,a]=max(score[i,a],nodefreq[i])
chains={i:[i] for i in range(n) if i not in thread};owner={i:i for i in chains}
for (a,b),weight in sorted(score.items(),key=lambda v:(-v[1],v[0])):
 x,y=owner[a],owner[b]
 if x==y or chains[x][-1]!=a or chains[y][0]!=b or b==0:continue
 merged=chains.pop(x)+chains.pop(y);chains[x]=merged
 for node in merged:owner[node]=x
first=owner[0];order=chains.pop(first)
while chains:
 end=order[-1]
 chosen=max(chains,key=lambda c:(score.get((end,chains[c][0]),0),sum(nodefreq[i] for i in chains[c])/max(1,sum((heads[i+1] if i+1<n else shape['code_end'])-heads[i] for i in chains[c])),-heads[chains[c][0]]))
 order+=chains.pop(chosen)
order=[heads[i] for i in order]+[heads[i] for i in sorted(thread)]
assert order[0]==0 and sorted(order)==heads
profile={'order':order,'literal_offset':shape['pool'],'thread_jumps':True}
(r/'scorer-count-layout.json').write_text(json.dumps(profile,indent=2)+'\n')
def dynamic_branches(profile,counts,known):
 order=[heads.index(pc) for pc in profile['order'] if heads.index(pc) not in thread];total=0;unresolved=[]
 for pos,i in enumerate(order):
  following=order[pos+1] if pos+1<len(order) else None
  kind,taken,fall=blocks[i];c=counts[i]
  if kind[0]=='condition':
   a,b=collapse(taken),collapse(fall)
   if a==b:
    if following!=a:total+=c
   else:
    total+=c
    if following not in (a,b):
     edge=(i,1)
     if edge in known:total+=known[edge]
     else:unresolved.append(edge)
  elif kind[0] in ('next','jump'):
   dest=collapse(taken if taken is not None else fall)
   if following!=dest:total+=c
 return total,unresolved
predictions={}
for name,(counts,known) in bycase.items():
 before,bad1=dynamic_branches(old,counts,known);after,bad2=dynamic_branches(profile,counts,known)
 short=read(r/'scorer-short-loop-layout.json');short_count,bad3=dynamic_branches(short,counts,known)
 predictions[name]={'old_dynamic_branches':before,'short_loop_dynamic_branches':short_count,'count_layout_dynamic_branches':after,'underdetermined_contributions':len(bad1)+len(bad2)+len(bad3)}
proof={'method':__doc__+' Infer edges by nonnegative integer flow conservation where unique, and mark underdetermined edges. Half the aggregation weight goes to equally normalized fixture cases, half to equally normalized full corpus files. Merge traces by descending flow, keeping the entry first. Conditional self-loop exits receive adjacency priority to avoid an extra unconditional backedge.', 'counts_sha256':sha256((r/'scorer-exact-counts-current/counts.json').read_bytes()).hexdigest(),'profile_sha256':sha256((r/'scorer-count-layout.json').read_bytes()).hexdigest(),'source_shape':shape,'underdetermined_edges':unknown,'inferred_edges':{name:len(known) for name,(counts,known) in bycase.items()},'total_edges':len(edges),'predicted_dynamic_branches':predictions}
(r/'scorer-count-layout-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
for name in ['prefix-natural-1024','16384-distribution-change','silesia-mr']:print(name,predictions[name])
print('under-determined',len(unknown),'of',len(edges)*len(active))
