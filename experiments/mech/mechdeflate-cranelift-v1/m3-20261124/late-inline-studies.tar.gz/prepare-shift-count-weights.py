from pathlib import Path
import json,subprocess
r=Path(__file__).resolve().parent;o=r/'source-experiments/shift-counts'
def run(*args):
 print('COMMAND',*map(str,args),flush=True);subprocess.run(list(map(str,args)),check=True)
run('python3','-B',r/'build-variant.py','shift-counts-default-parity','--settings',r/'settings/ccmp-immediates-profiled.json')
a=json.loads((r/'variants/shift-counts-default-parity/receipt.json').read_text())['artifacts'];assert a['program.o']=='02dc6f4bf03fbaa141d3e21e39ad04553c81b7af4d09c4cad13621057c0561b2'
s=json.loads((r/'settings/shift-counts.json').read_text());s['MECH_COMPACT_ROUTE_DUMP']=str(r/'capture-shift-counts');path=r/'settings/shift-counts-capture.json';path.write_text(json.dumps(s,indent=2)+'\n')
run('python3','-B',r/'build-variant.py','shift-counts-capture','--settings',path)
for name,old in [('shift-counts-root-blend',r/'root-prior-weights/blend.json'),('shift-counts-root-representative',r/'representative-root-weights/representative-prior.json')]:
 reg=r/'rebased-profiles'/(name+'.json');run('python3','-B',r/'transfer-register.py','--source',old,'--capture',r/'capture-shift-counts/native-vcode.asm','--output',reg)
 s=json.loads((r/'settings/shift-counts.json').read_text());s['MECH_COMPACT_PHASE_REGISTER_WEIGHTS']+=';mech_compact_closed_checked@'+str(reg)
 path=r/'settings'/(name+'.json');path.write_text(json.dumps(s,indent=2)+'\n')
 run('python3','-B',r/'build-variant.py',name,'--settings',path)
 v=r/'variants'/name;run('python3','-B','/private/tmp/mech-m3-81-20261124/smoke.py',v/'bound/mech-worker',v/'bound/metadata.json',o/(name+'-smoke.json'))
