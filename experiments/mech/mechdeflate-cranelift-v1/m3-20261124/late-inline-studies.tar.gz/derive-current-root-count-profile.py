"""Derive allocation frequencies from current, output-verified native block counts."""
from pathlib import Path
from hashlib import sha256
import ast,bisect,collections,difflib,json,re,struct,subprocess
r=Path('/private/tmp/mech-m3-cranelift-20261124')
out=r/'root-current-count-profiles';out.mkdir()
sha=lambda p:sha256(Path(p).read_bytes()).hexdigest()
# Reuse only the self-contained Mach-O body tokenizer, never historical profile data.
source=r/'derive-root-representative-weights.py'
nodes=[n for n in ast.parse(source.read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='body']
assert len(nodes)==1
symbol='_mech_compact_closed_checked'
exec(compile(ast.Module(body=nodes,type_ignores=[]),str(source),'exec'),globals())
normal_path=r/'variants/shift-counts/frontend/program.o';capture_path=r/'variants/shift-counts-capture/frontend/program.o'
a,b=body(normal_path),body(capture_path)
matches=difflib.SequenceMatcher(None,a,b,autojunk=False).get_matching_blocks()
mapping={4*(y+i):4*(x+i) for x,y,n in matches for i in range(n)}
assert len(mapping)==len(a),(len(mapping),len(a))
vcode_path=r/'capture-shift-counts/native-vcode.asm';vcode=vcode_path.read_text()
expected=vcode.split(';; REGALLOC_INPUT_BEGIN\n',1)[1].split(';; REGALLOC_INPUT_END\n',1)[0]
labels=[(int(i),int(at)) for i,at in re.findall(r'^;; REGALLOC_BLOCK (\d+) offset=(\d+) ',vcode,re.M)]
assert [i for i,at in labels]==list(range(len(labels)))
counts_path=r/'root-exact-counts-current-v2/counts.json';data=json.loads(counts_path.read_text())
assert data['source_object_sha256']==sha(normal_path) and data['training_cases']==93
heads=data['leaders'];mapped=[]
for label,at in labels:
    word=mapping.get(at)
    mapped.append(None if word is None else bisect.bisect_right(heads,word)-1)
raws={}
case_vectors={name:[block['visits'] for block in case['blocks']] for name,case in data['cases'].items()}
for case in data['cases'].values():assert [block['offset'] for block in case['blocks']]==heads
raws['invocation-sum']=[sum(visits[i] for visits in case_vectors.values()) for i in range(len(heads))]
active=[name for name,visits in case_vectors.items() if sum(visits)]
suites={'fixtures':[name for name in active if not name.startswith('silesia-')], 'silesia':[name for name in active if name.startswith('silesia-')]}
raws['suite-balanced']=[sum(0.5*sum(case_vectors[name][i]/sum(case_vectors[name]) for name in cases)/len(cases) for cases in suites.values()) for i in range(len(heads))]
for name,raw in raws.items():
    weights=[0 if native is None else raw[native] for native in mapped];peak=max(weights)
    profile={'expected_vcode':expected,'block_frequencies':[max(1,round(4096*n/peak)) for n in weights],
       'scope':'Exact native block-entry frequencies measured from this current Cranelift object, with deterministic output-verified observations. Eliminated VCode tails receive one; zero-size VCode aliases inherit their machine block count.',
       'aggregation':name,'training_cases':list(case_vectors),'native_counts_sha256':sha(counts_path),'training_object_sha256':data['source_object_sha256']}
    (out/(name+'.json')).write_text(json.dumps(profile,indent=2)+'\n')
proof={'normal_object_sha256':sha(normal_path),'capture_object_sha256':sha(capture_path),'normal_words':len(a),'capture_words':len(b),'matched_normal_words':len(mapping),'allocation_blocks':len(labels),'mapped_blocks':sum(v is not None for v in mapped),'allocation_block_native_block':mapped,'active_suites':suites,'counts_sha256':sha(counts_path),'vcode_sha256':sha(vcode_path),'policy':'Invocation-sum adds all visits per complete invocation. Suite-balanced gives each active fixture equal weight within one half of the training distribution and each full-corpus file equal weight within the other half, normalizing each case by total visited blocks. Both scale maximum weight to 4096 and floor cold blocks at one.'}
(out/'proof.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps({k:v for k,v in proof.items() if k not in ['allocation_block_native_block','active_suites']}),flush=True)
for profile in raws:
    name='shift-root-counts-'+profile
    settings=json.loads((r/'settings/shift-counts.json').read_text())
    settings['MECH_COMPACT_PHASE_REGISTER_WEIGHTS']+=';mech_compact_closed_checked@'+str(out/(profile+'.json'))
    path=r/'settings'/(name+'.json');path.write_text(json.dumps(settings,indent=2)+'\n')
    subprocess.run(['python3','-B',str(r/'build-variant.py'),name,'--settings',str(path)],check=True)
    v=r/'variants'/name
    subprocess.run(['python3','-B','/private/tmp/mech-m3-81-20261124/smoke.py',str(v/'bound/mech-worker'),str(v/'bound/metadata.json'),str(out/(name+'-smoke.json'))],check=True)
    meta=json.loads((v/'frontend/metadata.json').read_text());print(name,'root',meta['code_bytes'],'frame',meta['stack_bytes'],flush=True)
