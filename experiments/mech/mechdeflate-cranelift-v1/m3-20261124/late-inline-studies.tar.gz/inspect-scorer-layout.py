from pathlib import Path
import json,subprocess,re
r=Path('/private/tmp/mech-m3-cranelift-20261124')
p=Path('/private/tmp/mech-m3-81-20261124/rebase-spill-layout.py')
ns={'__file__':str(p)};exec(compile(p.read_text().split('parser=argparse.ArgumentParser')[0],str(p),'exec'),ns)
ns['SYMBOL']='mech_compact_numeric_3009_no_growth_composed';shape=ns['shape'](r/'variants/shift-scorer-unlaid')
heads=shape['heads'];blocks=shape['blocks']
# Same one-hop pure-jump threading as the existing compiler.
jump={heads[i]:heads[dest] for i,(kind,dest,fall) in enumerate(blocks) if kind[0]=='jump'}
thread={pc:dest for pc,dest in jump.items() if pc!=0 and dest not in jump}
collapsed=lambda at:thread.get(at,at)
print('heads',len(heads),'pool',shape['pool'],'threaded',len(thread))
for i,(kind,taken,fall) in enumerate(blocks):
 if kind[0]!='condition':continue
 successors=[collapsed(heads[x]) for x in [taken,fall]]
 if heads[i] in successors:
  print('selfloop',heads[i],'end',heads[i+1] if i+1<len(heads) else shape['code_end'],'successors',successors,'exit',[x for x in successors if x!=heads[i]])
(d:=r/'scorer-layout-shape.json').write_text(json.dumps(shape|{'one_hop_threading':thread},indent=2)+'\n')
