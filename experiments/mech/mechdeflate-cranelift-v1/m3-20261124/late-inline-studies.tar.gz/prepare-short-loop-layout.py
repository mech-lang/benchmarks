from pathlib import Path
from hashlib import sha256
import json,subprocess
r=Path(__file__).resolve().parent
base=Path('/private/tmp/mech-m3-deflate-81-benchmarks/experiments/mech/mechdeflate-cranelift-v1/word-mismatch-order/profiles/069b98a9e53752e75cbe56873ef6e370b7a280bb773aac195536b37d39dab6b7.json')
p=json.loads(base.read_text());shape=json.loads((r/'scorer-layout-shape.json').read_text());assert sorted(p['order'])==shape['heads']
order=p['order'].copy();order.remove(312);order.insert(order.index(1076)+1,312)
profile=r/'scorer-short-loop-layout.json';profile.write_text(json.dumps(p|{'order':order},indent=2)+'\n')
proof={'change':'Move the scalar reduction loop exit block immediately after its self-loop body, after existing one-hop jump threading. This permits a single conditional backedge rather than a conditional exit and an unconditional backedge. All other block ordering is preserved.', 'original_profile_sha256':sha256(base.read_bytes()).hexdigest(),'shape':shape,'loop_body':1076,'exit':312,'new_profile_sha256':sha256(profile.read_bytes()).hexdigest()}
(r/'scorer-short-loop-layout-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
for name,settings_name in [('scorer-short-loop','ccmp-immediates-profiled'),('root-blend-short-loop','root-prior-blend')]:
 settings=json.loads((r/'settings'/(settings_name+'.json')).read_text());symbol='mech_compact_numeric_3009_no_growth_composed'
 settings['MECH_COMPACT_PHASE_BLOCK_LAYOUT']=';'.join(symbol+'@'+str(profile) if part.startswith(symbol+'@') else part for part in settings['MECH_COMPACT_PHASE_BLOCK_LAYOUT'].split(';'))
 path=r/'settings'/(name+'.json');path.write_text(json.dumps(settings,indent=2)+'\n')
 subprocess.run(['python3','-B',str(r/'build-variant.py'),name,'--settings',str(path)],check=True)
 v=r/'variants'/name
 subprocess.run(['python3','-B','/private/tmp/mech-m3-81-20261124/smoke.py',str(v/'bound/mech-worker'),str(v/'bound/metadata.json'),str(r/(name+'-smoke.json'))],check=True)
