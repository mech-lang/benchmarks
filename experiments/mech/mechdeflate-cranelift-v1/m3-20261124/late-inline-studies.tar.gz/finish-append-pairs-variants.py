from pathlib import Path
import json,subprocess
r=Path(__file__).resolve().parent
s=json.loads((r/'settings/append-pairs-profiled.json').read_text());s['MECH_COMPACT_ROOT_TAIL_PROFILE']=None
c=s.copy();c['MECH_COMPACT_ROUTE_DUMP']=str(r/'capture-append-pairs-root')
p=r/'settings/append-pairs-root-capture.json';p.write_text(json.dumps(c,indent=2)+'\n')
def run(*args):print('COMMAND',*map(str,args),flush=True);subprocess.run(list(map(str,args)),check=True)
run('python3','-B',r/'build-variant.py','append-pairs-root-capture','--settings',p)
reg=r/'rebased-profiles/append-pairs-root-register.json'
run('python3','-B',r/'transfer-register.py','--source',r/'root-prior-weights/blend.json','--capture',r/'capture-append-pairs-root/native-vcode.asm','--output',reg)
s['MECH_COMPACT_PHASE_REGISTER_WEIGHTS']+=';mech_compact_closed_checked@'+str(reg)
for name,backedge in [('append-pairs-root-blend-v2',False),('append-pairs-root-backedge',True)]:
 settings=s.copy()
 if backedge:
  old=r/'rebased-profiles/append-pairs-layout.json';new=r/'rebased-profiles/append-pairs-backedge-layout.json';new.write_text(json.dumps(json.loads(old.read_text())|{'prefer_backedges':True},indent=2)+'\n');settings['MECH_COMPACT_PHASE_BLOCK_LAYOUT']=settings['MECH_COMPACT_PHASE_BLOCK_LAYOUT'].replace(str(old),str(new))
 p=r/'settings'/(name+'.json');p.write_text(json.dumps(settings,indent=2)+'\n');run('python3','-B',r/'build-variant.py',name,'--settings',p)
 v=r/'variants'/name;run('python3','-B','/private/tmp/mech-m3-81-20261124/smoke.py',v/'bound/mech-worker',v/'bound/metadata.json',r/'source-experiments/append-store-pairs'/(name+'-smoke.json'))
