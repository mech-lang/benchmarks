"""Untimed diagnostic block counts for the current Cranelift scorer before layout."""
from pathlib import Path
from hashlib import sha256
from struct import pack,pack_into,unpack_from
from types import SimpleNamespace
import ast,json,os,re,shutil,struct,subprocess,zlib
r=Path('/private/tmp/mech-m3-cranelift-20261124')
source=r/'variants/shift-scorer-unlaid'
s=json.loads((r/'settings/shift-counts.json').read_text())
s['MECH_COMPACT_PHASE_BLOCK_LAYOUT']=';'.join(v for v in s['MECH_COMPACT_PHASE_BLOCK_LAYOUT'].split(';') if not v.startswith('mech_compact_numeric_3009_no_growth_composed@'))
settings=r/'settings/shift-scorer-unlaid.json';settings.write_text(json.dumps(s,indent=2)+'\n')
assert source.is_dir()  # reuse the completed, receipted preparation
# Initialize the identical checked object normalizer and alignment-preserving atom replacement.
setup=(r/'count-current-root.py').read_text().split("front = d / 'frontend'",1)[0]
setup=setup.replace("d = r / 'root-exact-counts-current-v2'", "d = r / 'scorer-exact-counts-current'")
exec(compile(setup,'<scorer-counter-tools>','exec'),globals())
front=d/'frontend';front.mkdir()
normalization=normal.normalize(source/'frontend/program.o',front/'program.o')
for name in ['metadata.json','program.mecb']:shutil.copyfile(source/'frontend'/name,front/name)
(d/'normalization.json').write_text(json.dumps(normalization,indent=2)+'\n')
def branch_field(word):
 if word&0x7c000000==0x14000000:return 0,26
 if word&0xff000010==0x54000000 or word&0x7e000000==0x34000000:return 5,19
 if word&0x7e000000==0x36000000:return 5,14
def branch_target(at,word,field):
 low,width=field;n=(word>>low)&((1<<width)-1)
 if n>>(width-1):n-=1<<width
 return at+4*n
def branch_opcode(word,at,target,field):
 low,width=field;distance=target-at
 assert distance%4==0 and -(1<<(width-1))<=distance//4<1<<(width-1)
 mask=((1<<width)-1)<<low
 return (word&~mask)|(((distance//4)&((1<<width)-1))<<low)
layout=SimpleNamespace(obj=obj,branch_field=branch_field,branch_target=branch_target,branch_opcode=branch_opcode)
symbol='_mech_compact_numeric_3009_no_growth_composed'
counter_name=b'_mech_root_block_counts\0'
leaf=extract(tools/'count-matcher-instructions.py',['instructions','leaf_code','instrument'],globals())
meta=json.loads((front/'metadata.json').read_text())
def phase(v):
 if isinstance(v,dict):
  if v.get('symbol')==symbol[1:]:yield v
  for val in v.values():yield from phase(val)
 elif isinstance(v,list):
  for val in v:yield from phase(val)
info,=phase(meta)
base,secs,syms=macho.load(front/'program.o');names=macho.text_symbols(secs,syms)
start=names[symbol];sec=secs[text];origin=sec[3]+start-sec[1]
# Literal loads in this checked leaf all refer to its aligned terminal pool.
refs=[]
for at in range(0,info['code_bytes'],4):
 if refs and at>=min(refs):break
 w=unpack_from('<I',base,origin+at)[0]
 if w&0x3b000000==0x18000000:
  refs.append(layout.branch_target(at,w,(5,19)))
literal_offset=min(refs) if refs else None
assert literal_offset is not None and literal_offset%16==0
instrumented=d/'instrumented.o'
# The extracted instrumenter shares this module's scope and its adapted replace_atom.
asm,leaders,body_end=leaf.instrument(front/'program.o',info['code_bytes'],instrumented,symbol,literal_offset)
assert len(leaders)<=4096
info['stack_bytes']+=16;meta['stack_bytes']+=16
(front/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
shape={'leaders':[pc-start for pc in leaders],'root_bytes':info['code_bytes'],'symbol':symbol,'literal_offset':literal_offset,'source_object_sha256':sha(source/'frontend/program.o'),'instrumented_sha256':sha(instrumented)}
(d/'shape.json').write_text(json.dumps(shape,indent=2)+'\n')
reference=source/'bound';worker_source=(reference/'mech-worker.rs').read_text()
edits=[('use serde::Deserialize;', 'use serde::Deserialize;\n#[unsafe(no_mangle)]\npub static mut mech_root_block_counts: [u64; 4096] = [0; 4096];'),('let start = Instant::now();','unsafe { std::ptr::addr_of_mut!(mech_root_block_counts).write([0; 4096]); }\nlet start = Instant::now();'),('serde_json::json!({"case":case.name,','let counts = unsafe { std::ptr::addr_of!(mech_root_block_counts).read() };\nserde_json::json!({"block_counts": &counts[..], "case":case.name,')]
for before,after in edits:assert worker_source.count(before)==1;worker_source=worker_source.replace(before,after)
worker=d/'counter-worker.rs';worker.write_text(worker_source)
shutil.copyfile(reference/'pinned_allocator.rs',d/'pinned_allocator.rs')
receipt=json.loads((source/'receipt.json').read_text());command=receipt['worker_command']
replacements={str(reference/'mech-worker.rs'):str(worker),str(reference/'mech-worker'):str(d/'counter-worker'),'link-arg='+str(reference/'program.o'):'link-arg='+str(instrumented)}
assert set(replacements)<=set(command)
subprocess.run([replacements.get(a,a) for a in command],check=True)
# The same fixed deployed host used by the root counters, with independent global data.
shutil.copyfile(r/'root-exact-counts-current-v2/counter-clock.c',d/'counter-clock.c')
subprocess.run(['/usr/bin/clang','-arch','arm64','-mmacosx-version-min=15.0','-O2','-Wall','-Wextra','-Werror','-c',str(d/'counter-clock.c'),'-o',str(d/'counter-clock.o')],check=True)
command=receipt['silesia_link_command'];replacements={str(r/'build/silesia-support/clock.o'):str(d/'counter-clock.o'),str(source/'bound/program.o'):str(instrumented),str(source/'silesia-encoder'):str(d/'counter-encoder')}
assert set(replacements)<=set(command)
subprocess.run([replacements.get(a,a) for a in command],check=True)
all_cases=json.loads((r/'root-exact-counts-current-v2/fixtures.json').read_text());fixture_path=r/'baseline/suite81/fixtures.json';report={}
for index,case in enumerate(all_cases[:81]):
 result=subprocess.run([str(d/'counter-worker'),str(front/'metadata.json'),str(fixture_path)],input=f'C\t{index}\t0\nNNQ\n',text=True,capture_output=True)
 (d/(case['name']+'.stdout')).write_text(result.stdout);(d/(case['name']+'.stderr')).write_text(result.stderr)
 assert result.returncode==0,(case['name'],result.stderr)
 assert result.stderr.endswith('CLEANUP private_payload_bytes=0 live_owner_records=0\n')
 rows=[json.loads(line) for line in result.stdout.splitlines() if line.startswith('{')]
 assert len(rows)==2 and all(row['exact_reference'] and row['independent_inflation'] and row['input_alias_unchanged'] and row['borrowed_output_alias_unchanged'] for row in rows)
 visits,other=[row['block_counts'] for row in rows]
 assert visits==other and not any(visits[len(leaders):])
 report[case['name']]={'invocations':visits[0],'observations':2,'input_bytes':rows[0]['input_bytes'],'blocks':[{'offset':pc-start,'visits':visits[i]} for i,pc in enumerate(leaders)]}
 print(case['name'],'exact deterministic calls',visits[0],flush=True)
for case in all_cases[81:]:
 observations=[];name=case['name'];expected=Path(case['expected']).read_bytes();input_data=Path(case['input']).read_bytes()
 for index in range(2):
  counts_path=d/(name+f'.{index}.counts.bin');env=os.environ.copy();env['MECH_ROOT_COUNTER_OUT']=str(counts_path)
  result=subprocess.run([str(d/'counter-encoder'),case['input'],'--verify'],env=env,capture_output=True)
  (d/(name+f'.{index}.stderr')).write_bytes(result.stderr)
  assert result.returncode==0 and result.stdout==expected and zlib.decompress(result.stdout,-15)==input_data,(name,result.returncode,result.stderr)
  visits=list(struct.unpack('<4096Q',counts_path.read_bytes()));assert not any(visits[len(leaders):]);observations.append(visits)
 assert observations[0]==observations[1]
 visits=observations[0];report[name]={'invocations':visits[0],'observations':2,'input_bytes':len(input_data),'blocks':[{'offset':pc-start,'visits':visits[i]} for i,pc in enumerate(leaders)]}
 print(name,'exact deterministic calls',visits[0],flush=True)
shape|={'cases':report,'training_cases':len(report),'diagnostic_only':True,'scope':'Current Cranelift leaf before block layout. Two deterministic output-verified observations for all 81 fixtures and all 12 full corpus files. Fixture aliases/inflation/cleanup verified; deployed corpus streams compared byte for byte and independently inflated. Seven-instruction counters preserve SP, IP registers, flags. Timings from diagnostic binary excluded.'}
(d/'counts.json').write_text(json.dumps(shape,indent=2)+'\n')
print('complete',len(report),'cases',len(leaders),'blocks',flush=True)
