from pathlib import Path
from hashlib import sha256
import json,shutil,subprocess
r=Path(__file__).resolve().parent;b=Path('/private/tmp/mech-m3-deflate-81-benchmarks/experiments/mech/mechdeflate-cranelift-v1');symbol='mech_compact_numeric_3009_no_growth_composed';mech=Path('/Users/cim310/.codex/worktrees/level12-compile-profile/mech')
o=r/'source-experiments/append-store-pairs';o.mkdir()
compiler=Path('/private/tmp/mech-m3-81-20261124/target/release/compile_profile');shutil.copyfile(compiler,o/'compile_profile')
(o/'tracked.patch').write_text(subprocess.check_output(['git','diff'],cwd=mech,text=True))
new_files=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=mech,text=True).splitlines()
for path in new_files:
 target=o/'untracked'/path;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(mech/path,target)
(o/'source-receipt.json').write_text(json.dumps({'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=mech,text=True).strip(),'compiler_sha256':sha256(compiler.read_bytes()).hexdigest(),'untracked_files':new_files,'default_profile_remains_off':True},indent=2)+'\n')
def run(*args):
 print('COMMAND',*map(str,args),flush=True);subprocess.run(list(map(str,args)),check=True)
def build(name,settings,capture=False):
 settings=settings.copy()
 if capture:
  d=r/('capture-'+name);d.mkdir();settings['MECH_INSPECT_PHASE_REGISTER_PROFILE']=str(d/(symbol+'.vcode'));settings['MECH_INSPECT_OPTIMIZED_PHASE_CLIF']=str(d/(symbol+'.clif'))
 path=r/'settings'/(name+'.json');path.write_text(json.dumps(settings,indent=2)+'\n');run('python3','-B',r/'build-variant.py',name,'--settings',path)
run('python3','-B',r/'build-variant.py','append-pairs-default-parity','--settings',r/'settings/ccmp-immediates-profiled.json')
assert json.loads((r/'variants/append-pairs-default-parity/receipt.json').read_text())['artifacts']['program.o']=='02dc6f4bf03fbaa141d3e21e39ad04553c81b7af4d09c4cad13621057c0561b2'
s=json.loads((r/'settings/ccmp-immediates-profiled.json').read_text());s['MECH_COMPACT_PAIR_ADMITTED_APPEND_STORES']='1'
for key in ['MECH_COMPACT_PHASE_REGISTER_WEIGHTS','MECH_COMPACT_PHASE_BLOCK_LAYOUT']:
 s[key]=';'.join(part for part in s[key].split(';') if not part.startswith(symbol+'@'))
build('append-pairs-raw',s,True)
reg=r/'rebased-profiles/append-pairs-register.json';run('python3','-B',r/'transfer-register.py','--source',b/'word-mismatch-order/profiles/c1acb158a41536816386146f55e5be5e2ea9e8607c1dc78df41f900e40671bcd.json','--capture',r/'capture-append-pairs-raw'/(symbol+'.vcode'),'--output',reg)
s['MECH_COMPACT_PHASE_REGISTER_WEIGHTS']+=';'+symbol+'@'+str(reg);build('append-pairs-weighted',s,True)
layout=r/'rebased-profiles/append-pairs-layout.json';run('python3','-B',r/'project-layout.py','--control',r/'variants/scorer-base-unlaid','--candidate',r/'variants/append-pairs-weighted','--old-capture',r/'capture-scorer-unlaid'/(symbol+'.vcode'),'--new-capture',r/'capture-append-pairs-weighted'/(symbol+'.vcode'),'--profile',b/'word-mismatch-order/profiles/069b98a9e53752e75cbe56873ef6e370b7a280bb773aac195536b37d39dab6b7.json','--mapping',reg.with_suffix('.proof.json'),'--output',layout,'--symbol',symbol)
s['MECH_COMPACT_PHASE_BLOCK_LAYOUT']+=';'+symbol+'@'+str(layout)
for name,blend,backedge in [('append-pairs-profiled',False,False),('append-pairs-root-blend',True,False),('append-pairs-root-backedge',True,True)]:
 settings=s.copy()
 if blend:settings['MECH_COMPACT_PHASE_REGISTER_WEIGHTS']+=';mech_compact_closed_checked@'+str(r/'root-prior-weights/blend.json')
 if backedge:
  p=r/'rebased-profiles/append-pairs-backedge-layout.json';p.write_text(json.dumps(json.loads(layout.read_text())|{'prefer_backedges':True},indent=2)+'\n');settings['MECH_COMPACT_PHASE_BLOCK_LAYOUT']=settings['MECH_COMPACT_PHASE_BLOCK_LAYOUT'].replace(str(layout),str(p))
 build(name,settings)
 v=r/'variants'/name;run('python3','-B','/private/tmp/mech-m3-81-20261124/smoke.py',v/'bound/mech-worker',v/'bound/metadata.json',o/(name+'-smoke.json'))
