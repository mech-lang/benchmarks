from collections import defaultdict
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import tarfile

packet = Path('/private/tmp/mech-m3-deflate-81-benchmarks/experiments/mech/mechdeflate-masked-fields-v1')
out = Path(__file__).resolve().parent / 'support'
manifest = json.loads((packet / 'raw-manifest.json').read_text())['files']
plan = json.loads((packet / 'archive.json').read_text())
names = [
    'copy-study/census/wide-linear4096-gates/linked-proofs/failure-support/mech-worker.rs',
    'copy-study/census/wide-linear4096-gates/linked-proofs/failure-support/pinned_allocator.rs',
    'diagnostics/control/worker.rs',
    'actors/control/bound/runtime.json',
    'fixed-support/mech-control-reference/2',
]
pending = defaultdict(list)
for name in names:
    pin = manifest[name]
    pending[pin['sha256']].append((name, pin['bytes']))
paths = [packet / p['file'] for p in plan['parts']]
with subprocess.Popen(['/bin/cat', *map(str, paths)], stdout=subprocess.PIPE) as child:
    with tarfile.open(fileobj=child.stdout, mode='r|gz') as archive:
        for member in archive:
            digest = member.name.removeprefix('blobs/')
            if digest not in pending:
                continue
            data = archive.extractfile(member).read()
            assert sha256(data).hexdigest() == digest
            for name, size in pending.pop(digest):
                assert len(data) == size
                path = out / name
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(data)
    assert child.wait() == 0
assert not pending
print('Pinned worker and allocator sources restored.')
