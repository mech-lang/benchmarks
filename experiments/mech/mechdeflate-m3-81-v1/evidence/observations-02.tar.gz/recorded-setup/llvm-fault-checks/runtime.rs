pub mod native_artifact {
 #[path = "/private/tmp/mech-m3-81-20261124/llvm-fault-checks/runtime-source/mod.rs"]
 pub mod compact_runtime;
}
