use mech_gpu::native_artifact::compact_runtime::{self, Heap, NativeStatus, OwnerStorage, View};
#[path = "pinned_allocator.rs"] mod pinned_allocator;
#[global_allocator] static ALLOCATOR: pinned_allocator::PinnedMimalloc = pinned_allocator::PinnedMimalloc;
use serde::Deserialize;
unsafe extern "C" {
    fn mech_compact_closed_v2(context: *mut std::ffi::c_void, input: *const u64, output: *mut u64) -> NativeStatus;
}
#[derive(Deserialize)]
struct Case { name: String, input: String, prefix: String, expected: String, capacity: usize }

fn invoke(case: &Case, input: &[u8], prefix: &[u8], expected: &[u8], metadata: &serde_json::Value,
          fail_at: usize, recovery: bool) -> serde_json::Value {
    let original_input = input.to_vec();
    let mut borrowed = Vec::with_capacity(case.capacity);
    borrowed.extend_from_slice(prefix);
    assert_eq!(borrowed.capacity(), case.capacity);
    let mut arguments = vec![0; metadata["input_words"].as_u64().unwrap() as usize];
    for port in metadata["inputs"].as_array().unwrap() {
        let name = mech_engine::decode_source_input_name(port["name"].as_str().unwrap()).unwrap();
        let at = port["input_offset"].as_u64().unwrap() as usize;
        let words = match name.as_str() {
            "input" => [input.as_ptr() as u64, input.len() as u64, input.len() as u64, 1, input.len() as u64, 0],
            "output" => [borrowed.as_ptr() as u64, borrowed.len() as u64, borrowed.capacity() as u64, 1, borrowed.len() as u64, 0],
            _ => panic!("unexpected input {name}"),
        };
        arguments[at..at+6].copy_from_slice(&words);
    }
    let mut storage = OwnerStorage::default();
    let mut heap = Heap::with_owner_storage(&mut storage);
    let mut output: View = [0; 6];
    compact_runtime::diagnostic_fault_set(fail_at);
    let status = unsafe { mech_compact_closed_v2((&mut heap as *mut Heap).cast(), arguments.as_ptr(), output.as_mut_ptr()) };
    let fault_hit = compact_runtime::diagnostic_fault_hit();
    compact_runtime::diagnostic_fault_set(0);
    let returned = if status.status == 0 { Some(unsafe { heap.take_u8(output) }.unwrap()) } else { None };
    assert_eq!(input, original_input);
    assert_eq!(borrowed, prefix);
    if let Some(ref returned) = returned {
        assert_eq!(returned, expected);
        assert_eq!(returned.capacity(), case.capacity);
        assert_ne!(returned.as_ptr(), borrowed.as_ptr());
        assert_eq!(miniz_oxide::inflate::decompress_to_vec(&returned[prefix.len()..]).unwrap(), input);
        assert_eq!(heap.counters.live_payload_bytes, 0);
    }
    if recovery || !fault_hit { assert_eq!(status.status, 0); }
    let result = serde_json::json!({
        "case":case.name,"fail_at":fail_at,"recovery":recovery,"fault_hit":fault_hit,
        "status":status.status,"origin":status.origin,
        "payload_allocation_requests":heap.counters.payload_requests,
        "requested_payload_bytes":heap.counters.requested_payload_bytes,
        "initialized_bytes_copied":heap.counters.initialized_bytes_copied,
        "zeroed_bytes":heap.counters.zeroed_bytes,"peak_private_payload_bytes":heap.counters.peak_payload_bytes,
        "private_bytes_before_caller_discard":heap.counters.live_payload_bytes,
        "input_alias_unchanged":true,"borrowed_output_alias_unchanged":true,
        "exact_output_and_independent_inflation":returned.is_some(),
    });
    heap.discard_private();
    assert_eq!(heap.counters.live_payload_bytes, 0);
    drop(heap);
    drop(returned);
    result
}

fn main() {
    let args=std::env::args().skip(1).collect::<Vec<_>>();
    assert_eq!(args.len(),3);
    let metadata:serde_json::Value=serde_json::from_slice(&std::fs::read(&args[0]).unwrap()).unwrap();
    let cases:Vec<Case>=serde_json::from_slice(&std::fs::read(&args[1]).unwrap()).unwrap();
    let smoke:serde_json::Value=serde_json::from_slice(&std::fs::read(&args[2]).unwrap()).unwrap();
    for case in cases {
        let input=std::fs::read(&case.input).unwrap();
        let prefix=std::fs::read(&case.prefix).unwrap();
        let expected=std::fs::read(&case.expected).unwrap();
        assert_eq!(&expected[..prefix.len()],prefix);
        assert_eq!(miniz_oxide::inflate::decompress_to_vec(&expected[prefix.len()..]).unwrap(),input);
        let count=smoke["observations"].as_array().unwrap().iter().find(|v|v["case"]==case.name).unwrap()["payload_allocation_requests"].as_u64().unwrap() as usize;
        let mut indices=vec![1,2,3,(count/2).max(1),count.max(1),count+1];
        indices.sort_unstable();indices.dedup();
        for index in indices {
            println!("{}",invoke(&case,&input,&prefix,&expected,&metadata,index,false));
            println!("{}",invoke(&case,&input,&prefix,&expected,&metadata,0,true));
        }
    }
    eprintln!("FAULT_CHECK_DONE all input/output aliases preserved; all caller discards empty; every fault followed by exact fresh-heap recovery");
}
