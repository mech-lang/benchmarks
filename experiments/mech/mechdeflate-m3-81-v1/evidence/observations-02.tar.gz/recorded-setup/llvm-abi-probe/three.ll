target triple = "arm64-apple-macosx26.0.0"
define {i64,i64,i64} @triple() { ret {i64,i64,i64} {i64 11,i64 22,i64 33} }
