	.build_version macos, 26, 0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_triple                         ; -- Begin function triple
	.p2align	2
_triple:                                ; @triple
	.cfi_startproc
; %bb.0:
	mov	w0, #11                         ; =0xb
	mov	w1, #22                         ; =0x16
	mov	w2, #33                         ; =0x21
	ret
	.cfi_endproc
                                        ; -- End function
.subsections_via_symbols
