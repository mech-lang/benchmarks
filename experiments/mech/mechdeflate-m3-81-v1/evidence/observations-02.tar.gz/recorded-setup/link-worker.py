"""Link the unchanged measurement worker against a freshly built codec and runtime."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent
MECH = Path('/Users/cim310/.codex/worktrees/level12-compile-profile/mech')
SUPPORT = ROOT / 'support/copy-study/census/wide-linear4096-gates/linked-proofs/failure-support'
parser = argparse.ArgumentParser()
parser.add_argument('frontend', type=Path)
parser.add_argument('output', type=Path)
parser.add_argument('--runtime-library', type=Path)
parser.add_argument('--worker-source', type=Path)
parser.add_argument('--extra-object', type=Path, action='append', default=[])
parser.add_argument('--runtime-variant', type=Path)
parser.add_argument('--inline-owner-records', type=int, default=12, choices=(1,8,12,16))
parser.add_argument('--target-native', action='store_true')
parser.add_argument('--profile-generate', type=Path)
args = parser.parse_args()
out = args.output.resolve()
out.mkdir(parents=True, exist_ok=False)
for name in ('program.o', 'program.mecb', 'metadata.json'):
    shutil.copyfile(args.frontend / name, out / name)
for name in ('mech-worker.rs', 'pinned_allocator.rs'):
    shutil.copyfile(args.worker_source if name == 'mech-worker.rs' and args.worker_source else SUPPORT / name, out / name)
allocator = ROOT / 'support/fixed-support/mech-control-reference/2'
assert hashlib.file_digest(allocator.open('rb'), 'sha256').hexdigest() == '38c6ec82a41e90a96bb9f1ae2c89058a77909da3fbb69c16e542ae5c858bf874'
deps = ROOT / 'target/release/deps'
externs = {'mech_gpu': args.runtime_library.resolve() if args.runtime_library else ROOT / 'libmech_gpu_runtime.rlib'}
for crate in ('mech_engine', 'serde', 'serde_json', 'miniz_oxide'):
    paths = list(deps.glob('lib' + crate + '-*.rlib'))
    assert len(paths) == 1, (crate, paths)
    externs[crate] = paths[0]
command = ['rustc', '+nightly-2026-03-03', '--edition=2024', '-C', 'opt-level=3',
           '-D', 'warnings', '-L', 'dependency=' + str(deps), str(out / 'mech-worker.rs'),
           '-o', str(out / 'mech-worker'), '-C', 'link-arg=' + str(allocator),
           '-C', 'link-arg=' + str(out / 'program.o')]
for extra in args.extra_object:
    command += ['-C', 'link-arg=' + str(extra.resolve())]
if args.target_native:
    command += ['-C', 'target-cpu=native', '-C', 'codegen-units=1']
if args.profile_generate:
    command += ['-C', 'profile-generate=' + str(args.profile_generate.resolve())]
for crate, path in externs.items():
    command += ['--extern', crate + '=' + str(path)]
with (out / 'link.log').open('w') as log:
    subprocess.run(command, stdout=log, stderr=log, check=True)
digest = lambda p: hashlib.file_digest(p.open('rb'), 'sha256').hexdigest()
record = {'command': command, 'inline_owner_records': args.inline_owner_records,
          'worker_source_sha256': digest(out / 'mech-worker.rs'),
          'allocator_sha256': digest(allocator),
          'runtime_source_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=MECH, text=True).strip(),
          'inputs': {str(p): digest(p) for p in externs.values()},
          'artifacts': {name: digest(out / name) for name in ('program.o','metadata.json','program.mecb','mech-worker')}}
if args.runtime_variant:
    record['runtime_variant'] = json.loads(args.runtime_variant.read_text())
(out / 'runtime.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record['artifacts'], indent=2))
