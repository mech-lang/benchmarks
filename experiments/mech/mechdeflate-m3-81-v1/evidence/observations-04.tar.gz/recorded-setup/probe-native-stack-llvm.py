"""Untimed own-stack watermark, preserving the original native ABI and checks."""
from pathlib import Path
from hashlib import sha256
import json,subprocess,time

r=Path('/private/tmp/mech-m3-81-20261124')
while True:
    p=r/'llvm-oz-primary-job.json'
    if p.exists() and json.loads(p.read_text())['state']!='running':break
    time.sleep(2)
assert json.loads(p.read_text())['state']=='complete'
d=r/'native-stack-probe-llvm'
d.mkdir()
subprocess.run(['clang','-c',str(r/'profile-native-stack.s'),'-o',str(d/'stack.o')],check=True)
source=(r/'support/copy-study/census/wide-linear4096-gates/linked-proofs/failure-support/mech-worker.rs').read_text()
assert source.count('mech_compact_closed_v2(')==2
source=source.replace('mech_compact_closed_v2(', 'mech_profiled_entry(')
before='        output: *mut u64,\n'
assert source.count(before)==1
source=source.replace(before,before+'        native_stack_bytes: *mut u64,\n')
before='        let status = unsafe {'
assert source.count(before)==1
source=source.replace(before,'        let mut native_stack_bytes=0u64;\n'+before)
before='                output.as_mut_ptr(),\n'
assert source.count(before)==1
source=source.replace(before,before+'                &mut native_stack_bytes,\n')
before='serde_json::json!({"case":case.name,'
assert source.count(before)==1
source=source.replace(before,'serde_json::json!({"native_stack_bytes":native_stack_bytes,"case":case.name,')
worker=d/'mech-worker.rs'
worker.write_text(source)
cases=json.loads((r/'comparison/fixtures.json').read_text())
report={}
for role,front,library,variant in [
    ('original-m1',r/'winner-rebuilt/frontend',r/'libmech_gpu_runtime.rlib',None),
    ('llvm-size',r/'llvm-final-oz/frontend',r/'compiler-llvm/runtime-default/libmech_gpu_runtime.rlib',r/'compiler-llvm/runtime-default/variant.json'),
]:
    out=d/role
    command=['python3','-B',str(r/'link-worker.py'),str(front),str(out),'--runtime-library',str(library),'--worker-source',str(worker),'--extra-object',str(d/'stack.o')]
    if variant:command+=['--runtime-variant',str(variant)]
    subprocess.run(command,check=True)
    script=''.join(f'C\t{i}\t0\nNN' for i in range(len(cases)))+'Q\n'
    result=subprocess.run([str(out/'mech-worker'),str(out/'metadata.json'),str(r/'comparison/fixtures.json')],input=script,text=True,capture_output=True,check=True)
    (out/'observations.stdout').write_text(result.stdout)
    (out/'observations.stderr').write_text(result.stderr)
    assert result.stderr.endswith('CLEANUP private_payload_bytes=0 live_owner_records=0\n')
    rows=[json.loads(l) for l in result.stdout.splitlines() if l.startswith('{')]
    assert len(rows)==162
    assert all(v['exact_reference'] and v['independent_inflation'] and v['input_alias_unchanged'] and v['borrowed_output_alias_unchanged'] and v['nonreturned_private_bytes_at_return']==0 for v in rows)
    peak=max(v['native_stack_bytes'] for v in rows)
    assert peak<32768, 'Watermark exhausted'
    report[role]={'peak_touched_bytes':peak,'cases':81,'observations':162,'rows':rows}
    print(role,'native peak touched stack bytes',peak,flush=True)
(d/'result.json').write_text(json.dumps({'scope':'Diagnostic own-stack watermark over 32KiB immediately below SP before the original public native entry. Reports touched stack in 16-byte units, including its native/runtime/library callees. Excludes the watermark wrapper frame and caller heap construction. All original output/alias/cleanup checks remain enabled. Never used for primary timings.',
    'assembly_sha256':sha256((r/'profile-native-stack.s').read_bytes()).hexdigest(),'results':report},indent=2)+'\n')
