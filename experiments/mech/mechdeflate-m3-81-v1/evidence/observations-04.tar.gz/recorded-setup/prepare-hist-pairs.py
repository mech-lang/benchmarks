from pathlib import Path
import json,subprocess
r=Path('/private/tmp/mech-m3-81-20261124')
roles=['histpair64','pairhistpair64','unseededhistpair64']
for role in roles:
 base='exact-align64' if role=='histpair64' else 'exact-paired64'
 x=json.loads((r/(base+'-recipe.json')).read_text());x['flags']['MECH_GROUP_PACKED_HISTOGRAM_PAIR_VECTOR_CHUNKS']='1'
 if role=='unseededhistpair64':x['flags'].pop('MECH_COMPACT_SEEDED_HISTOGRAM')
 p=r/(role+'-recipe.json');p.write_text(json.dumps(x,indent=2)+'\n')
 with (r/(role+'-setup.log')).open('w') as log:
  subprocess.run(['python3','-B',str(r/'emit.py'),str(p),str(r/role)],stdout=log,stderr=log,check=True)
  subprocess.run(['python3','-B',str(r/'link-worker.py'),str(r/role/'frontend'),str(r/role/'bound')],stdout=log,stderr=log,check=True)
  subprocess.run(['python3','-B',str(r/'smoke.py'),str(r/role/'bound/mech-worker'),str(r/role/'bound/metadata.json'),str(r/role/'smoke.json')],stdout=log,stderr=log,check=True)
 print('Prepared',role,flush=True)
for role in roles:
 subprocess.run(['python3','-B',str(r/'study.py'),'screen-'+role,str(r/'exact-fresh-base/bound'),str(r/role/'bound'),'--panel',str(r/'critical-panel.json'),'--blocks','24'],check=True)
