from pathlib import Path
from hashlib import sha256
import subprocess,json,os
r=Path('/private/tmp/mech-m3-81-20261124');d=r/'compiler-llvm';mech=Path('/Users/cim310/.codex/worktrees/level12-compile-profile/mech')
subprocess.run(['python3','-B',str(d/'build.py')],check=True);(d/'compile_profile').chmod(0o755)
sha=lambda p:sha256(Path(p).read_bytes()).hexdigest();patch=subprocess.check_output(['git','diff','--binary'],cwd=mech);(d/'source-current.patch').write_bytes(patch);files=subprocess.check_output(['git','diff','--name-only'],cwd=mech,text=True).splitlines();record={'basis_commit':'2b301734fb43a4abff0d38d68d881e2bf85bd969','source_patch_sha256':sha(d/'source-current.patch'),'source_files':{f:sha(mech/f) for f in files},'driver_changes':'Select the existing LLVM-root API through MECH_PROFILE_LLVM_BIN; default mode unchanged.','driver_sha256':sha(d/'driver/compile_profile.rs'),'compiler_sha256':sha(d/'compile_profile')};(d/'source-current-receipt.json').write_text(json.dumps(record,indent=2)+'\n')
runtime=d/'runtime-default';runtime.mkdir();module=runtime/'runtime.rs';module.write_text('pub mod native_artifact {\n #[path = '+json.dumps(str(mech/'hosts/gpu/src/native_artifact/compact_runtime/mod.rs'))+']\n pub mod compact_runtime;\n}\n');env={k:v for k,v in os.environ.items() if not k.startswith('MECH_')}|{'MECH_INLINE_OWNER_RECORDS':'12'};base=['rustc','+nightly-2026-03-03','--edition=2024','-C','opt-level=3','-D','warnings',str(module)]
with (runtime/'build.log').open('w') as log:
 subprocess.run(base+['--test','-o',str(runtime/'tests')],env=env,stdout=log,stderr=log,check=True)
 subprocess.run(base+['--crate-type','rlib','--crate-name','mech_gpu','-o',str(runtime/'libmech_gpu_runtime.rlib')],env=env,stdout=log,stderr=log,check=True)
with (runtime/'tests.log').open('w') as log:subprocess.run([str(runtime/'tests')],stdout=log,stderr=log,check=True)
(runtime/'variant.json').write_text(json.dumps({'source_receipt':record,'inline_owner_records':12,'alignment':'unchanged default','runtime_build_command':base},indent=2)+'\n')
for name,recipe_name in [('llvm-default-reproduction','published-winning-recipe.json'),('llvm-preserved-oz','compiler-llvm/recipe.json')]:
 out=r/name;p=r/recipe_name
 with (d/(name+'-setup.log')).open('w') as log:
  subprocess.run(['python3','-B',str(r/'emit.py'),str(p),str(out),'--compiler',str(d/'compile_profile'),'--compiler-source-receipt',str(d/'source-current-receipt.json')],stdout=log,stderr=log,check=True)
  if name!='llvm-default-reproduction':
   subprocess.run(['python3','-B',str(r/'link-worker.py'),str(out/'frontend'),str(out/'bound'),'--runtime-library',str(runtime/'libmech_gpu_runtime.rlib'),'--runtime-variant',str(runtime/'variant.json')],stdout=log,stderr=log,check=True)
   subprocess.run(['python3','-B',str(r/'smoke.py'),str(out/'bound/mech-worker'),str(out/'bound/metadata.json'),str(out/'smoke.json')],stdout=log,stderr=log,check=True)
 print(name,'all exact artifact or81 smoke checks passed',flush=True)
subprocess.run(['python3','-B',str(r/'study.py'),'screen-llvm-preserved-oz',str(r/'scratch-paired128/bound'),str(r/'llvm-preserved-oz/bound'),'--panel',str(r/'critical-panel.json'),'--blocks','96'],check=True)
