from pathlib import Path
from hashlib import sha256
import json,subprocess,os
r=Path('/private/tmp/mech-m3-81-20261124');d=r/'compiler-llvm';mech=Path('/Users/cim310/.codex/worktrees/level12-compile-profile/mech');env=os.environ.copy();env.update(CARGO_BUILD_JOBS='4',CARGO_PROFILE_RELEASE_OPT_LEVEL='3',CARGO_PROFILE_RELEASE_DEBUG='false',CARGO_PROFILE_RELEASE_LTO='false',CARGO_PROFILE_RELEASE_CODEGEN_UNITS='16',CARGO_INCREMENTAL='0',MECH_LLVM_TEST_BIN='/Users/cim310/.rustup/toolchains/nightly-2026-03-03-aarch64-apple-darwin/lib/rustlib/aarch64-apple-darwin/bin')
command=['cargo','+nightly-2026-03-03','test','--offline','--release','--config','profile.release.package.libmimalloc-sys.opt-level=1','--manifest-path',str(d/'driver/Cargo.toml'),'--target-dir',str(r/'target'),'--test','llvm_register_results','--','--include-ignored'];(d/'register-abi-command.json').write_text(json.dumps(command,indent=2)+'\n')
with (d/'register-abi-test.log').open('w') as log:subprocess.run(command,env=env,stdout=log,stderr=log,check=True)
print('Register ABI refusal and both-direction native checks passed',flush=True)
subprocess.run(['python3','-B',str(d/'build.py')],check=True);(d/'compile_profile').chmod(0o755)
sha=lambda p:sha256(Path(p).read_bytes()).hexdigest();(d/'source-addresses.patch').write_bytes(subprocess.check_output(['git','diff','--binary'],cwd=mech));files=subprocess.check_output(['git','diff','--name-only'],cwd=mech,text=True).splitlines();record={'basis_commit':'2b301734fb43a4abff0d38d68d881e2bf85bd969','source_patch_sha256':sha(d/'source-addresses.patch'),'source_files':{f:sha(mech/f) for f in files},'added_source_file':{'hosts/gpu/src/native_artifact/program/llvm_backend/register_results_tests.rs':sha(mech/'hosts/gpu/src/native_artifact/program/llvm_backend/register_results_tests.rs')},'driver_sha256':sha(d/'driver/compile_profile.rs'),'compiler_sha256':sha(d/'compile_profile'),'cross_backend_abi_test':'All1..8I64 register results,10000full-width inputs per arity in each direction; 9-word and mixed-type layouts refused'};(d/'source-addresses-receipt.json').write_text(json.dumps(record,indent=2)+'\n')
for name,recipe_name in [('llvm-addresses-default-reproduction','published-winning-recipe.json'),('llvm-addresses-oz','compiler-llvm/recipe.json')]:
 out=r/name
 with (d/(name+'-setup.log')).open('w') as log:
  subprocess.run(['python3','-B',str(r/'emit.py'),str(r/recipe_name),str(out),'--compiler',str(d/'compile_profile'),'--compiler-source-receipt',str(d/'source-addresses-receipt.json')],stdout=log,stderr=log,check=True)
  if name=='llvm-addresses-oz':
   subprocess.run(['python3','-B',str(r/'link-worker.py'),str(out/'frontend'),str(out/'bound'),'--runtime-library',str(d/'runtime-default/libmech_gpu_runtime.rlib'),'--runtime-variant',str(d/'runtime-default/variant.json')],stdout=log,stderr=log,check=True)
   subprocess.run(['python3','-B',str(r/'smoke.py'),str(out/'bound/mech-worker'),str(out/'bound/metadata.json'),str(out/'smoke.json')],stdout=log,stderr=log,check=True)
 print(name,'exact artifacts or all81smoke checks passed',flush=True)
subprocess.run(['python3','-B',str(r/'study.py'),'screen-llvm-addresses-oz',str(r/'scratch-paired128/bound'),str(r/'llvm-addresses-oz/bound'),'--panel',str(r/'critical-panel.json'),'--blocks','96'],check=True)
