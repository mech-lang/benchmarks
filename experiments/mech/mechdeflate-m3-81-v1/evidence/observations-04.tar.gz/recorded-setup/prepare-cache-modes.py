from pathlib import Path
import json,subprocess
r=Path('/private/tmp/mech-m3-81-20261124')
roles=['nocache128','nocache64','sortcache128']
for role in roles:
 x=json.loads((r/'exact-paired64-recipe.json').read_text())
 x['flags']['MECH_COMPACT_PAIR_REGISTER_SPILLS']='checked'
 if role!='nocache64':x['flags']['MECH_COMPACT_FUNCTION_ALIGNMENT_LOG2']='7'
 if role=='sortcache128':x['flags']['MECH_COMPACT_FIXED_TRANSFORMS']='3956'
 else:x['flags'].pop('MECH_COMPACT_FIXED_TRANSFORMS')
 p=r/(role+'-recipe.json');p.write_text(json.dumps(x,indent=2)+'\n');out=r/role
 with (r/(role+'-setup.log')).open('w') as log:
  subprocess.run(['python3','-B',str(r/'emit.py'),str(p),str(out)],stdout=log,stderr=log,check=True)
  subprocess.run(['python3','-B',str(r/'link-worker.py'),str(out/'frontend'),str(out/'bound')],stdout=log,stderr=log,check=True)
  subprocess.run(['python3','-B',str(r/'smoke.py'),str(out/'bound/mech-worker'),str(out/'bound/metadata.json'),str(out/'smoke.json')],stdout=log,stderr=log,check=True)
 print('Prepared',role,flush=True)
for role in roles:
 subprocess.run(['python3','-B',str(r/'study.py'),'screen-'+role,str(r/'exact-paired64/bound'),str(r/role/'bound'),'--panel',str(r/'critical-panel.json'),'--blocks','24'],check=True)
