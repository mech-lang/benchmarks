import json
from pathlib import Path
import runpy
import sys
import time
import traceback

ROOT = Path(__file__).resolve().parent
BENCH = Path('/private/tmp/mech-m3-deflate-81-benchmarks/experiments/mech')
MECH = Path('/Users/cim310/.codex/worktrees/level12-compile-profile/mech')
kind = sys.argv[1]
status = ROOT / f'{kind}-job.json'
started = time.time()
status.write_text(json.dumps({'state': 'running', 'pid': __import__('os').getpid(), 'started': started}))
try:
    if kind == 'compiler':
        out = ROOT / 'compiler'
        out.mkdir()
        ns = runpy.run_path(str(BENCH / 'mechdeflate-masked-fields-v1/reproduce.py'))
        compiler = ns['build_compiler'](MECH, out, ROOT / 'target')
        print(compiler, flush=True)
    elif kind == 'peers':
        sys.path.insert(0, str(BENCH / 'mechdeflate-phase-routes-v1'))
        ns = runpy.run_path(str(BENCH / 'mechdeflate-phase-routes-v1/replay_timings.py'))
        out = ROOT / 'comparison'
        out.mkdir()
        ns['extract_previous'](BENCH / 'mechdeflate-masked-fields-v1', out)
        ns['bind'](out)
        print('All 81 fixtures and both pinned peers restored and verified.', flush=True)
    else:
        raise ValueError(kind)
except BaseException:
    traceback.print_exc()
    status.write_text(json.dumps({'state': 'failed', 'seconds': time.time() - started}))
    raise
else:
    status.write_text(json.dumps({'state': 'complete', 'seconds': time.time() - started}))
