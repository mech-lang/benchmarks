from pathlib import Path
from runpy import run_path
import json,subprocess,shutil
r=Path('/private/tmp/mech-m3-81-20261124');sym='mech_compact_numeric_3009_no_growth_composed';registers=run_path(str(r/'support/study/derive-registers.py'))['derive'];layouts=run_path(str(r/'support/mechdeflate-literal-pairs-v1/tooling/derive-coalesced-layout.py'))['derive']
def emit(name,flags,capture=False):
 x=json.loads((r/'exact-align64-recipe.json').read_text());x['flags']=flags.copy()
 if capture:x['flags']['MECH_INSPECT_PHASE_REGISTER_PROFILE']=str(r/name/(sym+'.vcode'))
 (r/(name+'-recipe.json')).write_text(json.dumps(x,indent=2)+'\n')
 with (r/(name+'-setup.log')).open('w') as log:
  subprocess.run(['python3','-B',str(r/'emit.py'),str(r/(name+'-recipe.json')),str(r/name)],stdout=log,stderr=log,check=True)
  subprocess.run(['python3','-B',str(r/'link-worker.py'),str(r/name/'frontend'),str(r/name/'bound')],stdout=log,stderr=log,check=True)
 return r/name
def count(folder):
 with (folder/'counts.log').open('w') as log:subprocess.run(['python3','-B',str(r/'native-counts.py'),str(folder),sym,'--panel',str(r/'original22-panel.json')],stdout=log,stderr=log,check=True)
 shutil.copyfile(folder/'receipt.json',folder/'emission-receipt.json');shutil.copyfile(folder/'native-receipt.json',folder/'receipt.json')
for role in ['singleaccum','noeight','page6']:
 flags=json.loads((r/'exact-align64-recipe.json').read_text())['flags']
 for key in ['MECH_COMPACT_PHASE_REGISTER_WEIGHTS','MECH_COMPACT_PHASE_BLOCK_LAYOUT']:flags[key]=';'.join(v for v in flags[key].split(';') if not v.startswith(sym+'@'))
 if role=='singleaccum':flags['MECH_ORDERED_PACKED_ACCUMULATORS']='1'
 if role=='noeight':flags.pop('MECH_ORDERED_PACKED_EIGHT_ENTRY')
 if role=='page6':flags['MECH_COMPOSE_IMMUTABLE_COST_CODE_PAGE_SHIFT']='6'
 flags['MECH_COMPACT_PAIR_REGISTER_SPILLS']='checked'
 raw=emit(role+'-unweighted',flags,True);count(raw);profiles,proof=registers(raw,sym);p=r/('profiles/'+role+'-registers.json');p.write_text(json.dumps(profiles['linear-4096'],indent=2)+'\n');(raw/'register-proof.json').write_text(json.dumps(proof,indent=2)+'\n');flags['MECH_COMPACT_PHASE_REGISTER_WEIGHTS']+=';'+sym+'@'+str(p)
 weighted=emit(role+'-unlaid',flags);count(weighted);s=weighted/'counts-word-reuse-v1-3009';profile,proof=layouts(json.loads((s/'native-shape.json').read_text()),json.loads((s/'counts.json').read_text()));p=r/('profiles/'+role+'-layout.json');p.write_text(json.dumps(profile,indent=2)+'\n');(weighted/'layout-proof.json').write_text(json.dumps(proof,indent=2)+'\n');flags['MECH_COMPACT_PHASE_BLOCK_LAYOUT']+=';'+sym+'@'+str(p)
 final=emit(role+'-laid',flags)
 with (final/'smoke.log').open('w') as log:subprocess.run(['python3','-B',str(r/'smoke.py'),str(final/'bound/mech-worker'),str(final/'bound/metadata.json'),str(final/'smoke.json')],stdout=log,stderr=log,check=True)
 print('Prepared',role,flush=True)
