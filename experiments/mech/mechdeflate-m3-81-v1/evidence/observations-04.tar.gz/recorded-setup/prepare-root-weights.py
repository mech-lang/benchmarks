from pathlib import Path
import json,subprocess
r=Path('/private/tmp/mech-m3-81-20261124');d=r/'compiler-root-capture'
for mode in ['linear','sqrt']:
 role='root-'+mode;x=json.loads((r/'scratch-paired128-recipe.json').read_text());x['flags']['MECH_COMPACT_PHASE_REGISTER_WEIGHTS']+=';mech_compact_closed_v2@'+str(r/'root-profiles'/(mode+'.json'));p=r/(role+'-recipe.json');p.write_text(json.dumps(x,indent=2)+'\n');out=r/role
 with (r/(role+'-setup.log')).open('w') as log:
  subprocess.run(['python3','-B',str(r/'emit.py'),str(p),str(out),'--compiler',str(d/'compile_profile'),'--compiler-source-receipt',str(d/'source-receipt.json')],stdout=log,stderr=log,check=True)
  subprocess.run(['python3','-B',str(r/'link-worker.py'),str(out/'frontend'),str(out/'bound'),'--runtime-library',str(r/'compiler-scratch/libmech_gpu_runtime.rlib'),'--runtime-variant',str(r/'compiler-scratch/runtime-variant.json')],stdout=log,stderr=log,check=True)
  subprocess.run(['python3','-B',str(r/'smoke.py'),str(out/'bound/mech-worker'),str(out/'bound/metadata.json'),str(out/'smoke.json')],stdout=log,stderr=log,check=True)
 m=json.loads((out/'frontend/metadata.json').read_text());print('Prepared',role,'root stack',m['stack_bytes'],'root bytes',m['code_bytes'],flush=True)
for mode in ['linear','sqrt']:
 role='root-'+mode
 subprocess.run(['python3','-B',str(r/'study.py'),'screen-'+role,str(r/'scratch-paired128/bound'),str(r/role/'bound'),'--panel',str(r/'critical-panel.json'),'--blocks','24'],check=True)
