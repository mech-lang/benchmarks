.text
.p2align 2
.globl _mech_profiled_entry
_mech_profiled_entry:
    stp x29, x30, [sp, #-64]!
    stp x19, x20, [sp, #16]
    str x21, [sp, #32]
    mov x29, sp
    mov x19, sp
    mov x20, x3
    movz x21, #0xe91b
    movk x21, #0xd417, lsl #16
    movk x21, #0x6b29, lsl #32
    movk x21, #0xa53d, lsl #48
    sub x8, x19, #8, lsl #12
1:
    stp x21, x21, [x8], #16
    cmp x8, x19
    b.lo 1b
    bl _mech_compact_closed_v2
    sub x8, x19, #8, lsl #12
2:
    ldp x9, x10, [x8], #16
    cmp x9, x21
    b.ne 3f
    cmp x10, x21
    b.ne 3f
    cmp x8, x19
    b.lo 2b
3:
    sub x9, x19, x8
    add x9, x9, #16
    str x9, [x20]
    ldr x21, [sp, #32]
    ldp x19, x20, [sp, #16]
    ldp x29, x30, [sp], #64
    ret
