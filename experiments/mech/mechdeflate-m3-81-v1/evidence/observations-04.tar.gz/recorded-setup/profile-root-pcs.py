"""Sample complete worker warmups; these are diagnostics, outside primary clocks."""
import json
import os
from pathlib import Path
import select
import subprocess
import time
import traceback

ROOT = Path(__file__).resolve().parent
COMPARISON = ROOT/'comparison'
OUT = ROOT/'root-pcs'
OUT.mkdir()
pins = json.loads((COMPARISON/'pinned-peers/pins.json').read_text())
fixtures = COMPARISON/'fixtures.json'
cases = json.loads(fixtures.read_text())
commands = {'mech-current':[str(ROOT/'pc-profiler/bound/mech-worker'),str(ROOT/'pc-profiler/bound/metadata.json'),str(fixtures)]}
job = ROOT/'root-pcs-job.json'
start = time.time()
job.write_text(json.dumps({'state':'running','pid':os.getpid(),'started':start}))
records = []
try:
    for case_name in ('reymont-prefix-1024','prefix-natural-4096','prefix-natural-16384','prefix-random-4096','prefix-random-65536','prefix-random-1048576','16384-distribution-change'):
        index = next(i for i,c in enumerate(cases) if c['name']==case_name)
        for actor, command in commands.items():
            folder = OUT/(case_name+'-'+actor)
            folder.mkdir()
            buffer = bytearray()
            with (folder/'worker.stderr').open('wb') as stderr:
                child = subprocess.Popen(command,env=os.environ | {'MECH_PC_SAMPLE_OUT':str(folder/'pcs.csv')},stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=stderr)
                def line():
                    while b'\n' not in buffer:
                        assert select.select([child.stdout],[],[],60)[0]
                        data = os.read(child.stdout.fileno(),65536)
                        assert data, (actor,child.poll())
                        buffer.extend(data)
                    at = buffer.index(b'\n')
                    result = bytes(buffer[:at]).decode()
                    del buffer[:at+1]
                    return result
                def send(data):
                    child.stdin.write(data)
                    child.stdin.flush()
                try:
                    assert line()=='SESSION_READY'
                    send(f'C\t{index}\t0\n'.encode())
                    assert line()=='CASE_READY\t'+case_name
                    send(b'N')
                    initial = json.loads(line())
                    assert initial['warmup'] and initial['independent_inflation']
                    send(b'W'*20)
                    sample_command = ['/usr/bin/sample',str(child.pid),'3','1','-file',str(folder/'sample.txt')]
                    sampled = subprocess.run(sample_command,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
                    (folder/'sample.stdout').write_bytes(sampled.stdout)
                    (folder/'sample.stderr').write_bytes(sampled.stderr)
                    warmups = [line() for _ in range(20)]
                    assert all(x.startswith('WARMUP_DONE\t'+case_name+'\t') for x in warmups)
                    send(b'N')
                    final = json.loads(line())
                    assert final['profile'] and final['independent_inflation']
                    assert line()=='CASE_DONE\t'+case_name
                    send(b'Q\n')
                    assert child.wait(timeout=30)==0
                finally:
                    if child.poll() is None:
                        child.kill()
                        child.wait()
            record = {'actor':actor,'case':case_name,'sample_command':sample_command,
                      'sample_exit_code':sampled.returncode,'warmups':warmups,'initial':initial,'final':final,
                      'scope':'Diagnostic whole-worker sample, including output verification outside the encoder timer. Not primary timing or an isolated causal budget.'}
            (folder/'receipt.json').write_text(json.dumps(record,indent=2)+'\n')
            records.append(record)
            print(case_name,actor,'sample exit',sampled.returncode,flush=True)
    (OUT/'index.json').write_text(json.dumps(records,indent=2)+'\n')
except BaseException:
    traceback.print_exc()
    job.write_text(json.dumps({'state':'failed','seconds':time.time()-start}))
    raise
else:
    job.write_text(json.dumps({'state':'complete','seconds':time.time()-start}))
