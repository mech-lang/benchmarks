from pathlib import Path
import subprocess
r=Path('/private/tmp/mech-m3-81-20261124');d=r/'compiler-llvm';out=r/'llvm-compatible-oz';runtime=d/'runtime-default'
with (d/'compatible-setup.log').open('w') as log:
 subprocess.run(['python3','-B',str(r/'emit.py'),str(d/'compatible-recipe.json'),str(out),'--compiler',str(d/'compile_profile'),'--compiler-source-receipt',str(d/'source-current-receipt.json')],stdout=log,stderr=log,check=True)
 subprocess.run(['python3','-B',str(r/'link-worker.py'),str(out/'frontend'),str(out/'bound'),'--runtime-library',str(runtime/'libmech_gpu_runtime.rlib'),'--runtime-variant',str(runtime/'variant.json')],stdout=log,stderr=log,check=True)
 subprocess.run(['python3','-B',str(r/'smoke.py'),str(out/'bound/mech-worker'),str(out/'bound/metadata.json'),str(out/'smoke.json')],stdout=log,stderr=log,check=True)
print('LLVM compatible all81 smoke checks passed',flush=True)
subprocess.run(['python3','-B',str(r/'study.py'),'screen-llvm-compatible-oz',str(r/'scratch-paired128/bound'),str(out/'bound'),'--panel',str(r/'critical-panel.json'),'--blocks','96'],check=True)
