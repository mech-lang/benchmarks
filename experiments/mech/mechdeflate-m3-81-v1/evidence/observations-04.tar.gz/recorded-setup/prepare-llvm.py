from pathlib import Path
from hashlib import sha256
import subprocess,json
r=Path('/private/tmp/mech-m3-81-20261124');d=r/'compiler-llvm'
subprocess.run(['python3','-B',str(d/'build.py')],check=True);(d/'compile_profile').chmod(0o755)
record=json.loads((r/'compiler-final/source-receipt.json').read_text());record['driver_changes']='Select the existing public LLVM-root API when MECH_PROFILE_LLVM_BIN is set; default mode unchanged.';record['driver_sha256']=sha256((d/'driver/compile_profile.rs').read_bytes()).hexdigest();record['compiler_sha256']=sha256((d/'compile_profile').read_bytes()).hexdigest();(d/'source-receipt.json').write_text(json.dumps(record,indent=2)+'\n')
x=json.loads((r/'scratch-paired128-recipe.json').read_text());x['flags']['MECH_PROFILE_LLVM_BIN']='/Users/cim310/.rustup/toolchains/nightly-2026-03-03-aarch64-apple-darwin/lib/rustlib/aarch64-apple-darwin/bin';p=d/'recipe.json';p.write_text(json.dumps(x,indent=2)+'\n');out=r/'llvm-root-oz'
with (d/'setup.log').open('w') as log:
 subprocess.run(['python3','-B',str(r/'emit.py'),str(p),str(out),'--compiler',str(d/'compile_profile'),'--compiler-source-receipt',str(d/'source-receipt.json')],stdout=log,stderr=log,check=True)
 subprocess.run(['python3','-B',str(r/'link-worker.py'),str(out/'frontend'),str(out/'bound'),'--runtime-library',str(r/'compiler-final/12-default/libmech_gpu_runtime.rlib'),'--runtime-variant',str(r/'compiler-final/12-default/variant.json')],stdout=log,stderr=log,check=True)
 subprocess.run(['python3','-B',str(r/'smoke.py'),str(out/'bound/mech-worker'),str(out/'bound/metadata.json'),str(out/'smoke.json')],stdout=log,stderr=log,check=True)
print('LLVM-root all81 smoke cases passed',flush=True)
subprocess.run(['python3','-B',str(r/'study.py'),'screen-llvm-root-oz',str(r/'scratch-paired128/bound'),str(out/'bound'),'--panel',str(r/'critical-panel.json'),'--blocks','96'],check=True)
