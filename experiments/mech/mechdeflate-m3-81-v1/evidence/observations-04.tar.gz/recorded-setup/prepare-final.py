from pathlib import Path
import hashlib,json,os,shutil,subprocess,time
r=Path('/private/tmp/mech-m3-81-20261124');mech=Path('/Users/cim310/.codex/worktrees/level12-compile-profile/mech');d=r/'compiler-final'
while True:
 p=r/'aligned64-primary-job.json'
 if p.exists() and json.loads(p.read_text())['state']!='running':break
 time.sleep(2)
assert json.loads(p.read_text())['state']=='complete'
d.mkdir();start=time.time();env={k:v for k,v in os.environ.items() if not k.startswith('MECH_')};env.update(CARGO_BUILD_JOBS='4',CARGO_PROFILE_RELEASE_OPT_LEVEL='3',CARGO_PROFILE_RELEASE_DEBUG='false',CARGO_PROFILE_RELEASE_LTO='false',CARGO_PROFILE_RELEASE_CODEGEN_UNITS='16',CARGO_INCREMENTAL='0')
driver=r/'compiler/compiler-driver';manifest=driver/'Cargo.toml';s=manifest.read_text();extra='[[test]]\nname = "seed_choice"\npath = "seed_choice.rs"';assert s.count(extra)==1;manifest.write_text(s.replace(extra,''))
command=['cargo','+nightly-2026-03-03','build','--locked','--release','--config','profile.release.package.libmimalloc-sys.opt-level=1','--manifest-path',str(manifest),'--target-dir',str(r/'target'),'--bin','compile_profile'];(d/'build-command.json').write_text(json.dumps(command,indent=2))
with (d/'build.log').open('w') as log:subprocess.run(command,env=env,stdout=log,stderr=log,check=True)
shutil.copy2(r/'target/release/compile_profile',d/'compile_profile');(d/'compile_profile').chmod(0o755)
sha=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest();patch=subprocess.check_output(['git','diff','--binary'],cwd=mech);(d/'source.patch').write_bytes(patch);files=subprocess.check_output(['git','diff','--name-only'],cwd=mech,text=True).splitlines();receipt={'basis_commit':'2b301734fb43a4abff0d38d68d881e2bf85bd969','source_patch_sha256':sha(d/'source.patch'),'source_files':{name:sha(mech/name) for name in files},'compiler_sha256':sha(d/'compile_profile'),'build_command':command};(d/'source-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
for records,aligned in [(1,False),(12,False),(1,True),(12,True)]:
 role=str(records)+('-aligned64' if aligned else '-default');out=d/role;out.mkdir();module=out/'runtime.rs';module.write_text('pub mod native_artifact {\n #[path = '+json.dumps(str(mech/'hosts/gpu/src/native_artifact/compact_runtime/mod.rs'))+']\n pub mod compact_runtime;\n}\n');runtime_env=env|{'MECH_INLINE_OWNER_RECORDS':str(records)};base=['rustc','+nightly-2026-03-03','--edition=2024','-C','opt-level=3','-D','warnings',str(module)]
 if aligned:base+=['--cfg','feature="compact-owner-storage-align64"']
 with (out/'build.log').open('w') as log:
  subprocess.run(base+['--test','-o',str(out/'tests')],env=runtime_env,stdout=log,stderr=log,check=True)
  if records==12:subprocess.run(base+['--crate-type','rlib','--crate-name','mech_gpu','-o',str(out/'libmech_gpu_runtime.rlib')],env=runtime_env,stdout=log,stderr=log,check=True)
 with (out/'tests.log').open('w') as log:subprocess.run([str(out/'tests')],stdout=log,stderr=log,check=True)
 (out/'variant.json').write_text(json.dumps({'source_receipt':receipt,'inline_owner_records':records,'alignment':64 if aligned else 'default','runtime_build_command':base+['--crate-type','rlib','--crate-name','mech_gpu','-o',str(out/'libmech_gpu_runtime.rlib')]},indent=2)+'\n')
 print('Runtime tests complete',role,flush=True)
for name,recipe_name in [('final-default-reproduction','published-winning-recipe.json'),('final-aligned64','scratch-paired128-recipe.json')]:
 out=r/name;x=json.loads((r/recipe_name).read_text())
 if name=='final-aligned64':x['artifacts']=json.loads((r/'scratch-paired128/receipt.json').read_text())['artifacts']
 p=d/(name+'-recipe.json');p.write_text(json.dumps(x,indent=2)+'\n')
 with (d/(name+'-setup.log')).open('w') as log:
  subprocess.run(['python3','-B',str(r/'emit.py'),str(p),str(out),'--compiler',str(d/'compile_profile'),'--compiler-source-receipt',str(d/'source-receipt.json')],stdout=log,stderr=log,check=True)
  if name=='final-aligned64':
   runtime=d/'12-aligned64';subprocess.run(['python3','-B',str(r/'link-worker.py'),str(out/'frontend'),str(out/'bound'),'--runtime-library',str(runtime/'libmech_gpu_runtime.rlib'),'--runtime-variant',str(runtime/'variant.json')],stdout=log,stderr=log,check=True)
   subprocess.run(['python3','-B',str(r/'smoke.py'),str(out/'bound/mech-worker'),str(out/'bound/metadata.json'),str(out/'smoke.json')],stdout=log,stderr=log,check=True)
 print('Exact artifacts and smoke passed',name,flush=True)
(d/'job.json').write_text(json.dumps({'state':'complete','seconds':time.time()-start})+'\n');print('Final source build complete',flush=True)
subprocess.run(['python3','-B',str(r/'study.py'),'final-aligned64-primary',str(r/'scratch-paired128/bound'),str(r/'final-aligned64/bound')],check=True)
