from pathlib import Path
import json,os,subprocess,shutil,hashlib
r=Path('/private/tmp/mech-m3-81-20261124');mech=Path('/Users/cim310/.codex/worktrees/level12-compile-profile/mech');source=mech/'hosts/gpu/src/native_artifact/compact_runtime'
for align in [64,128]:
 d=r/('runtime-align'+str(align));shutil.copytree(source,d/'source');p=d/'source/owner_storage.rs';s=p.read_text();assert s.count('#[repr(C)]')==1;s=s.replace('#[repr(C)]','#[repr(C, align('+str(align)+'))]');s=s.replace('RECORDS * size_of::<Owner>()','(RECORDS * size_of::<Owner>()).next_multiple_of(std::mem::align_of::<OwnerStorage>())');p.write_text(s);(d/'runtime.rs').write_text('pub mod native_artifact {\n #[path = '+json.dumps(str(d/'source/mod.rs'))+']\n pub mod compact_runtime;\n}\n');env=os.environ.copy();env['MECH_INLINE_OWNER_RECORDS']='12';base=['rustc','+nightly-2026-03-03','--edition=2024','-C','opt-level=3','-D','warnings',str(d/'runtime.rs')]
 with (d/'build.log').open('w') as log:
  subprocess.run(base+['--test','-o',str(d/'tests')],env=env,stdout=log,stderr=log,check=True)
  subprocess.run(base+['--crate-type','rlib','--crate-name','mech_gpu','-o',str(d/'libmech_gpu_runtime.rlib')],env=env,stdout=log,stderr=log,check=True)
 with (d/'tests.log').open('w') as log:subprocess.run([str(d/'tests')],stdout=log,stderr=log,check=True)
 variant={'prototype':True,'basis_commit':'2b301734fb43a4abff0d38d68d881e2bf85bd969','changes':'Existing snapshot scratch sort plus OwnerStorage container alignment '+str(align),'owner_records':12,'sources':{p.name:hashlib.file_digest(p.open('rb'),'sha256').hexdigest() for p in (d/'source').glob('*.rs')}};(d/'variant.json').write_text(json.dumps(variant,indent=2)+'\n')
for role in ['unshared-copies','unshared-tails','unshared-both','aligned64','aligned128']:
 out=r/role;command=['python3','-B',str(r/'link-worker.py')]
 if role.startswith('unshared'):
  x=json.loads((r/'scratch-paired128-recipe.json').read_text())
  if role in ['unshared-copies','unshared-both']:x['flags'].pop('MECH_COMPACT_SHARE_FRAME_COPIES')
  if role in ['unshared-tails','unshared-both']:x['flags'].pop('MECH_COMPACT_SHARE_COLD_TAILS')
  p=r/(role+'-recipe.json');p.write_text(json.dumps(x,indent=2)+'\n')
  with (r/(role+'-emission.log')).open('w') as log:subprocess.run(['python3','-B',str(r/'emit.py'),str(p),str(out),'--compiler',str(r/'compiler-scratch/compile_profile'),'--compiler-source-receipt',str(r/'compiler-scratch/source-receipt.json')],stdout=log,stderr=log,check=True)
  command +=[str(out/'frontend'),str(out/'bound'),'--runtime-library',str(r/'compiler-scratch/libmech_gpu_runtime.rlib'),'--runtime-variant',str(r/'compiler-scratch/runtime-variant.json')]
 else:
  out.mkdir();d=r/('runtime-align'+role.removeprefix('aligned'));command +=[str(r/'scratch-paired128/frontend'),str(out/'bound'),'--runtime-library',str(d/'libmech_gpu_runtime.rlib'),'--runtime-variant',str(d/'variant.json')]
 with (out/'setup.log').open('w') as log:
  subprocess.run(command,stdout=log,stderr=log,check=True)
  subprocess.run(['python3','-B',str(r/'smoke.py'),str(out/'bound/mech-worker'),str(out/'bound/metadata.json'),str(out/'smoke.json')],stdout=log,stderr=log,check=True)
 print('Prepared',role,flush=True)
for role in ['unshared-copies','unshared-tails','unshared-both','aligned64','aligned128']:
 subprocess.run(['python3','-B',str(r/'study.py'),'screen-'+role,str(r/'scratch-paired128/bound'),str(r/role/'bound'),'--panel',str(r/'critical-panel.json'),'--blocks','96'],check=True)
