pub mod native_artifact {
 #[path = "/private/tmp/mech-m3-81-20261124/runtime-align128/source/mod.rs"]
 pub mod compact_runtime;
}
