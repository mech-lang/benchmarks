from pathlib import Path
import subprocess
r=Path('/private/tmp/mech-m3-81-20261124')
for role,extra in [('null96',[]),('null96-parallel',['--parallel-warmup']),('null96-qos',['--parallel-warmup','--qos-library',str(r/'scheduling/qos.dylib')])]:
 subprocess.run(['python3','-B',str(r/'study.py'),role,str(r/'scratch-paired128/bound'),str(r/'scratch-paired128/bound'),'--panel',str(r/'null-panel.json')]+extra,check=True)
