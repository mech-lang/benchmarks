pub mod native_artifact {
    #[path = "/Users/cim310/.codex/worktrees/level12-compile-profile/mech/hosts/gpu/src/native_artifact/compact_runtime/mod.rs"]
    pub mod compact_runtime;
}
