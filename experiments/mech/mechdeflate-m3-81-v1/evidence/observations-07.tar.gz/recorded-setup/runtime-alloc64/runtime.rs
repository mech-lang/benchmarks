pub mod native_artifact {
    #[path = "/private/tmp/mech-m3-81-20261124/runtime-alloc64/src/mod.rs"]
    pub mod compact_runtime;
}
