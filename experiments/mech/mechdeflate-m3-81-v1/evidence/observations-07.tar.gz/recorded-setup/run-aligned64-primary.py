from pathlib import Path
import os,time,subprocess,json
r=Path('/private/tmp/mech-m3-81-20261124')
while True:
 try:os.kill(96858,0)
 except ProcessLookupError:break
 time.sleep(2)
for role in ['unshared-copies','unshared-tails','unshared-both','aligned64','aligned128']:
 assert json.loads((r/('screen-'+role+'-job.json')).read_text())['state']=='complete'
subprocess.run(['python3','-B',str(r/'study.py'),'aligned64-primary',str(r/'scratch-paired128/bound'),str(r/'aligned64/bound')],check=True)
