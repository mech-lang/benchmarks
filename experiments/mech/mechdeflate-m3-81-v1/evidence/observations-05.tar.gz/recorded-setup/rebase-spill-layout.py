"""Translate a layout only after exact ordered native CFG equality."""
import argparse
from hashlib import file_digest,sha256
import json
from pathlib import Path
from runpy import run_path
from struct import unpack_from

ROOT=Path(__file__).resolve().parent
MACHO=run_path(str(ROOT/'support/pure-counters/reachability-census.py'))
SYMBOL='mech_compact_numeric_475_vector'
sha=lambda p:file_digest(p.open('rb'),'sha256').hexdigest()
read=lambda p:json.loads(p.read_text())

def signed(word,low,bits):
    n=(word>>low)&((1<<bits)-1)
    return n-(1<<bits) if n>>(bits-1) else n

def shape(folder):
    receipt=read(folder/'receipt.json')
    assert sha(folder/'frontend/program.o')==receipt['artifacts']['program.o']
    metadata=read(folder/'frontend/metadata.json')
    def phases(v):
        if isinstance(v,dict):
            if v.get('symbol')==SYMBOL and v.get('code_bytes',0)>0:yield v
            for c in v.values():yield from phases(c)
        elif isinstance(v,list):
            for c in v:yield from phases(c)
    phase,=phases(metadata)
    image,sections,symbols=MACHO['load'](folder/'frontend/program.o')
    names=MACHO['text_symbols'](sections,symbols)
    _,base,_,offset,*_=sections[MACHO['TEXT']]
    begin=offset+names['_'+SYMBOL]-base
    body=image[begin:begin+phase['code_bytes']]
    assert len(body)==phase['code_bytes']
    words={};refs=[]
    for at in range(0,len(body),4):
        if refs and at>=min(refs):break
        w=unpack_from('<I',body,at)[0];words[at]=w
        if w&0x3b000000==0x18000000:
            vector,opc=(w>>26)&1,w>>30
            assert opc<3
            width=([4,8,16] if vector else [4,8,4])[opc]
            target=at+4*signed(w,5,19)
            assert at<target and target+width<=len(body) and target%width==0
            refs.append(target)
    pool=min(refs) if refs else None
    while words[max(words)]==0xd503201f:words.pop(max(words))
    end=max(words)+4
    flow={};heads={0}
    for at,w in words.items():
        field=None
        if w&0xfc000000==0x14000000:field=(0,26)
        elif w&0xff000010==0x54000000 or w&0x7e000000==0x34000000:field=(5,19)
        elif w&0x7e000000==0x36000000:field=(5,14)
        if field:
            low,bits=field;target=at+4*signed(w,low,bits)
            assert target in words
            heads.add(target)
            opcode=w&~(((1<<bits)-1)<<low)
            kind=('jump' if bits==26 else 'condition',opcode)
        else:
            target=None
            if w&0xfffffc1f==0xd65f0000 or w in (0xd65f0bff,0xd65f0fff):kind=('return',w)
            elif w&0xffe0001f==0xd4200000 or w&0xffff0000==0:kind=('trap',w)
            else:
                assert w&0xfc000000!=0x94000000 and w&0xfe000000!=0xd6000000
                kind=('next',None)
        flow[at]=(kind,target)
        if kind[0]!='next' and at+4<end:heads.add(at+4)
    heads=sorted(heads);ids={v:i for i,v in enumerate(heads)};blocks=[]
    for stop in [*heads[1:],end]:
        kind,target=flow[stop-4]
        fall=ids.get(stop) if kind[0] not in ('jump','return','trap') else None
        blocks.append((kind,None if target is None else ids[target],fall))
    assert flow[end-4][0][0] in ('jump','return','trap')
    return {'heads':heads,'blocks':blocks,'pool':pool,'code_end':end,
            'object_sha256':receipt['artifacts']['program.o'],'body_sha256':sha256(body).hexdigest()}

parser=argparse.ArgumentParser(__doc__)
parser.add_argument('limit',type=int)
args=parser.parse_args()
old=ROOT/'spill2-unlaid';new=ROOT/('spill'+str(args.limit)+'-unlaid')
prior=read(ROOT/'published-winning-recipe.json')
path=next(v.split('@',1)[1] for v in prior['flags']['MECH_COMPACT_PHASE_BLOCK_LAYOUT'].split(';') if v.startswith(SYMBOL+'@'))
profile=read(Path(path));a,b=shape(old),shape(new)
assert sorted(profile['order'])==a['heads'] and profile['literal_offset']==a['pool']
assert a['blocks']==b['blocks'], 'Native CFG or branch opcodes changed; do not transfer layout'
assert len(a['heads'])==len(b['heads'])
assert b['pool'] is None or b['pool']%16==0, 'The backend requires 16-byte pool geometry'
assert 'object_tail' not in profile
table=dict(zip(a['heads'],b['heads'],strict=True))
profile=profile|{'order':[table[v] for v in profile['order']],'literal_offset':b['pool']}
dest=ROOT/('profiles/spill'+str(args.limit)+'-layout.json')
dest.write_text(json.dumps(profile,indent=2)+'\n')
(ROOT/('spill'+str(args.limit)+'-layout-proof.json')).write_text(json.dumps({
    'control':a,'candidate':b,'prior_profile_sha256':sha(Path(path)),
    'scope':'Exact ordered native control-flow graph and branch opcode equality. Only block byte coordinates translate; all blocks and pool boundaries remain validated by the compiler.'
},indent=2)+'\n')
recipe=read(ROOT/('spill'+str(args.limit)+'-unlaid-recipe.json'))
recipe['flags'].pop('MECH_INSPECT_FP_SPILL_CACHE')
recipe['flags']['MECH_COMPACT_PHASE_BLOCK_LAYOUT']+=';'+SYMBOL+'@'+str(dest)
(ROOT/('spill'+str(args.limit)+'-recipe.json')).write_text(json.dumps(recipe,indent=2)+'\n')
print('Proved layout translation for',len(table),'blocks; pool',b['pool'])
