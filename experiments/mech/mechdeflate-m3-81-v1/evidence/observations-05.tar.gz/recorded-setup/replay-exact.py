"""Run the published M1 winner unchanged on this M3, outside all build work."""
import argparse
from hashlib import file_digest
import json
import os
from pathlib import Path
from runpy import run_path
import sys
import time
import traceback

ROOT=Path(__file__).resolve().parent
PACKET=Path('/private/tmp/mech-m3-deflate-81-benchmarks/experiments/mech/mechdeflate-81-v1')
parser=argparse.ArgumentParser(__doc__)
parser.add_argument('prepared',type=Path)
parser.add_argument('label')
args=parser.parse_args()
out=args.prepared.resolve()
assert json.loads((out/'prepared.json').read_text())['blocks_per_case']==96
assert not (out/'short-prefix-copy-forward').exists()
assert not (out/'short-prefix-copy-reverse').exists()
assert json.loads((ROOT/'compiler-job.json').read_text())['state']=='complete'
sys.dont_write_bytecode=True
sys.path.insert(0,str(PACKET.parent/'mechdeflate-phase-routes-v1'))
published=run_path(str(PACKET/'replay_timings.py'))
helpers=run_path(str(published['PREVIOUS']/'replay_timings.py'))
status=ROOT/(args.label+'-job.json')
start=time.time()
status.write_text(json.dumps({'state':'running','pid':os.getpid(),'started':start,'output':str(out)},indent=2)+'\n')
sha=lambda p:file_digest(p.open('rb'),'sha256').hexdigest()
(out/'m3-scope.json').write_text(json.dumps({
    'hardware':'Apple M3','source_commit':'2b301734fb43a4abff0d38d68d881e2bf85bd969',
    'benchmark_commit':'a11b5816598a8e215ed46e1e3ef722ae2022a3a4',
    'replay_script_sha256':sha(PACKET/'replay_timings.py'),
    'recipe_sha256':sha(PACKET/'recipe.json'),
    'exact_published_timing_workers':True,'compiler_and_codec_builds_excluded_from_runtime_clocks':True,
    'all_cases':81,'balanced_blocks_per_case_per_order':96,
    'orders':['forward','reverse'],
    'scope':'Original published diagnostic complete-invocation boundary, including fresh private runtime state and final output ownership. Every result has exact peer-byte rules, independent inflate and alias checks. Unchanged M1 worker binaries, peers and controller, relocated fixtures only.'
},indent=2)+'\n')
try:
    published['run_timings'](out,helpers,'roc')
except BaseException:
    traceback.print_exc()
    status.write_text(json.dumps({'state':'failed','seconds':time.time()-start,'output':str(out)},indent=2)+'\n')
    raise
else:
    wins=json.loads((out/'runtime-wins.json').read_text())
    status.write_text(json.dumps({'state':'complete','seconds':time.time()-start,'output':str(out),'wins':wins},indent=2)+'\n')
