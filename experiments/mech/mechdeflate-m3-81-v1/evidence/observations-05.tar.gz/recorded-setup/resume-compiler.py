"""Finish compiler setup with four build workers; no runtime observations have run."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import time
import traceback

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'compiler'
MECH = Path('/Users/cim310/.codex/worktrees/level12-compile-profile/mech')
prior = json.loads((ROOT/'compiler-initial-job.json').read_text())
start = time.time()
job = ROOT/'compiler-job.json'
job.write_text(json.dumps({'state':'running','pid':os.getpid(),'started':start,'resumed':True}))
command = ['cargo','+nightly-2026-03-03','build','--locked','--release','--config',
           'profile.release.package.libmimalloc-sys.opt-level=1','--manifest-path',
           str(OUT/'compiler-driver/Cargo.toml'),'--target-dir',str(ROOT/'target'),'--bin','compile_profile']
profile = {'CARGO_BUILD_JOBS':'4','CARGO_PROFILE_RELEASE_OPT_LEVEL':'3',
           'CARGO_PROFILE_RELEASE_DEBUG':'false','CARGO_PROFILE_RELEASE_LTO':'false',
           'CARGO_PROFILE_RELEASE_CODEGEN_UNITS':'16','CARGO_INCREMENTAL':'0'}
try:
    env = {k:v for k,v in os.environ.items() if not k.startswith('MECH_')} | profile
    with (OUT/'compiler-build-resumed.log').open('w') as log:
        subprocess.run(command,cwd=MECH,env=env,stdout=log,stderr=log,check=True)
    shutil.copy2(ROOT/'target/release/compile_profile',OUT/'compile_profile')
except BaseException:
    traceback.print_exc()
    job.write_text(json.dumps({'state':'failed','seconds':time.time()-start,'resumed':True}))
    raise
else:
    record = {'scope':'Compiler construction only; excluded from all codec runtime clocks.',
              'reason':'Resume unfinished setup with four Cargo workers instead of one; compiler/codegen options unchanged.',
              'initial_attempt':prior,'resumed_command':command,'resumed_environment':profile,
              'resumed_seconds':time.time()-start,'total_wall_seconds':time.time()-prior['original_started']}
    (OUT/'compiler-build.json').write_text(json.dumps(record,indent=2)+'\n')
    job.write_text(json.dumps({'state':'complete','seconds':record['total_wall_seconds'],'resumed':True}))
    print('Compiler setup complete.',flush=True)
