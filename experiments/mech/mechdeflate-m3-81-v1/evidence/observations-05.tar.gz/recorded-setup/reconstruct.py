"""Reconstruct a candidate from published recipes/review updates; exactness remains gated."""
import json
from pathlib import Path
import re
import runpy
import sys

ROOT = Path(__file__).resolve().parent
PACKETS = Path('/private/tmp/mech-m3-deflate-81-benchmarks/experiments/mech')
sys.path.insert(0,str(PACKETS/'mechdeflate-phase-routes-v1'))
ns = runpy.run_path(str(PACKETS/'mechdeflate-phase-routes-v1/run_study.py'))
_, flags = ns['bind_recipe'](PACKETS/'mechdeflate-masked-fields-v1')
updates = {
 'MECH_COMPACT_FORWARD_PHASE_ROUTES':'mech_compact_numeric_475_vector;mech_compact_numeric_3956_vector',
 'MECH_COMPACT_PHASE_BRANCH_ON_ZERO':'mech_compact_numeric_475_vector',
 'MECH_ARM64_REUSE_PREFETCH_BASES':'1',
 'MECH_GROUP_PACKED_HISTOGRAM_VISITS':'16',
 'MECH_GROUP_PACKED_HISTOGRAM_VECTOR_CHUNKS':'1',
 'MECH_GROUP_PACKED_HISTOGRAM_STREAM_CHUNKS':'1',
 'MECH_GROUP_PACKED_HISTOGRAM_BYTE_KEYS':'1',
 'MECH_COMPACT_ADMIT_DECREASING_INDICES':'mech_compact_numeric_3956_vector',
 'MECH_COMPACT_SEEDED_HISTOGRAM':'1',
 'MECH_COMPACT_SHORT_BYTE_APPENDS':'1',
 'MECH_COMPACT_ADMIT_CARRIED_HALFWORDS':'mech_compact_numeric_475_vector',
 'MECH_COMPACT_FOLD_SINGLE_USE_CSET':'mech_compact_numeric_475_vector',
 'MECH_COMPACT_FOLD_REDUNDANT_ZERO':'1',
 'MECH_COMPACT_CCMP_LITERAL_CONSTANTS':'mech_compact_numeric_475_vector',
 'MECH_FOLD_NARROW_PACKED_WORDS':'immediates',
 'MECH_PAIR_REBASE_LITERAL_COSTS':'1',
 'MECH_CHECK_GROUPED_LITERAL_BYTES':'1',
 'MECH_COMPACT_INLINE_SHORT_BYTE_APPENDS':'1',
 'MECH_COMPACT_HOIST_INDEXED_LOAD_BASES':'mech_compact_numeric_3009_no_growth_composed',
 'MECH_COMPOSE_FOLD_ADMITTED_COST_MINIMUM':'1',
 'MECH_GROUPED_LITERAL_PREFIX_SPAN':'1',
 'MECH_COMPACT_SPECIALIZE_TAGGED_STORE_TAILS':'mech_compact_numeric_3956_vector',
 'MECH_COMPACT_CARRY_BRANCH_OUTCOMES':'thread:mech_compact_numeric_3956_vector',
 'MECH_COMPACT_FOLD_PHASE_CHECKED_ARITHMETIC':'mech_compact_numeric_5895;mech_compact_numeric_5895_vector;mech_compact_numeric_6633;mech_compact_numeric_6633_vector',
 'MECH_COMPACT_FIXED_TRANSFORMS':'3956',
 'MECH_COMPACT_NATIVE_GAP_SORT':'1',
 'MECH_COMPACT_BOUNDED_U32_TREE':'1',
 'MECH_COMPACT_GROUP_FOUR_LITERAL_APPENDS':'1',
 'MECH_COMPACT_BOUNDED_PRICE_BLEND':'1',
 'MECH_COMPACT_GROUP_CODE_PRICES':'1',
 'MECH_COMPACT_NONZERO_U32_PACK':'1',
 'MECH_COMPACT_CHECKED_BYTE_SCATTER':'1',
}
flags |= updates
for key in ('MECH_COMPOSE_IMMUTABLE_COST_CODE_PAGE_SHIFT','MECH_COMPACT_PHASE_BLOCK_LAYOUT','MECH_COMPACT_PHASE_REGISTER_WEIGHTS'):
    flags.pop(key,None)
record = {'flags':flags,'scope':'Provisional reconstruction from public notes. Not the M1 winner unless its object and metadata hashes match.',
          'unconfirmed_options':['MECH_COMPACT_FIXED_TRANSFORMS','MECH_COMPACT_CARRY_BRANCH_OUTCOMES'],
          'expected_m1_artifacts':{'program.o':'58c9177ccf6158d352d5a8f888cdb34f0897b4bd5aaeeb53e187b371dd89c553',
                                   'metadata.json':'980e9c35249cfd37c9866b7be9c70f664bc0e78a55feaf5f415d866ef5a78de7'},
          'updates':updates}
(ROOT/'provisional-recipe.json').write_text(json.dumps(record,indent=2)+'\n')
comments = json.loads((ROOT/'pr999-public-comments.json').read_text())
decoder = json.JSONDecoder()
profiles = {}
for date, symbol in [('2026-11-23T13:15:31Z','mech_compact_numeric_475_vector'),
                     ('2026-11-23T18:33:20Z','mech_compact_numeric_3009_no_growth_composed'),
                     ('2026-11-23T20:32:17Z','mech_compact_numeric_3956_vector')]:
    body = next(c['body'] for c in comments if c['created_at']==date)
    values = []
    for block in re.findall(r'```json\n(.*?)```',body,re.S):
        while block.strip():
            value,end = decoder.raw_decode(block.lstrip())
            values.append(value)
            block = block.lstrip()[end:]
    profiles[symbol] = {'source_comment_date':date,'records':values}
(ROOT/'public-profile-updates.json').write_text(json.dumps(profiles,indent=2)+'\n')
print('Provisional flags and published profile updates saved; exact hash gates retained.')
