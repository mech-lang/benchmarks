def replace_atom(path, destination, start, extent, body, new_relocs=(), new_name=b"", moved_relocs=None):
    base, sections, symbols = macho.load(path)
    commands, headers = layout.obj.tables(base)
    assert set(commands) == {0x19, 2, 11} and set(sections) == {text, constant}
    assert not any(unpack_from("<12I", base, commands[11] + 32))
    text_id, address, text_size, text_offset, reloc_at, reloc_count = sections[text]
    const_id, const_address, const_size, const_offset, _, const_relocs = sections[constant]
    assert address == 0 and not const_relocs
    prior_relocs = layout.obj.relocs(base, sections[text])
    contained = {at for at, _ in prior_relocs if start <= at < extent}
    moved_relocs = moved_relocs or {}
    assert set(moved_relocs) == contained
    alignment = 1 << unpack_from("<I", base, headers[text] + 52)[0]
    assert start % 4 == extent % 4 == 0 and alignment >= 4
    padding = (extent - start - len(body)) % alignment
    delta = len(body) + padding - (extent - start)
    assert delta % alignment == 0
    sys_symbols = commands[2]
    symbols_at, n, strings_at, strings_size = unpack_from("<4I", base, sys_symbols + 8)
    undefined_at, n_undefined = unpack_from("<2I", base, commands[11] + 24)
    assert undefined_at + n_undefined == n == len(symbols) and n < (1 << 24)
    assert not any(label.encode() + b"\0" == new_name for label, *_ in symbols)
    const_end = const_offset + const_size
    assert reloc_at == (const_end + 7) & -8
    assert reloc_at + 8 * reloc_count == symbols_at and symbols_at + 16 * n == strings_at
    assert strings_at + strings_size == len(base)
    old_relocs = [(moved_relocs.get(at, at + (delta if at >= extent else 0)), info)
                  for at, info in prior_relocs]
    fixed = sorted([*new_relocs, *old_relocs], key=lambda pair: -pair[0])
    new_reloc_at = (const_end + delta + 7) & -8
    new_symbol_at = new_reloc_at + 8 * len(fixed)
    header = bytearray(base[:text_offset])
    pack_into("<Q", header, commands[0x19] + 32, const_address + const_size + delta)
    pack_into("<Q", header, commands[0x19] + 48, const_end + delta - text_offset)
    pack_into("<Q", header, headers[text] + 40, text_size + delta)
    pack_into("<2I", header, headers[text] + 56, new_reloc_at, len(fixed))
    pack_into("<Q", header, headers[constant] + 32, const_address + delta)
    pack_into("<I", header, headers[constant] + 48, const_offset + delta)
    symbol_count = n + bool(new_name)
    pack_into("<4I", header, sys_symbols + 8, new_symbol_at, symbol_count,
              new_symbol_at + 16 * symbol_count, strings_size + len(new_name))
    records = bytearray(base[symbols_at:strings_at])
    for index, (_, _, section, pc) in enumerate(symbols):
        if section == const_id or section == text_id and pc >= extent:
            pack_into("<Q", records, index * 16 + 8, pc + delta)
    if new_name:
        pack_into("<I", header, commands[11] + 28, n_undefined + 1)
        records.extend(pack("<IBBHQ", strings_size, 1, 0, 0, 0))
    destination.write_bytes(b"".join((
        header, base[text_offset:text_offset + start], body,
        pack("<I", 0xd503201f) * (padding // 4), base[text_offset + extent:const_end],
        bytes(new_reloc_at - (const_end + delta)), b"".join(pack("<2I", *r) for r in fixed),
        records, base[strings_at:], new_name,
    )))
    result, final_sections, final_symbols = macho.load(destination)
    assert final_sections[text][2] == text_size + delta and len(final_symbols) == symbol_count
    if new_name:
        assert final_symbols[-1] == (new_name[:-1].decode(), 1, 0, 0)
    assert len(layout.obj.relocs(result, final_sections[text])) == len(fixed)
    return text_size + delta
