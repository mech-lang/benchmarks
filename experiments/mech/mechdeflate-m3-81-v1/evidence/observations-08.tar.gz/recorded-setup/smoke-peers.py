"""Validate both pinned peers on the M3, excluding these calls from timing results."""
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
COMPARISON = ROOT / 'comparison'
pins = json.loads((COMPARISON / 'pinned-peers/pins.json').read_text())
cases = json.loads((COMPARISON / 'fixtures.json').read_text())
oracle = {x['case']:x for x in json.loads((COMPARISON / 'pinned-peers/libdeflate-output-oracle.json').read_text())}
records = {}
for actor in ('roc','libdeflate'):
    rows = []
    with (ROOT / ('peer-smoke-' + actor + '.stderr')).open('w') as stderr:
        child = subprocess.Popen(pins['actors'][actor]['command'],stdin=subprocess.PIPE,
                                 stdout=subprocess.PIPE,stderr=stderr,text=True)
        try:
            assert child.stdout.readline().strip() == 'SESSION_READY'
            for index, case in enumerate(cases):
                child.stdin.write(f'C\t{index}\t0\n')
                child.stdin.flush()
                assert child.stdout.readline().strip() == 'CASE_READY\t' + case['name']
                child.stdin.write('NN')
                child.stdin.flush()
                for _ in range(2):
                    row = json.loads(child.stdout.readline())
                    assert row['case'] == case['name']
                    assert all(row[k] for k in ('independent_inflation','input_alias_unchanged','borrowed_output_alias_unchanged'))
                    if actor == 'roc':
                        assert row['exact_reference'] and row['capacity'] == case['capacity']
                        assert row['raw_bytes'] == case['raw_bytes']
                    else:
                        assert row['level'] == 12 and row['version'] == '1.26'
                        assert row['reference_capacity'] == case['capacity']
                        for k in ('output_sha256','capacity','raw_bytes','matches_reference_bytes'):
                            assert row[k] == oracle[case['name']][k]
                    rows.append(row)
                assert child.stdout.readline().strip() == 'CASE_DONE\t' + case['name']
            child.stdin.write('Q\n')
            child.stdin.flush()
            assert child.wait(timeout=30) == 0
        finally:
            if child.poll() is None:
                child.kill()
                child.wait()
    records[actor] = rows
    print(actor, '162 complete calls checked', flush=True)
(ROOT / 'peer-smoke.json').write_text(json.dumps({'primary_timing':False,'actors':records},indent=2)+'\n')
