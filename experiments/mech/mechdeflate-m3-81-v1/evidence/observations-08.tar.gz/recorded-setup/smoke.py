"""Run the pinned complete-invocation assertions outside primary timing."""
import argparse
import json
from pathlib import Path
import subprocess

parser = argparse.ArgumentParser()
parser.add_argument('worker', type=Path)
parser.add_argument('metadata', type=Path)
parser.add_argument('output', type=Path)
args = parser.parse_args()
fixtures = Path(__file__).resolve().parent / 'comparison/fixtures.json'
cases = json.loads(fixtures.read_text())
assert len(cases) == 81
rows = []
with args.output.with_suffix('.stderr').open('w') as stderr:
    child = subprocess.Popen([str(args.worker.resolve()), str(args.metadata.resolve()), str(fixtures)],
                             stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=stderr, text=True)
    try:
        assert child.stdout.readline().strip() == 'SESSION_READY'
        for index, case in enumerate(cases):
            child.stdin.write(f'C\t{index}\t0\n')
            child.stdin.flush()
            assert child.stdout.readline().strip() == 'CASE_READY\t' + case['name']
            child.stdin.write('NN')
            child.stdin.flush()
            for _ in range(2):
                row = json.loads(child.stdout.readline())
                assert row['case'] == case['name']
                assert all(row[key] for key in ('exact_reference', 'independent_inflation',
                                              'input_alias_unchanged', 'borrowed_output_alias_unchanged'))
                assert row['capacity'] == case['capacity']
                assert row['nonreturned_private_bytes_at_return'] == 0
                rows.append(row)
            assert child.stdout.readline().strip() == 'CASE_DONE\t' + case['name']
        child.stdin.write('Q\n')
        child.stdin.flush()
        assert child.wait(timeout=30) == 0
    finally:
        if child.poll() is None:
            child.kill()
            child.wait()
args.output.write_text(json.dumps({'cases': 81, 'observations': rows, 'primary_timing': False}, indent=2) + '\n')
print('162 exact-output, inflation, capacity and alias checks passed.')
