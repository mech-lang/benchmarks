from pathlib import Path
import subprocess
r=Path('/private/tmp/mech-m3-81-20261124')
for role in ['paired16','paired64','hist8-64','unseeded64']:
 name=role+'-discovery'
 with (r/(name+'.log')).open('w') as log:
  subprocess.run(['python3','-B',str(r/'study.py'),name,str(r/'exact-fresh-base/bound'),str(r/('exact-'+role)/'bound'),'--panel',str(r/'exact-discovery-panel.json'),'--blocks','24'],stdout=log,stderr=log,check=True)
 print('Complete',name,flush=True)
