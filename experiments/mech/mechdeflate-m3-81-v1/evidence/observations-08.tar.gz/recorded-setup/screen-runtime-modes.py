from pathlib import Path
import subprocess
r=Path('/private/tmp/mech-m3-81-20261124')
for role in ['native12','native1','records8','records16']:
 name=role+'-critical'
 with (r/(name+'.log')).open('w') as log:
  subprocess.run(['python3','-B',str(r/'study.py'),name,str(r/'exact-align64/bound'),str(r/(role+'-align64')/'bound'),'--panel',str(r/'critical-panel.json'),'--blocks','24'],stdout=log,stderr=log,check=True)
 print('Complete',name,flush=True)
