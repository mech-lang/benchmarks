from pathlib import Path
import subprocess
r=Path('/private/tmp/mech-m3-81-20261124')
for role in ['native1','pool12-generic','pool12-native']:
 subprocess.run(['python3','-B',str(r/'study.py'),'screen-'+role+'-paired64',str(r/'exact-fresh-base/bound'),str(r/(role+'-paired64')/'bound'),'--panel',str(r/'critical-panel.json'),'--blocks','24'],check=True)
