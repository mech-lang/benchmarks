from pathlib import Path
import subprocess
r=Path('/private/tmp/mech-m3-81-20261124')
for alignment in [32,64,128]:
 name='layout'+str(alignment)+'-discovery'
 with (r/(name+'.log')).open('w') as log:
  subprocess.run(['python3','-B',str(r/'study.py'),name,str(r/'exact-fresh-base/bound'),str(r/('exact-align'+str(alignment))/'bound'),'--panel',str(r/'exact-discovery-panel.json'),'--blocks','24'],stdout=log,stderr=log,check=True)
 print('Complete',name,flush=True)
