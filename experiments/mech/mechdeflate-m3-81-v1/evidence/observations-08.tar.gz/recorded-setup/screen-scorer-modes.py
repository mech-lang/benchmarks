from pathlib import Path
import subprocess
r=Path('/private/tmp/mech-m3-81-20261124')
for role in ['singleaccum','noeight','page6']:
 subprocess.run(['python3','-B',str(r/'study.py'),'screen-'+role,str(r/'exact-fresh-base/bound'),str(r/(role+'-laid')/'bound'),'--panel',str(r/'critical-panel.json'),'--blocks','24'],check=True)
