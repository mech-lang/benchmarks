from pathlib import Path
import subprocess
r=Path('/private/tmp/mech-m3-81-20261124')
for role in ['spill6-original22','spill12-original22']:
 name=role+'-critical'
 with (r/(name+'.log')).open('w') as log:
  subprocess.run(['python3','-B',str(r/'study.py'),name,str(r/'exact-fresh-base/bound'),str(r/role/'bound'),'--panel',str(r/'critical-panel.json'),'--blocks','24'],stdout=log,stderr=log,check=True)
 print('Complete',name,flush=True)
