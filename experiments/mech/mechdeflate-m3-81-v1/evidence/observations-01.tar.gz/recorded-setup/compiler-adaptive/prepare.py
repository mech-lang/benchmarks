from pathlib import Path
import hashlib,json,subprocess,shutil,os
r=Path('/private/tmp/mech-m3-81-20261124');d=r/'compiler-adaptive'
recipe=json.loads((r/'exact-paired64-recipe.json').read_text());recipe['flags']['MECH_COMPACT_PAIR_REGISTER_SPILLS']='checked';recipe['scope']='Unchanged compressor source, adaptive histogram choice compiler, paired literal emission and 64-byte function alignment.';(r/'adaptive-paired64-recipe.json').write_text(json.dumps(recipe,indent=2)+'\n')
with (r/'adaptive-paired64-setup.log').open('w') as log:
 subprocess.run(['python3','-B',str(r/'emit.py'),str(r/'adaptive-paired64-recipe.json'),str(r/'adaptive-paired64'),'--compiler',str(d/'compile_profile'),'--compiler-source-receipt',str(d/'source-receipt.json')],stdout=log,stderr=log,check=True)
combined=r/'runtime-combined';shutil.copytree(r/'runtime-permutation-sort/source',combined/'source');shutil.copyfile(r/'runtime-lazy-transforms/source/fixed_transform.rs',combined/'source/fixed_transform.rs');(combined/'runtime.rs').write_text('pub mod native_artifact {\n #[path = '+json.dumps(str(combined/'source/mod.rs'))+']\n pub mod compact_runtime;\n}\n');env=os.environ.copy();env['MECH_INLINE_OWNER_RECORDS']='12';base=['rustc','+nightly-2026-03-03','--edition=2024','-C','opt-level=3','-D','warnings',str(combined/'runtime.rs')]
with (combined/'build.log').open('w') as log:
 subprocess.run(base+['--test','-o',str(combined/'tests')],env=env,stdout=log,stderr=log,check=True)
 subprocess.run(base+['--crate-type','rlib','--crate-name','mech_gpu','-o',str(combined/'libmech_gpu_runtime.rlib')],env=env,stdout=log,stderr=log,check=True)
with (combined/'tests.log').open('w') as log:subprocess.run([str(combined/'tests')],stdout=log,stderr=log,check=True)
variant={'basis_commit':'2b301734fb43a4abff0d38d68d881e2bf85bd969','prototype':True,'change':'In-place frequency counting permutation plus lazy snapshot payload initialization.','runtime_compile_environment':{'MECH_INLINE_OWNER_RECORDS':'12'},'sources':{p.name:hashlib.file_digest(p.open('rb'),'sha256').hexdigest() for p in (combined/'source').glob('*.rs')}};(combined/'variant.json').write_text(json.dumps(variant,indent=2)+'\n')
for role in ['adaptive-paired64','adaptive-permutation','adaptive-combined']:
 out=r/role;out.mkdir(exist_ok=True);command=['python3','-B',str(r/'link-worker.py'),str(r/'adaptive-paired64/frontend'),str(out/'bound')]
 if role!='adaptive-paired64':
  runtime=r/('runtime-permutation-sort' if role=='adaptive-permutation' else 'runtime-combined');command+=['--runtime-library',str(runtime/'libmech_gpu_runtime.rlib'),'--runtime-variant',str(runtime/'variant.json')]
 with (out/'link-setup.log').open('w') as log:
  subprocess.run(command,stdout=log,stderr=log,check=True)
  subprocess.run(['python3','-B',str(r/'smoke.py'),str(out/'bound/mech-worker'),str(out/'bound/metadata.json'),str(out/'smoke.json')],stdout=log,stderr=log,check=True)
 print('Prepared',role,flush=True)
for role in ['adaptive-paired64','adaptive-permutation','adaptive-combined']:
 subprocess.run(['python3','-B',str(r/'study.py'),'screen-'+role,str(r/'exact-paired64/bound'),str(r/role/'bound'),'--panel',str(r/'critical-panel.json'),'--blocks','24'],check=True)
