from pathlib import Path
import hashlib,json,subprocess,shutil,os
r=Path('/private/tmp/mech-m3-81-20261124');d=r/'compiler-adaptive-v3'
recipe=json.loads((r/'exact-paired64-recipe.json').read_text());recipe['flags']['MECH_COMPACT_PAIR_REGISTER_SPILLS']='checked';recipe['scope']='Unchanged compressor source, adaptive histogram choice compiler, paired literal emission and 64-byte function alignment.';(r/'adaptive-v3-paired64-recipe.json').write_text(json.dumps(recipe,indent=2)+'\n')
with (r/'adaptive-v3-paired64-setup.log').open('w') as log:
 subprocess.run(['python3','-B',str(r/'emit.py'),str(r/'adaptive-v3-paired64-recipe.json'),str(r/'adaptive-v3-paired64'),'--compiler',str(d/'compile_profile'),'--compiler-source-receipt',str(d/'source-receipt.json')],stdout=log,stderr=log,check=True)
for role in ['adaptive-v3-paired64','adaptive-v3-permutation','adaptive-v3-combined']:
 out=r/role;out.mkdir(exist_ok=True);command=['python3','-B',str(r/'link-worker.py'),str(r/'adaptive-v3-paired64/frontend'),str(out/'bound')]
 if role!='adaptive-v3-paired64':
  runtime=r/('runtime-permutation-sort' if role=='adaptive-v3-permutation' else 'runtime-combined');command+=['--runtime-library',str(runtime/'libmech_gpu_runtime.rlib'),'--runtime-variant',str(runtime/'variant.json')]
 with (out/'link-setup.log').open('w') as log:
  subprocess.run(command,stdout=log,stderr=log,check=True)
  subprocess.run(['python3','-B',str(r/'smoke.py'),str(out/'bound/mech-worker'),str(out/'bound/metadata.json'),str(out/'smoke.json')],stdout=log,stderr=log,check=True)
 print('Prepared',role,flush=True)
for role in ['adaptive-v3-paired64','adaptive-v3-permutation','adaptive-v3-combined']:
 subprocess.run(['python3','-B',str(r/'study.py'),'screen-'+role,str(r/'exact-paired64/bound'),str(r/role/'bound'),'--panel',str(r/'critical-panel.json'),'--blocks','24'],check=True)
