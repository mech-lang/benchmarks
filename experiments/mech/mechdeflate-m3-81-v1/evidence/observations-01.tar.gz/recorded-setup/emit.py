"""Emit the unchanged codec using an explicit recipe, with optional exact handoff gates."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parent
MECH = Path('/Users/cim310/.codex/worktrees/level12-compile-profile/mech')
parser = argparse.ArgumentParser()
parser.add_argument('recipe', type=Path)
parser.add_argument('output', type=Path)
parser.add_argument('--compiler', type=Path, default=ROOT/'compiler/compile_profile')
parser.add_argument('--compiler-source-receipt', type=Path)
args = parser.parse_args()
recipe = json.loads(args.recipe.read_text())
source = MECH / 'hosts/gpu/tests/fixtures/native/compact-compiler-regression.mec'
digest = lambda p: hashlib.file_digest(p.open('rb'), 'sha256').hexdigest()
assert digest(source) == '653597f08f889908c48610e90aa65e94a77847fb34500d0cc3a046f83cd3d299'
assert json.loads((ROOT/'compiler-job.json').read_text())['state'] == 'complete'
out = args.output.resolve()
out.mkdir(parents=True, exist_ok=False)
command = [str(args.compiler.resolve()),str(source),str(out/'frontend'),'compact']
flags = recipe['flags']
environment = {k:v for k,v in os.environ.items() if not k.startswith('MECH_')} | flags
start = time.monotonic()
with (out/'compile.log').open('w') as log:
    subprocess.run(command, cwd=MECH, env=environment, stdout=log, stderr=log, check=True)
seconds = time.monotonic() - start
artifacts = {name:digest(out/'frontend'/name) for name in ('program.o','program.mecb','metadata.json')}
record = {'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=MECH,text=True).strip(),
          'source_sha256':digest(source),'compiler_sha256':digest(args.compiler),
          'command':command,'flags':flags,'artifacts':artifacts,'setup_emission_seconds':seconds,
          'scope':'One setup emission, excluded from all runtime clocks.'}
if args.compiler_source_receipt:
    record['compiler_source_receipt'] = json.loads(args.compiler_source_receipt.read_text())
(out/'receipt.json').write_text(json.dumps(record,indent=2)+'\n')
assert artifacts['program.mecb'] == 'c6529d934f020f07f8e59f13fab40927e066649e202269818ad3f009a942a8c3'
if recipe.get('artifacts'):
    assert artifacts == recipe['artifacts'], (artifacts, recipe['artifacts'])
print(json.dumps(record['artifacts'],indent=2))
