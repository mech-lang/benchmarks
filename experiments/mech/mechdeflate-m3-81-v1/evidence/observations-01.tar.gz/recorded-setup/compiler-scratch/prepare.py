from pathlib import Path
import json,subprocess
r=Path('/private/tmp/mech-m3-81-20261124');d=r/'compiler-scratch'
for role in ['scratch-reproduction','scratch-paired64','scratch-paired128']:
 x=json.loads((r/('published-winning-recipe.json' if role=='scratch-reproduction' else 'exact-paired64-recipe.json')).read_text())
 if role!='scratch-reproduction':
  x['flags']['MECH_COMPACT_SORT_SNAPSHOT_SCRATCH']='1';x['flags']['MECH_COMPACT_PAIR_REGISTER_SPILLS']='checked'
  if role=='scratch-paired128':x['flags']['MECH_COMPACT_FUNCTION_ALIGNMENT_LOG2']='7'
 p=r/(role+'-recipe.json');p.write_text(json.dumps(x,indent=2)+'\n');out=r/role
 with (r/(role+'-setup.log')).open('w') as log:
  subprocess.run(['python3','-B',str(r/'emit.py'),str(p),str(out),'--compiler',str(d/'compile_profile'),'--compiler-source-receipt',str(d/'source-receipt.json')],stdout=log,stderr=log,check=True)
  if role!='scratch-reproduction':
   subprocess.run(['python3','-B',str(r/'link-worker.py'),str(out/'frontend'),str(out/'bound'),'--runtime-library',str(d/'libmech_gpu_runtime.rlib'),'--runtime-variant',str(d/'runtime-variant.json')],stdout=log,stderr=log,check=True)
   subprocess.run(['python3','-B',str(r/'smoke.py'),str(out/'bound/mech-worker'),str(out/'bound/metadata.json'),str(out/'smoke.json')],stdout=log,stderr=log,check=True)
 print('Prepared',role,flush=True)
for role in ['scratch-paired64','scratch-paired128']:
 subprocess.run(['python3','-B',str(r/'study.py'),'screen-'+role,str(r/'exact-paired64/bound'),str(r/role/'bound'),'--panel',str(r/'critical-panel.json'),'--blocks','24'],check=True)
