import json,os,subprocess,time,shutil
from pathlib import Path
r=Path('/private/tmp/mech-m3-81-20261124');d=r/'compiler-llvm';env=os.environ.copy();env.update(CARGO_BUILD_JOBS='4',CARGO_PROFILE_RELEASE_OPT_LEVEL='3',CARGO_PROFILE_RELEASE_DEBUG='false',CARGO_PROFILE_RELEASE_LTO='false',CARGO_PROFILE_RELEASE_CODEGEN_UNITS='16',CARGO_INCREMENTAL='0')
base=['cargo','+nightly-2026-03-03','--locked']
common=['--release','--config','profile.release.package.libmimalloc-sys.opt-level=1','--manifest-path',str(d/'driver/Cargo.toml'),'--target-dir',str(r/'target')]
start=time.time()
for action,extra in [('build',['--bin','compile_profile'])]:
 command=['cargo','+nightly-2026-03-03',action,'--locked']+common+extra
 with (d/(action+'.log')).open('w') as log:subprocess.run(command,env=env,stdout=log,stderr=log,check=True)
shutil.copyfile(r/'target/release/compile_profile',d/'compile_profile');(d/'job.json').write_text(json.dumps({'state':'complete','seconds':time.time()-start}));print('Compiler and predicate test complete',flush=True)
