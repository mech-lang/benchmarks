from pathlib import Path
from collections import Counter, defaultdict
import ast,bisect,difflib,hashlib,json,math,re,runpy,struct,subprocess
r=Path('/private/tmp/mech-m3-81-20261124');read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest();m=runpy.run_path(str(r/'support/pure-counters/reachability-census.py'));obj={'unpack_from':struct.unpack_from}; tree=ast.parse((r/'support/pure-counters/compact_object.py').read_text()); exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ['tables','relocs']],type_ignores=[]),'<object tables>','exec'),obj)
def body(path):
 data,sections,syms=m['load'](path);names=m['text_symbols'](sections,syms);section=sections[m['TEXT']];base,offset=section[1],section[3];start=names['_mech_compact_closed_checked'];end=min(v for v in names.values() if v>start);rel=defaultdict(list)
 for at,info in obj['relocs'](data,section):
  at+=base
  if start<=at<end:
   target=syms[info&0xffffff][0] if info>>27&1 else info&0xffffff
   rel[(at-start)//4].append((info>>24,target))
 words=struct.unpack('<'+'I'*((end-start)//4),data[offset+start-base:offset+end-base])
 tokens=[]
 for i,word in enumerate(words):
  if word&0x7c000000==0x14000000:word &= ~0x3ffffff
  elif word&0xff000010==0x54000000 or word&0x7e000000==0x34000000 or word&0x3b000000==0x18000000:word &= ~(0x7ffff<<5)
  elif word&0x7e000000==0x36000000:word &= ~(0x3fff<<5)
  tokens.append((word,tuple(sorted(rel[i],key=str))))
 return tokens
normal_path=r/'scratch-paired128/frontend/program.o';observed_path=r/'root-profile-capture/frontend/program.o';normal=body(normal_path);observed=body(observed_path);matches=difflib.SequenceMatcher(None,normal,observed,autojunk=False).get_matching_blocks();mapping={a+i:b+i for a,b,n in matches for i in range(n)};assert len(mapping)/len(normal)>.95
vcode=(r/'root-inspection-final/native-vcode.asm').read_text();expected=vcode.split(';; REGALLOC_INPUT_BEGIN\n',1)[1].split(';; REGALLOC_INPUT_END\n',1)[0];labels=[(int(a),int(b)) for a,b in re.findall(r'^;; REGALLOC_BLOCK (\d+) offset=(\d+) ',vcode,re.M)];assert [i for i,at in labels]==list(range(len(labels)));at_ids=defaultdict(list)
for i,at in labels:at_ids[at].append(i)
starts=sorted(at_ids);nm=subprocess.check_output(['/Users/cim310/.rustup/toolchains/nightly-2026-03-03-aarch64-apple-darwin/lib/rustlib/aarch64-apple-darwin/bin/llvm-nm','--defined-only',str(r/'pc-profiler/bound/mech-worker')],text=True);symbols={name:int(at,16) for at,kind,name in [line.split() for line in nm.splitlines() if len(line.split())==3]};delta=symbols['_mech_compact_closed_checked']-symbols['_mech_compact_closed_v2'];total=Counter();cases=[]
for folder in sorted((r/'root-pcs').iterdir()):
 if not folder.is_dir():continue
 rows=(folder/'pcs.csv').read_text().splitlines();assert rows[1]=='failures,0';anchor=int(rows[0].split(',')[1],16);base=anchor+delta;counts=Counter();stats=Counter()
 for line in rows[2:]:
  pc,lr=[int(x,16) for x in line.split(',')];relative=pc-base;kind='self';weight=1.0
  if not 0<=relative<4*len(normal):relative=lr-base-4;kind='direct-caller';weight=.25
  if not 0<=relative<4*len(normal):continue
  stats[kind+'-total']+=1;assert relative%4==0
  mapped=mapping.get(relative//4)
  if mapped is None:continue
  stats[kind+'-mapped']+=1;pos=bisect.bisect_right(starts,mapped*4)-1
  if pos<0:continue
  for label in at_ids[starts[pos]]:counts[label]+=weight
 assert sum(counts.values())>0
 scale=sum(counts.values())
 for label,count in counts.items():total[label]+=count/scale
 cases.append({'case':folder.name.removesuffix('-mech-current'),'rows':len(rows)-2,'stats':dict(stats),'csv_sha256':sha(folder/'pcs.csv'),'scope':'Self-PC time samples plus quarter-weight direct callsite LR samples; equal normalization per case. Inferred allocation hints, not exact block visit counts.'})
peak=max(total.values());proof={'normal_object_sha256':sha(normal_path),'inspection_object_sha256':sha(observed_path),'native_words':len(normal),'matched_words':len(mapping),'mapping':'Instruction-sequence alignment, preserving registers and immediates except PC-relative branch/literal displacements; external relocations match by target. Cold tail sharing changes the inspection image; unmatched sampled words are omitted.','cases':cases,'blocks':len(labels),'expected_vcode_sha256':hashlib.sha256(expected.encode()).hexdigest(),'scope':'Diagnostic PC sampler pauses only its own worker main thread. Primary runtime workers remain unchanged.'};out=r/'root-profiles';out.mkdir()
for power in [1.0,.5]:
 frequencies=[max(1,round(4096*((total[i]/peak)**power))) for i in range(len(labels))];profile={'expected_vcode':expected,'block_frequencies':frequencies,'scope':'M3 sampled root allocation hints; '+('linear' if power==1 else 'square-root')+' scaling','power':power,'maximum':4096,'training_object_sha256':sha(normal_path),'inspection_object_sha256':sha(observed_path),'cases':[a['case'] for a in cases]};name='linear' if power==1 else 'sqrt';(out/(name+'.json')).write_text(json.dumps(profile,indent=2)+'\n')
(out/'proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps({'blocks':len(labels),'matched_words':len(mapping),'native_words':len(normal),'case_stats':[{k:v for k,v in c.items() if k in ['case','stats']} for c in cases]},indent=2))
