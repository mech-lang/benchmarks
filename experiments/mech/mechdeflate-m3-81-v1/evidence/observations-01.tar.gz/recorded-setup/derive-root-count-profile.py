"""Map untimed native root counts to the checked register-allocation input."""
from pathlib import Path
from collections import defaultdict
from types import SimpleNamespace
from hashlib import sha256
from struct import unpack_from
import ast,bisect,difflib,json,re,runpy,subprocess

r=Path('/private/tmp/mech-m3-81-20261124')
m=runpy.run_path(str(r/'support/pure-counters/reachability-census.py'))
obj={'unpack_from':unpack_from}
tree=ast.parse((r/'support/pure-counters/compact_object.py').read_text())
exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ['tables','relocs']],type_ignores=[]),'<macho>','exec'),obj)
def body(path):
    data,sections,syms=m['load'](path)
    names=m['text_symbols'](sections,syms)
    section=sections[m['TEXT']]
    base,offset=section[1],section[3]
    start=names['_mech_compact_closed_checked']
    end=start+json.loads(path.with_name('metadata.json').read_text())['code_bytes']
    rel=defaultdict(list)
    for at,info in obj['relocs'](data,section):
        at+=base
        if start<=at<end:
            target=syms[info&0xffffff][0] if info>>27&1 else info&0xffffff
            rel[(at-start)//4].append((info>>24,target))
    tokens=[]
    for i in range((end-start)//4):
        word=unpack_from('<I',data,offset+start-base+4*i)[0]
        if word&0x7c000000==0x14000000: word&=~0x3ffffff
        elif word&0xff000010==0x54000000 or word&0x7e000000==0x34000000 or word&0x3b000000==0x18000000: word&=~(0x7ffff<<5)
        elif word&0x7e000000==0x36000000: word&=~(0x3fff<<5)
        tokens.append((word,tuple(sorted(rel[i],key=str))))
    return tokens

normal_path=r/'final-aligned64/frontend/program.o'
inspection_path=r/'root-profile-capture/frontend/program.o'
a,b=body(normal_path),body(inspection_path)
matches=difflib.SequenceMatcher(None,a,b,autojunk=False).get_matching_blocks()
mapping={4*(y+i):4*(x+i) for x,y,n in matches for i in range(n)}
assert len(mapping)==len(a)
vcode=(r/'root-inspection-final/native-vcode.asm').read_text()
expected=vcode.split(';; REGALLOC_INPUT_BEGIN\n',1)[1].split(';; REGALLOC_INPUT_END\n',1)[0]
labels=[(int(i),int(at)) for i,at in re.findall(r'^;; REGALLOC_BLOCK (\d+) offset=(\d+) ',vcode,re.M)]
assert [i for i,at in labels]==list(range(len(labels)))
data=json.loads((r/'root-exact-counts/counts.json').read_text())
assert data['source_object_sha256']==sha256(normal_path.read_bytes()).hexdigest()
heads=data['leaders']
mapped=[]
for label,at in labels:
    word=mapping.get(at)
    mapped.append(None if word is None else bisect.bisect_right(heads,word)-1)
raw=[0]*len(labels)
for case in data['cases'].values():
    counts=case['blocks']
    assert [v['offset'] for v in counts]==heads
    for i,native_block in enumerate(mapped):
        if native_block is not None: raw[i]+=counts[native_block]['visits']
peak=max(raw)
out=r/'root-exact-profile'
out.mkdir()
profile={'expected_vcode':expected,'block_frequencies':[max(1,round(4096*n/peak)) for n in raw],
         'scope':'Native block-entry counts from seven declared training families, summed per complete invocation. An instruction-exact subsequence mapping identifies the corresponding VCode allocation blocks. Eliminated cold tails receive weight one; zero-size block aliases inherit the frequency of their shared machine instruction.',
         'training_cases':list(data['cases']),'native_counts_sha256':sha256((r/'root-exact-counts/counts.json').read_bytes()).hexdigest(),
         'training_object_sha256':data['source_object_sha256']}
(out/'weights.json').write_text(json.dumps(profile,indent=2)+'\n')
(out/'proof.json').write_text(json.dumps({'normal_words':len(a),'matched_words':len(mapping),
    'allocation_blocks':len(labels),'mapped_blocks':sum(v is not None for v in mapped),
    'expected_vcode_sha256':sha256(expected.encode()).hexdigest(),'maximum_training_visits':peak,
    'allocation_block_native_block':mapped},indent=2)+'\n')
recipe=json.loads((r/'scratch-paired128-recipe.json').read_text())
recipe['flags']['MECH_COMPACT_PHASE_REGISTER_WEIGHTS']+=';mech_compact_closed_v2@'+str(out/'weights.json')
p=out/'recipe.json'
p.write_text(json.dumps(recipe,indent=2)+'\n')
with (out/'setup.log').open('w') as log:
    subprocess.run(['python3','-B',str(r/'emit.py'),str(p),str(r/'root-exact-weighted'),
        '--compiler',str(r/'compiler-root-capture/compile_profile'),'--compiler-source-receipt',str(r/'compiler-root-capture/source-receipt.json')],stdout=log,stderr=log,check=True)
    subprocess.run(['python3','-B',str(r/'link-worker.py'),str(r/'root-exact-weighted/frontend'),str(r/'root-exact-weighted/bound'),
        '--runtime-library',str(r/'compiler-final/12-default/libmech_gpu_runtime.rlib'),
        '--runtime-variant',str(r/'compiler-final/12-default/variant.json')],stdout=log,stderr=log,check=True)
    subprocess.run(['python3','-B',str(r/'smoke.py'),str(r/'root-exact-weighted/bound/mech-worker'),
        str(r/'root-exact-weighted/bound/metadata.json'),str(r/'root-exact-weighted/smoke.json')],stdout=log,stderr=log,check=True)
metadata=json.loads((r/'root-exact-weighted/frontend/metadata.json').read_text())
print(json.dumps({'root_stack_bytes':metadata['stack_bytes'],'root_code_bytes':metadata['code_bytes'],'smoke_observations':162}),flush=True)
