"""Compare checked error origins/accounting and recoveries outside all clocks."""
from pathlib import Path
from hashlib import sha256
import json,os,shutil,subprocess

r=Path('/private/tmp/mech-m3-81-20261124');mech=Path('/Users/cim310/.codex/worktrees/level12-compile-profile/mech');d=r/'llvm-fault-checks';d.mkdir()
source=d/'runtime-source';shutil.copytree(mech/'hosts/gpu/src/native_artifact/compact_runtime',source)
p=source/'mod.rs';s=p.read_text();needle='        debug_assert_eq!(alignment & Owner::MAPPED, 0);';assert s.count(needle)==1
s=s.replace(needle,'        if diagnostic_fail_this_request() { return Err(1); }\n'+needle)
s+='''
static DIAGNOSTIC_FAULT_COUNTDOWN: std::sync::atomic::AtomicUsize = std::sync::atomic::AtomicUsize::new(0);
static DIAGNOSTIC_FAULT_HIT: std::sync::atomic::AtomicBool = std::sync::atomic::AtomicBool::new(false);
pub fn diagnostic_fault_set(index: usize) {
    DIAGNOSTIC_FAULT_COUNTDOWN.store(index, std::sync::atomic::Ordering::Relaxed);
    DIAGNOSTIC_FAULT_HIT.store(false, std::sync::atomic::Ordering::Relaxed);
}
pub fn diagnostic_fault_hit() -> bool { DIAGNOSTIC_FAULT_HIT.load(std::sync::atomic::Ordering::Relaxed) }
fn diagnostic_fail_this_request() -> bool {
    let index=DIAGNOSTIC_FAULT_COUNTDOWN.load(std::sync::atomic::Ordering::Relaxed);
    if index==0{return false}
    DIAGNOSTIC_FAULT_COUNTDOWN.store(index-1,std::sync::atomic::Ordering::Relaxed);
    if index==1 { DIAGNOSTIC_FAULT_HIT.store(true,std::sync::atomic::Ordering::Relaxed); true } else { false }
}
''';p.write_text(s)
module=d/'runtime.rs';module.write_text('pub mod native_artifact {\n #[path = '+json.dumps(str(source/'mod.rs'))+']\n pub mod compact_runtime;\n}\n')
env=os.environ.copy();env['MECH_INLINE_OWNER_RECORDS']='12';library=d/'libmech_gpu_runtime.rlib'
command=['rustc','+nightly-2026-03-03','--edition=2024','-C','opt-level=3','-D','warnings',str(module),'--crate-type','rlib','--crate-name','mech_gpu','-o',str(library)]
with (d/'runtime-build.log').open('w') as log:subprocess.run(command,env=env,stdout=log,stderr=log,check=True)
shutil.copyfile(r/'check-llvm-faults.rs',d/'worker.rs')
shutil.copyfile(r/'support/copy-study/census/wide-linear4096-gates/linked-proofs/failure-support/pinned_allocator.rs',d/'pinned_allocator.rs')
deps=r/'target/release/deps';externs={'mech_gpu':library}
for crate in ['mech_engine','serde','serde_json','miniz_oxide']:
    paths=list(deps.glob('lib'+crate+'-*.rlib'));assert len(paths)==1;externs[crate]=paths[0]
base=['rustc','+nightly-2026-03-03','--edition=2024','-C','opt-level=3','-D','warnings','-L','dependency='+str(deps),str(d/'worker.rs'),'-C','link-arg='+str(r/'support/fixed-support/mech-control-reference/2')]
for crate,path in externs.items():base+=['--extern',crate+'='+str(path)]
rows=[]
for role,front in [('cranelift',r/'scratch-paired128/frontend'),('llvm',r/'llvm-final-oz/frontend')]:
    folder=d/role;folder.mkdir();worker=folder/'worker'
    with (folder/'build.log').open('w') as log:subprocess.run(base+['-C','link-arg='+str(front/'program.o'),'-o',str(worker)],stdout=log,stderr=log,check=True)
    with (folder/'observations.jsonl').open('w') as stdout,(folder/'stderr').open('w') as stderr:
        subprocess.run([str(worker),str(front/'metadata.json'),str(r/'comparison/fixtures.json'),str(r/'scratch-paired128/smoke.json')],stdout=stdout,stderr=stderr,check=True)
    observed=[json.loads(line) for line in (folder/'observations.jsonl').read_text().splitlines()]
    assert (folder/'stderr').read_text().startswith('FAULT_CHECK_DONE')
    rows.append(observed);print(role,len(observed),'fault/recovery observations passed',flush=True)
assert rows[0]==rows[1], 'Native status/origin/accounting/recovery mismatch'
count=sum(not v['recovery'] for v in rows[0]);errors=sum(v['status']!=0 for v in rows[0]);hits=sum(v['fault_hit'] for v in rows[0])
record={'complete':True,'cases':81,'fault_and_recovery_pairs_per_backend':count,'checked_error_returns_per_backend':errors,'injected_refusals_per_backend':hits,'all_rows_identical':True,'observations_per_backend':len(rows[0]),'runtime_hook_sha256':sha256(p.read_bytes()).hexdigest(),'scope':'Diagnostic only. Refuse one selected nonzero payload request before allocator state changes. Compare status, exact source origin, aliases, all recorded accounting, caller discard and subsequent exact fresh-heap recovery. Not ordinary exact resource-admission recovery; no instrumented worker is used for timing.'}
(d/'result.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)
