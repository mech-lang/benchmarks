"""Isolated balanced study; every run retains complete outputs and observations."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time
import traceback

ROOT = Path(__file__).resolve().parent
COMPARISON = ROOT / 'comparison'
PACKET = Path('/private/tmp/mech-m3-deflate-81-benchmarks/experiments/mech/mechdeflate-phase-routes-v1')
parser = argparse.ArgumentParser(__doc__)
parser.add_argument('name')
parser.add_argument('control', type=Path)
parser.add_argument('candidate', type=Path)
parser.add_argument('--panel', type=Path)
parser.add_argument('--parallel-warmup', action='store_true')
parser.add_argument('--qos-library', type=Path)
parser.add_argument('--blocks', type=int, default=96, choices=(24,48,96))
args = parser.parse_args()
directory = ROOT / (args.name + '-timings')
directory.mkdir()
status = ROOT / (args.name + '-job.json')
start = time.time()
status.write_text(json.dumps({'state':'running','pid':os.getpid(),'started':start}))
digest = lambda path: hashlib.file_digest(path.open('rb'), 'sha256').hexdigest()
try:
    assert json.loads((ROOT/'compiler-job.json').read_text())['state']=='complete'
    for name in ('fixtures.json',):
        shutil.copyfile(COMPARISON/name, directory/name)
    shutil.copytree(COMPARISON/'pinned-peers', directory/'pinned-peers')
    controller_text = (COMPARISON/'controller-96.py').read_text()
    original = 'orders = list(permutations(commands)) * 4'
    assert controller_text.count(original)==1
    controller_text=controller_text.replace(original, 'orders = list(permutations(commands)) * '+str(args.blocks//24))
    cases=json.loads((directory/'fixtures.json').read_text())
    if args.panel:
        selected=json.loads(args.panel.read_text())['cases']
        assert len(selected)==len(set(selected)) and set(selected)<=set(case['name'] for case in cases)
        original="selected = {case['name'] for case in cases}"
        assert controller_text.count(original)==1
        controller_text=controller_text.replace(original, 'selected = set('+repr(selected)+')')
        shutil.copyfile(args.panel, directory/'declared-panel.json')
    else:
        selected=[case['name'] for case in cases]
    if args.parallel_warmup:
        first="        for actor in warmup_order:\n            worker=workers[actor]\n            worker.send('W')\n            state,warm_case,calls,seconds=worker.line().split('\\t')"
        second="        for actor in warmup_order: workers[actor].send('W')\n        for actor in warmup_order:\n            worker=workers[actor]\n            state,warm_case,calls,seconds=worker.line().split('\\t')"
        assert controller_text.count(first)==1
        controller_text=controller_text.replace(first,second)
    if args.qos_library:
        assert not os.environ.get('DYLD_INSERT_LIBRARIES')
        first="stdout=subprocess.PIPE, stderr=self.stderr)"
        second="stdout=subprocess.PIPE, stderr=self.stderr, env=os.environ | {'DYLD_INSERT_LIBRARIES':"+repr(str(args.qos_library.resolve()))+"})"
        assert controller_text.count(first)==1
        controller_text=controller_text.replace(first,second)
    controller = directory/'controller.py'
    controller.write_text(controller_text)
    (directory/'scope.json').write_text(json.dumps(dict(
        control=str(args.control.resolve()), candidate=str(args.candidate.resolve()),
        cases=selected, blocks=args.blocks, orders=['forward','reverse'],
        scheduling={'parallel_warmup':args.parallel_warmup,'qos_library':str(args.qos_library) if args.qos_library else None,'qos_library_sha256':digest(args.qos_library) if args.qos_library else None},
        discovery=bool(args.panel), boundary='Unchanged published complete diagnostic invocation',
        source_commit='2b301734fb43a4abff0d38d68d881e2bf85bd969',
        candidate_receipt=(json.loads((args.candidate.parent/'receipt.json').read_text()) if (args.candidate.parent/'receipt.json').exists() else None),
    ),indent=2)+'\n')
    runs=[]
    for order in ('forward','reverse'):
        name=args.name+'-'+order
        command=['python3','-B',str(controller),name,str(args.control.resolve()),str(args.candidate.resolve())]
        if order=='reverse': command.append(order)
        with (ROOT/(name+'.log')).open('w') as log:
            subprocess.run(command,stdout=log,stderr=log,check=True)
        folder=directory/name
        completion=json.loads((folder/'complete.json').read_text())
        assert completion['cases']==len(selected) and completion['balanced_blocks_per_case']==args.blocks
        rows=json.loads((folder/'summary.json').read_text())
        scores={actor:{peer:sum(row['paired_x_'+peer][actor]<1 for row in rows)
                       for peer in ('roc','libdeflate')}
                for actor in ('mech-control','mech-experiment')}
        runs.append({'order':order,'summary_sha256':digest(folder/'summary.json'),'results':rows})
        print(order,scores,flush=True)
    results={'complete':True,'runs':runs,'blocks_per_case':args.blocks,'controller_sha256':digest(controller)}
    result_path=directory/(args.name+'-results.json')
    result_path.write_text(json.dumps(results,indent=2)+'\n')
    command=['python3','-B',str(PACKET/'verify_timings.py'),str(directory),args.name,
             str(directory/'pinned-peers/libdeflate-output-oracle.json')]
    with (ROOT/(args.name+'-verification.log')).open('w') as log:
        subprocess.run(command,stdout=log,stderr=log,check=True)
except BaseException:
    traceback.print_exc()
    status.write_text(json.dumps({'state':'failed','seconds':time.time()-start}))
    raise
else:
    status.write_text(json.dumps({'state':'complete','seconds':time.time()-start}))
