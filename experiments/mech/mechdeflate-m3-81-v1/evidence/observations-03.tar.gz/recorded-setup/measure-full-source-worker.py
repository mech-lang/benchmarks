from pathlib import Path
from statistics import median
import subprocess,json,time
r=Path('/private/tmp/mech-m3-81-20261124');d=r/'compiler-llvm';results=[];expected=json.loads((r/'llvm-final-oz/receipt.json').read_text())['artifacts']
for index in range(3):
 out=r/('full-source-worker-'+str(index));start=time.perf_counter()
 with (r/('full-source-worker-'+str(index)+'.log')).open('w') as log:
  subprocess.run(['python3','-B',str(r/'emit.py'),str(d/'recipe.json'),str(out),'--compiler',str(d/'compile_profile'),'--compiler-source-receipt',str(d/'source-final-receipt.json')],stdout=log,stderr=log,check=True)
  emitted=time.perf_counter()
  subprocess.run(['python3','-B',str(r/'link-worker.py'),str(out/'frontend'),str(out/'bound'),'--runtime-library',str(d/'runtime-default/libmech_gpu_runtime.rlib'),'--runtime-variant',str(d/'runtime-default/variant.json')],stdout=log,stderr=log,check=True)
  end=time.perf_counter()
 assert json.loads((out/'receipt.json').read_text())['artifacts']==expected
 results.append({'trial':index,'source_through_executable_seconds':end-start,'source_through_object_seconds':emitted-start,'worker_link_seconds':end-emitted,'artifacts':json.loads((out/'bound/runtime.json').read_text())['artifacts']})
 print(index,results[-1]['source_through_executable_seconds'],flush=True)
record={'trials':results,'median_source_through_executable_seconds':median(v['source_through_executable_seconds'] for v in results),'scope':'Source file through native timing-worker executable, including frontend, LLVM-root optimization/emission, object assembly and Rust worker compilation/link. Compiler and matching host/runtime dependencies are prebuilt, as for the M1 source-through-link measurement. Not a compiler-from-scratch build, and not the separate stripped deployment adapter.'};(r/'full-source-worker-timings.json').write_text(json.dumps(record,indent=2)+'\n')
subprocess.run(['python3','-B',str(r/'smoke.py'),str(r/'full-source-worker-2/bound/mech-worker'),str(r/'full-source-worker-2/bound/metadata.json'),str(r/'full-source-worker-2/smoke.json')],check=True)
