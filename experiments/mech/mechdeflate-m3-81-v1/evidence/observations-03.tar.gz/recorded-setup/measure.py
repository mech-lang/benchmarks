"""Run both full 96-block orders, retaining the unchanged M1 measurement boundary."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time
import traceback

ROOT = Path(__file__).resolve().parent
COMPARISON = ROOT / 'comparison'
PACKET = Path('/private/tmp/mech-m3-deflate-81-benchmarks/experiments/mech/mechdeflate-phase-routes-v1')
parser = argparse.ArgumentParser()
parser.add_argument('name')
parser.add_argument('control', type=Path)
parser.add_argument('candidate', type=Path)
args = parser.parse_args()
assert not any((COMPARISON / f'{args.name}-{order}').exists() for order in ('forward','reverse'))
compiler_job = json.loads((ROOT / 'compiler-job.json').read_text())
assert compiler_job['state'] == 'complete', 'No compiler construction may overlap primary clocks.'
status = ROOT / (args.name + '-job.json')
start = time.time()
status.write_text(json.dumps({'state':'running','pid':os.getpid(),'started':start}))
digest = lambda p: hashlib.file_digest(p.open('rb'), 'sha256').hexdigest()
try:
    controller = COMPARISON / 'controller-96.py'
    (COMPARISON / 'controller.py').write_bytes(controller.read_bytes())
    runs = []
    for order in ('forward', 'reverse'):
        directory = COMPARISON / (args.name + '-' + order)
        command = ['python3','-B',str(controller),str(directory),str(args.control.resolve()),str(args.candidate.resolve())]
        if order == 'reverse':
            command.append(order)
        with (ROOT / (args.name + '-' + order + '.log')).open('w') as log:
            subprocess.run(command, stdout=log, stderr=log, check=True)
        completion = json.loads((directory/'complete.json').read_text())
        assert completion['cases'] == 81 and completion['balanced_blocks_per_case'] == 96
        rows = json.loads((directory/'summary.json').read_text())
        scores = {actor:{peer:sum(row['paired_x_'+peer][actor] < 1 for row in rows)
                         for peer in ('roc','libdeflate')}
                  for actor in ('mech-control','mech-experiment')}
        runs.append({'order':order,'summary_sha256':digest(directory/'summary.json'),'results':rows})
        print(order, scores, flush=True)
    results = {'complete':True,'runs':runs,'blocks_per_case':96,'controller_sha256':digest(controller)}
    result_path = COMPARISON / (args.name + '-results.json')
    result_path.write_text(json.dumps(results,indent=2)+'\n')
    command = ['python3','-B',str(PACKET/'verify_timings.py'),str(COMPARISON),args.name,
               str(COMPARISON/'pinned-peers/libdeflate-output-oracle.json')]
    with (ROOT/(args.name+'-verification.log')).open('w') as log:
        subprocess.run(command, stdout=log, stderr=log, check=True)
except BaseException:
    traceback.print_exc()
    status.write_text(json.dumps({'state':'failed','seconds':time.time()-start}))
    raise
else:
    status.write_text(json.dumps({'state':'complete','seconds':time.time()-start}))
