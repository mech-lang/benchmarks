"""Replay archived leaf instrumentation with the current checked worker and object.

Counters are diagnostic only. The original object and timed worker are untouched.
The archived instrumentation saves both scratch registers and never changes NZCV.
"""
import argparse
import ast
from collections import Counter
from hashlib import sha256
import json
from pathlib import Path
import re
from runpy import run_path
from shutil import copy2
from struct import pack, pack_into, unpack_from
import subprocess
from types import SimpleNamespace

ROOT=Path(__file__).resolve().parent
TOOLS=ROOT/'support/pure-counters'
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:sha256(Path(p).read_bytes()).hexdigest()

def functions(path,names,scope):
    nodes=[n for n in ast.parse(path.read_text()).body if isinstance(n,ast.FunctionDef) and n.name in names]
    assert {n.name for n in nodes}==set(names)
    exec(compile(ast.Module(body=nodes,type_ignores=[]),str(path),'exec'),scope)
    return SimpleNamespace(**{name:scope[name] for name in names})

def signed_field(word,low,width):
    v=(word>>low)&((1<<width)-1)
    return v-(1<<width) if v>>(width-1) else v

def branch_field(word):
    if word & 0x7c000000 == 0x14000000: return (0,26)
    if word & 0xff000010 == 0x54000000 or word & 0x7e000000 == 0x34000000: return (5,19)
    if word & 0x7e000000 == 0x36000000: return (5,14)
    return None

def branch_target(at,word,field):
    return at+4*signed_field(word,*field)

def branch_opcode(word,at,target,field):
    low,width=field
    delta=target-at
    assert delta%4==0 and -(1<<(width-1)) <= delta//4 < (1<<(width-1))
    mask=((1<<width)-1)<<low
    return word & ~mask | (((delta//4)&((1<<width)-1))<<low)

def control(word,at):
    field=branch_field(word)
    if field is not None:
        assert word&0xfc000000!=0x94000000, 'Calls are not leaf counter edges'
        return ('jump' if field==(0,26) else ('condition',word&0xf)),branch_target(at,word,field)
    if word&0xfffffc1f==0xd65f0000 or word in (0xd65f0fff,0xd65f0bff): return 'return',None
    if word==0 or word&0xffe0001f in (0xd4200000,0xd4400000): return 'trap',None
    return 'next',None

parser=argparse.ArgumentParser(__doc__)
parser.add_argument('folder',type=Path)
parser.add_argument('symbol')
parser.add_argument('--panel',type=Path,required=True)
args=parser.parse_args()
folder=args.folder.resolve()
symbol=args.symbol
assert re.fullmatch(r'mech_compact_numeric_[a-z0-9_]+',symbol)
assert not (folder/('counts-word-reuse-v1-'+symbol.split('_')[3])).exists()
selected=read(args.panel)['cases']
assert len(selected)==len(set(selected))
macho=SimpleNamespace(**run_path(str(TOOLS/'reachability-census.py')))
obj=functions(TOOLS/'compact_object.py',['tables','relocs'],{'unpack_from':unpack_from})
layout=SimpleNamespace(obj=obj,branch_field=branch_field,branch_target=branch_target,branch_opcode=branch_opcode)
image,sections,syms=macho.load(folder/'frontend/program.o')
names=macho.text_symbols(sections,syms)
_,base,text_size,offset,*_=sections[macho.TEXT]
starts=sorted((at,name) for name,at in names.items())
atoms={}
for (start,name),(end,_) in zip(starts,starts[1:]+[(base+text_size,None)],strict=True):
    relocs=[]
    for at,info in obj.relocs(image,sections[macho.TEXT]):
        absolute=at+base
        if start<=absolute<end:
            target=syms[info&0xffffff][0] if info>>27&1 else info&0xffffff
            relocs.append((absolute-start,info>>24,target))
    atoms[name]={'start':start,'extent':end-start,
                 'sha256':sha256(image[offset+start-base:offset+end-base]).hexdigest(),
                 'relocations':sorted(relocs)}
receipt=read(folder/'receipt.json')
assert receipt['artifacts']['program.o']==sha(folder/'frontend/program.o')==sha(folder/'bound/program.o')
receipt.update(object_sha256=receipt['artifacts']['program.o'],layout={'text_bytes':text_size,'symbols':atoms})
(folder/'native-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')

# Validate each literal before using the archived graph helper, whose original
# alignment test assumed that every reference was to a 128-bit vector.
atom=atoms['_'+symbol]
body=image[offset+atom['start']-base:offset+atom['start']-base+atom['extent']]
literal_refs=[]
for at in range(0,len(body),4):
    word=unpack_from('<I',body,at)[0]
    if literal_refs and at>=min(literal_refs): break
    if word&0x3b000000==0x18000000:
        target=at+4*signed_field(word,5,19)
        vector,opc=(word>>26)&1,word>>30
        assert opc<3, 'Prefetch and unallocated literal opcodes are excluded'
        width=([4,8,16] if vector else [4,8,4])[opc]
        assert at<target and target+width<=len(body) and target%width==0
        literal_refs.append(target)

shape_scope={'read':read,'sha':sha,'unpack_from':unpack_from,
             'emit':SimpleNamespace(macho=macho),'r':{'signed_field':signed_field,'control':control},
             'OUT':folder.parent}
functions(TOOLS/'rebase-spill-pair-profiles.py',['info','shape'],shape_scope)
shape_text=ast.get_source_segment((TOOLS/'rebase-spill-pair-profiles.py').read_text(),
    next(n for n in ast.parse((TOOLS/'rebase-spill-pair-profiles.py').read_text()).body
         if isinstance(n,ast.FunctionDef) and n.name=='shape'))
assert shape_text.count("folder/'receipt.json'")==1
shape_text=shape_text.replace("folder/'receipt.json'","folder/'native-receipt.json'")
if literal_refs:
    assert shape_text.count('dest%16==0')==1
    shape_text=shape_text.replace('dest%16==0','dest%4==0')
exec(compile(shape_text,str(TOOLS/'rebase-spill-pair-profiles.py'),'exec'),shape_scope)
shape=shape_scope['shape'](folder.name,symbol)

canonical=folder/'canonical-counter-input'
canonical_front=canonical/'frontend'
canonical_front.mkdir(parents=True)
normal_scope={'m':macho.__dict__,'text':macho.TEXT,'const':(b'__TEXT',b'__const'),
              'unpack_from':unpack_from,'pack_into':pack_into,'sha':sha,
              'align':lambda n,a:(n+a-1)&-a}
normal=functions(TOOLS/'canonical-counter-input.py',['normalize'],normal_scope)
normalization=normal.normalize(folder/'frontend/program.o',canonical_front/'program.o')
for name in ('metadata.json','program.mecb'):copy2(folder/'frontend'/name,canonical_front/name)
(canonical/'canonicalization.json').write_text(json.dumps(normalization,indent=2)+'\n')
subprocess.run(['python3','-B',str(ROOT/'link-worker.py'),str(canonical_front),str(canonical/'bound')],check=True)

counter_file=TOOLS/'count-matcher-instructions.py'
counter_text=counter_file.read_text()
nodes=[n for n in ast.parse(counter_text).body if isinstance(n,ast.FunctionDef)]
program='\n\n'.join(ast.get_source_segment(counter_text,n) for n in nodes)
patch=functions(ROOT/'support/study/count.py',['patch_counter'],{})
program=patch.patch_counter(program)
if literal_refs and min(literal_refs)%16:
    assert program.count('literal_start % 16 == 0')==2
    program=program.replace('literal_start % 16 == 0','literal_start % 8 == 0')
replacements={
    "allow_data_references=literal_start is not None":"allow_data_references=True",
    '(reference / "runtime.json").read_text())["link"]':'(reference / "runtime.json").read_text())["command"]',
    '    root = q / f"{label}-native/final-candidate"':'    root = Path('+repr(str(canonical/'bound'))+')',
    '    directory = q / "matcher-dynamic-blocks" / actor':'    directory = Path('+repr(str(folder/('counts-word-reuse-v1-'+symbol.split('_')[3])))+')',
}
for old,new in replacements.items():
    assert program.count(old)==1,(old,program.count(old))
    program=program.replace(old,new)
fixtures=ROOT/'comparison/fixtures.json'
scope=globals()|dict(text=macho.TEXT,constant=(b'__TEXT',b'__const'),
    counter_name=b'_mech_matcher_block_counts\0',fixtures=fixtures,
    indices={v['name']:i for i,v in enumerate(read(fixtures))})
exec(compile(program,str(counter_file),'exec'),scope)
scope['count'](folder.name,folder.name,selected,'_'+symbol,shape['pool'])
output=folder/('counts-word-reuse-v1-'+symbol.split('_')[3])
(output/'counts.json').rename(output/'canonical-counts.json')
counts=read(output/'canonical-counts.json')
assert counts['object_sha256']==sha(canonical_front/'program.o')
_,canonical_sections,canonical_symbols=macho.load(canonical_front/'program.o')
canonical_start=macho.text_symbols(canonical_sections,canonical_symbols)['_'+symbol]
delta=atom['start']-canonical_start
for case in counts['cases'].values():
    for block in case['blocks']:block['address']=hex(int(block['address'],16)+delta)
counts.update(object_sha256=sha(folder/'frontend/program.o'),canonical_counts_sha256=sha(output/'canonical-counts.json'),address_translation=delta)
(output/'counts.json').write_text(json.dumps(counts,indent=2)+'\n')
(output/'native-shape.json').write_text(json.dumps(shape,indent=2)+'\n')
(output/'plan.json').write_text(json.dumps({'untimed':True,'source_object_sha256':sha(folder/'frontend/program.o'),
    'source_worker_sha256':sha(folder/'bound/mech-worker'),'cases':selected,
    'counter_helper_sha256':sha(counter_file),'adapted_counter_source':program,
    'proved_64bit_literal_targets':literal_refs,'address_translation':delta,
    'scope':'Archived scratch-register-preserving instrumentation, current original object and current maintained worker; two independently checked calls per case have identical counters. No instrumented elapsed times are primary clocks.'},indent=2)+'\n')
print('Complete counts and static shape retained:',output,flush=True)
