from pathlib import Path
from hashlib import file_digest
import json,tarfile,os,shutil
r=Path('/private/tmp/mech-m3-81-20261124');p=Path('/private/tmp/mech-m3-deflate-81-benchmarks/experiments/mech/mechdeflate-m3-81-v1')
sha=lambda path:file_digest(path.open('rb'),'sha256').hexdigest()
selected={};studies=[]
for folder in sorted(r.iterdir()):
 if not folder.is_dir() or folder.name in ['target','support']:continue
 for results in sorted(folder.glob('*-results.json')):
  try:x=json.loads(results.read_text())
  except (ValueError,UnicodeError):continue
  if not x.get('complete') or not x.get('runs') or not all('order' in v and 'results' in v for v in x['runs']):continue
  name=results.name.removesuffix('-results.json');archive_dir='studies/'+folder.name
  verified=folder/(name+'-verified.json');scope=folder/'scope.json';record={'name':name,'archive_directory':archive_dir,'blocks_per_case':x['blocks_per_case'],'verified':verified.exists(),'discovery':scope.exists() and json.loads(scope.read_text()).get('discovery',False),'runs':[]}
  if scope.exists():record['scope']=json.loads(scope.read_text())
  for run in x['runs']:
   rows=run['results'];record['runs'].append({'order':run['order'],'cases':len(rows),'wins':{actor:{peer:sum(v['paired_x_'+peer][actor]<1 for v in rows) for peer in ['roc','libdeflate']} for actor in ['mech-control','mech-experiment']},'misses':{peer:[{'case':v['case'],'ratio':v['paired_x_'+peer]['mech-experiment']} for v in rows if v['paired_x_'+peer]['mech-experiment']>=1] for peer in ['roc','libdeflate']}})
  for name_file in ['controller.py','scope.json',results.name,verified.name,'declared-panel.json']:
   file=folder/name_file
   if file.is_file():selected[archive_dir+'/'+name_file]=file
  for run in x['runs']:
   order_dir=folder/(name+'-'+run['order'])
   assert order_dir.is_dir(),order_dir
   for file in order_dir.rglob('*'):
    if file.is_file() and (file.name in ['summary.json','complete.json','pins.json','observations.json.gz'] or file.suffix=='.stderr'):
     selected[archive_dir+'/'+str(file.relative_to(folder))]=file
  studies.append(record)
(p/'studies.json').write_text(json.dumps(studies,indent=2)+'\n')
assert {v['name'] for v in studies}>={'llvm-oz-primary','llvm-oz-confirmation','short-prefix-copy'}
# Preserve as-run setup logs, recipes, source patches, profiles, counters and diagnostics.
skip={'target','support','comparison','winner-runtime'}|{v['archive_directory'].split('/')[1] for v in studies}
extensions={'.py','.rs','.json','.patch','.log','.stderr','.stdout','.asm','.clif','.s','.txt','.ll','.yaml','.vcode','.csv','.mec'}
for root,dirs,files in os.walk(r):
 base=Path(root)
 if base==r:dirs[:]=[v for v in dirs if v not in skip]
 dirs[:]=[v for v in dirs if v not in ['target','deps','incremental','.git','__pycache__','fixtures','pinned-peers','peers']]
 for name in files:
  file=base/name
  if file.suffix in extensions and file.stat().st_size<=20_000_000:
   selected['recorded-setup/'+str(file.relative_to(r))]=file
files=sorted(selected.items());chunks=[];chunk=[];size=0
for name,file in files:
 n=file.stat().st_size
 if chunk and size+n>32_000_000:chunks.append(chunk);chunk=[];size=0
 chunk.append((name,file));size+=n
if chunk:chunks.append(chunk)
manifest={'archives':[],'files_sha256':{},'study_count':len(studies),'scope':'All discovered completed timing studies, including unqualified recipes and null controls, plus as-run setup/diagnostic evidence. Frozen M1 transport is short-prefix-copy. The final winning source and portable build are separately pinned in recipe.json.'}
for i,chunk in enumerate(chunks):
 archive=p/'evidence'/('observations-'+str(i+1).zfill(2)+'.tar.gz')
 with tarfile.open(archive,'w:gz',compresslevel=1) as stream:
  for name,file in chunk:
   manifest['files_sha256'][name]=sha(file);stream.add(file,arcname=name,recursive=False)
 manifest['archives'].append({'file':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive),'files':len(chunk)})
 print('Archived',archive.name,archive.stat().st_size,'bytes',len(chunk),'files',flush=True)
(p/'evidence/manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
qualified=[]
for label,name in [('primary','llvm-oz-primary'),('confirmation','llvm-oz-confirmation')]:
 x=json.loads((r/(name+'-timings')/(name+'-results.json')).read_text())
 for run in x['runs']:
  for row in run['results']:
   qualified.append({'run':label,'order':run['order'],'case':row['case'],'roc_ratio':row['paired_x_roc']['mech-experiment'],'libdeflate_ratio':row['paired_x_libdeflate']['mech-experiment'],'median_seconds':row['median_seconds']['mech-experiment']})
(p/'case-margins.json').write_text(json.dumps(qualified,indent=2)+'\n')
print('Complete:',len(studies),'studies;',len(selected),'evidence files;',len(qualified),'qualified case/order rows',flush=True)
