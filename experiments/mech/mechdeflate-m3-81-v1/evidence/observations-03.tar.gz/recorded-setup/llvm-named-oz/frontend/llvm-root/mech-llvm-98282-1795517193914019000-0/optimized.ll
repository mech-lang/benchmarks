; ModuleID = 'root.ll'
source_filename = "root.ll"
target datalayout = "e-m:o-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "arm64-apple-macosx26.0.0"

@mech_compact_llvm_anonymous_data_1 = external dso_local constant [8 x i8]
@mech_compact_table_11 = external dso_local constant [1094 x i8]
@mech_compact_table_14 = external dso_local constant [19 x i8]
@mech_compact_table_15 = external dso_local constant [19 x i8]
@mech_compact_table_18 = external dso_local constant [256 x i8]
@mech_compact_table_19 = external dso_local constant [256 x i8]
@mech_compact_table_2 = external dso_local constant [2188 x i8]
@mech_compact_table_20 = external dso_local constant [1164 x i8]
@mech_compact_table_21 = external dso_local constant [320 x i8]
@mech_compact_table_22 = external dso_local constant [320 x i8]
@mech_compact_table_24 = external dso_local constant [257 x i8]
@mech_compact_table_25 = external dso_local constant [257 x i8]
@mech_compact_table_26 = external dso_local constant [257 x i8]
@mech_compact_table_4 = external dso_local constant [3 x i8]
@mech_compact_table_6 = external dso_local constant [80 x i8]
@mech_compact_table_7 = external dso_local constant [259 x i8]
@mech_compact_table_8 = external dso_local constant [2064 x i8]
@mech_compact_table_9 = external dso_local constant [1280 x i8]

declare i64 @mech_compact_free(i64, i64) local_unnamed_addr #0

declare i64 @mech_compact_matrix_word(i64, i64, i64, i64, i64) local_unnamed_addr #0

declare i64 @mech_compact_release_four(i64, i64, i64, i64, i64) local_unnamed_addr #0

declare i64 @mech_compact_release_nullable(i64, i64) local_unnamed_addr #0

declare i64 @mech_compact_release_owner(i64, i64) local_unnamed_addr #0

declare i64 @mech_compact_release_three(i64, i64, i64, i64) local_unnamed_addr #0

declare i64 @mech_compact_release_two(i64, i64, i64) local_unnamed_addr #0

declare i64 @mech_compact_unsigned_dot_product(i64, i64, i64, i64) local_unnamed_addr #0

declare i64 @mech_compact_word_collection_10(i64, i64, i64, i64) local_unnamed_addr #0

declare i64 @memmove(i64, i64, i64) local_unnamed_addr #0

declare preserve_allcc void @mech_compact_expand_capacity_preserving(i64, i64, i64, i64) local_unnamed_addr #0

declare { i64, i64 } @mech_compact_allocate_backing(i64, i64, i64, i64, i64) local_unnamed_addr #0

declare { i64, i64 } @mech_compact_fixed_transform(i64, i64, i64, i64, i64) local_unnamed_addr #0

declare { i64, i64 } @mech_compact_numeric_2821_vector(i64, i64, i64) local_unnamed_addr #0

declare { i64, i64 } @mech_compact_numeric_3009_no_growth_composed(i64, i64, i64) local_unnamed_addr #0

declare { i64, i64 } @mech_compact_numeric_3447_seeded_entry(i64, i64, i64, i64, i64, i64, i64, i64) local_unnamed_addr #0

declare { i64, i64 } @mech_compact_numeric_362_vector(i64, i64, i64) local_unnamed_addr #0

declare { i64, i64 } @mech_compact_numeric_3872(i64, i64, i64) local_unnamed_addr #0

declare { i64, i64 } @mech_compact_numeric_3956_vector(i64, i64, i64) #0

declare { i64, i64 } @mech_compact_numeric_4173(i64, i64, i64) #0

declare { i64, i64 } @mech_compact_numeric_4673_vector(i64, i64, i64) local_unnamed_addr #0

declare { i64, i64 } @mech_compact_numeric_475_vector(i64, i64, i64) local_unnamed_addr #0

declare { i64, i64 } @mech_compact_numeric_4799(i64, i64, i64) local_unnamed_addr #0

declare { i64, i64 } @mech_compact_numeric_4879(i64, i64, i64) local_unnamed_addr #0

declare { i64, i64 } @mech_compact_numeric_5895(i64, i64, i64) local_unnamed_addr #0

declare { i64, i64 } @mech_compact_numeric_6633(i64, i64, i64) local_unnamed_addr #0

declare { i64, i64 } @mech_compact_numeric_8026(i64, i64, i64) local_unnamed_addr #0

declare { i64, i64 } @mech_compact_writable_scalar_backing(i64, i64, i64, i64, i64, i64, i64) local_unnamed_addr #0

declare { i64, i64, i64 } @mech_compact_append_backing_byte_consume(i64, i64, i64, i64, i64, i64) local_unnamed_addr #0

declare { i64, i64, i64 } @mech_compact_checked_layout_continuation_8603(i64, i64, i64, i64, i64) local_unnamed_addr #0

declare { i64, i64, i64, i64 } @mech_compact_checked_layout_10939(i64) local_unnamed_addr #0

declare { i64, i64, i64, i64 } @mech_compact_checked_layout_13100(i64) local_unnamed_addr #0

declare { i64, i64, i64, i64 } @mech_compact_checked_layout_16147(i64) local_unnamed_addr #0

declare { i64, i64, i64, i64 } @mech_compact_checked_layout_continuation_21033(i64, i64, i64, i64, i64, i64) local_unnamed_addr #0

declare { i64, i64, i64, i64 } @mech_compact_checked_layout_continuation_9112(i64, i64, i64, i64, i64, i64, i64) local_unnamed_addr #0

declare { i64, i64, i64, i64 } @mech_compact_checked_layout_continuation_9562(i64, i64, i64, i64, i64, i64, i64) local_unnamed_addr #0

declare { i64, i64, i64, i64, i64, i64, i64 } @mech_compact_checked_layout_continuation_44068(i64, i64, i64, i64, i64, i64, i64, i64) local_unnamed_addr #0

declare { i64, i64, i64, i64, i64, i64, i64, i64 } @mech_compact_checked_layout_continuation_16644(i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64) local_unnamed_addr #0

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.cttz.i64(i64, i1 immarg) #1

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.umax.i64(i64, i64) #2

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.umin.i64(i64, i64) #2

; Function Attrs: cold noreturn nounwind memory(inaccessiblemem: write)
declare void @llvm.trap() #3

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64) #2

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64) #2

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i64, i1 } @llvm.uadd.with.overflow.i64(i64, i64) #2

; Function Attrs: noinline uwtable
define { i64, i64 } @mech_compact_closed_checked(i64 %v0, i64 %v1, i64 %v2) local_unnamed_addr #4 align 128 {
block0:
  %ss2 = alloca [8 x i8], align 8
  %ss3 = alloca [224 x i8], align 16
  %ss4 = alloca [136 x i8], align 8
  %ss5 = alloca [32 x i8], align 16
  %ss6 = alloca [56 x i8], align 16
  %t0 = inttoptr i64 %v1 to ptr
  %v1394 = load i64, ptr %t0, align 1
  %t2 = getelementptr i8, ptr %t0, i64 8
  %v1395 = load i64, ptr %t2, align 1
  %t6 = getelementptr i8, ptr %t0, i64 24
  %v1397 = load i64, ptr %t6, align 1
  %t8 = getelementptr i8, ptr %t0, i64 32
  %v1398 = load i64, ptr %t8, align 1
  %t10 = getelementptr i8, ptr %t0, i64 40
  %v1399 = load i64, ptr %t10, align 1
  %t12 = getelementptr i8, ptr %t0, i64 48
  %v1400 = load i64, ptr %t12, align 1
  %t14 = getelementptr i8, ptr %t0, i64 56
  %v1401 = load i64, ptr %t14, align 1
  %t16 = getelementptr i8, ptr %t0, i64 64
  %v1402 = load i64, ptr %t16, align 1
  %t18 = getelementptr i8, ptr %t0, i64 72
  %v1403 = load i64, ptr %t18, align 1
  %t22 = getelementptr i8, ptr %t0, i64 88
  %v1405 = load i64, ptr %t22, align 1
  %t23.not = icmp eq i64 %v1399, 0
  br i1 %t23.not, label %block2, label %edge0

block2:                                           ; preds = %block0, %edge0
  %t26.not = icmp eq i64 %v1405, 0
  br i1 %t26.not, label %block11, label %edge3

block11:                                          ; preds = %block2, %edge3
  %t29 = icmp ult i64 %v1395, 8
  br i1 %t29, label %edge7, label %edge8

block8139:                                        ; preds = %edge17
  %t48 = icmp eq i64 %v1405, %v1733
  %t50.not163 = icmp eq i64 %v1733, 0
  %t50.not = or i1 %t48, %t50.not163
  br i1 %t50.not, label %block8145, label %edge26

block8145:                                        ; preds = %block8139, %edge26
  %t54.not = or i1 %t26.not, %t48
  br i1 %t54.not, label %block22, label %edge29

common.ret:                                       ; preds = %edge2186, %edge534, %block39125, %block39124, %block39122, %edge5664, %block38973, %block38917, %block38785, %edge5613, %edge5600, %edge5595, %edge5589, %edge5584, %edge5578, %edge5573, %edge5567, %edge5554, %edge5549, %edge5536, %edge5518, %edge5511, %edge5499, %edge5470, %edge5464, %edge5455, %edge5448, %edge5341, %edge5214, %edge5205, %edge5198, %edge5149, %edge5127, %block35488, %block35264, %edge4931, %edge4922, %edge4913, %block35034, %block34998, %block34947, %edge4821, %edge4762, %block34107, %block33722, %block33698, %edge4572, %edge4522, %edge4436, %edge4382, %block31232, %edge4253, %edge4238, %edge4225, %block30586, %block30566, %edge4127, %edge4123, %edge4067, %edge4044, %edge4009, %edge3904, %block28398, %block28236, %block28170, %block28150, %edge3725, %edge3665, %edge3660, %edge3654, %edge3649, %edge3635, %edge3609, %block26585, %edge3544, %edge3536, %edge3514, %edge3492, %edge3489, %edge3474, %edge3449, %edge3439, %edge3435, %edge3427, %edge3411, %edge3400, %edge3391, %edge3362, %edge3358, %block24953, %block24905, %edge3281, %edge3254, %block24501, %block24249, %block24156, %block24119, %edge3122, %edge3106, %edge3061, %edge3051, %edge2998, %block23019, %block22984, %edge2928, %edge2915, %edge2891, %edge2847, %edge2832, %edge2820, %edge2799, %edge2795, %edge2787, %block21479, %edge2759, %block21424, %edge2737, %edge2715, %edge2705, %edge2691, %edge2679, %edge2672, %edge2666, %block20780, %block20629, %block20579, %block20424, %edge2538, %edge2499, %edge2495, %edge2484, %edge2479, %block19756, %block19708, %block19221, %edge2270, %edge2266, %block18420, %block18032, %block17903, %block17883, %edge2062, %edge2058, %edge2043, %edge2038, %edge1997, %edge1994, %edge1968, %edge1965, %edge1934, %edge1894, %edge1868, %edge1865, %edge1839, %edge1836, %edge1770, %edge1676, %edge1669, %edge1657, %edge1645, %edge1642, %edge1632, %edge1567, %block14393, %edge1532, %edge1500, %edge1488, %edge1485, %block14110, %edge1458, %edge1422, %edge1386, %edge1377, %edge1374, %edge1371, %block13388, %edge1316, %edge1313, %edge1252, %block12844, %edge1217, %edge1185, %edge1173, %edge1170, %block12565, %edge1145, %edge1114, %edge1094, %edge1058, %edge1049, %edge1046, %edge1043, %block11711, %edge989, %edge986, %block11417, %block11382, %edge906, %edge884, %block10649, %edge770, %block10437, %block10144, %block10134, %block9974, %edge568, %edge475, %edge460, %block9671, %edge427, %edge417, %edge413, %edge393, %edge388, %edge352, %edge342, %edge337, %edge327, %edge322, %edge312, %edge307, %edge297, %edge292, %edge282, %edge277, %edge267, %edge261, %edge256, %edge250, %block8737, %edge223, %edge203, %edge198, %block8598, %edge156, %edge147, %block8377, %block8308, %block8188, %block8164, %edge38, %block8136
  %common.ret.op = phi { i64, i64 } [ %t57, %block8136 ], [ %t64, %edge38 ], [ %t88, %block8164 ], [ %t118, %block8188 ], [ %t156, %block8308 ], [ %t181, %block8377 ], [ %t186, %edge147 ], [ %t196, %edge156 ], [ %t233, %block8598 ], [ %t238, %edge198 ], [ %t243, %edge203 ], [ %t256, %edge223 ], [ %t273, %block8737 ], [ %t283, %edge250 ], [ %t288, %edge256 ], [ %t293, %edge261 ], [ %t298, %edge267 ], [ %t303, %edge277 ], [ %t308, %edge282 ], [ %t313, %edge292 ], [ %t318, %edge297 ], [ %t323, %edge307 ], [ %t328, %edge312 ], [ %t333, %edge322 ], [ %t338, %edge327 ], [ %t343, %edge337 ], [ %t348, %edge342 ], [ %t353, %edge352 ], [ %t376, %edge388 ], [ %t381, %edge393 ], [ %t430, %edge413 ], [ %t434, %edge417 ], [ %t444, %edge427 ], [ %t470, %block9671 ], [ %t480, %edge460 ], [ %t490, %edge475 ], [ %t5393, %edge5584 ], [ %t672, %edge568 ], [ %t696, %block9974 ], [ %t707, %block10134 ], [ %t741, %block10144 ], [ %t614, %edge534 ], [ %t5486, %block39125 ], [ %t814, %block10437 ], [ %t850, %edge770 ], [ %t874, %block10649 ], [ %t942, %edge884 ], [ %t954, %edge906 ], [ %t987, %block11382 ], [ %t1011, %block11417 ], [ %t1027, %edge986 ], [ %t1032, %edge989 ], [ %t1050, %block11711 ], [ %t1068, %edge1043 ], [ %t1073, %edge1046 ], [ %t1078, %edge1049 ], [ %t1088, %edge1058 ], [ %t1108, %edge1094 ], [ %t1134, %edge1114 ], [ %t1157, %edge1145 ], [ %t1181, %block12565 ], [ %t1186, %edge1170 ], [ %t1191, %edge1173 ], [ %t1199, %edge1185 ], [ %t1226, %edge1217 ], [ %t1250, %block12844 ], [ %t1256, %edge1252 ], [ %t5484, %block39124 ], [ %t1293, %edge1313 ], [ %t1298, %edge1316 ], [ %t1316, %block13388 ], [ %t1334, %edge1371 ], [ %t1339, %edge1374 ], [ %t1344, %edge1377 ], [ %t1354, %edge1386 ], [ %t1374, %edge1422 ], [ %t1399, %edge1458 ], [ %t1423, %block14110 ], [ %t1429, %edge1485 ], [ %t1434, %edge1488 ], [ %t1442, %edge1500 ], [ %t1469, %edge1532 ], [ %t1493, %block14393 ], [ %t1499, %edge1567 ], [ %t5421, %edge5613 ], [ %t1557, %edge1632 ], [ %t1581, %edge1642 ], [ %t1586, %edge1645 ], [ %t1608, %edge1657 ], [ %t1613, %edge1669 ], [ %t1634, %edge1676 ], [ %t1698, %edge1770 ], [ %t1771, %edge1836 ], [ %t1786, %edge1839 ], [ %t1819, %edge1865 ], [ %t1834, %edge1868 ], [ %t1844, %edge1894 ], [ %t1872, %edge1934 ], [ %t1905, %edge1965 ], [ %t1920, %edge1968 ], [ %t1950, %edge1994 ], [ %t1965, %edge1997 ], [ %t1989, %edge2038 ], [ %t1994, %edge2043 ], [ %t2040, %edge2058 ], [ %t2044, %edge2062 ], [ %t2088, %block17883 ], [ %t2099, %block17903 ], [ %t2126, %block18032 ], [ %t2178, %block18420 ], [ %t5480, %block39122 ], [ %t2272, %edge2266 ], [ %t2285, %edge2270 ], [ %t2355, %block19221 ], [ %t2400, %block19708 ], [ %t2414, %block19756 ], [ %t2427, %edge2479 ], [ %t2432, %edge2484 ], [ %t2492, %edge2495 ], [ %t2496, %edge2499 ], [ %t2530, %edge2538 ], [ %t2562, %block20424 ], [ %t2601, %block20579 ], [ %t2615, %block20629 ], [ %t2639, %block20780 ], [ %t2645, %edge2666 ], [ %t2651, %edge2672 ], [ %t2657, %edge2679 ], [ %t2667, %edge2691 ], [ %t2678, %edge2705 ], [ %t2682, %edge2715 ], [ %t2699, %edge2737 ], [ %t2712, %block21424 ], [ %t2717, %edge2759 ], [ %t2730, %block21479 ], [ %t2741, %edge2787 ], [ %t2785, %edge2795 ], [ %t2790, %edge2799 ], [ %t2822, %edge2820 ], [ %t2833, %edge2832 ], [ %t2865, %edge2847 ], [ %t2910, %edge2891 ], [ %t2925, %edge2915 ], [ %t5398, %edge5589 ], [ %t2941, %edge2928 ], [ %t2979, %block22984 ], [ %t3003, %block23019 ], [ %t3037, %edge2998 ], [ %t3095, %edge3051 ], [ %t3117, %edge3061 ], [ %t3156, %edge3106 ], [ %t3163, %edge3122 ], [ %t3176, %block24119 ], [ %t3202, %block24156 ], [ %t3234, %block24249 ], [ %t3274, %block24501 ], [ %t3293, %edge3254 ], [ %t3318, %edge3281 ], [ %t3352, %block24905 ], [ %t3366, %block24953 ], [ %t3418, %edge3358 ], [ %t3422, %edge3362 ], [ %t3442, %edge3391 ], [ %t3468, %edge3400 ], [ %t3474, %edge3411 ], [ %t5408, %edge5600 ], [ %t3487, %edge3427 ], [ %t3526, %edge3435 ], [ %t3530, %edge3439 ], [ %t3540, %edge3449 ], [ %t3571, %edge3474 ], [ %t3631, %edge3489 ], [ %t3634, %edge3492 ], [ %t3672, %edge3514 ], [ %t3705, %edge3536 ], [ %t3709, %edge3544 ], [ %t3735, %block26585 ], [ %t3762, %edge3609 ], [ %t3784, %edge3635 ], [ %t3793, %edge3649 ], [ %t3798, %edge3654 ], [ %t3803, %edge3660 ], [ %t3808, %edge3665 ], [ %t3851, %edge3725 ], [ %t3901, %block28150 ], [ %t3926, %block28170 ], [ %t3944, %block28236 ], [ %t3972, %block28398 ], [ %t3996, %edge3904 ], [ %t5478, %edge5664 ], [ %t4073, %edge4009 ], [ %t4102, %edge4044 ], [ %t4115, %edge4067 ], [ zeroinitializer, %block38973 ], [ %t4191, %edge4123 ], [ %t4195, %edge4127 ], [ %t4247, %block30566 ], [ %t4258, %block30586 ], [ %t4270, %edge4225 ], [ %t4280, %edge4238 ], [ %t4294, %edge4253 ], [ %t4321, %block31232 ], [ %t5459, %block38917 ], [ %t4362, %edge4382 ], [ %t4408, %edge4436 ], [ %t4477, %edge4522 ], [ %t4549, %edge4572 ], [ %t4617, %block33698 ], [ %t4628, %block33722 ], [ %t4663, %block34107 ], [ %t5432, %block38785 ], [ %t4686, %edge4762 ], [ %t4725, %edge4821 ], [ %t4763, %block34947 ], [ %t4790, %block34998 ], [ %t4815, %block35034 ], [ %t4820, %edge4913 ], [ %t4830, %edge4922 ], [ %t4837, %edge4931 ], [ %t4889, %block35264 ], [ %t4975, %block35488 ], [ %t5003, %edge5127 ], [ %t5024, %edge5149 ], [ %t5069, %edge5198 ], [ %t5073, %edge5205 ], [ %t5079, %edge5214 ], [ %t5168, %edge5341 ], [ %t5241, %edge5448 ], [ %t5245, %edge5455 ], [ %t5252, %edge5464 ], [ %t5258, %edge5470 ], [ %t5281, %edge5499 ], [ %t5289, %edge5511 ], [ %t5319, %edge5518 ], [ %t5352, %edge5536 ], [ %t5360, %edge5549 ], [ %t5365, %edge5554 ], [ %t5403, %edge5595 ], [ %t5378, %edge5567 ], [ %t5383, %edge5573 ], [ %t5388, %edge5578 ], [ { i64 103427, i64 3000 }, %edge2186 ]
  ret { i64, i64 } %common.ret.op

block8136:                                        ; preds = %edge29, %edge17, %edge7
  %v1705 = phi i64 [ %v1733, %edge17 ], [ 103427, %edge7 ], [ %v1743, %edge29 ]
  %t56 = insertvalue { i64, i64 } poison, i64 %v1705, 0
  %t57 = insertvalue { i64, i64 } %t56, i64 17, 1
  br label %common.ret

block22:                                          ; preds = %edge15, %edge29, %block8145
  %v1715187201 = phi i64 [ %v1732, %block8145 ], [ %v1732, %edge29 ], [ %v1400, %edge15 ]
  %v1717188200 = phi i64 [ %v1713, %block8145 ], [ %v1713, %edge29 ], [ %v1402, %edge15 ]
  %v1720189199 = phi i64 [ %v1733, %block8145 ], [ %v1733, %edge29 ], [ %v1405, %edge15 ]
  %t50.not163191198 = phi i1 [ %t50.not163, %block8145 ], [ %t50.not163, %edge29 ], [ %t26.not, %edge15 ]
  %t58 = icmp eq i64 %v1395, 0
  br i1 %t58, label %edge34, label %block8275

block8165:                                        ; preds = %edge36, %edge34
  %t65 = tail call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %v1401, i64 1)
  %v1774 = extractvalue { i64, i1 } %t65, 0
  %t66 = extractvalue { i64, i1 } %t65, 1
  br i1 %t66, label %block8164, label %edge40

block8179:                                        ; preds = %edge44, %edge40
  %t76 = tail call { i64, i64, i64 } @mech_compact_append_backing_byte_consume(i64 %v0, i64 %v1715187201, i64 %v1401, i64 %v1717188200, i64 %v1720189199, i64 %v1774)
  %v137546 = extractvalue { i64, i64, i64 } %t76, 0
  %v137547 = extractvalue { i64, i64, i64 } %t76, 1
  %v137548 = extractvalue { i64, i64, i64 } %t76, 2
  %t77.not = icmp eq i64 %v137546, 0
  br i1 %t77.not, label %block8164, label %block8178

block8178:                                        ; preds = %block8179, %edge44
  %v1804 = phi i64 [ %v1715187201, %edge44 ], [ %v137546, %block8179 ]
  %v1806 = phi i64 [ %v1717188200, %edge44 ], [ %v137548, %block8179 ]
  %v1809 = phi i64 [ %v1720189199, %edge44 ], [ %v137547, %block8179 ]
  %v1816 = add i64 %v1804, %v1401
  %t78 = inttoptr i64 %v1816 to ptr
  store i8 1, ptr %t78, align 1
  %t79 = icmp eq i64 %v1720189199, %v1809
  %t81.not169 = icmp eq i64 %v1809, 0
  %t81.not = or i1 %t79, %t81.not169
  br i1 %t81.not, label %block8183, label %edge51

block8183:                                        ; preds = %block8178, %edge51
  %t85.not = or i1 %t50.not163191198, %t79
  br i1 %t85.not, label %edge58, label %edge54

block8164:                                        ; preds = %edge54, %block8179, %block8165
  %v1768 = phi i64 [ %v137547, %block8179 ], [ 1, %block8165 ], [ %v1827, %edge54 ]
  %t87 = insertvalue { i64, i64 } poison, i64 %v1768, 0
  %t88 = insertvalue { i64, i64 } %t87, i64 23, 1
  br label %common.ret

block8204:                                        ; preds = %edge63, %edge59
  %t100 = tail call { i64, i64, i64 } @mech_compact_append_backing_byte_consume(i64 %v0, i64 %v1804, i64 %v1774, i64 %v1806, i64 %v1809, i64 %v1836)
  %v137549 = extractvalue { i64, i64, i64 } %t100, 0
  %v137550 = extractvalue { i64, i64, i64 } %t100, 1
  %v137551 = extractvalue { i64, i64, i64 } %t100, 2
  %t101.not = icmp eq i64 %v137549, 0
  br i1 %t101.not, label %block8188, label %edge70

block8224:                                        ; preds = %edge70, %edge75
  %t112.not = or i1 %t81.not169, %t106
  br i1 %t112.not, label %edge5660, label %edge78

block8188:                                        ; preds = %edge81, %block8204, %edge58
  %v1829 = phi i64 [ %v137550, %block8204 ], [ 1, %edge58 ], [ %v1925, %edge81 ]
  %t117 = insertvalue { i64, i64 } poison, i64 %v1829, 0
  %t118 = insertvalue { i64, i64 } %t117, i64 24, 1
  br label %common.ret

block8275:                                        ; preds = %block22, %edge158
  %v137774 = phi i64 [ %v138370, %edge158 ], [ %v1715187201, %block22 ]
  %v137775 = phi i64 [ %v138369, %edge158 ], [ %v1401, %block22 ]
  %v137776 = phi i64 [ %v138371, %edge158 ], [ %v1717188200, %block22 ]
  %v137777 = phi i64 [ %v138367, %edge158 ], [ 1, %block22 ]
  %v137778 = phi i64 [ %v138372, %edge158 ], [ %v1720189199, %block22 ]
  %v137779 = phi i64 [ %v138368, %edge158 ], [ 0, %block22 ]
  %v2012 = sub nsw i64 %v1395, %v137779
  %t121 = icmp ult i64 %v2012, 65535
  %spec.select = zext i1 %t121 to i8
  %spec.select173 = tail call i64 @llvm.umin.i64(i64 %v2012, i64 65535)
  %t128 = icmp eq i64 %v137777, 1
  br i1 %t128, label %edge101, label %block8308

block8323:                                        ; preds = %edge107, %edge103
  %t141 = tail call { i64, i64, i64 } @mech_compact_append_backing_byte_consume(i64 %v0, i64 %v137774, i64 %v137775, i64 %v137776, i64 %v137778, i64 %v2098)
  %v137552 = extractvalue { i64, i64, i64 } %t141, 0
  %v137553 = extractvalue { i64, i64, i64 } %t141, 1
  %v137554 = extractvalue { i64, i64, i64 } %t141, 2
  %t142.not = icmp eq i64 %v137552, 0
  br i1 %t142.not, label %block8308, label %block8322

block8322:                                        ; preds = %block8323, %edge107
  %v2128 = phi i64 [ %v137774, %edge107 ], [ %v137552, %block8323 ]
  %v2130 = phi i64 [ %v137776, %edge107 ], [ %v137554, %block8323 ]
  %v2133 = phi i64 [ %v137778, %edge107 ], [ %v137553, %block8323 ]
  %v2140 = add i64 %v2128, %v137775
  %t143 = inttoptr i64 %v2140 to ptr
  store i8 %spec.select, ptr %t143, align 1
  %t144 = icmp eq i64 %v137778, %v2133
  %t146.not165 = icmp eq i64 %v2133, 0
  %t146.not = or i1 %t144, %t146.not165
  br i1 %t146.not, label %block8327, label %edge114

block8327:                                        ; preds = %block8322, %edge114
  %t150.not166 = icmp eq i64 %v137778, 0
  %t150.not = or i1 %t150.not166, %t144
  br i1 %t150.not, label %edge124, label %edge117

block8308:                                        ; preds = %edge120, %block8323, %edge101, %block8275
  %v2092 = phi i64 [ %v137553, %block8323 ], [ 103427, %block8275 ], [ 1, %edge101 ], [ %v2151, %edge120 ]
  %t155 = insertvalue { i64, i64 } poison, i64 %v2092, 0
  %t156 = insertvalue { i64, i64 } %t155, i64 69, 1
  br label %common.ret

block8393:                                        ; preds = %edge129, %edge125
  %t168 = tail call { i64, i64, i64 } @mech_compact_append_backing_byte_consume(i64 %v0, i64 %v2128, i64 %v2098, i64 %v2130, i64 %v2133, i64 %v2264)
  %v137558 = extractvalue { i64, i64, i64 } %t168, 0
  %v137559 = extractvalue { i64, i64, i64 } %t168, 1
  %v137560 = extractvalue { i64, i64, i64 } %t168, 2
  %t169.not = icmp eq i64 %v137558, 0
  br i1 %t169.not, label %block8377, label %edge136

block8413:                                        ; preds = %edge136, %edge139
  %t178.not = or i1 %t146.not165, %t172
  br i1 %t178.not, label %block84, label %edge142

block8377:                                        ; preds = %edge142, %block8393, %edge124
  %v2251 = phi i64 [ %v137559, %block8393 ], [ 1, %edge124 ], [ %v2353, %edge142 ]
  %t180 = insertvalue { i64, i64 } poison, i64 %v2251, 0
  %t181 = insertvalue { i64, i64 } %t180, i64 80, 1
  br label %common.ret

block84:                                          ; preds = %edge142, %block8413
  %v2360 = xor i64 %spec.select173, -1
  %t182 = tail call { i64, i64, i64, i64, i64, i64, i64, i64 } @mech_compact_checked_layout_continuation_16644(i64 %v2264, i64 %v2296, i64 %v2299, i64 %v2294, i64 %v2360, i64 %v0, i64 %v1397, i64 %v137779, i64 %v1395, i64 %spec.select173, i64 %v1394)
  %v138365 = extractvalue { i64, i64, i64, i64, i64, i64, i64, i64 } %t182, 0
  %v138367 = extractvalue { i64, i64, i64, i64, i64, i64, i64, i64 } %t182, 2
  %v138368 = extractvalue { i64, i64, i64, i64, i64, i64, i64, i64 } %t182, 3
  %v138369 = extractvalue { i64, i64, i64, i64, i64, i64, i64, i64 } %t182, 4
  %v138370 = extractvalue { i64, i64, i64, i64, i64, i64, i64, i64 } %t182, 5
  %v138371 = extractvalue { i64, i64, i64, i64, i64, i64, i64, i64 } %t182, 6
  %v138372 = extractvalue { i64, i64, i64, i64, i64, i64, i64, i64 } %t182, 7
  %t183 = icmp eq i64 %v138365, 2
  br i1 %t183, label %edge147, label %edge148

block8601:                                        ; preds = %edge180
  %t224 = icmp eq i64 %v1405, %v2786
  %t226.not44 = icmp eq i64 %v2786, 0
  %t226.not = or i1 %t224, %t226.not44
  br i1 %t226.not, label %block8607, label %edge189

block8607:                                        ; preds = %block8601, %edge189
  %t230.not = or i1 %t26.not, %t224
  br i1 %t230.not, label %edge201, label %edge192

block8598:                                        ; preds = %edge192, %edge180, %edge175
  %v2758 = phi i64 [ %v2786, %edge180 ], [ 103427, %edge175 ], [ %v2796, %edge192 ]
  %t232 = insertvalue { i64, i64 } poison, i64 %v2758, 0
  %t233 = insertvalue { i64, i64 } %t232, i64 118, 1
  br label %common.ret

block8737:                                        ; preds = %edge199
  %t272 = insertvalue { i64, i64 } poison, i64 %v3171, 0
  %t273 = insertvalue { i64, i64 } %t272, i64 156, 1
  br label %common.ret

block167:                                         ; preds = %edge237, %edge239
  %spec.select1 = tail call i64 @llvm.umin.i64(i64 %v1395, i64 304999)
  %v3358 = add nuw nsw i64 %spec.select1, 258
  %t277 = tail call { i64, i64 } @mech_compact_allocate_backing(i64 %v0, i64 %v3358, i64 8, i64 8, i64 0)
  %v3365 = extractvalue { i64, i64 } %t277, 0
  %v3366 = extractvalue { i64, i64 } %t277, 1
  %t278.not = icmp eq i64 %v3365, 0
  br i1 %t278.not, label %edge250, label %edge249

block9353:                                        ; preds = %edge5633, %edge343
  %v137791 = phi i64 [ %v2768208219, %edge343 ], [ %v125845, %edge5633 ]
  %v137792 = phi i64 [ %v1401, %edge343 ], [ %v125859, %edge5633 ]
  %v137793 = phi i64 [ %v2770209218, %edge343 ], [ %v125873, %edge5633 ]
  %v137794 = phi i64 [ 1, %edge343 ], [ %v125887, %edge5633 ]
  %v137795 = phi i64 [ %v2773210217, %edge343 ], [ %v125915, %edge5633 ]
  %v137796 = phi i64 [ 0, %edge343 ], [ %v125935, %edge5633 ]
  %v137797 = phi i64 [ 0, %edge343 ], [ %v125950, %edge5633 ]
  %v137798 = phi i64 [ %v2855, %edge343 ], [ %v35962, %edge5633 ]
  %v137801 = phi i64 [ %v2856, %edge343 ], [ %v35967, %edge5633 ]
  %v137802 = phi i64 [ %v3170, %edge343 ], [ %v125725, %edge5633 ]
  %v137803 = phi i64 [ %v3171, %edge343 ], [ %v125730, %edge5633 ]
  %v137804 = phi i64 [ %v3365, %edge343 ], [ %v49360, %edge5633 ]
  %v137805 = phi i64 [ 0, %edge343 ], [ %v49361, %edge5633 ]
  %v137806 = phi i64 [ %v3358, %edge343 ], [ %v49362, %edge5633 ]
  %v137807 = phi i64 [ 1, %edge343 ], [ %v49363, %edge5633 ]
  %v137808 = phi i64 [ 0, %edge343 ], [ %v49364, %edge5633 ]
  %v137809 = phi i64 [ %v3366, %edge343 ], [ %v49365, %edge5633 ]
  %v137810 = phi i64 [ 0, %edge343 ], [ %v35974, %edge5633 ]
  %v137811 = phi i64 [ 0, %edge343 ], [ %v35975, %edge5633 ]
  %v137812 = phi i64 [ 0, %edge343 ], [ %v35976, %edge5633 ]
  %v137813 = phi i64 [ 0, %edge343 ], [ %v125761, %edge5633 ]
  %v137814 = phi i64 [ 0, %edge343 ], [ %v35978, %edge5633 ]
  %v137815 = phi i64 [ %spec.select18, %edge343 ], [ %v35979, %edge5633 ]
  %v137816 = phi i64 [ 0, %edge343 ], [ %v125765, %edge5633 ]
  %v137817 = phi i64 [ %v3457, %edge343 ], [ %v91645, %edge5633 ]
  %v137822 = phi i64 [ %v3458, %edge343 ], [ %v137736, %edge5633 ]
  %v137823 = phi i64 [ %v3652, %edge343 ], [ %v91624, %edge5633 ]
  %v137828 = phi i64 [ %v3653, %edge343 ], [ %v87729, %edge5633 ]
  %v137829 = phi i64 [ %v3867, %edge343 ], [ %v125767, %edge5633 ]
  %v137831 = phi i64 [ %v3868, %edge343 ], [ %v125560.sink, %edge5633 ]
  %v137832 = phi i64 [ %v4086, %edge343 ], [ %v125779, %edge5633 ]
  %v137834 = phi i64 [ %v4087, %edge343 ], [ %v125784, %edge5633 ]
  %v137835 = phi i64 [ %v4329, %edge343 ], [ %v35992, %edge5633 ]
  %v137836 = phi i64 [ %v4330, %edge343 ], [ %v35997, %edge5633 ]
  %v137837 = phi i64 [ 0, %edge343 ], [ %v36004, %edge5633 ]
  %v137838 = phi i64 [ %v4827, %edge343 ], [ %v125813, %edge5633 ]
  %v137840 = phi i64 [ %v4828, %edge343 ], [ %v125818, %edge5633 ]
  %v137841 = phi i64 [ %v4572, %edge343 ], [ %v125825, %edge5633 ]
  %v137843 = phi i64 [ %v4573, %edge343 ], [ %v125830, %edge5633 ]
  %v137844 = phi i64 [ 0, %edge343 ], [ %v125839, %edge5633 ]
  %v137845 = phi i64 [ 0, %edge343 ], [ %v44196, %edge5633 ]
  %v137848 = phi i64 [ 0, %edge343 ], [ %v129095, %edge5633 ]
  %v137849 = phi i64 [ 0, %edge343 ], [ %v129198, %edge5633 ]
  %v5538 = sub i64 %v1395, %v137813
  %t359 = icmp ult i64 %v5538, 305000
  br i1 %t359, label %block323, label %edge367

block323:                                         ; preds = %edge367, %block9353
  %v5790 = phi i64 [ %v1395, %block9353 ], [ %v5669, %edge367 ]
  %t364.not = icmp eq i64 %v137845, 0
  br i1 %t364.not, label %edge375, label %block473

block364:                                         ; preds = %block364.preheader, %edge454
  %v6393 = phi i64 [ %v6678, %edge454 ], [ %v6112, %block364.preheader ]
  %v6398 = phi i64 [ %v6832, %edge454 ], [ 0, %block364.preheader ]
  %v6399 = phi i64 [ %v6673, %edge454 ], [ %v6111, %block364.preheader ]
  %t391 = icmp ne i64 %v6393, 0
  %or.cond19 = select i1 %v636946, i1 %t391, i1 false
  br i1 %or.cond19, label %edge408, label %block374

block374:                                         ; preds = %edge408, %block364
  %exitcond.not = icmp eq i64 %v6398, %v6346
  br i1 %exitcond.not, label %edge455, label %edge422

block9676:                                        ; preds = %edge436, %edge435
  %t458 = call { i64, i64 } @mech_compact_writable_scalar_backing(i64 %v0, i64 %v6399, i64 256, i64 256, i64 %v6393, i64 256, i64 3)
  %v6690 = extractvalue { i64, i64 } %t458, 0
  %v6691 = extractvalue { i64, i64 } %t458, 1
  %t459.not = icmp eq i64 %v6690, 0
  br i1 %t459.not, label %block9671, label %block9676.block9675_crit_edge

block9676.block9675_crit_edge:                    ; preds = %block9676
  %.pre19818 = add i64 %v6690, %v138387
  %.pre19819 = inttoptr i64 %.pre19818 to ptr
  br label %block9675

block9675:                                        ; preds = %block9676.block9675_crit_edge, %edge436
  %t460.pre-phi = phi ptr [ %.pre19819, %block9676.block9675_crit_edge ], [ %t449, %edge436 ]
  %v6679 = phi i64 [ %v6690, %block9676.block9675_crit_edge ], [ %v6399, %edge436 ]
  %v6684 = phi i64 [ %v6691, %block9676.block9675_crit_edge ], [ %v6393, %edge436 ]
  store i8 1, ptr %t460.pre-phi, align 1
  br label %block9674

block9674:                                        ; preds = %edge432, %block9675
  %v6673 = phi i64 [ %v6679, %block9675 ], [ %v6399, %edge432 ]
  %v6678 = phi i64 [ %v6684, %block9675 ], [ %v6393, %edge432 ]
  %t461 = icmp eq i64 %v6393, %v6678
  %t463.not47 = icmp eq i64 %v6678, 0
  %t463.not = or i1 %t461, %t463.not47
  br i1 %t463.not, label %block9680, label %edge444

block9680:                                        ; preds = %block9674, %edge444
  %t467.not48 = icmp eq i64 %v6393, 0
  %t467.not = or i1 %t467.not48, %t461
  br i1 %t467.not, label %edge454, label %edge447

block9671:                                        ; preds = %edge447, %block9676, %edge429
  %v6661 = phi i64 [ %v6691, %block9676 ], [ 103425, %edge429 ], [ %v6702, %edge447 ]
  %t469 = insertvalue { i64, i64 } poison, i64 %v6661, 0
  %t470 = insertvalue { i64, i64 } %t469, i64 393, 1
  br label %common.ret

block427:                                         ; preds = %block427.preheader, %edge485
  %v137625 = phi i64 [ %v7026, %edge485 ], [ 0, %block427.preheader ]
  %v137626 = phi i64 [ %v7142, %edge485 ], [ 0, %block427.preheader ]
  %v7124 = add i64 %v137625, %v6399
  %t496 = inttoptr i64 %v7124 to ptr
  %t497 = load i8, ptr %t496, align 1
  %v7125 = zext i8 %t497 to i64
  %v7142 = add i64 %v137626, %v7125
  %t498.not = icmp ult i64 %v7142, %v137626
  br i1 %t498.not, label %block39122, label %edge485

block449:                                         ; preds = %edge474, %edge471, %edge470
  %t500 = icmp ugt i64 %v7142, 79
  br i1 %t500, label %block473, label %edge488

block473:                                         ; preds = %edge377, %block449, %edge488, %block323
  %v7562 = phi i64 [ 259, %block323 ], [ 3, %edge377 ], [ %v7404, %edge488 ], [ 3, %block449 ]
  br i1 %t23.not, label %block9976.outer.preheader, label %edge496

block9976.outer.outer:                            ; preds = %block2378, %block9976.outer.preheader
  %v138626.ph.ph = phi i64 [ %v137801, %block9976.outer.preheader ], [ %v24249653, %block2378 ]
  %v138627.ph.ph = phi i64 [ %v137803, %block9976.outer.preheader ], [ %v138160, %block2378 ]
  %v138628.ph.ph = phi i64 [ %v137831, %block9976.outer.preheader ], [ %v30915.ph, %block2378 ]
  %v138629.ph.ph = phi i64 [ %v137834, %block9976.outer.preheader ], [ %v30927.ph, %block2378 ]
  %v138630.ph.ph = phi i64 [ %v137840, %block9976.outer.preheader ], [ %v138222, %block2378 ]
  %v138631.ph.ph = phi i64 [ %v137843, %block9976.outer.preheader ], [ %v138278, %block2378 ]
  %v138634.ph.ph = phi i64 [ %v137812, %block9976.outer.preheader ], [ %v27344, %block2378 ]
  %v138635.ph.ph = phi i64 [ %v137815, %block9976.outer.preheader ], [ %v27392, %block2378 ]
  %v138636.ph.ph = phi i64 [ %v137810, %block9976.outer.preheader ], [ %v24268656, %block2378 ]
  %v138637.ph.ph = phi i64 [ %v137811, %block9976.outer.preheader ], [ %v24270657, %block2378 ]
  %v138638.ph.ph = phi i64 [ %v137814, %block9976.outer.preheader ], [ %spec.select2, %block2378 ]
  %v138639.ph.ph = phi i64 [ %v137816, %block9976.outer.preheader ], [ %v26833, %block2378 ]
  %v138640.ph.ph = phi i64 [ 0, %block9976.outer.preheader ], [ %v30581, %block2378 ]
  %v138641.ph.ph = phi i64 [ %v137844, %block9976.outer.preheader ], [ 0, %block2378 ]
  %v138642.ph.ph = phi i64 [ %v137812, %block9976.outer.preheader ], [ %v26682, %block2378 ]
  %v138644.ph.ph = phi i64 [ %v137813, %block9976.outer.preheader ], [ %v27796, %block2378 ]
  %v138645.ph.ph = phi i64 [ %v5790, %block9976.outer.preheader ], [ %v27569, %block2378 ]
  %v138646.ph.ph = phi i64 [ %v7562, %block9976.outer.preheader ], [ %v25296, %block2378 ]
  %v138647.ph.ph = phi i64 [ 0, %block9976.outer.preheader ], [ %v27344, %block2378 ]
  %v138648.ph.ph = phi i64 [ 0, %block9976.outer.preheader ], [ 1, %block2378 ]
  %v138649.ph.ph = phi i64 [ %v137798, %block9976.outer.preheader ], [ %v24244652, %block2378 ]
  %v138650.ph.ph = phi i64 [ %v137802, %block9976.outer.preheader ], [ %v138159, %block2378 ]
  %v138651.ph.ph = phi i64 [ %v137829, %block9976.outer.preheader ], [ %v30910.ph, %block2378 ]
  %v138652.ph.ph = phi i64 [ %v137832, %block9976.outer.preheader ], [ %v30922.ph, %block2378 ]
  %v138653.ph.ph = phi i64 [ %v137838, %block9976.outer.preheader ], [ %v138221, %block2378 ]
  %v138654.ph.ph = phi i64 [ %v137841, %block9976.outer.preheader ], [ %v138277, %block2378 ]
  %v138655.ph.ph = phi i64 [ %v137848, %block9976.outer.preheader ], [ %v8626, %block2378 ]
  %v138656.ph.ph = phi i64 [ %v137849, %block9976.outer.preheader ], [ %v8837, %block2378 ]
  %t519 = icmp ne i64 %v138628.ph.ph, 0
  %t520 = inttoptr i64 %v138628.ph.ph to ptr
  %t527 = icmp ne i64 %v138630.ph.ph, 0
  %t528 = inttoptr i64 %v138630.ph.ph to ptr
  %t594 = zext i64 %v138651.ph.ph to i128
  %v138730 = or disjoint i128 %t594, 4777706715090773868544
  %t604 = zext i64 %v138653.ph.ph to i128
  %v138734 = or disjoint i128 %t604, 184467440737095516160
  br label %block9976.outer

block9976.outer:                                  ; preds = %block9976.outer.outer, %edge1708.block2462_crit_edge
  %v138626.ph = phi i64 [ %v24249653, %edge1708.block2462_crit_edge ], [ %v138626.ph.ph, %block9976.outer.outer ]
  %v138627.ph = phi i64 [ %v138160, %edge1708.block2462_crit_edge ], [ %v138627.ph.ph, %block9976.outer.outer ]
  %v138629.ph = phi i64 [ %v26661, %edge1708.block2462_crit_edge ], [ %v138629.ph.ph, %block9976.outer.outer ]
  %v138631.ph = phi i64 [ %v26673, %edge1708.block2462_crit_edge ], [ %v138631.ph.ph, %block9976.outer.outer ]
  %v138634.ph = phi i64 [ %v27344, %edge1708.block2462_crit_edge ], [ %v138634.ph.ph, %block9976.outer.outer ]
  %v138635.ph = phi i64 [ %v27392, %edge1708.block2462_crit_edge ], [ %v138635.ph.ph, %block9976.outer.outer ]
  %v138636.ph = phi i64 [ %v24268656, %edge1708.block2462_crit_edge ], [ %v138636.ph.ph, %block9976.outer.outer ]
  %v138637.ph = phi i64 [ %v24270657, %edge1708.block2462_crit_edge ], [ %v138637.ph.ph, %block9976.outer.outer ]
  %v138638.ph = phi i64 [ %spec.select2, %edge1708.block2462_crit_edge ], [ %v138638.ph.ph, %block9976.outer.outer ]
  %v138639.ph = phi i64 [ %v26833, %edge1708.block2462_crit_edge ], [ %v138639.ph.ph, %block9976.outer.outer ]
  %v138640.ph = phi i64 [ %v28038, %edge1708.block2462_crit_edge ], [ %v138640.ph.ph, %block9976.outer.outer ]
  %v138641.ph = phi i64 [ %v26680, %edge1708.block2462_crit_edge ], [ %v138641.ph.ph, %block9976.outer.outer ]
  %v138642.ph = phi i64 [ %v26682, %edge1708.block2462_crit_edge ], [ %v138642.ph.ph, %block9976.outer.outer ]
  %v138644.ph = phi i64 [ %v27796, %edge1708.block2462_crit_edge ], [ %v138644.ph.ph, %block9976.outer.outer ]
  %v138645.ph = phi i64 [ %v27569, %edge1708.block2462_crit_edge ], [ %v138645.ph.ph, %block9976.outer.outer ]
  %v138646.ph = phi i64 [ %v25296, %edge1708.block2462_crit_edge ], [ %v138646.ph.ph, %block9976.outer.outer ]
  %v138647.ph = phi i64 [ %v31750, %edge1708.block2462_crit_edge ], [ %v138647.ph.ph, %block9976.outer.outer ]
  %v138648.ph = phi i64 [ %v31806, %edge1708.block2462_crit_edge ], [ %v138648.ph.ph, %block9976.outer.outer ]
  %v138649.ph = phi i64 [ %v24244652, %edge1708.block2462_crit_edge ], [ %v138649.ph.ph, %block9976.outer.outer ]
  %v138650.ph = phi i64 [ %v138159, %edge1708.block2462_crit_edge ], [ %v138650.ph.ph, %block9976.outer.outer ]
  %v138652.ph = phi i64 [ %v26656, %edge1708.block2462_crit_edge ], [ %v138652.ph.ph, %block9976.outer.outer ]
  %v138654.ph = phi i64 [ %v26668, %edge1708.block2462_crit_edge ], [ %v138654.ph.ph, %block9976.outer.outer ]
  %v138655.ph = phi i64 [ %v8626, %edge1708.block2462_crit_edge ], [ %v138655.ph.ph, %block9976.outer.outer ]
  %v138656.ph = phi i64 [ %v8837, %edge1708.block2462_crit_edge ], [ %v138656.ph.ph, %block9976.outer.outer ]
  br label %block9976

block9976:                                        ; preds = %block9976.outer, %block2107
  %v138626 = phi i64 [ %v24249653, %block2107 ], [ %v138626.ph, %block9976.outer ]
  %v138627 = phi i64 [ %v138160, %block2107 ], [ %v138627.ph, %block9976.outer ]
  %v138629 = phi i64 [ %v26661, %block2107 ], [ %v138629.ph, %block9976.outer ]
  %v138631 = phi i64 [ %v26673, %block2107 ], [ %v138631.ph, %block9976.outer ]
  %v138634 = phi i64 [ %v27344, %block2107 ], [ %v138634.ph, %block9976.outer ]
  %v138635 = phi i64 [ %v27392, %block2107 ], [ %v138635.ph, %block9976.outer ]
  %v138636 = phi i64 [ %v24268656, %block2107 ], [ %v138636.ph, %block9976.outer ]
  %v138637 = phi i64 [ %v24270657, %block2107 ], [ %v138637.ph, %block9976.outer ]
  %v138638 = phi i64 [ %spec.select2, %block2107 ], [ %v138638.ph, %block9976.outer ]
  %v138639 = phi i64 [ %v26833, %block2107 ], [ %v138639.ph, %block9976.outer ]
  %v138640 = phi i64 [ %v28038, %block2107 ], [ %v138640.ph, %block9976.outer ]
  %v138641 = phi i64 [ %v26680, %block2107 ], [ %v138641.ph, %block9976.outer ]
  %v138642 = phi i64 [ %v26682, %block2107 ], [ %v138642.ph, %block9976.outer ]
  %v138643 = phi i64 [ %v27333, %block2107 ], [ 0, %block9976.outer ]
  %v138644 = phi i64 [ %v27796, %block2107 ], [ %v138644.ph, %block9976.outer ]
  %v138645 = phi i64 [ %v27569, %block2107 ], [ %v138645.ph, %block9976.outer ]
  %v138646 = phi i64 [ %v25296, %block2107 ], [ %v138646.ph, %block9976.outer ]
  %v138647 = phi i64 [ %v31750, %block2107 ], [ %v138647.ph, %block9976.outer ]
  %v138648 = phi i64 [ %v31806, %block2107 ], [ %v138648.ph, %block9976.outer ]
  %v138649 = phi i64 [ %v24244652, %block2107 ], [ %v138649.ph, %block9976.outer ]
  %v138650 = phi i64 [ %v138159, %block2107 ], [ %v138650.ph, %block9976.outer ]
  %v138652 = phi i64 [ %v26656, %block2107 ], [ %v138652.ph, %block9976.outer ]
  %v138654 = phi i64 [ %v26668, %block2107 ], [ %v138654.ph, %block9976.outer ]
  %v138655 = phi i64 [ %v8626, %block2107 ], [ %v138655.ph, %block9976.outer ]
  %v138656 = phi i64 [ %v8837, %block2107 ], [ %v138656.ph, %block9976.outer ]
  %t511 = icmp ne i64 %v138626, 0
  %or.cond20 = select i1 %v636946, i1 %t511, i1 false
  br i1 %or.cond20, label %edge503, label %block503

block9974:                                        ; preds = %edge570, %edge563, %edge547
  %v7587 = phi i64 [ %v7691, %edge563 ], [ %v7687, %edge547 ], [ %v7721, %edge570 ]
  %t695 = insertvalue { i64, i64 } poison, i64 %v7587, 0
  %t696 = insertvalue { i64, i64 } %t695, i64 475, 1
  br label %common.ret

block503:                                         ; preds = %edge529, %edge523, %edge519, %edge515, %edge511, %edge507, %edge503, %block9976
  %v7942 = sub i64 %v1395, %v138634
  %t697 = icmp eq i64 %v138634, %v138635
  br i1 %t697, label %edge594, label %block535

block10134:                                       ; preds = %edge583
  %t706 = insertvalue { i64, i64 } poison, i64 %v8230, 0
  %t707 = insertvalue { i64, i64 } %t706, i64 511, 1
  br label %common.ret

block10145:                                       ; preds = %edge600, %edge598
  br i1 %t511, label %edge606, label %edge639

block10144:                                       ; preds = %edge606, %edge596, %edge594
  %v8241 = phi i64 [ 103427, %edge596 ], [ %v8297, %edge606 ], [ %v8281, %edge594 ]
  %t740 = insertvalue { i64, i64 } poison, i64 %v8241, 0
  %t741 = insertvalue { i64, i64 } %t740, i64 514, 1
  br label %common.ret

block535:                                         ; preds = %block503, %edge583, %edge639
  %v8541 = phi i64 [ %v8542, %edge583 ], [ %v8542, %edge639 ], [ 0, %block503 ]
  %v8618 = phi i64 [ %v8619, %edge583 ], [ %v8619, %edge639 ], [ %v138634, %block503 ]
  %v8626 = phi i64 [ %v8627, %edge583 ], [ %v8627, %edge639 ], [ %v138638, %block503 ]
  %v8737 = phi i64 [ %v8738, %edge583 ], [ %v8738, %edge639 ], [ %v7942, %block503 ]
  %v8837 = phi i64 [ %v8838, %edge583 ], [ %v8838, %edge639 ], [ %v138635, %block503 ]
  %v8988 = phi i64 [ %v8989, %edge583 ], [ %v8989, %edge639 ], [ %v138643, %block503 ]
  %v9871 = phi i64 [ %v8281, %edge583 ], [ 0, %edge639 ], [ %v138626, %block503 ]
  %v10614 = phi i64 [ %v10615, %edge583 ], [ %v10615, %edge639 ], [ %v138636, %block503 ]
  %v10729 = phi i64 [ %v8280, %edge583 ], [ %v8280, %edge639 ], [ %v138649, %block503 ]
  %v12848 = phi i64 [ %v12849, %edge583 ], [ %v12849, %edge639 ], [ %v138639, %block503 ]
  %v13212 = phi i64 [ %v13213, %edge583 ], [ %v13213, %edge639 ], [ %v138637, %block503 ]
  %v24555 = phi i64 [ %v24556, %edge583 ], [ %v24556, %edge639 ], [ %v138642, %block503 ]
  %v25226 = phi i64 [ %v25227, %edge583 ], [ %v25227, %edge639 ], [ %v138641, %block503 ]
  %v25296 = phi i64 [ %v25297, %edge583 ], [ %v25297, %edge639 ], [ %v138646, %block503 ]
  %v27569 = phi i64 [ %v27570, %edge583 ], [ %v27570, %edge639 ], [ %v138645, %block503 ]
  %v27796 = phi i64 [ %v27797, %edge583 ], [ %v27797, %edge639 ], [ %v138644, %block503 ]
  %v28038 = phi i64 [ %v28039, %edge583 ], [ %v28039, %edge639 ], [ %v138640, %block503 ]
  %v31750 = phi i64 [ %v31751, %edge583 ], [ %v31751, %edge639 ], [ %v138647, %block503 ]
  %v31806 = phi i64 [ %v31807, %edge583 ], [ %v31807, %edge639 ], [ %v138648, %block503 ]
  %t774 = icmp eq i64 %v8541, 1
  %spec.select2 = select i1 %t774, i64 %v8618, i64 %v8626
  %v8828 = call i64 @llvm.umin.i64(i64 %v8737, i64 32768)
  %v8829 = add i64 %v8828, %v8618
  %v27392 = select i1 %t774, i64 %v8829, i64 %v8837
  %spec.select3 = call i64 @llvm.umin.i64(i64 %v8737, i64 258)
  %v9023 = lshr i64 %v8988, 32
  %t785 = icmp ne i64 %v9023, 0
  %t786 = icmp ugt i64 %v8737, 4
  br i1 %t786, label %edge665, label %block1945

block10452:                                       ; preds = %edge696, %edge695
  %v9926 = or i64 %v137836, %v137828
  %v9928 = or i64 %v9926, %v138627
  %t807.not = icmp eq i64 %v9928, 0
  br i1 %t807.not, label %block10455, label %edge700

block10455:                                       ; preds = %edge700, %block10452
  %v9931 = or i64 %v138629, %v138628.ph.ph
  %v9932 = or i64 %v9931, %v1399
  %v9933 = or i64 %v9932, %v138630.ph.ph
  %t809.not = icmp eq i64 %v9933, 0
  br i1 %t809.not, label %block10458, label %edge704

block10458:                                       ; preds = %edge704, %block10455
  %v9936 = or i64 %v9871, %v138631
  %t811.not = icmp eq i64 %v9936, 0
  br i1 %t811.not, label %block39124, label %edge708

block10437:                                       ; preds = %edge708, %edge704, %edge700, %edge696
  %v9897 = phi i64 [ %v9934, %edge704 ], [ %v9924, %edge696 ], [ %v9929, %edge700 ], [ %v9937, %edge708 ]
  %t813 = insertvalue { i64, i64 } poison, i64 %v9897, 0
  %t814 = insertvalue { i64, i64 } %t813, i64 589, 1
  br label %common.ret

block10615:                                       ; preds = %edge757, %edge730
  %t846 = call { i64, i64, i64, i64 } @mech_compact_checked_layout_continuation_9112(i64 %v10703, i64 262144, i64 %v10729, i64 %v10601, i64 262144, i64 %v9871, i64 %v0)
  %v138287 = extractvalue { i64, i64, i64, i64 } %t846, 0
  %v138289 = extractvalue { i64, i64, i64, i64 } %t846, 2
  %v138290 = extractvalue { i64, i64, i64, i64 } %t846, 3
  %t847 = icmp eq i64 %v138287, 2
  br i1 %t847, label %edge770, label %edge773

block10654:                                       ; preds = %edge777, %edge776
  %t862 = call { i64, i64 } @mech_compact_writable_scalar_backing(i64 %v0, i64 %v138289, i64 262144, i64 262144, i64 %v138290, i64 262144, i64 5)
  %v10878 = extractvalue { i64, i64 } %t862, 0
  %v10879 = extractvalue { i64, i64 } %t862, 1
  %t863.not = icmp eq i64 %v10878, 0
  br i1 %t863.not, label %block10649, label %block10652

block10652:                                       ; preds = %block10654
  %v10880 = add i64 %v10878, %v10739
  %t864 = inttoptr i64 %v10880 to ptr
  store i16 %t830, ptr %t864, align 1
  %t865 = icmp eq i64 %v138290, %v10879
  %t867.not52 = icmp eq i64 %v10879, 0
  %t867.not = or i1 %t865, %t867.not52
  br i1 %t867.not, label %block10658, label %edge785

block10658:                                       ; preds = %block10652, %edge785
  %t871.not = or i1 %t857.not, %t865
  br i1 %t871.not, label %block662, label %edge788

block10649:                                       ; preds = %edge788, %block10654
  %v10849 = phi i64 [ %v10879, %block10654 ], [ %v10890, %edge788 ]
  %t873 = insertvalue { i64, i64 } poison, i64 %v10849, 0
  %t874 = insertvalue { i64, i64 } %t873, i64 662, 1
  br label %common.ret

block662.sink.split:                              ; preds = %edge777, %edge761
  %t853.sink = phi ptr [ %t833, %edge761 ], [ %t853, %edge777 ]
  %v13353.ph = phi i64 [ %v10729, %edge761 ], [ %v138289, %edge777 ]
  %v13375.ph = phi i64 [ %v9871, %edge761 ], [ %v138290, %edge777 ]
  store i16 %t830, ptr %t853.sink, align 1
  br label %block662

block662:                                         ; preds = %block662.sink.split, %edge773, %block10658, %edge788
  %v13353 = phi i64 [ %v138289, %edge773 ], [ %v10878, %edge788 ], [ %v10878, %block10658 ], [ %v13353.ph, %block662.sink.split ]
  %v13375 = phi i64 [ %v138290, %edge773 ], [ %v10879, %edge788 ], [ %v10879, %block10658 ], [ %v13375.ph, %block662.sink.split ]
  br i1 %t785, label %edge901, label %edge793

block850:                                         ; preds = %edge833, %edge863
  %v11496572.pn = phi i64 [ %v12137, %edge863 ], [ %v11496572, %edge833 ]
  %t919.not.not = icmp eq i64 %v8618, %v11496572.pn
  br i1 %t919.not.not, label %block866, label %edge877

block866:                                         ; preds = %edge837, %edge863, %edge793, %block850, %edge877
  %t919.not247 = phi i64 [ 1, %edge877 ], [ 0, %block850 ], [ 0, %edge793 ], [ 0, %edge863 ], [ 0, %edge837 ]
  %v13155 = phi i64 [ %v138173, %edge877 ], [ %v138650, %block850 ], [ %v138650, %edge793 ], [ %v138650, %edge863 ], [ %v138650, %edge837 ]
  %v13160 = phi i64 [ %v138174, %edge877 ], [ %v138627, %block850 ], [ %v138627, %edge793 ], [ %v138627, %edge863 ], [ %v138627, %edge837 ]
  %v13161 = add i64 %t919.not247, %v12848
  br label %edge901

block11383:                                       ; preds = %edge912
  %v13667 = shl nuw nsw i64 %v13521, 1
  %v13668 = add i64 %v138283, %v13667
  %t966 = inttoptr i64 %v13668 to ptr
  %t967 = load i16, ptr %t966, align 1
  %t968 = icmp eq i16 %t967, 0
  br i1 %t968, label %edge943, label %block11407

block11383.thread:                                ; preds = %edge915
  %t967599 = load i16, ptr %t963, align 1
  %t968600 = icmp eq i16 %t967599, 0
  br i1 %t968600, label %edge943, label %block11407

block11407:                                       ; preds = %block11383.thread, %block11383
  %v13667601604 = phi i64 [ %v13667, %block11383 ], [ %v13625, %block11383.thread ]
  %t975 = call { i64, i64 } @mech_compact_writable_scalar_backing(i64 %v0, i64 %v138283, i64 262144, i64 262144, i64 %v138284, i64 262144, i64 5)
  %v13690 = extractvalue { i64, i64 } %t975, 0
  %v13691 = extractvalue { i64, i64 } %t975, 1
  %t976.not = icmp eq i64 %v13690, 0
  br i1 %t976.not, label %block11382, label %block11405

block11405:                                       ; preds = %block11407
  %v13692 = add i64 %v13690, %v13667601604
  %t977 = inttoptr i64 %v13692 to ptr
  store i16 0, ptr %t977, align 1
  %t978 = icmp eq i64 %v138284, %v13691
  %t980.not69 = icmp eq i64 %v13691, 0
  %t980.not = or i1 %t978, %t980.not69
  br i1 %t980.not, label %block11411, label %edge935

block11411:                                       ; preds = %block11405, %edge935
  %t984.not = or i1 %t958.not, %t978
  br i1 %t984.not, label %edge943, label %edge938

block11382:                                       ; preds = %edge938, %block11407
  %v13615 = phi i64 [ %v13691, %block11407 ], [ %v13702, %edge938 ]
  %t986 = insertvalue { i64, i64 } poison, i64 %v13615, 0
  %t987 = insertvalue { i64, i64 } %t986, i64 901, 1
  br label %common.ret

block11422:                                       ; preds = %edge947, %edge946
  %t999 = call { i64, i64 } @mech_compact_writable_scalar_backing(i64 %v0, i64 %v13673253273, i64 262144, i64 262144, i64 %v13678254272, i64 262144, i64 5)
  %v13787 = extractvalue { i64, i64 } %t999, 0
  %v13788 = extractvalue { i64, i64 } %t999, 1
  %t1000.not = icmp eq i64 %v13787, 0
  br i1 %t1000.not, label %block11417, label %block11422.block11420_crit_edge

block11422.block11420_crit_edge:                  ; preds = %block11422
  %.pre19816 = add i64 %v13787, %v13764
  %.pre19817 = inttoptr i64 %.pre19816 to ptr
  br label %block11420

block11420:                                       ; preds = %block11422.block11420_crit_edge, %edge947
  %t1001.pre-phi = phi ptr [ %.pre19817, %block11422.block11420_crit_edge ], [ %t990, %edge947 ]
  %v13776 = phi i64 [ %v13787, %block11422.block11420_crit_edge ], [ %v13673253273, %edge947 ]
  %v13781 = phi i64 [ %v13788, %block11422.block11420_crit_edge ], [ %v13678254272, %edge947 ]
  store i16 0, ptr %t1001.pre-phi, align 1
  %t1002 = icmp eq i64 %v13678254272, %v13781
  %t1004.not71 = icmp eq i64 %v13781, 0
  %t1004.not = or i1 %t1002, %t1004.not71
  br i1 %t1004.not, label %block11426, label %edge955

block11426:                                       ; preds = %block11420, %edge955
  %t1008.not = or i1 %t980.not69257271, %t1002
  br i1 %t1008.not, label %edge1596, label %edge958

block11417:                                       ; preds = %edge958, %block11422
  %v13758 = phi i64 [ %v13788, %block11422 ], [ %v13799, %edge958 ]
  %t1010 = insertvalue { i64, i64 } poison, i64 %v13758, 0
  %t1011 = insertvalue { i64, i64 } %t1010, i64 903, 1
  br label %common.ret

block913:                                         ; preds = %block913.preheader, %edge1188
  %v14073 = phi i64 [ %v138295, %edge1188 ], [ %v138283, %block913.preheader ]
  %v14078 = phi i64 [ %v138296, %edge1188 ], [ %v138284, %block913.preheader ]
  %v14085 = phi i64 [ %v138591, %edge1188 ], [ %v13191, %block913.preheader ]
  %v14090 = phi i64 [ %v138592, %edge1188 ], [ %v13196, %block913.preheader ]
  %v14097 = phi i64 [ %v138593, %edge1188 ], [ %v13203, %block913.preheader ]
  %v14123 = phi i64 [ %v18370, %edge1188 ], [ %v13521, %block913.preheader ]
  %v14125 = phi i64 [ %v18372, %edge1188 ], [ %v13525, %block913.preheader ]
  %v14127 = phi i64 [ %v18436, %edge1188 ], [ %v13315, %block913.preheader ]
  %v14129 = phi i64 [ %v18531, %edge1188 ], [ 300, %block913.preheader ]
  %v14131 = phi i64 [ %v18374, %edge1188 ], [ 0, %block913.preheader ]
  %v14133 = phi i64 [ %v18376, %edge1188 ], [ 0, %block913.preheader ]
  %v14135 = phi i64 [ %v18814, %edge1188 ], [ 0, %block913.preheader ]
  %v14137 = phi i64 [ %v138594, %edge1188 ], [ 3, %block913.preheader ]
  %t1017 = icmp ult i64 %v14135, %spec.select3
  br i1 %t1017, label %edge974, label %block12932

block11726:                                       ; preds = %edge1003, %edge1002
  %v14727 = or i64 %v137836, %v137828
  %v14729 = or i64 %v14727, %v1399
  %t1043.not = icmp eq i64 %v14729, 0
  br i1 %t1043.not, label %block11729, label %edge1007

block11729:                                       ; preds = %edge1007, %block11726
  %v14732 = or i64 %v138629, %v138628.ph.ph
  %v14733 = or i64 %v14732, %v138630.ph.ph
  %v14734 = or i64 %v14733, %v138631
  %t1045.not = icmp eq i64 %v14734, 0
  br i1 %t1045.not, label %block11732, label %edge1011

block11732:                                       ; preds = %edge1011, %block11729
  %v14737 = or i64 %v14078, %v1399
  %v14738 = or i64 %v14737, %v14090
  %t1047.not = icmp eq i64 %v14738, 0
  br i1 %t1047.not, label %block39124, label %edge1015

block11711:                                       ; preds = %edge1015, %edge1011, %edge1007, %edge1003
  %v14698 = phi i64 [ %v14735, %edge1011 ], [ %v14725, %edge1003 ], [ %v14730, %edge1007 ], [ %v14739, %edge1015 ]
  %t1049 = insertvalue { i64, i64 } poison, i64 %v14698, 0
  %t1050 = insertvalue { i64, i64 } %t1049, i64 996, 1
  br label %common.ret

block1017:                                        ; preds = %edge1027, %edge1052
  %v15551 = phi i64 [ %v15998, %edge1052 ], [ %v15354, %edge1027 ]
  %t1059.not = icmp ult i64 %v15551, %spec.select3
  br i1 %t1059.not, label %edge1038, label %edge1037

block1221:                                        ; preds = %edge1092, %edge1091
  %t1109 = call range(i64 0, 65) i64 @llvm.cttz.i64(i64 %v17158.le, i1 true)
  %v17245 = lshr i64 %t1109, 3
  %v17249 = add nuw nsw i64 %v17245, %v15354
  br label %edge1103

block12531:                                       ; preds = %edge1132, %edge1120
  %t1153 = call { i64, i64, i64, i64 } @mech_compact_checked_layout_continuation_9562(i64 %v17830, i64 262144, i64 %v14073, i64 %v17813, i64 %v14078, i64 %v0, i64 262144)
  %v138305 = extractvalue { i64, i64, i64, i64 } %t1153, 0
  %v138307 = extractvalue { i64, i64, i64, i64 } %t1153, 2
  %v138308 = extractvalue { i64, i64, i64, i64 } %t1153, 3
  %t1154 = icmp eq i64 %v138305, 2
  br i1 %t1154, label %edge1145, label %edge1148

block12570:                                       ; preds = %edge1152, %edge1151
  %t1169 = call { i64, i64 } @mech_compact_writable_scalar_backing(i64 %v0, i64 %v138307, i64 262144, i64 262144, i64 %v138308, i64 262144, i64 5)
  %v17965 = extractvalue { i64, i64 } %t1169, 0
  %v17966 = extractvalue { i64, i64 } %t1169, 1
  %t1170.not = icmp eq i64 %v17965, 0
  br i1 %t1170.not, label %block12565, label %block12568

block12568:                                       ; preds = %block12570
  %v17967 = add i64 %v17965, %v17942
  %t1171 = inttoptr i64 %v17967 to ptr
  store i16 %t1141, ptr %t1171, align 1
  %t1172 = icmp eq i64 %v138308, %v17966
  %t1174.not67 = icmp eq i64 %v17966, 0
  %t1174.not = or i1 %t1172, %t1174.not67
  br i1 %t1174.not, label %block12574, label %edge1160

block12574:                                       ; preds = %block12568, %edge1160
  %t1178.not = or i1 %t1164.not, %t1172
  br i1 %t1178.not, label %block12932, label %edge1163

block12565:                                       ; preds = %edge1163, %block12570
  %v17936 = phi i64 [ %v17966, %block12570 ], [ %v17977, %edge1163 ]
  %t1180 = insertvalue { i64, i64 } poison, i64 %v17936, 0
  %t1181 = insertvalue { i64, i64 } %t1180, i64 1288, 1
  br label %common.ret

block1288:                                        ; preds = %edge1115, %edge1103, %edge990
  %v138588 = phi i64 [ %v17253, %edge1103 ], [ %v14135, %edge990 ], [ %v17253, %edge1115 ]
  %v138591 = phi i64 [ %v14085, %edge1103 ], [ %v14085, %edge990 ], [ %v138166, %edge1115 ]
  %v138592 = phi i64 [ %v14090, %edge1103 ], [ %v14090, %edge990 ], [ %v138167, %edge1115 ]
  %v138593 = phi i64 [ %v14097, %edge1103 ], [ %v14097, %edge990 ], [ %v17435, %edge1115 ]
  %v138594 = phi i64 [ %v14137, %edge1103 ], [ %v14137, %edge990 ], [ %v17253, %edge1115 ]
  %v18013 = add i64 %v138588, %v14344
  %t1182 = call { i64, i64, i64 } @mech_compact_checked_layout_continuation_8603(i64 %v18013, i64 %v1395, i64 %v1397, i64 %v1398, i64 %v1394)
  %v138410 = extractvalue { i64, i64, i64 } %t1182, 0
  %v138412 = extractvalue { i64, i64, i64 } %t1182, 2
  %t1183 = icmp eq i64 %v138410, 2
  br i1 %t1183, label %edge1170, label %edge1171

block12810:                                       ; preds = %edge1204, %edge1201
  %t1222 = call { i64, i64, i64, i64 } @mech_compact_checked_layout_continuation_21033(i64 %v18630, i64 262144, i64 %v138295, i64 %v138296, i64 %v0, i64 262144)
  %v138317 = extractvalue { i64, i64, i64, i64 } %t1222, 0
  %v138319 = extractvalue { i64, i64, i64, i64 } %t1222, 2
  %v138320 = extractvalue { i64, i64, i64, i64 } %t1222, 3
  %t1223 = icmp eq i64 %v138317, 2
  br i1 %t1223, label %edge1217, label %edge1220

block12849:                                       ; preds = %edge1224, %edge1223
  %t1238 = call { i64, i64 } @mech_compact_writable_scalar_backing(i64 %v0, i64 %v138319, i64 262144, i64 262144, i64 %v138320, i64 262144, i64 5)
  %v18766 = extractvalue { i64, i64 } %t1238, 0
  %v18767 = extractvalue { i64, i64 } %t1238, 1
  %t1239.not = icmp eq i64 %v18766, 0
  br i1 %t1239.not, label %block12844, label %block12847

block12847:                                       ; preds = %block12849
  %v18768 = add i64 %v18766, %v18743
  %t1240 = inttoptr i64 %v18768 to ptr
  store i16 0, ptr %t1240, align 1
  %t1241 = icmp eq i64 %v138320, %v18767
  %t1243.not65 = icmp eq i64 %v18767, 0
  %t1243.not = or i1 %t1241, %t1243.not65
  br i1 %t1243.not, label %block12853, label %edge1232

block12853:                                       ; preds = %block12847, %edge1232
  %t1247.not = or i1 %t1233.not, %t1241
  br i1 %t1247.not, label %block12932, label %edge1235

block12844:                                       ; preds = %edge1235, %block12849
  %v18737 = phi i64 [ %v18767, %block12849 ], [ %v18778, %edge1235 ]
  %t1249 = insertvalue { i64, i64 } poison, i64 %v18737, 0
  %t1250 = insertvalue { i64, i64 } %t1249, i64 1368, 1
  br label %common.ret

block12932:                                       ; preds = %block913, %edge1220, %block12847.thread318, %edge1208, %edge1235, %block12853, %edge1148, %block12568.thread297, %edge1163, %block12574, %edge1136
  %v137864 = phi i64 [ %v17965, %edge1163 ], [ %v138319, %edge1220 ], [ %v17965, %block12574 ], [ %v14073, %edge1136 ], [ %v138307, %edge1148 ], [ %v138307, %block12568.thread297 ], [ %v18766, %block12853 ], [ %v18766, %edge1235 ], [ %v138295, %edge1208 ], [ %v138319, %block12847.thread318 ], [ %v14073, %block913 ]
  %v137865 = phi i64 [ %v17966, %edge1163 ], [ %v138320, %edge1220 ], [ %v17966, %block12574 ], [ %v14078, %edge1136 ], [ %v138308, %edge1148 ], [ %v138308, %block12568.thread297 ], [ %v18767, %block12853 ], [ %v18767, %edge1235 ], [ %v138296, %edge1208 ], [ %v138320, %block12847.thread318 ], [ %v14078, %block913 ]
  %v137866 = phi i64 [ %v138166, %edge1163 ], [ %v138591, %edge1220 ], [ %v138166, %block12574 ], [ %v138166, %edge1136 ], [ %v138166, %edge1148 ], [ %v138166, %block12568.thread297 ], [ %v138591, %block12853 ], [ %v138591, %edge1235 ], [ %v138591, %edge1208 ], [ %v138591, %block12847.thread318 ], [ %v14085, %block913 ]
  %v137867 = phi i64 [ %v138167, %edge1163 ], [ %v138592, %edge1220 ], [ %v138167, %block12574 ], [ %v138167, %edge1136 ], [ %v138167, %edge1148 ], [ %v138167, %block12568.thread297 ], [ %v138592, %block12853 ], [ %v138592, %edge1235 ], [ %v138592, %edge1208 ], [ %v138592, %block12847.thread318 ], [ %v14090, %block913 ]
  %v137868 = phi i64 [ %v17435, %edge1163 ], [ %v138593, %edge1220 ], [ %v17435, %block12574 ], [ %v17435, %edge1136 ], [ %v17435, %edge1148 ], [ %v17435, %block12568.thread297 ], [ %v138593, %block12853 ], [ %v138593, %edge1235 ], [ %v138593, %edge1208 ], [ %v138593, %block12847.thread318 ], [ %v14097, %block913 ]
  br i1 %t23.not, label %edge1596, label %edge1250

block1421:                                        ; preds = %edge1503, %edge1279
  %v19475 = phi i64 [ %v138283, %edge1279 ], [ %v138301, %edge1503 ]
  %v19480 = phi i64 [ %v138284, %edge1279 ], [ %v138302, %edge1503 ]
  %v19505 = phi i64 [ %v13521, %edge1279 ], [ %v23462, %edge1503 ]
  %v19507 = phi i64 [ %v13525, %edge1279 ], [ %v23464, %edge1503 ]
  %v19509 = phi i64 [ %v13315, %edge1279 ], [ %v23528, %edge1503 ]
  %v19511 = phi i64 [ 300, %edge1279 ], [ %v23623, %edge1503 ]
  %v19513 = phi i64 [ 0, %edge1279 ], [ %v23466, %edge1503 ]
  %v19515 = phi i64 [ 0, %edge1279 ], [ %v23468, %edge1503 ]
  %v19517 = phi i64 [ 0, %edge1279 ], [ %v23906, %edge1503 ]
  %t1272 = icmp ult i64 %v19517, %spec.select3
  br i1 %t1272, label %edge1283, label %block14480

block1490:                                        ; preds = %edge1283
  %v20023 = add i64 %v19517, %v19722
  %t1289 = call { i64, i64, i64 } @mech_compact_checked_layout_continuation_8603(i64 %v20023, i64 %v1395, i64 %v1397, i64 %v1398, i64 %v1394)
  %v138420 = extractvalue { i64, i64, i64 } %t1289, 0
  %v138422 = extractvalue { i64, i64, i64 } %t1289, 2
  %t1290 = icmp eq i64 %v138420, 2
  br i1 %t1290, label %edge1313, label %edge1314

block13403:                                       ; preds = %edge1331, %edge1330
  %v20491 = or i64 %v137836, %v137828
  %v20493 = or i64 %v20491, %v1399
  %t1309.not = icmp eq i64 %v20493, 0
  br i1 %t1309.not, label %block13406, label %edge1335

block13406:                                       ; preds = %edge1335, %block13403
  %v20496 = or i64 %v138629, %v138628.ph.ph
  %v20497 = or i64 %v20496, %v138630.ph.ph
  %v20498 = or i64 %v20497, %v138631
  %t1311.not = icmp eq i64 %v20498, 0
  br i1 %t1311.not, label %block13409, label %edge1339

block13409:                                       ; preds = %edge1339, %block13406
  %v20501 = or i64 %v13196, %v1399
  %v20502 = or i64 %v20501, %v19480
  %t1313.not = icmp eq i64 %v20502, 0
  br i1 %t1313.not, label %block39124, label %edge1343

block13388:                                       ; preds = %edge1343, %edge1339, %edge1335, %edge1331
  %v20462 = phi i64 [ %v20499, %edge1339 ], [ %v20489, %edge1331 ], [ %v20494, %edge1335 ], [ %v20503, %edge1343 ]
  %t1315 = insertvalue { i64, i64 } poison, i64 %v20462, 0
  %t1316 = insertvalue { i64, i64 } %t1315, i64 1544, 1
  br label %common.ret

block1561:                                        ; preds = %edge1355, %edge1380
  %v20691 = phi i64 [ %v21138, %edge1380 ], [ %v20551, %edge1355 ]
  %t1325.not = icmp ult i64 %v20691, %spec.select3
  br i1 %t1325.not, label %edge1366, label %edge1365

block1765:                                        ; preds = %edge1420, %edge1419
  %t1375 = call range(i64 0, 65) i64 @llvm.cttz.i64(i64 %v22298.le, i1 true)
  %v22385 = lshr i64 %t1375, 3
  %v22389 = add nuw nsw i64 %v22385, %v20551
  br label %edge1431

block14076:                                       ; preds = %edge1445, %edge1434
  %t1395 = call { i64, i64, i64, i64 } @mech_compact_checked_layout_continuation_9562(i64 %v22911, i64 262144, i64 %v19475, i64 %v22894, i64 %v19480, i64 %v0, i64 262144)
  %v138311 = extractvalue { i64, i64, i64, i64 } %t1395, 0
  %v138313 = extractvalue { i64, i64, i64, i64 } %t1395, 2
  %v138314 = extractvalue { i64, i64, i64, i64 } %t1395, 3
  %t1396 = icmp eq i64 %v138311, 2
  br i1 %t1396, label %edge1458, label %edge1461

block14115:                                       ; preds = %edge1465, %edge1464
  %t1411 = call { i64, i64 } @mech_compact_writable_scalar_backing(i64 %v0, i64 %v138313, i64 262144, i64 262144, i64 %v138314, i64 262144, i64 5)
  %v23034 = extractvalue { i64, i64 } %t1411, 0
  %v23035 = extractvalue { i64, i64 } %t1411, 1
  %t1412.not = icmp eq i64 %v23034, 0
  br i1 %t1412.not, label %block14110, label %block14113

block14113:                                       ; preds = %block14115
  %v23036 = add i64 %v23034, %v23011
  %t1413 = inttoptr i64 %v23036 to ptr
  store i16 %t1383, ptr %t1413, align 1
  %t1414 = icmp eq i64 %v138314, %v23035
  %t1416.not60 = icmp eq i64 %v23035, 0
  %t1416.not = or i1 %t1414, %t1416.not60
  br i1 %t1416.not, label %block14119, label %edge1473

block14119:                                       ; preds = %block14113, %edge1473
  %t1420.not = or i1 %t1406.not, %t1414
  br i1 %t1420.not, label %block1793, label %edge1476

block14110:                                       ; preds = %edge1476, %block14115
  %v23005 = phi i64 [ %v23035, %block14115 ], [ %v23046, %edge1476 ]
  %t1422 = insertvalue { i64, i64 } poison, i64 %v23005, 0
  %t1423 = insertvalue { i64, i64 } %t1422, i64 1801, 1
  br label %common.ret

block1793.sink.split:                             ; preds = %edge1465, %edge1449
  %t1402.sink = phi ptr [ %t1394, %edge1449 ], [ %t1402, %edge1465 ]
  %v23068.ph = phi i64 [ %v19475, %edge1449 ], [ %v138313, %edge1465 ]
  %v23073.ph = phi i64 [ %v19480, %edge1449 ], [ %v138314, %edge1465 ]
  store i16 %t1383, ptr %t1402.sink, align 1
  br label %block1793

block1793:                                        ; preds = %block1793.sink.split, %edge1461, %block14119, %edge1476
  %v23068 = phi i64 [ %v138313, %edge1461 ], [ %v23034, %edge1476 ], [ %v23034, %block14119 ], [ %v23068.ph, %block1793.sink.split ]
  %v23073 = phi i64 [ %v138314, %edge1461 ], [ %v23035, %edge1476 ], [ %v23035, %block14119 ], [ %v23073.ph, %block1793.sink.split ]
  %v23062 = shl nuw nsw i64 %v22393, 16
  %v23066 = or i64 %v23062, %v19723
  br label %block14480

block1799:                                        ; preds = %edge1431.block1799_crit_edge, %edge1317
  %v23105.pre-phi = phi i64 [ %.pre, %edge1431.block1799_crit_edge ], [ %v20023, %edge1317 ]
  %v137630 = phi i64 [ %v22393, %edge1431.block1799_crit_edge ], [ %v19517, %edge1317 ]
  %t1425 = call { i64, i64, i64 } @mech_compact_checked_layout_continuation_8603(i64 %v23105.pre-phi, i64 %v1395, i64 %v1397, i64 %v1398, i64 %v1394)
  %v138440 = extractvalue { i64, i64, i64 } %t1425, 0
  %v138442 = extractvalue { i64, i64, i64 } %t1425, 2
  %t1426 = icmp eq i64 %v138440, 2
  br i1 %t1426, label %edge1485, label %edge1486

block14359:                                       ; preds = %edge1519, %edge1516
  %t1465 = call { i64, i64, i64, i64 } @mech_compact_checked_layout_continuation_21033(i64 %v23722, i64 262144, i64 %v138301, i64 %v138302, i64 %v0, i64 262144)
  %v138323 = extractvalue { i64, i64, i64, i64 } %t1465, 0
  %v138325 = extractvalue { i64, i64, i64, i64 } %t1465, 2
  %v138326 = extractvalue { i64, i64, i64, i64 } %t1465, 3
  %t1466 = icmp eq i64 %v138323, 2
  br i1 %t1466, label %edge1532, label %edge1535

block14398:                                       ; preds = %edge1539, %edge1538
  %t1481 = call { i64, i64 } @mech_compact_writable_scalar_backing(i64 %v0, i64 %v138325, i64 262144, i64 262144, i64 %v138326, i64 262144, i64 5)
  %v23858 = extractvalue { i64, i64 } %t1481, 0
  %v23859 = extractvalue { i64, i64 } %t1481, 1
  %t1482.not = icmp eq i64 %v23858, 0
  br i1 %t1482.not, label %block14393, label %block14396

block14396:                                       ; preds = %block14398
  %v23860 = add i64 %v23858, %v23835
  %t1483 = inttoptr i64 %v23860 to ptr
  store i16 0, ptr %t1483, align 1
  %t1484 = icmp eq i64 %v138326, %v23859
  %t1486.not58 = icmp eq i64 %v23859, 0
  %t1486.not = or i1 %t1484, %t1486.not58
  br i1 %t1486.not, label %block14402, label %edge1547

block14402:                                       ; preds = %block14396, %edge1547
  %t1490.not = or i1 %t1476.not, %t1484
  br i1 %t1490.not, label %block14480, label %edge1550

block14393:                                       ; preds = %edge1550, %block14398
  %v23829 = phi i64 [ %v23859, %block14398 ], [ %v23870, %edge1550 ]
  %t1492 = insertvalue { i64, i64 } poison, i64 %v23829, 0
  %t1493 = insertvalue { i64, i64 } %t1492, i64 1883, 1
  br label %common.ret

block14480:                                       ; preds = %block1421, %edge1535, %block14396.thread362, %edge1523, %edge1550, %block14402, %block1793
  %v137870 = phi i64 [ %v138325, %edge1535 ], [ %v23068, %block1793 ], [ %v23858, %block14402 ], [ %v23858, %edge1550 ], [ %v138301, %edge1523 ], [ %v138325, %block14396.thread362 ], [ %v19475, %block1421 ]
  %v137871 = phi i64 [ %v138326, %edge1535 ], [ %v23073, %block1793 ], [ %v23859, %block14402 ], [ %v23859, %edge1550 ], [ %v138302, %edge1523 ], [ %v138326, %block14396.thread362 ], [ %v19480, %block1421 ]
  %v137873 = phi i64 [ 0, %edge1535 ], [ %v23066, %block1793 ], [ 0, %block14402 ], [ 0, %edge1550 ], [ 0, %edge1523 ], [ 0, %block14396.thread362 ], [ 0, %block1421 ]
  br i1 %t23.not, label %edge1596, label %edge1565

block1945:                                        ; preds = %block535, %edge1596, %edge1600
  %v27197659 = phi i64 [ %v27197, %edge1600 ], [ %v27197, %edge1596 ], [ 0, %block535 ]
  %v24272658 = phi i64 [ %v24272, %edge1600 ], [ %v24272, %edge1596 ], [ %v12848, %block535 ]
  %v24270657 = phi i64 [ %v10553, %edge1600 ], [ %v10553, %edge1596 ], [ %v13212, %block535 ]
  %v24268656 = phi i64 [ %v10530, %edge1600 ], [ %v10530, %edge1596 ], [ %v10614, %block535 ]
  %v24261655 = phi i64 [ %v24261, %edge1600 ], [ %v24261, %edge1596 ], [ %v138627, %block535 ]
  %v24256654 = phi i64 [ %v24256, %edge1600 ], [ %v24256, %edge1596 ], [ %v138650, %block535 ]
  %v24249653 = phi i64 [ %v24249, %edge1600 ], [ %v24249, %edge1596 ], [ %v9871, %block535 ]
  %v24244652 = phi i64 [ %v24244, %edge1600 ], [ %v24244, %edge1596 ], [ %v10729, %block535 ]
  %v24413 = phi i64 [ %v24395, %edge1600 ], [ 0, %edge1596 ], [ 0, %block535 ]
  %v24417 = and i64 %v24413, 65535
  %t1521.not = icmp ult i64 %v8618, %v24555
  %or.cond175 = select i1 %t785, i1 true, i1 %t1521.not
  br i1 %or.cond175, label %edge1667, label %edge1611

block2107:                                        ; preds = %edge1679, %edge1678
  %v27202 = phi i64 [ %v27089, %edge1678 ], [ %v27098, %edge1679 ]
  %v27104 = shl nuw nsw i64 %v24417, 16
  %v27109 = lshr i64 %v24413, 16
  %v27113 = or disjoint i64 %v27104, %v27109
  %spec.select4 = select i1 %t785, i64 %v27197659, i64 %v27113
  %t1645.not = icmp eq i64 %v27202, 0
  %v27328 = shl i64 %v27202, 32
  %v27333 = or i64 %v27328, %spec.select4
  %v27344 = add i64 %v8618, 1
  %t1649865 = icmp eq i64 %v27333, 0
  %t1649 = select i1 %t1645.not, i1 true, i1 %t1649865
  br i1 %t1649, label %edge1708, label %block9976

block15387:                                       ; preds = %edge1726, %edge1728
  %t1665.not = icmp eq i64 %v138630.ph.ph, 0
  br i1 %t1665.not, label %block2176.preheader, label %edge1731

block2176.preheader:                              ; preds = %block15387, %edge1731
  br label %block2176

block2176:                                        ; preds = %block2176.preheader, %edge1750
  %v28481 = phi i64 [ %v29174, %edge1750 ], [ 0, %block2176.preheader ]
  %v28483 = phi i64 [ %v29182, %edge1750 ], [ 0, %block2176.preheader ]
  %exitcond19700.not = icmp eq i64 %v28481, 10
  br i1 %exitcond19700.not, label %edge1767, label %edge1738

block2258:                                        ; preds = %edge1768, %edge1767
  %v29208 = add i64 %v26680, %v28038
  %t1701.not = icmp ult i64 %v29208, %v28038
  br i1 %t1701.not, label %block39122, label %edge1777

block2325:                                        ; preds = %block2325.preheader, %edge1840
  %v138595 = phi i64 [ %v138277, %edge1840 ], [ %v26668, %block2325.preheader ]
  %v138596 = phi i64 [ %v138278, %edge1840 ], [ %v26673, %block2325.preheader ]
  %v138597 = phi i64 [ %v138221, %edge1840 ], [ %v138653.ph.ph, %block2325.preheader ]
  %v138598 = phi i64 [ %v138222, %edge1840 ], [ %v138630.ph.ph, %block2325.preheader ]
  %v138599 = phi i64 [ %v30138, %edge1840 ], [ 0, %block2325.preheader ]
  %v30138 = add nuw nsw i64 %v138599, 1
  %v30146 = shl nuw nsw i64 %v138599, 2
  %v30147 = add i64 %v30146, %v138597
  %t1747 = inttoptr i64 %v30147 to ptr
  %t1748 = load i32, ptr %t1747, align 1
  %v30148 = zext i32 %t1748 to i64
  %v30261 = add i64 %v30146, %v138595
  %t1749 = inttoptr i64 %v30261 to ptr
  %t1750 = load i32, ptr %t1749, align 1
  %v30262 = zext i32 %t1750 to i64
  %v30276 = add nuw nsw i64 %v30262, %v30148
  %t1751 = icmp samesign ult i64 %v30276, 4294967296
  br i1 %t1751, label %edge1832, label %block39122

block2378:                                        ; preds = %block2378.outer, %edge1850
  %v30934 = phi i64 [ %v31159, %edge1850 ], [ %v30934.ph, %block2378.outer ]
  %exitcond19702 = icmp eq i64 %v30934, 259
  br i1 %exitcond19702, label %block9976.outer.outer, label %edge1850

block2491:                                        ; preds = %edge1892, %edge1891
  %t1846 = icmp eq i64 %v31806, 1
  %v3337487 = and i1 %t1846, %v2794777
  br i1 %v3337487, label %edge1900, label %block2606

block2509:                                        ; preds = %block16699, %edge1909
  %v33576 = phi i64 [ %v26833, %edge1909 ], [ %v33878, %block16699 ]
  %v33578 = phi i64 [ %v33539, %edge1909 ], [ %v33978, %block16699 ]
  %t1854.not = icmp eq i64 %v33578, 0
  br i1 %t1854.not, label %edge1914, label %edge1913

block16699:                                       ; preds = %edge1920, %edge1915
  %v137876 = phi i64 [ 0, %edge1915 ], [ %v33872, %edge1920 ]
  %v33878 = sub i64 %v33668, %v137876
  %v33978 = add i64 %v33578, -1
  br label %block2509

block2606:                                        ; preds = %block2491, %edge1974
  %v138600 = phi i64 [ %v34757, %edge1974 ], [ %v138651.ph.ph, %block2491 ]
  %v138601 = phi i64 [ %v34762, %edge1974 ], [ %v138628.ph.ph, %block2491 ]
  %v138602 = phi i64 [ %v34763, %edge1974 ], [ %v26656, %block2491 ]
  %v138603 = phi i64 [ %v34768, %edge1974 ], [ %v26661, %block2491 ]
  %v138604 = phi i64 [ %v34416, %edge1974 ], [ 0, %block2491 ]
  %v34416 = add nuw nsw i64 %v138604, 1
  %v34424 = shl nuw nsw i64 %v138604, 2
  %v34425 = add i64 %v34424, %v138602
  %t1878 = inttoptr i64 %v34425 to ptr
  %t1879 = load i32, ptr %t1878, align 1
  %t1880.not = icmp eq i32 %t1879, 0
  br i1 %t1880.not, label %edge1974, label %edge1956

block2692:                                        ; preds = %edge1974, %edge1998
  %v138605 = phi i64 [ %v138253, %edge1998 ], [ %v26668, %edge1974 ]
  %v138606 = phi i64 [ %v138254, %edge1998 ], [ %v26673, %edge1974 ]
  %v138607 = phi i64 [ %v138197, %edge1998 ], [ %v138653.ph.ph, %edge1974 ]
  %v138608 = phi i64 [ %v138198, %edge1998 ], [ %v138630.ph.ph, %edge1974 ]
  %v138609 = phi i64 [ %v35269, %edge1998 ], [ 0, %edge1974 ]
  %v35269 = add nuw nsw i64 %v138609, 1
  %v35277 = shl nuw nsw i64 %v138609, 2
  %v35278 = add i64 %v35277, %v138607
  %t1926 = inttoptr i64 %v35278 to ptr
  %t1927 = load i32, ptr %t1926, align 1
  %v35279 = zext i32 %t1927 to i64
  %v35391 = add i64 %v35277, %v138605
  %t1928 = inttoptr i64 %v35391 to ptr
  %t1929 = load i32, ptr %t1928, align 1
  %v35392 = zext i32 %t1929 to i64
  %v35406 = add nuw nsw i64 %v35392, %v35279
  %t1930 = icmp samesign ult i64 %v35406, 4294967296
  br i1 %t1930, label %edge1990, label %block39122

block2744:                                        ; preds = %edge1983, %edge1940
  %v35821 = phi i64 [ %v138651.ph.ph, %edge1940 ], [ %v34757, %edge1983 ]
  %v35836 = phi i64 [ %v138628.ph.ph, %edge1940 ], [ %v34762, %edge1983 ]
  %v35845 = phi i64 [ %v26656, %edge1940 ], [ %v34763, %edge1983 ]
  %v35860 = phi i64 [ %v26661, %edge1940 ], [ %v34768, %edge1983 ]
  %v35869 = phi i64 [ %v138653.ph.ph, %edge1940 ], [ %v138197, %edge1983 ]
  %v35874 = phi i64 [ %v138630.ph.ph, %edge1940 ], [ %v138198, %edge1983 ]
  %v35881 = phi i64 [ %v26668, %edge1940 ], [ %v138253, %edge1983 ]
  %v35886 = phi i64 [ %v26673, %edge1940 ], [ %v138254, %edge1983 ]
  %v35893 = phi i64 [ %v28038, %edge1940 ], [ %v35706, %edge1983 ]
  %v35895 = phi i64 [ %v26680, %edge1940 ], [ 0, %edge1983 ]
  %v35915 = phi i64 [ %v31750, %edge1940 ], [ %v27344, %edge1983 ]
  %v35922 = phi i64 [ %v33576, %edge1940 ], [ %v26833, %edge1983 ]
  %v35926 = phi i64 [ %v34091, %edge1940 ], [ 0, %edge1983 ]
  %t1968 = icmp ne i64 %v27344, %v1395
  %v3573388.not = or i1 %t1968, %v3337487
  %not.v3573388.not = xor i1 %v3573388.not, true
  %v35931 = zext i1 %not.v3573388.not to i64
  br label %edge2014

block2789:                                        ; preds = %edge2015, %edge2029
  %t1982.not = icmp eq i64 %v35997, 0
  br i1 %t1982.not, label %edge2041, label %edge2032

block2806:                                        ; preds = %block2806.preheader, %block2872
  %v37061 = phi i64 [ %v37695, %block2872 ], [ %v36902, %block2806.preheader ]
  %v37066 = phi i64 [ %v37818, %block2872 ], [ 0, %block2806.preheader ]
  %v37069 = phi i64 [ %v37690, %block2872 ], [ %v36901, %block2806.preheader ]
  %t2001 = icmp ne i64 %v37061, 0
  %or.cond26 = select i1 %v636946, i1 %t2001, i1 false
  br i1 %or.cond26, label %edge2053, label %block2816

block2816:                                        ; preds = %edge2053, %block2806
  %exitcond19705.not = icmp eq i64 %v37066, %v36030
  br i1 %exitcond19705.not, label %edge2068, label %edge2067

trap2057:                                         ; preds = %edge2078
  call void @llvm.trap()
  unreachable

ok2057:                                           ; preds = %edge2078
  %v37327 = udiv i64 %v37204, %v1397
  %v37328 = mul i64 %v37327, %v1397
  %v37329 = sub nuw i64 %v37204, %v37328
  %v37330 = mul i64 %v37329, %v1398
  %v37331 = add i64 %v37330, %v37327
  br label %block17807

block17807:                                       ; preds = %edge2073, %ok2057
  %v37326 = phi i64 [ %v37331, %ok2057 ], [ %v37204, %edge2073 ]
  %v37333 = add i64 %v37326, %v1394
  %t2058 = inttoptr i64 %v37333 to ptr
  %t2059 = load i8, ptr %t2058, align 1
  %v37334 = zext i8 %t2059 to i64
  %0 = shl nuw nsw i64 %v37334, 2
  br label %edge2083

block17888:                                       ; preds = %edge2095, %edge2094
  %t2078 = call { i64, i64 } @mech_compact_writable_scalar_backing(i64 %v0, i64 %v37069, i64 320, i64 320, i64 %v37061, i64 320, i64 9)
  %v37701 = extractvalue { i64, i64 } %t2078, 0
  %v37702 = extractvalue { i64, i64 } %t2078, 1
  %t2079.not = icmp eq i64 %v37701, 0
  br i1 %t2079.not, label %block17883, label %block17888.block17887_crit_edge

block17888.block17887_crit_edge:                  ; preds = %block17888
  %.pre19814 = add i64 %v37701, %v37427
  %.pre19815 = inttoptr i64 %.pre19814 to ptr
  br label %block17887

block17887:                                       ; preds = %block17888.block17887_crit_edge, %edge2095
  %t2080.pre-phi = phi ptr [ %.pre19815, %block17888.block17887_crit_edge ], [ %t2063, %edge2095 ]
  %v37690 = phi i64 [ %v37701, %block17888.block17887_crit_edge ], [ %v37069, %edge2095 ]
  %v37695 = phi i64 [ %v37702, %block17888.block17887_crit_edge ], [ %v37061, %edge2095 ]
  store i32 %v37664, ptr %t2080.pre-phi, align 1
  %t2081 = icmp eq i64 %v37061, %v37695
  %t2083.not91 = icmp eq i64 %v37695, 0
  %t2083.not = or i1 %t2081, %t2083.not91
  br i1 %t2083.not, label %edge2112, label %edge2103

block17883:                                       ; preds = %block17888
  %t2087 = insertvalue { i64, i64 } poison, i64 %v37702, 0
  %t2088 = insertvalue { i64, i64 } %t2087, i64 2881, 1
  br label %common.ret

block17903:                                       ; preds = %edge2114, %edge2118
  %v37725 = phi i64 [ %v37735, %edge2118 ], [ %v37731, %edge2114 ]
  %t2098 = insertvalue { i64, i64 } poison, i64 %v37725, 0
  %t2099 = insertvalue { i64, i64 } %t2098, i64 2886, 1
  br label %common.ret

block2872:                                        ; preds = %edge2118, %edge2112
  %v37818 = add i64 %v37066, 1
  br label %block2806

block18037:                                       ; preds = %edge2135, %edge2125
  %t2106.not19831 = phi i1 [ false, %edge2135 ], [ true, %edge2125 ]
  %v3808219828 = phi i32 [ %v3808219830, %edge2135 ], [ %v38082, %edge2125 ]
  %t2111 = call { i64, i64 } @mech_compact_writable_scalar_backing(i64 %v0, i64 %v37069, i64 320, i64 320, i64 %v37061, i64 320, i64 9)
  %v38138 = extractvalue { i64, i64 } %t2111, 0
  %v38139 = extractvalue { i64, i64 } %t2111, 1
  %t2112.not = icmp eq i64 %v38138, 0
  br i1 %t2112.not, label %block18032, label %block18037.block18036_crit_edge

block18037.block18036_crit_edge:                  ; preds = %block18037
  %.pre19782 = add i64 %v38138, 1024
  %.pre19783 = inttoptr i64 %.pre19782 to ptr
  br label %block18036

block18036:                                       ; preds = %block18037.block18036_crit_edge, %edge2135
  %t2106.not19832 = phi i1 [ %t2106.not19831, %block18037.block18036_crit_edge ], [ false, %edge2135 ]
  %v3808219829 = phi i32 [ %v3808219828, %block18037.block18036_crit_edge ], [ %v3808219830, %edge2135 ]
  %t2113.pre-phi = phi ptr [ %.pre19783, %block18037.block18036_crit_edge ], [ %t210019827, %edge2135 ]
  %v38127 = phi i64 [ %v38138, %block18037.block18036_crit_edge ], [ %v37069, %edge2135 ]
  %v38132 = phi i64 [ %v38139, %block18037.block18036_crit_edge ], [ %v37061, %edge2135 ]
  store i32 %v3808219829, ptr %t2113.pre-phi, align 1
  %t2114 = icmp eq i64 %v37061, %v38132
  %t2116.not92 = icmp eq i64 %v38132, 0
  %t2116.not = or i1 %t2114, %t2116.not92
  br i1 %t2116.not, label %block18041, label %edge2143

block18041:                                       ; preds = %block18036, %edge2143
  %t2120.not = or i1 %t2106.not19832, %t2114
  br i1 %t2120.not, label %block18054, label %edge2146

block18032:                                       ; preds = %edge2149, %block18037
  %v38109 = phi i64 [ %v38139, %block18037 ], [ %v38150, %edge2149 ]
  %t2125 = insertvalue { i64, i64 } poison, i64 %v38109, 0
  %t2126 = insertvalue { i64, i64 } %t2125, i64 2923, 1
  br label %common.ret

block18054:                                       ; preds = %edge2149, %edge2146, %block18041
  br i1 %t2116.not92, label %edge2167, label %edge2152

block2907:                                        ; preds = %block2907.backedge, %edge2167
  %v43145 = phi i64 [ 1, %edge2167 ], [ %v102016, %block2907.backedge ]
  %v43239 = phi i64 [ 0, %edge2167 ], [ %v101872, %block2907.backedge ]
  %v43241 = phi i64 [ 0, %edge2167 ], [ %v101901, %block2907.backedge ]
  %v43243 = phi i64 [ %v137804, %edge2167 ], [ %v49360, %block2907.backedge ]
  %v43244 = phi i64 [ %v137805, %edge2167 ], [ %v49361, %block2907.backedge ]
  %v43245 = phi i64 [ %v137806, %edge2167 ], [ %v49362, %block2907.backedge ]
  %v43246 = phi i64 [ %v137807, %edge2167 ], [ %v49363, %block2907.backedge ]
  %v43247 = phi i64 [ %v137808, %edge2167 ], [ %v49364, %block2907.backedge ]
  %v43248 = phi i64 [ %v137809, %edge2167 ], [ %v49365, %block2907.backedge ]
  %v43255 = phi i64 [ %v137817, %edge2167 ], [ %v137740, %block2907.backedge ]
  %v43260 = phi i64 [ %v137822, %edge2167 ], [ %v137737, %block2907.backedge ]
  %v43267 = phi i64 [ %v137823, %edge2167 ], [ %v91624, %block2907.backedge ]
  %v43272 = phi i64 [ %v137828, %edge2167 ], [ %v87729, %block2907.backedge ]
  %v43279 = phi i64 [ -1, %edge2167 ], [ %spec.select9471, %block2907.backedge ]
  %v43281 = phi i64 [ 10, %edge2167 ], [ %v102056, %block2907.backedge ]
  %v43283 = phi i64 [ %v38127, %edge2167 ], [ %v53387, %block2907.backedge ]
  %v43288 = phi i64 [ %v38132, %edge2167 ], [ %v53385, %block2907.backedge ]
  %v43295 = phi i64 [ %v38127, %edge2167 ], [ %v83268, %block2907.backedge ]
  %v43296 = phi i64 [ 320, %edge2167 ], [ %v83269, %block2907.backedge ]
  %v43300 = phi i64 [ %v38132, %edge2167 ], [ %v83273, %block2907.backedge ]
  %v43337 = phi i64 [ 0, %edge2167 ], [ %spec.select14, %block2907.backedge ]
  %v43339 = phi i64 [ -1, %edge2167 ], [ %v102060, %block2907.backedge ]
  %v43401 = phi i64 [ %v38127, %edge2167 ], [ %v83279, %block2907.backedge ]
  %v43406 = phi i64 [ %v38132, %edge2167 ], [ %v83284, %block2907.backedge ]
  %v43413 = phi i64 [ %v38127, %edge2167 ], [ %v83285, %block2907.backedge ]
  %v43414 = phi i64 [ 320, %edge2167 ], [ %v83286, %block2907.backedge ]
  %v43418 = phi i64 [ %v38132, %edge2167 ], [ %v83290, %block2907.backedge ]
  %v43425 = phi i64 [ %v38127, %edge2167 ], [ %v83291, %block2907.backedge ]
  %v43430 = phi i64 [ %v38132, %edge2167 ], [ %v83296, %block2907.backedge ]
  %v43437 = phi i64 [ 0, %edge2167 ], [ %v83297, %block2907.backedge ]
  %v43439 = phi i64 [ 0, %edge2167 ], [ %v83298, %block2907.backedge ]
  %v43441 = phi i64 [ 0, %edge2167 ], [ %v83299, %block2907.backedge ]
  %v43443 = phi i64 [ 0, %edge2167 ], [ %v83300, %block2907.backedge ]
  %t2142 = icmp eq i64 %v43145, 1
  %v43449 = zext i1 %t2142 to i64
  %t2143 = icmp eq i64 %v43145, 2
  %v43467 = zext i1 %t2143 to i64
  %t2144 = icmp eq i64 %v43145, 4
  %v43485 = zext i1 %t2144 to i64
  %1 = and i64 %v43145, -2
  %v4350794 = icmp eq i64 %1, 2
  br i1 %v4350794, label %block2966, label %edge2176

block2966:                                        ; preds = %edge2178, %edge2176, %block2907
  %v44640 = phi i64 [ 0, %block2907 ], [ 0, %edge2176 ], [ %v43260, %edge2178 ]
  %v45333 = phi i64 [ ptrtoint (ptr @mech_compact_table_2 to i64), %block2907 ], [ %v43255, %edge2176 ], [ %v43255, %edge2178 ]
  %v44196 = or i64 %v43449, %v43485
  %t2151.not.not = icmp ne i64 %v44196, 0
  br i1 %t2151.not.not, label %block3390, label %edge2186

block18425:                                       ; preds = %edge2193, %edge2190
  %v45192 = phi i64 [ %v43245, %edge2190 ], [ %v137569, %edge2193 ]
  %t2160.not = icmp eq i64 %v43248, 0
  br i1 %t2160.not, label %block18436, label %edge2196

block18436:                                       ; preds = %edge2196, %block18425
  %t2165 = call { i64, i64 } @mech_compact_writable_scalar_backing(i64 %v0, i64 %v43243, i64 0, i64 %v43245, i64 %v43248, i64 %v45192, i64 17)
  %v45228 = extractvalue { i64, i64 } %t2165, 0
  %v45229 = extractvalue { i64, i64 } %t2165, 1
  %t2166.not = icmp eq i64 %v45228, 0
  br i1 %t2166.not, label %block18420, label %edge2200

block18442:                                       ; preds = %edge2203, %edge2206
  %t2175.not = or i1 %t2160.not, %t2169
  br i1 %t2175.not, label %edge2214, label %edge2209

block18420:                                       ; preds = %edge2209, %block18436, %edge2193
  %v44662 = phi i64 [ %v45229, %block18436 ], [ 1, %edge2193 ], [ %v45245, %edge2209 ]
  %t2177 = insertvalue { i64, i64 } poison, i64 %v44662, 0
  %t2178 = insertvalue { i64, i64 } %t2177, i64 3001, 1
  br label %common.ret

block18491:                                       ; preds = %edge2214, %edge2250
  %t2202.not = icmp eq i64 %v44640, 0
  br i1 %t2202.not, label %edge2256, label %edge2253

block2989:                                        ; preds = %block2989.backedge, %edge2256
  %v45358 = phi i64 [ %v45222, %edge2256 ], [ %v48914, %block2989.backedge ]
  %v45407 = phi i64 [ 258, %edge2256 ], [ %v48879, %block2989.backedge ]
  %v45413 = phi i64 [ %v45219, %edge2256 ], [ %v48911, %block2989.backedge ]
  %v45414 = phi i64 [ %v36030, %edge2256 ], [ %v45599, %block2989.backedge ]
  %v45415 = phi i64 [ %v36008, %edge2256 ], [ %v46483, %block2989.backedge ]
  %v45417 = phi i64 [ %v45217, %edge2256 ], [ %v48909, %block2989.backedge ]
  %t2205.not = icmp eq i64 %v45358, 0
  br i1 %t2205.not, label %block3000.thread, label %edge2257

block3000:                                        ; preds = %edge2263, %edge2257
  %t2286.not = icmp eq i64 %v45414, 0
  br i1 %t2286.not, label %edge2444, label %edge2300

block3000.thread:                                 ; preds = %block2989
  %t2286.not668 = icmp eq i64 %v45414, 0
  br i1 %t2286.not668, label %edge2450, label %edge2300

block3108:                                        ; preds = %block3215, %edge2300
  %v46513 = phi i64 [ %v46483, %edge2300 ], [ %v46672, %block3215 ]
  %v46518 = phi i64 [ 0, %edge2300 ], [ %umax, %block3215 ]
  %v46523 = phi i64 [ %v46427, %edge2300 ], [ %v47366, %block3215 ]
  %v46528 = phi i64 [ %v46469, %edge2300 ], [ %v47371, %block3215 ]
  %t2374.not = icmp eq i64 %v46513, %v45603
  br i1 %t2374.not, label %edge2422, label %edge2420

block19236:                                       ; preds = %edge2338, %edge2337
  %v47280 = or i64 %v36003, %v35991
  %v47281 = or i64 %v47280, %v35973
  %v47282 = or i64 %v47281, %v35997
  %t2338.not = icmp eq i64 %v47282, 0
  br i1 %t2338.not, label %block19239, label %edge2342

block19239:                                       ; preds = %edge2342, %block19236
  %v47286 = or i64 %v98262, %v35985
  %t2340.not = icmp eq i64 %v47286, 0
  br i1 %t2340.not, label %block19242, label %edge2346

block19242:                                       ; preds = %edge2346, %block19239
  %t2342.not = icmp eq i64 %v43260, 0
  br i1 %t2342.not, label %block19245, label %edge2350

block19245:                                       ; preds = %edge2350, %block19242
  %v47295 = or i64 %v43272, %v35973
  %v47296 = or i64 %v47295, %v43288
  %v47297 = or i64 %v47296, %v43300
  %t2344.not = icmp eq i64 %v47297, 0
  br i1 %t2344.not, label %block19248, label %edge2354

block19248:                                       ; preds = %edge2354, %block19245
  br i1 %t2116.not92, label %block19251, label %edge2358

block19251:                                       ; preds = %edge2358, %block19248
  %v47307 = or i64 %v43418, %v43406
  %t2348.not = icmp eq i64 %v47307, 0
  br i1 %t2348.not, label %block19254, label %edge2362

block19254:                                       ; preds = %edge2362, %block19251
  %v47310 = or i64 %v43430, %v35973
  %v47311 = or i64 %v47310, %v44640
  %v47312 = or i64 %v47311, %v45358
  %t2350.not = icmp eq i64 %v47312, 0
  br i1 %t2350.not, label %block39124, label %edge2366

block19221:                                       ; preds = %edge2370, %edge2366, %edge2362, %edge2358, %edge2354, %edge2350, %edge2346, %edge2342, %edge2338
  %v47251 = phi i64 [ %v47313, %edge2366 ], [ %v47278, %edge2338 ], [ %v47283, %edge2342 ], [ %v47288, %edge2346 ], [ %v47293, %edge2350 ], [ %v47298, %edge2354 ], [ %v47303, %edge2358 ], [ %v47308, %edge2362 ], [ %v47316, %edge2370 ]
  %t2354 = insertvalue { i64, i64 } poison, i64 %v47251, 0
  %t2355 = insertvalue { i64, i64 } %t2354, i64 3236, 1
  br label %common.ret

block3215:                                        ; preds = %edge2395, %edge2336
  %v47361 = phi i64 [ %v46518, %edge2336 ], [ %v48062, %edge2395 ]
  %v47366 = phi i64 [ %v46523, %edge2336 ], [ %v48064, %edge2395 ]
  %v47371 = phi i64 [ %v46528, %edge2336 ], [ %v48065, %edge2395 ]
  %exitcond19706.not = icmp eq i64 %v47361, %umax
  br i1 %exitcond19706.not, label %block3108, label %edge2415

block19712:                                       ; preds = %edge2429, %edge2426
  %v48884 = phi i64 [ %v45413, %edge2426 ], [ %v137573, %edge2429 ]
  br i1 %t2205.not, label %block19723, label %edge2432

block19723:                                       ; preds = %edge2432, %block19712
  %t2389 = call { i64, i64 } @mech_compact_writable_scalar_backing(i64 %v0, i64 %v45417, i64 %v45407, i64 %v45413, i64 %v45358, i64 %v48884, i64 17)
  %v48920 = extractvalue { i64, i64 } %t2389, 0
  %v48921 = extractvalue { i64, i64 } %t2389, 1
  %t2390.not = icmp eq i64 %v48920, 0
  br i1 %t2390.not, label %block19708, label %edge2436

block19722:                                       ; preds = %edge2432, %edge2436
  %v48909 = phi i64 [ %v48920, %edge2436 ], [ %v45417, %edge2432 ]
  %v48911 = phi i64 [ %t2391, %edge2436 ], [ %v45413, %edge2432 ]
  %v48914 = phi i64 [ %v48921, %edge2436 ], [ %v45358, %edge2432 ]
  %v48923 = shl i64 %v45407, 3
  %v48924 = add i64 %v48909, %v48923
  %t2392 = inttoptr i64 %v48924 to ptr
  store i64 %v48872, ptr %t2392, align 1
  %t2393 = icmp eq i64 %v45358, %v48914
  %t2395.not102 = icmp eq i64 %v48914, 0
  %t2395.not = or i1 %t2393, %t2395.not102
  br i1 %t2395.not, label %edge2448, label %edge2439

block19708:                                       ; preds = %block19723, %edge2429, %edge2422
  %v48873 = phi i64 [ 1, %edge2429 ], [ 1, %edge2422 ], [ %v48921, %block19723 ]
  %t2399 = insertvalue { i64, i64 } poison, i64 %v48873, 0
  %t2400 = insertvalue { i64, i64 } %t2399, i64 3396, 1
  br label %common.ret

block19756:                                       ; preds = %edge2451, %edge2458
  %v48975 = phi i64 [ %v48988, %edge2458 ], [ %v48984, %edge2451 ]
  %t2413 = insertvalue { i64, i64 } poison, i64 %v48975, 0
  %t2414 = insertvalue { i64, i64 } %t2413, i64 3407, 1
  br label %common.ret

block3390:                                        ; preds = %edge2450, %edge2451, %edge2267, %edge2268, %block2966
  %v49360 = phi i64 [ %v43243, %block2966 ], [ %v138903, %edge2267 ], [ %v138903, %edge2268 ], [ %v45417, %edge2451 ], [ %v45417, %edge2450 ]
  %v49361 = phi i64 [ %v43244, %block2966 ], [ %v138904, %edge2267 ], [ %v138904, %edge2268 ], [ %v45407, %edge2451 ], [ %v45407, %edge2450 ]
  %v49362 = phi i64 [ %v43245, %block2966 ], [ %v138907, %edge2267 ], [ %v138907, %edge2268 ], [ %v45413, %edge2451 ], [ %v45413, %edge2450 ]
  %v49363 = phi i64 [ %v43246, %block2966 ], [ %v138908, %edge2267 ], [ %v138908, %edge2268 ], [ 1, %edge2451 ], [ 1, %edge2450 ]
  %v49364 = phi i64 [ %v43247, %block2966 ], [ %v138911, %edge2267 ], [ %v138911, %edge2268 ], [ %v45407, %edge2451 ], [ %v45407, %edge2450 ]
  %v49365 = phi i64 [ %v43248, %block2966 ], [ %v138912, %edge2267 ], [ %v138912, %edge2268 ], [ %v45358, %edge2451 ], [ %v45358, %edge2450 ]
  %v49232 = or i64 %v44196, %v43467
  %t2415.not = icmp eq i64 %v49232, 0
  br i1 %t2415.not, label %edge2468, label %edge2467

block3417:                                        ; preds = %edge2485, %edge2633
  %v50254 = phi i64 [ %v52381722, %edge2633 ], [ %v50106, %edge2485 ]
  %v50277 = phi i64 [ %v52374723, %edge2633 ], [ 0, %edge2485 ]
  %v50283 = phi i64 [ %v52376721, %edge2633 ], [ %v50105, %edge2485 ]
  %t2433.not = icmp eq i64 %v50254, 0
  br i1 %t2433.not, label %block3429, label %edge2491

block3429:                                        ; preds = %block3417
  %t2497.not = icmp eq i64 %v50277, %v36030
  br i1 %t2497.not, label %edge2622, label %edge2504

block3429.thread:                                 ; preds = %edge2491
  %t2497.not683 = icmp eq i64 %v50277, %v36030
  br i1 %t2497.not683, label %edge2616, label %edge2504

block20258:                                       ; preds = %edge2533, %edge2521
  %t2520 = call { i64, i64 } @mech_compact_writable_scalar_backing(i64 %v0, i64 %v50283, i64 320, i64 320, i64 %v50254, i64 320, i64 9)
  %v51263 = extractvalue { i64, i64 } %t2520, 0
  %v51264 = extractvalue { i64, i64 } %t2520, 1
  %t2521.not = icmp eq i64 %v51263, 0
  br i1 %t2521.not, label %edge2538, label %block20258.block20257_crit_edge

block20258.block20257_crit_edge:                  ; preds = %block20258
  %.pre19808 = add i64 %v51263, %v51195
  %.pre19809 = inttoptr i64 %.pre19808 to ptr
  br label %block20257

block20257:                                       ; preds = %block20258.block20257_crit_edge, %edge2533
  %t2522.pre-phi = phi ptr [ %.pre19809, %block20258.block20257_crit_edge ], [ %t2509, %edge2533 ]
  %v51252 = phi i64 [ %v51263, %block20258.block20257_crit_edge ], [ %v50283, %edge2533 ]
  %v51257 = phi i64 [ %v51264, %block20258.block20257_crit_edge ], [ %v50254, %edge2533 ]
  store i32 %v51219, ptr %t2522.pre-phi, align 1
  %t2523 = icmp eq i64 %v50254, %v51257
  %t2525.not106 = icmp eq i64 %v51257, 0
  %t2525.not = or i1 %t2523, %t2525.not106
  br i1 %t2525.not, label %block20262, label %edge2541

block20262:                                       ; preds = %block20257, %edge2541
  br i1 %t2523, label %edge2633, label %edge2621

block20429:                                       ; preds = %edge2560, %edge2559
  %t2552 = call { i64, i64 } @mech_compact_writable_scalar_backing(i64 %v0, i64 %v50283, i64 320, i64 320, i64 %v50254, i64 320, i64 9)
  %v51792 = extractvalue { i64, i64 } %t2552, 0
  %v51793 = extractvalue { i64, i64 } %t2552, 1
  %t2553.not = icmp eq i64 %v51792, 0
  br i1 %t2553.not, label %block20424, label %block20429.block20428_crit_edge

block20429.block20428_crit_edge:                  ; preds = %block20429
  %.pre19812 = add i64 %v51792, %v51725
  %.pre19813 = inttoptr i64 %.pre19812 to ptr
  br label %block20428

block20428:                                       ; preds = %block20429.block20428_crit_edge, %edge2560
  %t2554.pre-phi = phi ptr [ %.pre19813, %block20429.block20428_crit_edge ], [ %35, %edge2560 ]
  %v51781 = phi i64 [ %v51792, %block20429.block20428_crit_edge ], [ %v50283, %edge2560 ]
  %v51786 = phi i64 [ %v51793, %block20429.block20428_crit_edge ], [ %v50254, %edge2560 ]
  store i32 %36, ptr %t2554.pre-phi, align 1
  br label %block20427

block20427:                                       ; preds = %edge2556, %block20428
  %v51775 = phi i64 [ %v51781, %block20428 ], [ %v50283, %edge2556 ]
  %v51780 = phi i64 [ %v51786, %block20428 ], [ %v50254, %edge2556 ]
  %t2555 = icmp eq i64 %v50254, %v51780
  %t2557.not103 = icmp eq i64 %v51780, 0
  %t2557.not = or i1 %t2555, %t2557.not103
  br i1 %t2557.not, label %block20433, label %edge2568

block20433:                                       ; preds = %block20427, %edge2568
  %v51800 = select i1 %t2555, i64 0, i64 %v50254
  %v51823 = sub nsw i64 256, %v50798695702
  %v51827 = lshr i64 %v51823, 29
  %v51837 = and i64 %v51827, 7
  %v51841 = add nsw i64 %v50798695702, -1
  %v51846 = lshr i64 %v51841, %v51837
  %t2565 = icmp ult i64 %v51846, 256
  %v51987 = add i64 %v51846, ptrtoint (ptr @mech_compact_table_18 to i64)
  %v139132 = select i1 %t2565, i64 %v51987, i64 ptrtoint (ptr @mech_compact_llvm_anonymous_data_1 to i64)
  %t2568 = inttoptr i64 %v139132 to ptr
  %t2569 = load i8, ptr %t2568, align 1
  %v51988 = zext i8 %t2569 to i64
  %v52005 = shl nuw nsw i64 %v51837, 1
  %v52009 = add nuw nsw i64 %v52005, %v51988
  %t2571 = icmp samesign ult i64 %v52009, 32
  %v52127 = shl nuw nsw i64 %v52009, 2
  %v52280 = add nuw nsw i64 %v52127, 1152
  %v52281 = add i64 %v52280, %v51775
  %v139133 = select i1 %t2571, i64 %v52281, i64 ptrtoint (ptr @mech_compact_llvm_anonymous_data_1 to i64)
  %t2574 = inttoptr i64 %v139133 to ptr
  %t2575 = load i32, ptr %t2574, align 1
  %2 = add i32 %t2575, 1
  br i1 %t2571, label %edge2590, label %block20579

block20424:                                       ; preds = %block20429, %edge2522.thread
  %v51763 = phi i64 [ 103425, %edge2522.thread ], [ %v51793, %block20429 ]
  %t2561 = insertvalue { i64, i64 } poison, i64 %v51763, 0
  %t2562 = insertvalue { i64, i64 } %t2561, i64 3575, 1
  br label %common.ret

block20585:                                       ; preds = %edge2594, %edge2593
  br i1 %t2557.not103, label %block20588, label %edge2598

block20588:                                       ; preds = %edge2598, %block20585
  %t2589 = call { i64, i64 } @mech_compact_writable_scalar_backing(i64 %v0, i64 %v51775, i64 320, i64 320, i64 %v51780, i64 320, i64 9)
  %v52351 = extractvalue { i64, i64 } %t2589, 0
  %v52352 = extractvalue { i64, i64 } %t2589, 1
  %t2590.not = icmp eq i64 %v52351, 0
  br i1 %t2590.not, label %block20579, label %block20588.block20587_crit_edge

block20588.block20587_crit_edge:                  ; preds = %block20588
  %.pre19810 = add i64 %v52351, %v52280
  %.pre19811 = inttoptr i64 %.pre19810 to ptr
  br label %block20587

block20587:                                       ; preds = %block20588.block20587_crit_edge, %edge2598
  %t2591.pre-phi = phi ptr [ %.pre19811, %block20588.block20587_crit_edge ], [ %t2578, %edge2598 ]
  %v52340 = phi i64 [ %v52351, %block20588.block20587_crit_edge ], [ %v51775, %edge2598 ]
  %v52345 = phi i64 [ %v52352, %block20588.block20587_crit_edge ], [ %v51780, %edge2598 ]
  store i32 %2, ptr %t2591.pre-phi, align 1
  br label %block20582

block20582:                                       ; preds = %edge2590, %block20587
  %v52330 = phi i64 [ %v52340, %block20587 ], [ %v51775, %edge2590 ]
  %v52335 = phi i64 [ %v52345, %block20587 ], [ %v51780, %edge2590 ]
  %v52437 = phi i64 [ 0, %block20587 ], [ %v51800, %edge2590 ]
  %t2592 = icmp eq i64 %v51780, %v52335
  %t2594.not104 = icmp eq i64 %v52335, 0
  %t2594.not = or i1 %t2592, %t2594.not104
  br i1 %t2594.not, label %block20592, label %edge2606

block20592:                                       ; preds = %block20582, %edge2606
  %t2598.not = or i1 %t2557.not103, %t2592
  br i1 %t2598.not, label %edge2621, label %edge2609

block20579:                                       ; preds = %edge2609, %block20588, %edge2594, %block20433
  %v52318 = phi i64 [ %v52352, %block20588 ], [ 103425, %block20433 ], [ %v52339, %edge2594 ], [ %v52363, %edge2609 ]
  %t2600 = insertvalue { i64, i64 } poison, i64 %v52318, 0
  %t2601 = insertvalue { i64, i64 } %t2600, i64 3625, 1
  br label %common.ret

block20629:                                       ; preds = %edge2623, %edge2630
  %v52421 = phi i64 [ %v52433, %edge2630 ], [ %v52429, %edge2623 ]
  %t2614 = insertvalue { i64, i64 } poison, i64 %v52421, 0
  %t2615 = insertvalue { i64, i64 } %t2614, i64 3636, 1
  br label %common.ret

block20785:                                       ; preds = %edge2645, %edge2635
  %t2622.not19847 = phi i1 [ false, %edge2645 ], [ true, %edge2635 ]
  %v5275419844 = phi i32 [ %v5275419846, %edge2645 ], [ %v52754, %edge2635 ]
  %v5258219841 = phi i64 [ %v50254, %edge2645 ], [ 0, %edge2635 ]
  %t2627 = call { i64, i64 } @mech_compact_writable_scalar_backing(i64 %v0, i64 %v50283, i64 320, i64 320, i64 %v5258219841, i64 320, i64 9)
  %v52798 = extractvalue { i64, i64 } %t2627, 0
  %v52799 = extractvalue { i64, i64 } %t2627, 1
  %t2628.not = icmp eq i64 %v52798, 0
  br i1 %t2628.not, label %block20780, label %block20784

block20784:                                       ; preds = %block20785
  %.pre19785 = add i64 %v52798, 1024
  %.pre19786 = inttoptr i64 %.pre19785 to ptr
  store i32 %v5275419844, ptr %.pre19786, align 1
  %t2630 = icmp eq i64 %v5258219841, %v52799
  %t2632.not107 = icmp eq i64 %v52799, 0
  %t2632.not = or i1 %t2630, %t2632.not107
  br i1 %t2632.not, label %block20789, label %edge2653

block20789:                                       ; preds = %block20784, %edge2653
  %t2636.not = or i1 %t2622.not19847, %t2630
  br i1 %t2636.not, label %block3637, label %edge2656

block20780:                                       ; preds = %edge2656, %block20785
  %v52769 = phi i64 [ %v52799, %block20785 ], [ %v52810, %edge2656 ]
  %t2638 = insertvalue { i64, i64 } poison, i64 %v52769, 0
  %t2639 = insertvalue { i64, i64 } %t2638, i64 3672, 1
  br label %common.ret

block3637:                                        ; preds = %block20789.thread, %block20789, %edge2656, %edge2469, %edge2467
  %v53385 = phi i64 [ %v38132, %edge2469 ], [ 0, %edge2467 ], [ %v52799, %edge2656 ], [ %v52799, %block20789 ], [ %v50254, %block20789.thread ]
  %v53387 = phi i64 [ %v38127, %edge2469 ], [ %v38127, %edge2467 ], [ %v52798, %edge2656 ], [ %v52798, %block20789 ], [ %v50283, %block20789.thread ]
  br i1 %t2151.not.not, label %edge2662, label %edge2663

block3684:                                        ; preds = %block3684.preheader, %edge2701
  %v138610 = phi i64 [ %v53715, %edge2701 ], [ 0, %block3684.preheader ]
  %v53720 = shl nuw nsw i64 %v138610, 2
  %v53721 = add i64 %v53720, %v53387
  %t2668 = inttoptr i64 %v53721 to ptr
  %t2669 = load i32, ptr %t2668, align 1
  %v53888 = add i64 %v53720, %v43283
  %t2670 = inttoptr i64 %v53888 to ptr
  %t2671 = load i32, ptr %t2670, align 1
  %t2672 = icmp eq i32 %t2669, %t2671
  br i1 %t2672, label %edge2701, label %edge2702

block21241:                                       ; preds = %edge2703, %edge2702, %edge2676, %edge2677, %edge2664, %edge2662
  %v54081 = or i64 %v43418, %v43406
  %v54082 = or i64 %v54081, %v43300
  %v54083 = or i64 %v54082, %v43430
  %t2679.not = icmp eq i64 %v54083, 0
  br i1 %t2679.not, label %block3743, label %edge2713

block3743:                                        ; preds = %edge2713, %block21241
  %t2683.not = icmp eq i64 %v53385, 0
  br i1 %t2683.not, label %edge2732, label %edge2719

block3784:                                        ; preds = %block5394, %edge2732
  %v64207 = phi i64 [ 14, %edge2732 ], [ %spec.select7, %block5394 ]
  %v137666 = phi i64 [ 0, %edge2732 ], [ %v79840, %block5394 ]
  %v137667 = phi i64 [ %v53387, %edge2732 ], [ %v79868464, %block5394 ]
  %v137668 = phi i64 [ 320, %edge2732 ], [ %v79869465, %block5394 ]
  %v137671 = phi i64 [ %v53385, %edge2732 ], [ %v79679463, %block5394 ]
  %v137672 = phi i64 [ %v53387, %edge2732 ], [ %v72505767, %block5394 ]
  %v137673 = phi i64 [ 320, %edge2732 ], [ %v72506769, %block5394 ]
  %v137674 = phi i64 [ 320, %edge2732 ], [ %v72507770, %block5394 ]
  %v137677 = phi i64 [ %v53385, %edge2732 ], [ %v72510773, %block5394 ]
  %v137678 = phi i64 [ %v53387, %edge2732 ], [ %v79611, %block5394 ]
  %v137679 = phi i64 [ 320, %edge2732 ], [ %v79612, %block5394 ]
  %v137682 = phi i64 [ %v53385, %edge2732 ], [ %v79616, %block5394 ]
  %v137683 = phi i64 [ %v53387, %edge2732 ], [ %v79851, %block5394 ]
  %v137684 = phi i64 [ %v53385, %edge2732 ], [ %v79678, %block5394 ]
  %v137685 = phi i64 [ 0, %edge2732 ], [ %v79862, %block5394 ]
  %v137686 = phi i64 [ 0, %edge2732 ], [ %v79864, %block5394 ]
  %v137687 = phi i64 [ 0, %edge2732 ], [ %v79866, %block5394 ]
  %v137688 = phi i1 [ false, %edge2732 ], [ %t3710, %block5394 ]
  %v137690 = phi i64 [ 288, %edge2732 ], [ %spec.select8, %block5394 ]
  %t2706 = call { i64, i64 } @mech_compact_allocate_backing(i64 %v0, i64 %v137690, i64 4, i64 4, i64 1)
  %v55831 = extractvalue { i64, i64 } %t2706, 0
  %v55832 = extractvalue { i64, i64 } %t2706, 1
  %t2707.not = icmp eq i64 %v55831, 0
  br i1 %t2707.not, label %block21424, label %edge2750

block21424:                                       ; preds = %block3784
  %t2711 = insertvalue { i64, i64 } poison, i64 %v55832, 0
  %t2712 = insertvalue { i64, i64 } %t2711, i64 3832, 1
  br label %common.ret

block21479:                                       ; preds = %edge2770
  %t2729 = insertvalue { i64, i64 } poison, i64 %v56721, 0
  %t2730 = insertvalue { i64, i64 } %t2729, i64 3845, 1
  br label %common.ret

block3810:                                        ; preds = %edge2772, %edge2774
  %brmerge.not = and i1 %t2151.not.not, %v137688
  %.mux = select i1 %v137688, i64 288, i64 0
  br i1 %brmerge.not, label %edge2781, label %block3829.preheader

block3829.preheader:                              ; preds = %block3810
  %t2804 = zext nneg i64 %v137690 to i128
  %t2805 = shl nuw nsw i128 %t2804, 64
  br label %block3829

block3829:                                        ; preds = %block3829.preheader, %edge2826
  %v57319 = phi i64 [ %v137702.ph, %edge2826 ], [ %v56721, %block3829.preheader ]
  %v57342 = phi i64 [ %v58204, %edge2826 ], [ 0, %block3829.preheader ]
  %v57343 = phi i64 [ %v58215.ph, %edge2826 ], [ 0, %block3829.preheader ]
  %v57348 = phi i64 [ %v137701.ph, %edge2826 ], [ %v56720, %block3829.preheader ]
  %t2742.not = icmp eq i64 %v57319, 0
  br i1 %t2742.not, label %block3840, label %edge2791

block3840:                                        ; preds = %edge2791, %block3829
  %exitcond19708.not = icmp eq i64 %v57342, %v137690
  br i1 %exitcond19708.not, label %edge2827, label %edge2812

block3911:                                        ; preds = %edge2899, %edge2838
  %v58406 = phi i64 [ %v57319, %edge2838 ], [ %v60147, %edge2899 ]
  %v58441 = phi i64 [ 4362938489, %edge2838 ], [ %v60140, %edge2899 ]
  %v58442 = phi i64 [ %v57348, %edge2838 ], [ %v60142, %edge2899 ]
  %t2834.not = icmp eq i64 %v58406, 0
  br i1 %t2834.not, label %block3919, label %edge2839

block3919:                                        ; preds = %edge2839, %block3911
  %v58475 = and i64 %v58441, 255
  %t2866 = icmp ne i64 %v58475, 0
  %t2867 = icmp ult i64 %v58475, %v58255
  %v58490109 = and i1 %t2866, %t2867
  br i1 %v58490109, label %block3929, label %block4052

block3929:                                        ; preds = %edge2892, %block3919
  %v58639 = phi i64 [ %v58442, %block3919 ], [ %v138145, %edge2892 ]
  %v58644 = phi i64 [ %v58406, %block3919 ], [ %v138146, %edge2892 ]
  %v58655 = phi i64 [ %v58475, %block3919 ], [ %v58928, %edge2892 ]
  %exitcond19710.not = icmp eq i64 %v58655, %v58255
  br i1 %exitcond19710.not, label %block4052, label %edge2861

block3964:                                        ; preds = %edge2892, %edge2861
  %v58978 = phi i64 [ %v58639, %edge2861 ], [ %v138145, %edge2892 ]
  %v58983 = phi i64 [ %v58644, %edge2861 ], [ %v138146, %edge2892 ]
  %v58992 = phi i64 [ %v58655, %edge2861 ], [ %spec.select5, %edge2892 ]
  %t2878.not = icmp ult i64 %v58992, %v58475
  %v59127 = select i1 %t2878.not, i64 0, i64 %v58475
  %spec.select5 = sub i64 %v58992, %v59127
  br i1 %t2878.not, label %block4010, label %edge2875

block4010:                                        ; preds = %block3964, %edge2878
  %v59435 = phi i64 [ %v59409, %edge2878 ], [ %v58935, %block3964 ]
  %t2888 = icmp samesign ule i64 %v59435, %v58935
  %spec.select6 = call i64 @llvm.umax.i64(i64 %v59435, i64 %v58935)
  br label %block4019

block4019:                                        ; preds = %block4010, %edge2875
  %v59613 = phi i64 [ %spec.select6, %block4010 ], [ %v58935, %edge2875 ]
  %v137703 = phi i1 [ %t2888, %block4010 ], [ true, %edge2875 ]
  %v59569 = add i64 %v58992, 1
  %t2891 = zext i64 %v59569 to i128
  %v138962 = or disjoint i128 %t2805, %t2891
  store i128 %v138962, ptr %ss6, align 16
  %t2895 = zext i64 %v58978 to i128
  %t2896 = zext nneg i64 %v59613 to i128
  %t2897 = shl nuw nsw i128 %t2896, 64
  %v138964 = or disjoint i128 %t2897, %t2895
  store i128 %v138964, ptr %t931, align 16
  %t2900 = zext i64 %v58983 to i128
  %v138966 = or disjoint i128 %t934, %t2900
  store i128 %v138966, ptr %t936, align 16
  store i64 %v137690, ptr %t937, align 16
  %t2906 = call { i64, i64, i64, i64 } @mech_compact_checked_layout_16147(i64 %v138793)
  %v138143 = extractvalue { i64, i64, i64, i64 } %t2906, 0
  %t2907 = icmp ugt i64 %v138143, 1
  br i1 %t2907, label %edge2891, label %edge2892

block4052:                                        ; preds = %block3929, %block3919
  %v60142 = phi i64 [ %v58442, %block3919 ], [ %v58639, %block3929 ]
  %v60147 = phi i64 [ %v58406, %block3919 ], [ %v58644, %block3929 ]
  br i1 %t2866, label %edge2899, label %edge2906

block4098:                                        ; preds = %edge2927, %edge2924, %edge2918
  %3 = and i32 %t2934, 1023
  %narrow126 = call i32 @llvm.umax.i32(i32 %3, i32 1)
  %v61188 = zext nneg i32 %narrow126 to i64
  br label %block4113

block4113:                                        ; preds = %edge2913, %edge2912, %block4098
  %v137704 = phi i64 [ %v61188, %block4098 ], [ 1, %edge2912 ], [ 1, %edge2913 ]
  br i1 %t2708.not, label %edge2950, label %edge2937

block23009:                                       ; preds = %edge2950.thread, %edge2950
  %t2967 = call { i64, i64 } @mech_compact_writable_scalar_backing(i64 %v0, i64 %v55831, i64 %v137690, i64 %v137690, i64 %v55832, i64 %v137690, i64 9)
  %v61044 = extractvalue { i64, i64 } %t2967, 0
  %v61045 = extractvalue { i64, i64 } %t2967, 1
  %t2968.not = icmp eq i64 %v61044, 0
  br i1 %t2968.not, label %block22984, label %block23007

block23007:                                       ; preds = %block23009
  %t2969 = inttoptr i64 %v61044 to ptr
  store i32 65536, ptr %t2969, align 1
  %t2970 = icmp eq i64 %v55832, %v61045
  %t2972.not127 = icmp eq i64 %v61045, 0
  %t2972.not = or i1 %t2970, %t2972.not127
  br i1 %t2972.not, label %block23013, label %edge2962

block23013:                                       ; preds = %block23007, %edge2962
  %t2976.not = or i1 %t2708.not, %t2970
  br i1 %t2976.not, label %block4114, label %edge2965

block22984:                                       ; preds = %edge2965, %block23009
  %v60962 = phi i64 [ %v61045, %block23009 ], [ %v61056, %edge2965 ]
  %t2978 = insertvalue { i64, i64 } poison, i64 %v60962, 0
  %t2979 = insertvalue { i64, i64 } %t2978, i64 4164, 1
  br label %common.ret

block4114:                                        ; preds = %edge2950, %edge2950.thread, %edge2965, %block23013
  %v61027395414 = phi i64 [ %v61044, %block23013 ], [ %v61044, %edge2965 ], [ %v55831, %edge2950.thread ], [ %v55831, %edge2950 ]
  %v61032396413 = phi i64 [ %v61045, %block23013 ], [ %v61045, %edge2965 ], [ %v55832, %edge2950.thread ], [ 0, %edge2950 ]
  %t2972.not127399412 = phi i1 [ %t2972.not127, %block23013 ], [ %t2972.not127, %edge2965 ], [ false, %edge2950.thread ], [ true, %edge2950 ]
  %t2980 = icmp samesign ult i64 %v137704, %v137690
  br i1 %t2980, label %edge2970, label %block23019

block23024:                                       ; preds = %edge2974, %edge2973
  %t2991 = call { i64, i64 } @mech_compact_writable_scalar_backing(i64 %v0, i64 %v61027395414, i64 %v137690, i64 %v137690, i64 %v61032396413, i64 %v137690, i64 9)
  %v61352 = extractvalue { i64, i64 } %t2991, 0
  %v61353 = extractvalue { i64, i64 } %t2991, 1
  %t2992.not = icmp eq i64 %v61352, 0
  br i1 %t2992.not, label %block23019, label %block23024.block23022_crit_edge

block23024.block23022_crit_edge:                  ; preds = %block23024
  %.pre19798 = add i64 %v61352, %v61329
  %.pre19799 = inttoptr i64 %.pre19798 to ptr
  br label %block23022

block23022:                                       ; preds = %block23024.block23022_crit_edge, %edge2974
  %t2993.pre-phi = phi ptr [ %.pre19799, %block23024.block23022_crit_edge ], [ %t2982, %edge2974 ]
  %v61341 = phi i64 [ %v61352, %block23024.block23022_crit_edge ], [ %v61027395414, %edge2974 ]
  %v61346 = phi i64 [ %v61353, %block23024.block23022_crit_edge ], [ %v61032396413, %edge2974 ]
  store i32 65537, ptr %t2993.pre-phi, align 1
  %t2994 = icmp eq i64 %v61032396413, %v61346
  %t2996.not129 = icmp eq i64 %v61346, 0
  %t2996.not = or i1 %t2994, %t2996.not129
  br i1 %t2996.not, label %block23028, label %edge2982

block23028:                                       ; preds = %block23022, %edge2982
  %t3000.not = or i1 %t2972.not127399412, %t2994
  br i1 %t3000.not, label %block4954, label %edge2985

block23019:                                       ; preds = %edge2985, %block23024, %block4114
  %v61323 = phi i64 [ %v61353, %block23024 ], [ 103425, %block4114 ], [ %v61364, %edge2985 ]
  %t3002 = insertvalue { i64, i64 } poison, i64 %v61323, 0
  %t3003 = insertvalue { i64, i64 } %t3002, i64 4166, 1
  br label %common.ret

block4122:                                        ; preds = %edge3107, %edge2909
  %v61405 = phi i64 [ %v60216, %edge2909 ], [ %v138125, %edge3107 ]
  %v61428 = phi i64 [ 0, %edge2909 ], [ %v63984, %edge3107 ]
  %v61429 = phi i64 [ 0, %edge2909 ], [ %spec.select174, %edge3107 ]
  %v61430 = phi i64 [ 0, %edge2909 ], [ %v63885, %edge3107 ]
  %v61432 = phi i64 [ %v60211, %edge2909 ], [ %v138124, %edge3107 ]
  %t3004.not = icmp eq i64 %v61405, 0
  br i1 %t3004.not, label %block4132, label %edge2994

block4132:                                        ; preds = %edge2994, %block4122
  %exitcond19711.not = icmp eq i64 %v61430, %v61388
  br i1 %exitcond19711.not, label %edge3114, label %edge3003

block4252:                                        ; preds = %edge3045
  br i1 %narrow, label %edge3054, label %block4285

block4285:                                        ; preds = %edge3054, %block4252, %edge3068
  %v63742436 = phi i64 [ %v61405, %edge3068 ], [ %v138139, %block4252 ], [ %v138132, %edge3054 ]
  %v63737435 = phi i64 [ %v61432, %edge3068 ], [ %v138138, %block4252 ], [ %v138131, %edge3054 ]
  %v63984 = phi i64 [ %v63176, %edge3068 ], [ %v61724, %block4252 ], [ %v61428, %edge3054 ]
  %v63591 = add nuw nsw i64 %v62063, %v61884
  %v63735.v = select i1 %v62479113, i64 %v62414, i64 %v61884
  %v63735 = add nuw nsw i64 %v63735.v, %v62410
  %v63917 = select i1 %v62444111.not, i64 %v63735, i64 %v63591
  %t3132 = icmp ult i64 %v61430, %v137690
  %v63885 = add i64 %v61430, 1
  %v63890 = shl i64 %v61430, 2
  %v63891 = add i64 %v63737435, %v63890
  %v139140 = select i1 %t3132, i64 %v63891, i64 ptrtoint (ptr @mech_compact_llvm_anonymous_data_1 to i64)
  %t3135 = inttoptr i64 %v139140 to ptr
  %t3136 = load i32, ptr %t3135, align 1
  %4 = and i32 %t3136, 1023
  %v63917.tr = trunc i64 %v63917 to i32
  %v63918.narrow = or i32 %4, %v63917.tr
  %t3137 = zext i64 %v63885 to i128
  %v138990 = or disjoint i128 %t2805, %t3137
  store i128 %v138990, ptr %ss6, align 16
  %t3141 = zext i64 %v63737435 to i128
  %t3142 = zext i32 %v63918.narrow to i128
  %t3143 = shl nuw nsw i128 %t3142, 64
  %v138992 = or disjoint i128 %t3143, %t3141
  store i128 %v138992, ptr %t931, align 16
  %t3146 = zext i64 %v63742436 to i128
  %v138994 = or disjoint i128 %t934, %t3146
  store i128 %v138994, ptr %t936, align 16
  store i64 %v137690, ptr %t937, align 16
  %t3152 = call { i64, i64, i64, i64 } @mech_compact_checked_layout_16147(i64 %v138793)
  %v138122 = extractvalue { i64, i64, i64, i64 } %t3152, 0
  %t3153 = icmp ugt i64 %v138122, 1
  br i1 %t3153, label %edge3106, label %edge3107

block24119:                                       ; preds = %edge3114
  %t3175 = insertvalue { i64, i64 } poison, i64 %v65057, 0
  %t3176 = insertvalue { i64, i64 } %t3175, i64 4434, 1
  br label %common.ret

block24161:                                       ; preds = %edge3142, %edge3146
  %t3187 = call { i64, i64 } @mech_compact_writable_scalar_backing(i64 %v0, i64 %v65056, i64 %v64216, i64 %v64216, i64 %v65057, i64 %v64216, i64 17)
  %v65190 = extractvalue { i64, i64 } %t3187, 0
  %v65191 = extractvalue { i64, i64 } %t3187, 1
  %t3188.not = icmp eq i64 %v65190, 0
  br i1 %t3188.not, label %block24156, label %block24159

block24159:                                       ; preds = %block24161
  %v65192 = add i64 %v65190, 8
  %t3189 = inttoptr i64 %v65192 to ptr
  store i64 2, ptr %t3189, align 1
  %t3190 = icmp eq i64 %v65057, %v65191
  %t3192.not116 = icmp eq i64 %v65191, 0
  %t3192.not = or i1 %t3190, %t3192.not116
  br i1 %t3192.not, label %block24165, label %edge3154

block24165:                                       ; preds = %block24159, %edge3154
  %t3196.not = or i1 %t3172.not, %t3190
  br i1 %t3196.not, label %block4394, label %edge3157

block24156:                                       ; preds = %edge3160, %block24161
  %v65161 = phi i64 [ %v65191, %block24161 ], [ %v65201, %edge3160 ]
  %t3201 = insertvalue { i64, i64 } poison, i64 %v65161, 0
  %t3202 = insertvalue { i64, i64 } %t3201, i64 4443, 1
  br label %common.ret

block4394:                                        ; preds = %edge3142.thread, %edge3142, %block24159.thread445, %edge3160, %edge3157, %block24165
  %v65173442458 = phi i64 [ %v65190, %block24165 ], [ %v65190, %edge3160 ], [ %v65190, %edge3157 ], [ %v65056, %block24159.thread445 ], [ %v65056, %edge3142 ], [ %v65056, %edge3142.thread ]
  %v65178443457 = phi i64 [ %v65191, %block24165 ], [ %v65191, %edge3160 ], [ %v65191, %edge3157 ], [ %v65057, %block24159.thread445 ], [ 0, %edge3142 ], [ %v65057, %edge3142.thread ]
  %t3203 = icmp ult i64 %v64199, %v137690
  %v65359 = shl i64 %v64199, 2
  %v65360 = add i64 %v61432, %v65359
  %v139141 = select i1 %t3203, i64 %v65360, i64 ptrtoint (ptr @mech_compact_llvm_anonymous_data_1 to i64)
  %t3206 = inttoptr i64 %v139141 to ptr
  %t3207 = load i32, ptr %t3206, align 1
  %5 = and i32 %t3207, 1023
  br i1 %t3203, label %edge3169, label %block24249

block24254:                                       ; preds = %edge3173, %edge3172
  %t3219 = call { i64, i64 } @mech_compact_writable_scalar_backing(i64 %v0, i64 %v61432, i64 %v137690, i64 %v137690, i64 %v61405, i64 %v137690, i64 9)
  %v65432 = extractvalue { i64, i64 } %t3219, 0
  %v65433 = extractvalue { i64, i64 } %t3219, 1
  %t3220.not = icmp eq i64 %v65432, 0
  br i1 %t3220.not, label %block24249, label %block24254.block24253_crit_edge

block24254.block24253_crit_edge:                  ; preds = %block24254
  %.pre19806 = add i64 %v65432, %v65359
  %.pre19807 = inttoptr i64 %.pre19806 to ptr
  br label %block24253

block24253:                                       ; preds = %block24254.block24253_crit_edge, %edge3173
  %t3221.pre-phi = phi ptr [ %.pre19807, %block24254.block24253_crit_edge ], [ %t3210, %edge3173 ]
  %v65421 = phi i64 [ %v65432, %block24254.block24253_crit_edge ], [ %v61432, %edge3173 ]
  %v65426 = phi i64 [ %v65433, %block24254.block24253_crit_edge ], [ %v61405, %edge3173 ]
  store i32 %5, ptr %t3221.pre-phi, align 1
  br label %block24252

block24252:                                       ; preds = %edge3169, %block24253
  %v65415 = phi i64 [ %v65421, %block24253 ], [ %v61432, %edge3169 ]
  %v65420 = phi i64 [ %v65426, %block24253 ], [ %v61405, %edge3169 ]
  %t3222 = icmp eq i64 %v61405, %v65420
  %t3224.not118 = icmp eq i64 %v65420, 0
  %t3224.not = or i1 %t3222, %t3224.not118
  br i1 %t3224.not, label %block24258, label %edge3181

block24258:                                       ; preds = %block24252, %edge3181
  %t3228.not = or i1 %t3004.not22203, %t3222
  br i1 %t3228.not, label %block4414.preheader, label %edge3184

block24249:                                       ; preds = %edge3187, %block24254, %block4394
  %v65403 = phi i64 [ %v65433, %block24254 ], [ 103425, %block4394 ], [ %v65444, %edge3187 ]
  %t3233 = insertvalue { i64, i64 } poison, i64 %v65403, 0
  %t3234 = insertvalue { i64, i64 } %t3233, i64 4469, 1
  br label %common.ret

block4414:                                        ; preds = %block4414.backedge, %block4414.preheader
  %v65471 = phi i64 [ %v65415, %block4414.preheader ], [ %v66050, %block4414.backedge ]
  %v65476 = phi i64 [ %v65420, %block4414.preheader ], [ %v66055, %block4414.backedge ]
  %v65483 = phi i64 [ %v65173442458, %block4414.preheader ], [ %v67057, %block4414.backedge ]
  %v65488 = phi i64 [ %v65178443457, %block4414.preheader ], [ %v67062, %block4414.backedge ]
  %v65495 = phi i64 [ %v64199, %block4414.preheader ], [ %v65633, %block4414.backedge ]
  %t3235.not = icmp eq i64 %v65495, 0
  br i1 %t3235.not, label %edge3195, label %edge3194

block24506:                                       ; preds = %edge3218, %edge3217
  %t3264 = call { i64, i64 } @mech_compact_writable_scalar_backing(i64 %v0, i64 %v65471, i64 %v137690, i64 %v137690, i64 %v65476, i64 %v137690, i64 9)
  %v66067 = extractvalue { i64, i64 } %t3264, 0
  %v66068 = extractvalue { i64, i64 } %t3264, 1
  %t3265.not = icmp eq i64 %v66067, 0
  br i1 %t3265.not, label %block24501, label %block24506.block24505_crit_edge

block24506.block24505_crit_edge:                  ; preds = %block24506
  %.pre19804 = add i64 %v66067, %v65785
  %.pre19805 = inttoptr i64 %.pre19804 to ptr
  br label %block24505

block24505:                                       ; preds = %block24506.block24505_crit_edge, %edge3218
  %t3266.pre-phi = phi ptr [ %.pre19805, %block24506.block24505_crit_edge ], [ %t3241, %edge3218 ]
  %v66056 = phi i64 [ %v66067, %block24506.block24505_crit_edge ], [ %v65471, %edge3218 ]
  %v66061 = phi i64 [ %v66068, %block24506.block24505_crit_edge ], [ %v65476, %edge3218 ]
  %v66070 = trunc nuw i64 %v66027 to i32
  store i32 %v66070, ptr %t3266.pre-phi, align 1
  br label %block24504

block24504:                                       ; preds = %edge3194, %block24505
  %v66050 = phi i64 [ %v66056, %block24505 ], [ %v65471, %edge3194 ]
  %v66055 = phi i64 [ %v66061, %block24505 ], [ %v65476, %edge3194 ]
  %t3267 = icmp eq i64 %v65476, %v66055
  %t3269.not121 = icmp eq i64 %v66055, 0
  %t3269.not = or i1 %t3267, %t3269.not121
  br i1 %t3269.not, label %block24510, label %edge3226

block24510:                                       ; preds = %block24504, %edge3226
  %v66075 = select i1 %t3267, i64 0, i64 %v65476
  %t3275.not = icmp samesign ugt i64 %v64207, %v65992
  br i1 %t3275.not, label %edge3261, label %edge3231

block24501:                                       ; preds = %block24506
  %t3273 = insertvalue { i64, i64 } poison, i64 %v66068, 0
  %t3274 = insertvalue { i64, i64 } %t3273, i64 4542, 1
  br label %common.ret

block4489:                                        ; preds = %edge3239, %edge3236
  %v66242 = phi i64 [ %v64207, %edge3236 ], [ %v66249, %edge3239 ]
  %t3281.not = icmp eq i64 %v66242, 0
  br i1 %t3281.not, label %block39122, label %edge3239

block24816:                                       ; preds = %edge3276, %edge3268
  %t3308 = call { i64, i64 } @mech_compact_writable_scalar_backing(i64 %v0, i64 %v65483, i64 %v64216, i64 %v64216, i64 %v65488, i64 %v64216, i64 17)
  %v66824 = extractvalue { i64, i64 } %t3308, 0
  %v66825 = extractvalue { i64, i64 } %t3308, 1
  %t3309.not = icmp eq i64 %v66824, 0
  br i1 %t3309.not, label %edge3281, label %block24816.block24815_crit_edge

block24816.block24815_crit_edge:                  ; preds = %block24816
  %.pre19800 = add i64 %v66824, %v66766
  %.pre19801 = inttoptr i64 %.pre19800 to ptr
  br label %block24815

block24815:                                       ; preds = %block24816.block24815_crit_edge, %edge3276
  %t3310.pre-phi = phi ptr [ %.pre19801, %block24816.block24815_crit_edge ], [ %t3297, %edge3276 ]
  %v66813 = phi i64 [ %v66824, %block24816.block24815_crit_edge ], [ %v65483, %edge3276 ]
  %v66818 = phi i64 [ %v66825, %block24816.block24815_crit_edge ], [ %v65488, %edge3276 ]
  store i64 %v66789, ptr %t3310.pre-phi, align 1
  %t3311 = icmp eq i64 %v65488, %v66818
  %t3313.not122 = icmp eq i64 %v66818, 0
  %t3313.not = or i1 %t3311, %t3313.not122
  br i1 %t3313.not, label %block24820, label %edge3284

block24820:                                       ; preds = %block24815, %edge3284
  %v66831 = select i1 %t3311, i64 0, i64 %v65488
  %t3319 = icmp ult i64 %v66761, %v64216
  br i1 %t3319, label %edge3297, label %block24905

block24911:                                       ; preds = %edge3307, %edge3306
  br i1 %t3313.not122, label %block24914, label %edge3311

block24914:                                       ; preds = %edge3311, %block24911
  %t3337 = call { i64, i64 } @mech_compact_writable_scalar_backing(i64 %v0, i64 %v66813, i64 %v64216, i64 %v64216, i64 %v66818, i64 %v64216, i64 17)
  %v67068 = extractvalue { i64, i64 } %t3337, 0
  %v67069 = extractvalue { i64, i64 } %t3337, 1
  %t3338.not = icmp eq i64 %v67068, 0
  br i1 %t3338.not, label %block24905, label %block24914.block24913_crit_edge

block24914.block24913_crit_edge:                  ; preds = %block24914
  %.pre19802 = add i64 %v67068, %v66997
  %.pre19803 = inttoptr i64 %.pre19802 to ptr
  br label %block24908

block24908:                                       ; preds = %edge3311, %block24914.block24913_crit_edge
  %t3339.pre-phi = phi ptr [ %.pre19803, %block24914.block24913_crit_edge ], [ %t3322, %edge3311 ]
  %v67057 = phi i64 [ %v67068, %block24914.block24913_crit_edge ], [ %v66813, %edge3311 ]
  %v67062 = phi i64 [ %v67069, %block24914.block24913_crit_edge ], [ %v66818, %edge3311 ]
  store i64 %v67020, ptr %t3339.pre-phi, align 1
  %t3340 = icmp eq i64 %v66818, %v67062
  %t3342.not123 = icmp eq i64 %v67062, 0
  %t3342.not = or i1 %t3340, %t3342.not123
  br i1 %t3342.not, label %block24918, label %edge3319

block24918:                                       ; preds = %block24908, %edge3319
  %t3346.not = or i1 %t3313.not122, %t3340
  br i1 %t3346.not, label %edge3337, label %edge3322

block24905:                                       ; preds = %block24820, %edge3325, %block24914, %edge3307
  %v67035 = phi i64 [ %v67069, %block24914 ], [ %v67079, %edge3325 ], [ %v67056, %edge3307 ], [ 103425, %block24820 ]
  %t3351 = insertvalue { i64, i64 } poison, i64 %v67035, 0
  %t3352 = insertvalue { i64, i64 } %t3351, i64 4644, 1
  br label %common.ret

block24935:                                       ; preds = %edge3195, %edge3329
  %t3356.not = icmp eq i64 %v65488, 0
  br i1 %t3356.not, label %edge3338, label %edge3332

block24953:                                       ; preds = %edge3339, %edge3343
  %v67134 = phi i64 [ %v67144, %edge3343 ], [ %v67141, %edge3339 ]
  %t3365 = insertvalue { i64, i64 } poison, i64 %v67134, 0
  %t3366 = insertvalue { i64, i64 } %t3365, i64 4654, 1
  br label %common.ret

block4605:                                        ; preds = %edge3339, %edge3338
  %t3367.not = icmp eq i64 %v65488, 0
  br i1 %t3367.not, label %edge3351, label %edge3348

block4608:                                        ; preds = %edge3408, %edge3351
  %v67371 = phi i64 [ %v55832, %edge3351 ], [ %v67795, %edge3408 ]
  %v67405 = phi i64 [ %v64207, %edge3351 ], [ %v68449, %edge3408 ]
  %v67406 = phi i64 [ 0, %edge3351 ], [ %v67804, %edge3408 ]
  %v67411 = phi i64 [ %v55831, %edge3351 ], [ %v67790, %edge3408 ]
  %t3370.not = icmp eq i64 %v67371, 0
  br i1 %t3370.not, label %block4618, label %edge3352

block4618:                                        ; preds = %edge3352, %block4608
  %t3423.not = icmp eq i64 %v67405, 0
  br i1 %t3423.not, label %edge3368, label %edge3367

block4644:                                        ; preds = %edge3401, %edge3381
  %v67790 = phi i64 [ %v67411, %edge3381 ], [ %v138117, %edge3401 ]
  %v67795 = phi i64 [ %v67371, %edge3381 ], [ %v138118, %edge3401 ]
  %v67804 = phi i64 [ %v67406, %edge3381 ], [ %v68097, %edge3401 ]
  %v67806 = phi i64 [ %v67751, %edge3381 ], [ %v68235, %edge3401 ]
  %t3433.not = icmp eq i64 %v67806, 0
  br i1 %t3433.not, label %edge3386, label %edge3385

block4730:                                        ; preds = %edge3475, %edge3426
  %v69675 = phi i64 [ %v69536, %edge3426 ], [ %v138190, %edge3475 ]
  %v69696 = phi i64 [ 2, %edge3426 ], [ %v70271, %edge3475 ]
  %v69701 = phi i64 [ %v69535, %edge3426 ], [ %v138189, %edge3475 ]
  %t3488.not = icmp eq i64 %v69675, 0
  br i1 %t3488.not, label %block4739, label %edge3431

block4739:                                        ; preds = %edge3431, %block4730
  %exitcond19712 = icmp eq i64 %v69696, %41
  br i1 %exitcond19712, label %edge3444, label %edge3467

block4807:                                        ; preds = %block4807.outer, %edge3497
  %v70439 = phi i64 [ %v70755, %edge3497 ], [ %v70439.ph, %block4807.outer ]
  br i1 %t3574.not, label %block4817, label %edge3481

block4817:                                        ; preds = %edge3485, %edge3481, %block4807
  %exitcond19713.not = icmp eq i64 %v70439, %v137690
  br i1 %exitcond19713.not, label %edge3498, label %edge3497

block4954:                                        ; preds = %edge2970, %edge3498, %edge3542, %edge3491, %block23028, %edge2985, %edge2944
  %v72075 = phi i64 [ %v61341, %block23028 ], [ %v55831, %edge2944 ], [ %v61341, %edge2985 ], [ %v70440.ph, %edge3491 ], [ %v70440.ph, %edge3542 ], [ %v70440.ph, %edge3498 ], [ %v61027395414, %edge2970 ]
  %v72080 = phi i64 [ %v61346, %block23028 ], [ %v55832, %edge2944 ], [ %v61346, %edge2985 ], [ %v70411.ph, %edge3491 ], [ %v70411.ph, %edge3542 ], [ %v70411.ph, %edge3498 ], [ %v61032396413, %edge2970 ]
  %t3710 = icmp eq i64 %v137666, 0
  br i1 %t3710, label %edge3552, label %edge3553

block26585:                                       ; preds = %edge3567, %edge3564, %edge3560
  %v72209 = phi i64 [ 1, %edge3564 ], [ 1, %edge3560 ], [ %v72277, %edge3567 ]
  %t3734 = insertvalue { i64, i64 } poison, i64 %v72209, 0
  %t3735 = insertvalue { i64, i64 } %t3734, i64 5043, 1
  br label %common.ret

block4979:                                        ; preds = %edge3594, %edge3590
  %v72595 = phi i64 [ 288, %edge3590 ], [ %v72734, %edge3594 ]
  %t3744 = icmp samesign ugt i64 %v72595, 257
  br i1 %t3744, label %edge3594, label %block26823

block26823:                                       ; preds = %edge3594, %block4979
  %v72595.lcssa = phi i64 [ %v72595, %edge3594 ], [ 257, %block4979 ]
  br i1 %t3741.not850, label %block5034.preheader, label %edge3605

block5034.preheader:                              ; preds = %block26823, %edge3613
  br label %block5034

block5034:                                        ; preds = %block5034.preheader, %edge3620
  %v73301 = phi i64 [ %v73439, %edge3620 ], [ 320, %block5034.preheader ]
  %t3766 = icmp samesign ugt i64 %v73301, 289
  br i1 %t3766, label %edge3620, label %block27041

block27041:                                       ; preds = %edge3620, %block5034
  %v73301.lcssa = phi i64 [ %v73301, %edge3620 ], [ 289, %block5034 ]
  br i1 %t3741.not850, label %edge3639, label %edge3631

block5117:                                        ; preds = %block5117.backedge, %edge3672
  %v75986 = phi i64 [ %v74758, %edge3672 ], [ %v78947, %block5117.backedge ]
  %v75991 = phi i64 [ %v74759, %edge3672 ], [ %v78952, %block5117.backedge ]
  %v75998 = phi i64 [ %v75802, %edge3672 ], [ %v79096, %block5117.backedge ]
  %v76003 = phi i64 [ %v75803, %edge3672 ], [ %v79101, %block5117.backedge ]
  %v76010 = phi i64 [ 0, %edge3672 ], [ %v79081, %block5117.backedge ]
  %v76012 = phi i64 [ 0, %edge3672 ], [ %v79155, %block5117.backedge ]
  %v76014 = phi i64 [ 0, %edge3672 ], [ %v77381, %block5117.backedge ]
  %v76016 = phi i64 [ 0, %edge3672 ], [ %v77389, %block5117.backedge ]
  %t3812.not = icmp eq i64 %v76012, %v73801
  br i1 %t3812.not, label %edge3677, label %edge3676

block5186:                                        ; preds = %block5186.preheader, %edge3719
  %v76845.in = phi i64 [ %v76845, %edge3719 ], [ %v76012, %block5186.preheader ]
  %v76845 = add nuw i64 %v76845.in, 1
  %t3832 = icmp ne i64 %v76845, %v73801
  %t3833 = icmp ult i64 %v76845, %v72595.lcssa
  %v77001 = select i1 %t3833, i64 0, i64 %v76441
  %v77004 = add i64 %v77001, %v76845
  %t3836 = icmp ult i64 %v77004, %v72506768848
  %v77162 = shl i64 %v77004, 2
  %v77163 = add i64 %v77162, %v72505766849
  %v139152 = select i1 %t3836, i64 %v77163, i64 ptrtoint (ptr @mech_compact_llvm_anonymous_data_1 to i64)
  %t3839 = inttoptr i64 %v139152 to ptr
  %t3840 = load i32, ptr %t3839, align 1
  %6 = lshr i32 %t3840, 16
  %7 = and i32 %6, 255
  %t3842 = icmp eq i32 %48, %7
  %v77208131 = and i1 %t3832, %t3842
  br i1 %v77208131, label %edge3719, label %edge3720

block5249:                                        ; preds = %edge3720, %edge3721, %edge3724, %edge3676
  %v77381 = phi i64 [ %v76014, %edge3676 ], [ %v76845, %edge3724 ], [ %v76845, %edge3721 ], [ %v76845, %edge3720 ]
  %v77389 = phi i64 [ %v76016, %edge3676 ], [ %v76652, %edge3724 ], [ %v76652, %edge3721 ], [ %v76652, %edge3720 ]
  %t3854.not = icmp ult i64 %v77381, %v76012
  br i1 %t3854.not, label %block39122, label %edge3732

block28155:                                       ; preds = %edge3779, %edge3778
  %t3891 = call { i64, i64 } @mech_compact_writable_scalar_backing(i64 %v0, i64 %v75986, i64 19, i64 19, i64 %v75991, i64 19, i64 9)
  %v78964 = extractvalue { i64, i64 } %t3891, 0
  %v78965 = extractvalue { i64, i64 } %t3891, 1
  %t3892.not = icmp eq i64 %v78964, 0
  br i1 %t3892.not, label %block28150, label %block28155.block28154_crit_edge

block28155.block28154_crit_edge:                  ; preds = %block28155
  %.pre19796 = add i64 %v78964, %v78896
  %.pre19797 = inttoptr i64 %.pre19796 to ptr
  br label %block28154

block28154:                                       ; preds = %block28155.block28154_crit_edge, %edge3779
  %t3893.pre-phi = phi ptr [ %.pre19797, %block28155.block28154_crit_edge ], [ %t3882, %edge3779 ]
  %v78953 = phi i64 [ %v78964, %block28155.block28154_crit_edge ], [ %v75986, %edge3779 ]
  %v78958 = phi i64 [ %v78965, %block28155.block28154_crit_edge ], [ %v75991, %edge3779 ]
  %v78967 = trunc nuw i64 %v78927 to i32
  store i32 %v78967, ptr %t3893.pre-phi, align 1
  br label %block28153

block28153:                                       ; preds = %edge3775, %block28154
  %v78947 = phi i64 [ %v78953, %block28154 ], [ %v75986, %edge3775 ]
  %v78952 = phi i64 [ %v78958, %block28154 ], [ %v75991, %edge3775 ]
  %t3894 = icmp eq i64 %v75991, %v78952
  %t3896.not133 = icmp eq i64 %v78952, 0
  %t3896.not = or i1 %t3894, %t3896.not133
  br i1 %t3896.not, label %block28159, label %edge3787

block28159:                                       ; preds = %block28153, %edge3787
  %v78972 = select i1 %t3894, i64 0, i64 %v75991
  %v79063 = shl nuw nsw i64 %v78731, 5
  %v79071 = or disjoint i64 %v79063, %v78578
  %v79081 = add nuw nsw i64 %v76010, 1
  %exitcond19714.not = icmp eq i64 %v76010, 320
  br i1 %exitcond19714.not, label %block28170, label %edge3796

block28150:                                       ; preds = %block28155, %edge3771
  %v78935 = phi i64 [ 103425, %edge3771 ], [ %v78965, %block28155 ]
  %t3900 = insertvalue { i64, i64 } poison, i64 %v78935, 0
  %t3901 = insertvalue { i64, i64 } %t3900, i64 5418, 1
  br label %common.ret

block28176:                                       ; preds = %edge3800, %edge3799
  %t3911.not = icmp eq i64 %v76003, 0
  br i1 %t3911.not, label %block28179, label %edge3804

block28179:                                       ; preds = %edge3804, %block28176
  %t3916 = call { i64, i64 } @mech_compact_writable_scalar_backing(i64 %v0, i64 %v75998, i64 320, i64 320, i64 %v76003, i64 320, i64 9)
  %v79117 = extractvalue { i64, i64 } %t3916, 0
  %v79118 = extractvalue { i64, i64 } %t3916, 1
  %t3917.not = icmp eq i64 %v79117, 0
  br i1 %t3917.not, label %block28170, label %block28179.block28178_crit_edge

block28179.block28178_crit_edge:                  ; preds = %block28179
  %.pre19794 = add i64 %v79117, %v79090
  %.pre19795 = inttoptr i64 %.pre19794 to ptr
  br label %block28178

block28178:                                       ; preds = %block28179.block28178_crit_edge, %edge3804
  %t3918.pre-phi = phi ptr [ %.pre19795, %block28179.block28178_crit_edge ], [ %t3905, %edge3804 ]
  %v79106 = phi i64 [ %v79117, %block28179.block28178_crit_edge ], [ %v75998, %edge3804 ]
  %v79111 = phi i64 [ %v79118, %block28179.block28178_crit_edge ], [ %v76003, %edge3804 ]
  %v79120 = trunc nuw nsw i64 %v79071 to i32
  store i32 %v79120, ptr %t3918.pre-phi, align 1
  br label %block28173

block28173:                                       ; preds = %edge3796, %block28178
  %v79096 = phi i64 [ %v79106, %block28178 ], [ %v75998, %edge3796 ]
  %v79101 = phi i64 [ %v79111, %block28178 ], [ %v76003, %edge3796 ]
  %v79233 = phi i64 [ 0, %block28178 ], [ %v78972, %edge3796 ]
  %t3919 = icmp eq i64 %v76003, %v79101
  %t3921.not134 = icmp eq i64 %v79101, 0
  %t3921.not = or i1 %t3919, %t3921.not134
  br i1 %t3921.not, label %edge3816, label %edge3812

block28170:                                       ; preds = %block28179, %edge3800, %block28159
  %v79082 = phi i64 [ %v79105, %edge3800 ], [ 103425, %block28159 ], [ %v79118, %block28179 ]
  %t3925 = insertvalue { i64, i64 } poison, i64 %v79082, 0
  %t3926 = insertvalue { i64, i64 } %t3925, i64 5427, 1
  br label %common.ret

block28215:                                       ; preds = %edge3677, %edge3823
  %t3934.not = icmp eq i64 %v76003, 0
  br i1 %t3934.not, label %edge3832, label %edge3826

block28236:                                       ; preds = %edge3833, %edge3837
  %v79216 = phi i64 [ %v79227, %edge3837 ], [ %v79224, %edge3833 ]
  %t3943 = insertvalue { i64, i64 } poison, i64 %v79216, 0
  %t3944 = insertvalue { i64, i64 } %t3943, i64 5446, 1
  br label %common.ret

block28337:                                       ; preds = %edge3586, %edge3843
  %t3948.not = icmp eq i64 %v137684, 0
  br i1 %t3948.not, label %block5380, label %edge3846

block5380:                                        ; preds = %edge3846, %block28337, %edge3832, %edge3833
  %v72510773 = phi i64 [ %v72510772846, %edge3832 ], [ %v72510772846, %edge3833 ], [ %v72510784, %block28337 ], [ %v72510784, %edge3846 ]
  %v72507770 = phi i64 [ %v72507771847, %edge3832 ], [ %v72507771847, %edge3833 ], [ %v72507783, %block28337 ], [ %v72507783, %edge3846 ]
  %v72506769 = phi i64 [ %v72506768848, %edge3832 ], [ %v72506768848, %edge3833 ], [ %v72506782, %block28337 ], [ %v72506782, %edge3846 ]
  %v72505767 = phi i64 [ %v72505766849, %edge3832 ], [ %v72505766849, %edge3833 ], [ %v72505781, %block28337 ], [ %v72505781, %edge3846 ]
  %v79611 = phi i64 [ %v75986, %edge3832 ], [ %v75986, %edge3833 ], [ %v137678, %block28337 ], [ %v137678, %edge3846 ]
  %v79612 = phi i64 [ 19, %edge3832 ], [ 19, %edge3833 ], [ %v137679, %block28337 ], [ %v137679, %edge3846 ]
  %v79616 = phi i64 [ %v75991, %edge3832 ], [ %v75991, %edge3833 ], [ %v137682, %block28337 ], [ %v137682, %edge3846 ]
  %v79678 = phi i64 [ %v76003, %edge3832 ], [ %v76003, %edge3833 ], [ 0, %block28337 ], [ %v137684, %edge3846 ]
  %v79851 = phi i64 [ %v75998, %edge3832 ], [ %v75998, %edge3833 ], [ %v137683, %block28337 ], [ %v137683, %edge3846 ]
  %v79862 = phi i64 [ %v76010, %edge3832 ], [ %v76010, %edge3833 ], [ %v137685, %block28337 ], [ %v137685, %edge3846 ]
  %v79864 = phi i64 [ %v72595.lcssa, %edge3832 ], [ %v72595.lcssa, %edge3833 ], [ %v137686, %block28337 ], [ %v137686, %edge3846 ]
  %v79866 = phi i64 [ %v73796, %edge3832 ], [ %v73796, %edge3833 ], [ %v137687, %block28337 ], [ %v137687, %edge3846 ]
  br i1 %t3710, label %edge3850, label %edge3851

block5389:                                        ; preds = %edge3856, %edge3851
  %t3959 = icmp eq i64 %v137666, 1
  br i1 %t3959, label %edge3861, label %edge3862

block28402:                                       ; preds = %edge3863, %edge3862
  br i1 %t3956.not, label %block5405, label %edge3867

block28398:                                       ; preds = %edge3870, %edge3863, %edge3873
  %v79642 = phi i64 [ %v79659, %edge3873 ], [ %v79650, %edge3863 ], [ %v79654, %edge3870 ]
  %t3971 = insertvalue { i64, i64 } poison, i64 %v79642, 0
  %t3972 = insertvalue { i64, i64 } %t3971, i64 5476, 1
  br label %common.ret

block5394:                                        ; preds = %edge3873, %edge3861
  %v79840 = add nuw nsw i64 %v137666, 1
  %spec.select7 = select i1 %t3710, i64 15, i64 7
  %spec.select8 = select i1 %t3710, i64 32, i64 19
  br label %block3784

block5405:                                        ; preds = %edge3870, %edge3867, %block28402
  %t3973.not = icmp eq i64 %v72080, 0
  br i1 %t3973.not, label %block5407.preheader, label %edge3879

block5407.preheader:                              ; preds = %block5405, %edge3879
  br label %block5407

block5407:                                        ; preds = %block5407.preheader, %edge3900
  %v82353 = phi i64 [ %v82539, %edge3900 ], [ 19, %block5407.preheader ]
  %t3976 = icmp samesign ugt i64 %v82353, 4
  br i1 %t3976, label %edge3886, label %block28771

block28771:                                       ; preds = %edge3886, %block5407
  %v82353.lcssa = phi i64 [ %v82353, %edge3886 ], [ 4, %block5407 ]
  br i1 %t3973.not, label %edge3909, label %edge3902

block5527:                                        ; preds = %edge3922, %edge3955
  %t4025.not = icmp eq i64 %v53385, 0
  br i1 %t4025.not, label %block5528, label %edge3958

block5528:                                        ; preds = %block5527, %edge3958
  %t4032 = icmp ult i64 %v83300, 6148914691236517206
  br i1 %t4032, label %edge3963, label %block39122

block5534:                                        ; preds = %edge3967, %edge3970
  %t4039.not = icmp eq i64 %v83290, 0
  br i1 %t4039.not, label %block5537.preheader, label %edge3973

block5537.preheader:                              ; preds = %block5534, %edge3973
  br label %block5537

block5537:                                        ; preds = %block5537.preheader, %edge3998
  %v83923 = phi i64 [ %v85015, %edge3998 ], [ 0, %block5537.preheader ]
  %v83925 = phi i64 [ %v84882, %edge3998 ], [ %v83849, %block5537.preheader ]
  %exitcond19715.not = icmp eq i64 %v83923, 19
  br i1 %exitcond19715.not, label %edge4006, label %edge3998

block5650:                                        ; preds = %block5650.preheader, %edge4033
  %v85890 = phi i64 [ %v86948, %edge4033 ], [ 0, %block5650.preheader ]
  %v85892 = phi i64 [ %v86822, %edge4033 ], [ %v83925, %block5650.preheader ]
  %exitcond19716.not = icmp eq i64 %v85890, 320
  br i1 %exitcond19716.not, label %edge4041, label %edge4033

block5762:                                        ; preds = %edge4041, %edge4042, %edge3909
  %v87196 = phi i64 [ %v83806, %edge3909 ], [ %v85892, %edge4042 ], [ %v85892, %edge4041 ]
  %v86976 = xor i64 %v43449, 1
  %v86980 = and i64 %v86976, %v43239
  %t4103.not = icmp eq i64 %v86980, 0
  br i1 %t4103.not, label %block5790, label %edge4051

block5774:                                        ; preds = %edge4051
  %t4107.not = icmp ult i64 %v87196, %v43279
  br i1 %t4107.not, label %edge4063, label %block5790

block5786:                                        ; preds = %edge4065, %edge4063
  %t4116.not = icmp eq i64 %v44640, 0
  br i1 %t4116.not, label %block5790, label %edge4069

block5790:                                        ; preds = %block5762, %block5774, %edge4069, %block5786
  %spec.select9471 = phi i64 [ %v87196, %edge4069 ], [ %v87196, %block5786 ], [ %v43279, %block5774 ], [ %v43279, %block5762 ]
  %t4108.not470 = phi i1 [ false, %edge4069 ], [ false, %block5786 ], [ true, %block5774 ], [ true, %block5762 ]
  %v87217469 = phi i64 [ 1, %edge4069 ], [ 1, %block5786 ], [ 0, %block5774 ], [ 0, %block5762 ]
  %v87729 = phi i64 [ %v44640, %edge4069 ], [ 0, %block5786 ], [ %v43272, %block5774 ], [ %v43272, %block5762 ]
  %v91624 = phi i64 [ %v45333, %edge4069 ], [ %v45333, %block5786 ], [ %v43267, %block5774 ], [ %v43267, %block5762 ]
  %v87660 = or i64 %v87217469, %v43241
  %t4119 = icmp eq i64 %v87660, 1
  br i1 %t4119, label %edge4075, label %block5990

block5796:                                        ; preds = %edge4075, %edge4111
  %t4144.not = icmp eq i64 %v44640, 0
  br i1 %t4144.not, label %block5798.preheader, label %edge4114

block5798.preheader:                              ; preds = %block5796, %edge4114
  br label %block5798

block5798:                                        ; preds = %block5798.preheader, %block5886
  %v88550 = phi i64 [ %v89919, %block5886 ], [ %v44640, %block5798.preheader ]
  %v88571 = phi i64 [ %v90085, %block5886 ], [ 3, %block5798.preheader ]
  %v88572 = phi i64 [ %v89914, %block5886 ], [ %v45333, %block5798.preheader ]
  %t4147.not = icmp eq i64 %v88550, 0
  br i1 %t4147.not, label %block5807, label %edge4118

block5807:                                        ; preds = %block5798
  %t4196 = icmp samesign ult i64 %v88571, 547
  br i1 %t4196, label %edge4132, label %edge4193

block5807.thread:                                 ; preds = %edge4118
  %t4196809 = icmp samesign ult i64 %v88571, 547
  br i1 %t4196809, label %edge4132, label %edge4188

block30571:                                       ; preds = %edge4175, %edge4174
  %t4237 = call { i64, i64 } @mech_compact_writable_scalar_backing(i64 %v0, i64 %v88572, i64 547, i64 547, i64 %v88550, i64 547, i64 9)
  %v89931 = extractvalue { i64, i64 } %t4237, 0
  %v89932 = extractvalue { i64, i64 } %t4237, 1
  %t4238.not = icmp eq i64 %v89931, 0
  br i1 %t4238.not, label %block30566, label %block30571.block30570_crit_edge

block30571.block30570_crit_edge:                  ; preds = %block30571
  %.pre19789 = add i64 %v89931, %v89908
  %.pre19790 = inttoptr i64 %.pre19789 to ptr
  br label %block30570

block30570:                                       ; preds = %block30571.block30570_crit_edge, %edge4175
  %t4239.pre-phi = phi ptr [ %.pre19790, %block30571.block30570_crit_edge ], [ %t4228, %edge4175 ]
  %v89920 = phi i64 [ %v89931, %block30571.block30570_crit_edge ], [ %v88572, %edge4175 ]
  %v89925 = phi i64 [ %v89932, %block30571.block30570_crit_edge ], [ %v88550, %edge4175 ]
  %v89934 = trunc nuw nsw i64 %v89880 to i32
  store i32 %v89934, ptr %t4239.pre-phi, align 1
  br label %block30569

block30569:                                       ; preds = %edge4132, %block30570
  %v89914 = phi i64 [ %v89920, %block30570 ], [ %v88572, %edge4132 ]
  %v89919 = phi i64 [ %v89925, %block30570 ], [ %v88550, %edge4132 ]
  %t4240 = icmp eq i64 %v88550, %v89919
  %t4242.not135 = icmp eq i64 %v89919, 0
  %t4242.not = or i1 %t4240, %t4242.not135
  br i1 %t4242.not, label %edge4192, label %edge4183

block30566:                                       ; preds = %block30571
  %t4246 = insertvalue { i64, i64 } poison, i64 %v89932, 0
  %t4247 = insertvalue { i64, i64 } %t4246, i64 5976, 1
  br label %common.ret

block30586:                                       ; preds = %edge4194, %edge4198
  %v89955 = phi i64 [ %v89966, %edge4198 ], [ %v89962, %edge4194 ]
  %t4257 = insertvalue { i64, i64 } poison, i64 %v89955, 0
  %t4258 = insertvalue { i64, i64 } %t4257, i64 5981, 1
  br label %common.ret

block5886:                                        ; preds = %edge4198, %edge4192
  %v90085 = add nuw nsw i64 %v88571, 1
  br label %block5798

block5907:                                        ; preds = %edge4206, %edge4211
  %v90232 = phi i64 [ %v90220, %edge4211 ], [ %v43281, %edge4206 ]
  %t4263.not = icmp eq i64 %v90232, 0
  %v90239 = select i1 %t4263.not, i64 0, i64 %v87217469
  %t4265.not136 = icmp eq i64 %v90239, 0
  %t4265.not = select i1 %t4264, i1 true, i1 %t4265.not136
  br i1 %t4265.not, label %edge4222, label %edge4221

block5917:                                        ; preds = %block5917.preheader, %edge4234
  %v90537 = phi i64 [ %v90808, %edge4234 ], [ 0, %block5917.preheader ]
  %exitcond19717.not = icmp eq i64 %v90537, 547
  br i1 %exitcond19717.not, label %edge4235, label %edge4234

block5990:                                        ; preds = %block5790, %edge4222, %edge4223, %edge4235, %edge4236, %edge4250, %edge4251
  %v91164 = phi i64 [ 0, %edge4235 ], [ 1, %edge4222 ], [ 1, %edge4250 ], [ 1, %edge4251 ], [ 0, %edge4236 ], [ 1, %edge4223 ], [ 1, %block5790 ]
  %v91524 = phi i64 [ %v88550, %edge4235 ], [ %v88550, %edge4222 ], [ %v88550, %edge4250 ], [ %v88550, %edge4251 ], [ %v88550, %edge4236 ], [ %v88550, %edge4223 ], [ %v44640, %block5790 ]
  %v91645 = phi i64 [ %v88572, %edge4235 ], [ %v88572, %edge4222 ], [ %v88572, %edge4250 ], [ %v88572, %edge4251 ], [ %v88572, %edge4236 ], [ %v88572, %edge4223 ], [ %v45333, %block5790 ]
  %v102056 = phi i64 [ %v90232, %edge4235 ], [ %v90232, %edge4222 ], [ %v90232, %edge4250 ], [ %v90232, %edge4251 ], [ %v90232, %edge4236 ], [ %v90232, %edge4223 ], [ %v43281, %block5790 ]
  %v137723 = phi i64 [ 1, %edge4235 ], [ %v90239, %edge4222 ], [ 1, %edge4250 ], [ 1, %edge4251 ], [ 1, %edge4236 ], [ %v90239, %edge4223 ], [ 0, %block5790 ]
  %v91169 = and i64 %v137723, %v91164
  %v91181 = xor i64 %v91169, -1
  %v91185 = and i64 %v86980, %v91181
  %t4295 = icmp ult i64 %v43337, %v43339
  %v91190 = zext i1 %t4295 to i64
  %spec.select11 = call i64 @llvm.umin.i64(i64 %v43337, i64 %v43339)
  %t4298 = icmp ult i64 %spec.select11, %spec.select9471
  %v91325 = select i1 %t4298, i64 %v91185, i64 0
  %v91334 = xor i64 %v91190, 1
  %v91338 = and i64 %v91325, %v91334
  %t4300.not = icmp eq i64 %v91325, %v91185
  br i1 %t4300.not, label %block6026.thread, label %edge4284

block6026.thread:                                 ; preds = %block5990
  %v91551478 = and i64 %v91185, %v91190
  br label %edge4294

block6026:                                        ; preds = %edge4284
  %t4304.not = icmp ugt i64 %v87196, %spec.select9471
  %v91551 = and i64 %v91325, %v91190
  br i1 %t4304.not, label %edge4293, label %edge4294

block6035.sink.split:                             ; preds = %edge4294, %edge4293
  %v91524.sink = phi i64 [ %v87729, %edge4293 ], [ %v91524, %edge4294 ]
  %v91551482.ph = phi i64 [ %v91551, %edge4293 ], [ %v91551483, %edge4294 ]
  %v91555480.ph = phi i64 [ 1, %edge4293 ], [ 0, %edge4294 ]
  %v100716.ph = phi i64 [ %v91624, %edge4293 ], [ %v91645, %edge4294 ]
  %t4311 = inttoptr i64 %v91524.sink to ptr
  %v91655 = load i64, ptr %t4311, align 1
  %v91656 = add i64 %v91655, 1
  store i64 %v91656, ptr %t4311, align 1
  br label %block6035

block6035:                                        ; preds = %block6035.sink.split, %edge4294, %edge4293
  %v91551482 = phi i64 [ %v91551483, %edge4294 ], [ %v91551, %edge4293 ], [ %v91551482.ph, %block6035.sink.split ]
  %v91555480 = phi i64 [ 0, %edge4294 ], [ 1, %edge4293 ], [ %v91555480.ph, %block6035.sink.split ]
  %v91778 = phi i64 [ 0, %edge4294 ], [ 0, %edge4293 ], [ %v91524.sink, %block6035.sink.split ]
  %v100716 = phi i64 [ %v91645, %edge4294 ], [ %v91624, %edge4293 ], [ %v100716.ph, %block6035.sink.split ]
  %v91664138 = and i1 %v3614990.not, %t2142
  %v91744139 = and i1 %t4313, %v91664138
  %v91744 = zext i1 %v91744139 to i64
  %8 = xor i64 %v91744, 1
  %v91760 = select i1 %v91664138, i64 %8, i64 0
  %v91764 = or i64 %v91760, %v43467
  %t4314.not = icmp eq i64 %v91764, 0
  br i1 %t4314.not, label %edge4313, label %edge4312

block31232:                                       ; preds = %edge4318, %edge4314
  %v91765 = phi i64 [ %v91772, %edge4314 ], [ %v91776, %edge4318 ]
  %t4320 = insertvalue { i64, i64 } poison, i64 %v91765, 0
  %t4321 = insertvalue { i64, i64 } %t4320, i64 6146, 1
  br label %common.ret

block6048:                                        ; preds = %edge4318, %edge4312
  %t4342.not = icmp eq i64 %v53385, 0
  br i1 %t4342.not, label %block6078.preheader, label %edge4356

block6078.preheader:                              ; preds = %block6048, %edge4356
  br label %block6078

block6078:                                        ; preds = %block6078.preheader, %edge4377
  %v138671 = phi i64 [ %v92213, %edge4377 ], [ 0, %block6078.preheader ]
  %v138672 = phi i64 [ %v92511, %edge4377 ], [ 0, %block6078.preheader ]
  %v92213 = add nuw nsw i64 %v138671, 1
  %v92218 = shl nuw nsw i64 %v138671, 2
  %v92219 = add i64 %v92218, %v53387
  %t4349 = inttoptr i64 %v92219 to ptr
  %t4350 = load i32, ptr %t4349, align 1
  %v92220 = zext i32 %t4350 to i64
  %t4351 = icmp samesign ult i64 %v91857, %v92220
  br i1 %t4351, label %edge4370, label %edge4377

block6112:                                        ; preds = %edge4381, %edge4378, %edge4365
  %spec.select12 = call i64 @llvm.umax.i64(i64 %v92511, i64 1)
  %t4377 = icmp ugt i64 %v92511, 79
  br i1 %t4377, label %block6219, label %edge4405

block6219:                                        ; preds = %block6112, %edge4405
  %v95247 = phi i64 [ %v93831, %edge4405 ], [ 3, %block6112 ]
  br i1 %t4382.not, label %block6221.preheader, label %edge4410

block6221.preheader:                              ; preds = %block6219, %edge4410
  br label %block6221

block6221:                                        ; preds = %block6221.preheader, %edge4429
  %v95445 = phi i64 [ %v95761, %edge4429 ], [ %v95247, %block6221.preheader ]
  %v95447 = phi i64 [ %v95796, %edge4429 ], [ 0, %block6221.preheader ]
  %v95449 = phi i64 [ %v95970, %edge4429 ], [ %v36030, %block6221.preheader ]
  %exitcond19719.not = icmp eq i64 %v95445, 259
  br i1 %exitcond19719.not, label %edge4418, label %edge4417

block6295:                                        ; preds = %edge4435, %edge4432, %edge4418
  %spec.select13 = call i64 @llvm.smax.i64(i64 %v95449, i64 0)
  %t4412 = icmp sgt i64 %v95447, %spec.select13
  br i1 %t4412, label %.thread, label %edge4447

block6323:                                        ; preds = %edge4447
  %v96565 = shl nsw i64 %v95447, 2
  %t4419 = icmp sgt i64 %v96565, %spec.select13
  %cond.fr = freeze i1 %t4419
  %v96698 = zext i1 %cond.fr to i64
  %spec.select870 = select i1 %cond.fr, i64 ptrtoint (ptr @mech_compact_table_25 to i64), i64 ptrtoint (ptr @mech_compact_table_24 to i64)
  br label %.thread

.thread:                                          ; preds = %block6323, %block6295
  %v96702488494 = phi i64 [ %v96698, %block6323 ], [ 2, %block6295 ]
  %9 = phi i64 [ %spec.select870, %block6323 ], [ ptrtoint (ptr @mech_compact_table_26 to i64), %block6295 ]
  %t4428 = icmp ult i64 %v92511, 257
  %v97129 = add i64 %9, %spec.select12
  %v139161 = select i1 %t4428, i64 %v97129, i64 ptrtoint (ptr @mech_compact_llvm_anonymous_data_1 to i64)
  %t4431 = inttoptr i64 %v139161 to ptr
  %t4432 = load i8, ptr %t4431, align 1
  %v97130 = zext i8 %t4432 to i64
  %v97297 = add i64 %v96702488494, ptrtoint (ptr @mech_compact_table_4 to i64)
  %t4436 = inttoptr i64 %v97297 to ptr
  %t4437 = load i8, ptr %t4436, align 1
  %v97298 = zext i8 %t4437 to i64
  br i1 %t1973, label %edge4478, label %edge4566

block32770:                                       ; preds = %edge4478, %edge4480
  br i1 %t4444.not, label %block6392.preheader, label %edge4483

block6392.preheader:                              ; preds = %block32770, %edge4483
  br label %block6392

block6392:                                        ; preds = %block6392.preheader, %edge4502
  %v97506 = phi i64 [ %v98378, %edge4502 ], [ 0, %block6392.preheader ]
  %v97508 = phi i64 [ %v98386, %edge4502 ], [ 0, %block6392.preheader ]
  %exitcond19720.not = icmp eq i64 %v97506, 10
  br i1 %exitcond19720.not, label %edge4519, label %edge4490

block6474:                                        ; preds = %edge4520, %edge4519
  br i1 %brmerge, label %block39122.loopexit19908.split.loop.exit29280, label %edge4533

block6524:                                        ; preds = %block6524.backedge, %edge4566
  %v99218 = phi i64 [ %v43260, %edge4566 ], [ %v100487, %block6524.backedge ]
  %v99241 = phi i64 [ 3, %edge4566 ], [ %v100238, %block6524.backedge ]
  %v99242 = phi i64 [ %v43255, %edge4566 ], [ %v100482, %block6524.backedge ]
  %v100513 = phi i64 [ %v91524, %edge4566 ], [ %v100679, %block6524.backedge ]
  %t4506.not = icmp eq i64 %v99218, 0
  br i1 %t4506.not, label %block6535, label %edge4567

block6535:                                        ; preds = %edge4567, %block6524
  %t4550 = icmp samesign ult i64 %v99241, 547
  br i1 %t4550, label %edge4577, label %edge4584

block33704:                                       ; preds = %edge4628, %edge4627
  br i1 %t4506.not, label %block33707, label %edge4632

block33707:                                       ; preds = %edge4632, %block33704
  %t4607 = call { i64, i64 } @mech_compact_writable_scalar_backing(i64 %v0, i64 %v99242, i64 547, i64 547, i64 %v99218, i64 547, i64 9)
  %v100503 = extractvalue { i64, i64 } %t4607, 0
  %v100504 = extractvalue { i64, i64 } %t4607, 1
  %t4608.not = icmp eq i64 %v100503, 0
  br i1 %t4608.not, label %block33698, label %block33707.block33706_crit_edge

block33707.block33706_crit_edge:                  ; preds = %block33707
  %.pre19792 = add i64 %v100503, %v100243
  %.pre19793 = inttoptr i64 %.pre19792 to ptr
  br label %block33706

block33706:                                       ; preds = %block33707.block33706_crit_edge, %edge4632
  %t4609.pre-phi = phi ptr [ %.pre19793, %block33707.block33706_crit_edge ], [ %t4596, %edge4632 ]
  %v100492 = phi i64 [ %v100503, %block33707.block33706_crit_edge ], [ %v99242, %edge4632 ]
  %v100497 = phi i64 [ %v100504, %block33707.block33706_crit_edge ], [ %v99218, %edge4632 ]
  %v100506 = trunc nuw i64 %v100330144 to i32
  store i32 %v100506, ptr %t4609.pre-phi, align 1
  br label %block33701

block33701:                                       ; preds = %edge4624, %block33706
  %v100482 = phi i64 [ %v100492, %block33706 ], [ %v99242, %edge4624 ]
  %v100487 = phi i64 [ %v100497, %block33706 ], [ %v99218, %edge4624 ]
  %v100679 = phi i64 [ 0, %block33706 ], [ %v100513, %edge4624 ]
  %t4610 = icmp eq i64 %v99218, %v100487
  %t4612.not145 = icmp eq i64 %v100487, 0
  %t4612.not = or i1 %t4610, %t4612.not145
  br i1 %t4612.not, label %edge4649, label %edge4640

block33698:                                       ; preds = %block33707, %edge4628
  %v100470 = phi i64 [ %v100491, %edge4628 ], [ %v100504, %block33707 ]
  %t4616 = insertvalue { i64, i64 } poison, i64 %v100470, 0
  %t4617 = insertvalue { i64, i64 } %t4616, i64 6719, 1
  br label %common.ret

block33722:                                       ; preds = %edge4651, %edge4655
  %v100532 = phi i64 [ %v100542, %edge4655 ], [ %v100538, %edge4651 ]
  %t4627 = insertvalue { i64, i64 } poison, i64 %v100532, 0
  %t4628 = insertvalue { i64, i64 } %t4627, i64 6724, 1
  br label %common.ret

block6652:                                        ; preds = %edge4666, %edge4671, %edge4313, %edge4314, %edge4663
  %v102060 = phi i64 [ %v43339, %edge4663 ], [ %v43339, %edge4313 ], [ %v43339, %edge4314 ], [ %67, %edge4671 ], [ 7, %edge4666 ]
  %v137736 = phi i64 [ %v100513, %edge4663 ], [ %v91524, %edge4313 ], [ %v91524, %edge4314 ], [ %v100513, %edge4671 ], [ %v100513, %edge4666 ]
  %v137737 = phi i64 [ %v99218, %edge4663 ], [ %v91778, %edge4313 ], [ %v91778, %edge4314 ], [ %v99218, %edge4671 ], [ %v99218, %edge4666 ]
  %v137740 = phi i64 [ %v99242, %edge4663 ], [ %v100716, %edge4313 ], [ %v100716, %edge4314 ], [ %v99242, %edge4671 ], [ %v99242, %edge4666 ]
  br i1 %v91744139, label %block6676, label %edge4683

block6676:                                        ; preds = %edge4686, %edge4683, %block6652
  %v102016 = phi i64 [ %spec.select31, %edge4686 ], [ 2, %block6652 ], [ 3, %edge4683 ]
  %spec.select14 = select i1 %t2142, i64 %v87196, i64 %v43337
  %v101872 = or i64 %v91169, %v91764
  %v101876 = or i64 %v91764, %v91744
  %v101880 = or i64 %v101876, %v91169
  %v101884 = or i64 %v101880, %v91338
  %v101893 = or i64 %v101884, %v91551482
  %v101897 = or i64 %v101893, %v91555480
  %v101901 = or i64 %v91555480, %v91551482
  %t4647 = icmp eq i64 %v101897, 1
  br i1 %t4647, label %edge4703, label %edge4704

block34111:                                       ; preds = %edge4705, %edge4704
  br i1 %t1979.not, label %block34114, label %edge4709

block34114:                                       ; preds = %edge4709, %block34111
  br i1 %t2116.not92, label %block34117, label %edge4713

block34117:                                       ; preds = %edge4713, %block34114
  %v101924 = or i64 %v137737, %v83284
  %t4655.not = icmp eq i64 %v101924, 0
  br i1 %t4655.not, label %edge4727, label %edge4717

block34107:                                       ; preds = %edge4717, %edge4713, %edge4709, %edge4705, %edge4724
  %v101902 = phi i64 [ %v101929, %edge4724 ], [ %v101920, %edge4713 ], [ %v101915, %edge4709 ], [ %v101910, %edge4705 ], [ %v101925, %edge4717 ]
  %t4662 = insertvalue { i64, i64 } poison, i64 %v101902, 0
  %t4663 = insertvalue { i64, i64 } %t4662, i64 6802, 1
  br label %common.ret

block6737:                                        ; preds = %edge4727, %edge4754
  %v104246 = add i64 %v87196, 3
  %t4681.not = icmp ugt i64 %v87196, -4
  br i1 %t4681.not, label %block39122, label %edge4757

block6876:                                        ; preds = %edge4819, %edge4817
  br i1 %t23.not, label %block6878.preheader, label %edge4823

block6878.preheader:                              ; preds = %block6876, %edge4823
  br label %block6878

block6878:                                        ; preds = %block6878.preheader, %edge4914
  %v106640 = phi i64 [ %v138380, %edge4914 ], [ %v137791, %block6878.preheader ]
  %v106641 = phi i64 [ %v138379, %edge4914 ], [ %v137792, %block6878.preheader ]
  %v106642 = phi i64 [ %v138381, %edge4914 ], [ %v137793, %block6878.preheader ]
  %v106643 = phi i64 [ %v138377, %edge4914 ], [ %v137794, %block6878.preheader ]
  %v106645 = phi i64 [ %v138382, %edge4914 ], [ %v137795, %block6878.preheader ]
  %v106652 = phi i64 [ 0, %edge4914 ], [ %v137796, %block6878.preheader ]
  %v106654 = phi i64 [ 0, %edge4914 ], [ %v137797, %block6878.preheader ]
  %v106668 = phi i64 [ %v138378, %edge4914 ], [ %v36006, %block6878.preheader ]
  %t4729.not = icmp ult i64 %v36007, %v106668
  br i1 %t4729.not, label %block39122, label %edge4829

block34962:                                       ; preds = %edge4853, %edge4849
  %t4751 = call { i64, i64, i64 } @mech_compact_append_backing_byte_consume(i64 %v0, i64 %v106640, i64 %v106641, i64 %v106642, i64 %v106645, i64 %v106880)
  %v137579 = extractvalue { i64, i64, i64 } %t4751, 0
  %v137580 = extractvalue { i64, i64, i64 } %t4751, 1
  %v137581 = extractvalue { i64, i64, i64 } %t4751, 2
  %t4752.not = icmp eq i64 %v137579, 0
  br i1 %t4752.not, label %block34947, label %block34961

block34961:                                       ; preds = %block34962, %edge4853
  %v106910 = phi i64 [ %v106640, %edge4853 ], [ %v137579, %block34962 ]
  %v106912 = phi i64 [ %v106642, %edge4853 ], [ %v137581, %block34962 ]
  %v106915 = phi i64 [ %v106645, %edge4853 ], [ %v137580, %block34962 ]
  %v106922 = add i64 %v106910, %v106641
  %v106923 = trunc i64 %v106863 to i8
  %t4753 = inttoptr i64 %v106922 to ptr
  store i8 %v106923, ptr %t4753, align 1
  %t4754 = icmp eq i64 %v106645, %v106915
  %t4756.not154 = icmp eq i64 %v106915, 0
  %t4756.not = or i1 %t4754, %t4756.not154
  br i1 %t4756.not, label %block34966, label %edge4860

block34966:                                       ; preds = %block34961, %edge4860
  %t4760.not155 = icmp eq i64 %v106645, 0
  %t4760.not = or i1 %t4760.not155, %t4754
  br i1 %t4760.not, label %block6915, label %edge4863

block34947:                                       ; preds = %edge4863, %block34962, %edge4847, %edge4829
  %v106874 = phi i64 [ %v137580, %block34962 ], [ 103427, %edge4829 ], [ 1, %edge4847 ], [ %v106933, %edge4863 ]
  %t4762 = insertvalue { i64, i64 } poison, i64 %v106874, 0
  %t4763 = insertvalue { i64, i64 } %t4762, i64 7029, 1
  br label %common.ret

block6915:                                        ; preds = %edge4863, %block34966
  %t4764 = icmp ugt i64 %v106654, 5
  br i1 %t4764, label %edge4868, label %edge4890

block35013:                                       ; preds = %edge4874, %edge4870
  %t4778 = call { i64, i64, i64 } @mech_compact_append_backing_byte_consume(i64 %v0, i64 %v106910, i64 %v106880, i64 %v106912, i64 %v106915, i64 %v107018)
  %v137582 = extractvalue { i64, i64, i64 } %t4778, 0
  %v137583 = extractvalue { i64, i64, i64 } %t4778, 1
  %v137584 = extractvalue { i64, i64, i64 } %t4778, 2
  %t4779.not = icmp eq i64 %v137582, 0
  br i1 %t4779.not, label %block34998, label %block35012

block35012:                                       ; preds = %block35013, %edge4874
  %v107048 = phi i64 [ %v106910, %edge4874 ], [ %v137582, %block35013 ]
  %v107050 = phi i64 [ %v106912, %edge4874 ], [ %v137584, %block35013 ]
  %v107053 = phi i64 [ %v106915, %edge4874 ], [ %v137583, %block35013 ]
  %v107060 = add i64 %v107048, %v106880
  %t4780 = inttoptr i64 %v107060 to ptr
  store i8 0, ptr %t4780, align 1
  %t4781 = icmp eq i64 %v106915, %v107053
  %t4783.not156 = icmp eq i64 %v107053, 0
  %t4783.not = or i1 %t4781, %t4783.not156
  br i1 %t4783.not, label %block35017, label %edge4881

block35017:                                       ; preds = %block35012, %edge4881
  %t4787.not = or i1 %t4756.not154, %t4781
  br i1 %t4787.not, label %edge4890, label %edge4884

block34998:                                       ; preds = %edge4884, %block35013, %edge4868
  %v107012 = phi i64 [ %v137583, %block35013 ], [ 1, %edge4868 ], [ %v107071, %edge4884 ]
  %t4789 = insertvalue { i64, i64 } poison, i64 %v107012, 0
  %t4790 = insertvalue { i64, i64 } %t4789, i64 7035, 1
  br label %common.ret

block35050:                                       ; preds = %edge4895, %edge4891
  %t4802 = call { i64, i64, i64 } @mech_compact_append_backing_byte_consume(i64 %v0, i64 %v107095, i64 %v107096, i64 %v107097, i64 %v107092, i64 %v107104)
  %v137585 = extractvalue { i64, i64, i64 } %t4802, 0
  %v137586 = extractvalue { i64, i64, i64 } %t4802, 1
  %v137587 = extractvalue { i64, i64, i64 } %t4802, 2
  %t4803.not = icmp eq i64 %v137585, 0
  br i1 %t4803.not, label %block35034, label %edge4902

block35070:                                       ; preds = %edge4902, %edge4905
  %t4812.not159 = icmp eq i64 %v107092, 0
  %t4812.not = or i1 %t4812.not159, %t4806
  br i1 %t4812.not, label %block6926, label %edge4908

block35034:                                       ; preds = %edge4908, %block35050, %edge4890
  %v107091 = phi i64 [ %v137586, %block35050 ], [ 1, %edge4890 ], [ %v107193, %edge4908 ]
  %t4814 = insertvalue { i64, i64 } poison, i64 %v107091, 0
  %t4815 = insertvalue { i64, i64 } %t4814, i64 7040, 1
  br label %common.ret

block6926:                                        ; preds = %edge4908, %block35070
  %v107366 = xor i64 %v107195, -1
  %t4816 = call { i64, i64, i64, i64, i64, i64, i64, i64 } @mech_compact_checked_layout_continuation_16644(i64 %v107104, i64 %v107136, i64 %v107139, i64 %v107134, i64 %v107366, i64 %v0, i64 %v1397, i64 %v106668, i64 %v1395, i64 %v107195, i64 %v1394)
  %v138375 = extractvalue { i64, i64, i64, i64, i64, i64, i64, i64 } %t4816, 0
  %v138377 = extractvalue { i64, i64, i64, i64, i64, i64, i64, i64 } %t4816, 2
  %t4817 = icmp eq i64 %v138375, 2
  br i1 %t4817, label %edge4913, label %edge4914

block35280:                                       ; preds = %edge4955, %edge4951
  %t4860 = call { i64, i64, i64 } @mech_compact_append_backing_byte_consume(i64 %v0, i64 %v137791, i64 %v137792, i64 %v137793, i64 %v137795, i64 %v107820)
  %v137594 = extractvalue { i64, i64, i64 } %t4860, 0
  %v137595 = extractvalue { i64, i64, i64 } %t4860, 1
  %v137596 = extractvalue { i64, i64, i64 } %t4860, 2
  %t4861.not = icmp eq i64 %v137594, 0
  br i1 %t4861.not, label %block35264, label %block35279

block35279:                                       ; preds = %block35280, %edge4955
  %v107850 = phi i64 [ %v137791, %edge4955 ], [ %v137594, %block35280 ]
  %v107852 = phi i64 [ %v137793, %edge4955 ], [ %v137596, %block35280 ]
  %v107855 = phi i64 [ %v137795, %edge4955 ], [ %v137595, %block35280 ]
  %t4862.not = icmp eq i64 %v107802, 0
  br i1 %t4862.not, label %block35298, label %edge4962

block35298:                                       ; preds = %edge4962, %block35279
  %t4880 = icmp eq i64 %v137795, %v107855
  %t4882.not150 = icmp eq i64 %v107855, 0
  %t4882.not = or i1 %t4880, %t4882.not150
  br i1 %t4882.not, label %block35300, label %edge4980

block35300:                                       ; preds = %block35298, %edge4980
  %t4886.not151 = icmp eq i64 %v137795, 0
  %t4886.not = or i1 %t4886.not151, %t4880
  br i1 %t4886.not, label %block7285.thread, label %edge4983

block35264:                                       ; preds = %edge4983, %block35280, %edge4949, %edge4936
  %v107813 = phi i64 [ %v137595, %block35280 ], [ 103427, %edge4936 ], [ %v107909, %edge4983 ], [ 1, %edge4949 ]
  %t4888 = insertvalue { i64, i64 } poison, i64 %v107813, 0
  %t4889 = insertvalue { i64, i64 } %t4888, i64 7078, 1
  br label %common.ret

block7285.thread:                                 ; preds = %block35300, %edge4983
  %v107915 = and i64 %v107794, -8
  %v107924 = lshr i64 %v107790, %v107915
  %v107928 = and i64 %v107794, 7
  %t5076.not = icmp eq i64 %v83273, 0
  br i1 %t5076.not, label %block7294, label %edge5212

block35504:                                       ; preds = %edge5055, %edge5051
  %t4940 = call { i64, i64, i64 } @mech_compact_append_backing_byte_consume(i64 %v0, i64 %v137791, i64 %v137792, i64 %v137793, i64 %v137795, i64 %v108693)
  %v137597 = extractvalue { i64, i64, i64 } %t4940, 0
  %v137598 = extractvalue { i64, i64, i64 } %t4940, 1
  %v137599 = extractvalue { i64, i64, i64 } %t4940, 2
  %t4941.not = icmp eq i64 %v137597, 0
  br i1 %t4941.not, label %block35488, label %edge5062

block35522:                                       ; preds = %edge5068, %edge5062
  %t4966 = icmp eq i64 %v137795, %v108728
  %t4968.not146 = icmp eq i64 %v108728, 0
  %t4968.not = or i1 %t4966, %t4968.not146
  br i1 %t4968.not, label %block35524, label %edge5086

block35524:                                       ; preds = %block35522, %edge5086
  %t4972.not147 = icmp eq i64 %v137795, 0
  %t4972.not = or i1 %t4972.not147, %t4966
  br i1 %t4972.not, label %block7048, label %edge5089

block35488:                                       ; preds = %edge5089, %block35504, %edge5049, %edge5031
  %v108686 = phi i64 [ %v137598, %block35504 ], [ 103427, %edge5031 ], [ %v108782, %edge5089 ], [ 1, %edge5049 ]
  %t4974 = insertvalue { i64, i64 } poison, i64 %v108686, 0
  %t4975 = insertvalue { i64, i64 } %t4974, i64 7164, 1
  br label %common.ret

block7048:                                        ; preds = %edge5089, %block35524
  %v108788 = and i64 %v108667, -8
  %v108797 = lshr i64 %v108663, %v108788
  %v108801 = and i64 %v108667, 7
  %t4978.not = icmp eq i64 %v83290, 0
  br i1 %t4978.not, label %edge5100, label %edge5097

block7059:                                        ; preds = %edge5104, %edge5100
  %v108866 = phi i64 [ 1, %edge5100 ], [ %v109436, %edge5104 ]
  %v108868 = phi i64 [ %v108797, %edge5100 ], [ %v109350, %edge5104 ]
  %v108870 = phi i64 [ %v108801, %edge5100 ], [ %v109444, %edge5104 ]
  %exitcond19749.not = icmp eq i64 %v108866, %v83300
  br i1 %exitcond19749.not, label %edge5124, label %edge5104

block7148:                                        ; preds = %edge5125, %edge5124
  %v109480 = lshr i64 %v108870, 3
  %v109484 = and i64 %v109480, 255
  %t5007 = icmp samesign ult i64 %v109484, 2
  br i1 %t5007, label %edge5136, label %block39092

block39090:                                       ; preds = %edge5142, %edge5144
  %v138483 = and i64 %v108870, 56
  %v138484 = lshr i64 %v108868, %v138483
  br label %block7165.outer.preheader

block39092:                                       ; preds = %block7148, %edge5136, %edge5140
  %t5020 = call { i64, i64, i64, i64, i64, i64, i64 } @mech_compact_checked_layout_continuation_44068(i64 %v109484, i64 %v108693, i64 %v108725, i64 %v108728, i64 %v108723, i64 %v108868, i64 %v0, i64 %v109480)
  %v138485 = extractvalue { i64, i64, i64, i64, i64, i64, i64 } %t5020, 0
  %v138487 = extractvalue { i64, i64, i64, i64, i64, i64, i64 } %t5020, 2
  %v138488 = extractvalue { i64, i64, i64, i64, i64, i64, i64 } %t5020, 3
  %v138489 = extractvalue { i64, i64, i64, i64, i64, i64, i64 } %t5020, 4
  %v138490 = extractvalue { i64, i64, i64, i64, i64, i64, i64 } %t5020, 5
  %v138491 = extractvalue { i64, i64, i64, i64, i64, i64, i64 } %t5020, 6
  %10 = icmp eq i64 %v138485, 2
  br i1 %10, label %edge5149, label %block7165.outer.preheader

block7165.outer.preheader:                        ; preds = %block39092, %block39090
  %v109993.ph906.ph = phi i64 [ %v138489, %block39092 ], [ %v108723, %block39090 ]
  %v109994.ph907.ph = phi i64 [ %v138488, %block39092 ], [ %v138469, %block39090 ]
  %v109995.ph908.ph = phi i64 [ %v138490, %block39092 ], [ %v108725, %block39090 ]
  %v109998.ph909.ph = phi i64 [ %v138491, %block39092 ], [ %v108728, %block39090 ]
  %v110005.ph910.ph = phi i64 [ %v138487, %block39092 ], [ %v138484, %block39090 ]
  br label %block7165.outer

block7165.outer:                                  ; preds = %block7165.outer.preheader, %block39101
  %v109993.ph906 = phi i64 [ %v138521, %block39101 ], [ %v109993.ph906.ph, %block7165.outer.preheader ]
  %v109994.ph907 = phi i64 [ %v138520, %block39101 ], [ %v109994.ph907.ph, %block7165.outer.preheader ]
  %v109995.ph908 = phi i64 [ %v138522, %block39101 ], [ %v109995.ph908.ph, %block7165.outer.preheader ]
  %v109998.ph909 = phi i64 [ %v138523, %block39101 ], [ %v109998.ph909.ph, %block7165.outer.preheader ]
  %v110005.ph910 = phi i64 [ %v138519, %block39101 ], [ %v110005.ph910.ph, %block7165.outer.preheader ]
  %v110007.in.ph = phi i64 [ %v110746, %block39101 ], [ %v108870, %block7165.outer.preheader ]
  %v110047.ph = phi i64 [ %v110237, %block39101 ], [ 0, %block7165.outer.preheader ]
  %t5057 = icmp ne i64 %v109998.ph909, 0
  %t5058 = inttoptr i64 %v109998.ph909 to ptr
  %umax19777 = call i64 @llvm.umax.i64(i64 %v83297, i64 %v110047.ph)
  br label %block7165

block7165:                                        ; preds = %block7165.outer, %block39099
  %v109994 = phi i64 [ %v138501, %block39099 ], [ %v109994.ph907, %block7165.outer ]
  %v110005 = phi i64 [ %v138516, %block39099 ], [ %v110005.ph910, %block7165.outer ]
  %v110007.in = phi i64 [ %v110746, %block39099 ], [ %v110007.in.ph, %block7165.outer ]
  %v110047 = phi i64 [ %v110237, %block39099 ], [ %v110047.ph, %block7165.outer ]
  %v110007 = and i64 %v110007.in, 7
  %exitcond19778.not = icmp eq i64 %v110047, %umax19777
  br i1 %exitcond19778.not, label %edge5157, label %edge5156

block39099:                                       ; preds = %edge5191, %edge5193
  %v138515 = and i64 %v110746, 56
  %v138516 = lshr i64 %v110614, %v138515
  br label %block7165

block39101:                                       ; preds = %edge5156, %edge5185, %edge5189
  %t5065 = call { i64, i64, i64, i64, i64, i64, i64 } @mech_compact_checked_layout_continuation_44068(i64 %v110759, i64 %v109994, i64 %v109995.ph908, i64 %v109998.ph909, i64 %v109993.ph906, i64 %v110614, i64 %v0, i64 %v110755)
  %v138517 = extractvalue { i64, i64, i64, i64, i64, i64, i64 } %t5065, 0
  %v138519 = extractvalue { i64, i64, i64, i64, i64, i64, i64 } %t5065, 2
  %v138520 = extractvalue { i64, i64, i64, i64, i64, i64, i64 } %t5065, 3
  %v138521 = extractvalue { i64, i64, i64, i64, i64, i64, i64 } %t5065, 4
  %v138522 = extractvalue { i64, i64, i64, i64, i64, i64, i64 } %t5065, 5
  %v138523 = extractvalue { i64, i64, i64, i64, i64, i64, i64 } %t5065, 6
  %11 = icmp eq i64 %v138517, 2
  br i1 %11, label %edge5198, label %block7165.outer

block7294:                                        ; preds = %edge5203, %edge5157, %edge5212, %block7285.thread
  %v111182530 = phi i64 [ %v107928, %edge5212 ], [ %v107928, %block7285.thread ], [ %v110007, %edge5157 ], [ %v110007, %edge5203 ]
  %v111180528 = phi i64 [ %v107924, %edge5212 ], [ %v107924, %block7285.thread ], [ %v110005, %edge5157 ], [ %v110005, %edge5203 ]
  %v111173526 = phi i64 [ %v107855, %edge5212 ], [ %v107855, %block7285.thread ], [ %v109998.ph909, %edge5157 ], [ %v109998.ph909, %edge5203 ]
  %v111170524 = phi i64 [ %v107852, %edge5212 ], [ %v107852, %block7285.thread ], [ %v109995.ph908, %edge5157 ], [ %v109995.ph908, %edge5203 ]
  %v111169522 = phi i64 [ %v107820, %edge5212 ], [ %v107820, %block7285.thread ], [ %v109994, %edge5157 ], [ %v109994, %edge5203 ]
  %v111168520 = phi i64 [ %v107850, %edge5212 ], [ %v107850, %block7285.thread ], [ %v109993.ph906, %edge5157 ], [ %v109993.ph906, %edge5203 ]
  %v138611 = phi i64 [ ptrtoint (ptr @mech_compact_table_9 to i64), %edge5212 ], [ ptrtoint (ptr @mech_compact_table_9 to i64), %block7285.thread ], [ %v83268, %edge5157 ], [ %v83268, %edge5203 ]
  %v138612 = phi i64 [ 320, %edge5212 ], [ 320, %block7285.thread ], [ %v83269, %edge5157 ], [ %v83269, %edge5203 ]
  %v138613 = phi i64 [ 0, %edge5212 ], [ 0, %block7285.thread ], [ %v83273, %edge5157 ], [ %v83273, %edge5203 ]
  br i1 %t23.not, label %block36376, label %edge5220

block36376:                                       ; preds = %block7294, %edge5220
  %t5084.not = icmp eq i64 %v138613, 0
  br i1 %t5084.not, label %edge5226, label %edge5223

block7301:                                        ; preds = %edge5449, %edge5226
  %v112429 = phi i64 [ %v111168520, %edge5226 ], [ %v138528541, %edge5449 ]
  %v112430 = phi i64 [ %v111169522, %edge5226 ], [ %v138527540, %edge5449 ]
  %v112431 = phi i64 [ %v111170524, %edge5226 ], [ %v138529542, %edge5449 ]
  %v112434 = phi i64 [ %v111173526, %edge5226 ], [ %v138530543, %edge5449 ]
  %v112441 = phi i64 [ %v111180528, %edge5226 ], [ %v138526539, %edge5449 ]
  %v112443 = phi i64 [ %v111182530, %edge5226 ], [ %v116513, %edge5449 ]
  %v112475 = phi i64 [ 0, %edge5226 ], [ %v116679, %edge5449 ]
  %t5087.not = icmp eq i64 %v112475, %v36030
  br i1 %t5087.not, label %edge5431, label %edge5230

block36958:                                       ; preds = %edge5238, %edge5295
  br i1 %t5084.not, label %block7494.preheader, label %edge5298

block7494.preheader:                              ; preds = %block36958, %edge5298
  br label %block7494

block7494:                                        ; preds = %block7494.preheader, %edge5322
  %v114148 = phi i64 [ %v114676, %edge5322 ], [ 0, %block7494.preheader ]
  %v114150 = phi i64 [ %v114686, %edge5322 ], [ 0, %block7494.preheader ]
  %v114164 = phi i64 [ %v114690, %edge5322 ], [ %v112757, %block7494.preheader ]
  %v114178 = phi i64 [ %v114783, %edge5322 ], [ %v112761, %block7494.preheader ]
  %t5141.not = icmp ne i64 %v114178, 0
  %t5144 = icmp ult i64 %v114164, %v1395
  %or.cond178 = select i1 %t5141.not, i1 %t5144, i1 false
  br i1 %or.cond178, label %edge5308, label %edge5321

trap5151:                                         ; preds = %edge5313
  call void @llvm.trap()
  unreachable

ok5151:                                           ; preds = %edge5313
  %v114392 = udiv i64 %v114164, %v1397
  %v114393 = mul i64 %v114392, %v1397
  %v114394 = sub nuw i64 %v114164, %v114393
  %v114395 = mul i64 %v114394, %v1398
  %v114396 = add i64 %v114395, %v114392
  br label %edge5321.thread

edge5321.thread:                                  ; preds = %ok5151, %edge5308
  %v114391 = phi i64 [ %v114396, %ok5151 ], [ %v114164, %edge5308 ]
  %v114398 = add i64 %v114391, %v1394
  %t5152 = inttoptr i64 %v114398 to ptr
  %t5153 = load i8, ptr %t5152, align 1
  %v114399 = zext i8 %t5153 to i64
  br label %edge5322

block39110.thread:                                ; preds = %edge5443, %edge5441
  %v138547 = and i64 %v116357, 56
  %v138548 = lshr i64 %v116265, %v138547
  br label %edge5449

block39110:                                       ; preds = %edge5430, %edge5435, %edge5439
  %t5237 = call { i64, i64, i64, i64, i64, i64, i64 } @mech_compact_checked_layout_continuation_44068(i64 %v116375, i64 %v112430, i64 %v112431, i64 %v112434, i64 %v112429, i64 %v116265, i64 %v0, i64 %v116371)
  %v138549 = extractvalue { i64, i64, i64, i64, i64, i64, i64 } %t5237, 0
  %v138551 = extractvalue { i64, i64, i64, i64, i64, i64, i64 } %t5237, 2
  %v138552 = extractvalue { i64, i64, i64, i64, i64, i64, i64 } %t5237, 3
  %v138553 = extractvalue { i64, i64, i64, i64, i64, i64, i64 } %t5237, 4
  %v138554 = extractvalue { i64, i64, i64, i64, i64, i64, i64 } %t5237, 5
  %v138555 = extractvalue { i64, i64, i64, i64, i64, i64, i64 } %t5237, 6
  %12 = icmp eq i64 %v138549, 2
  br i1 %12, label %edge5448, label %edge5449

block7835:                                        ; preds = %edge5453, %edge5431
  %t5246 = icmp ugt i64 %v138612, 256
  br i1 %t5246, label %edge5460, label %edge5461

block39119.thread:                                ; preds = %edge5494, %edge5492
  %v138579 = and i64 %v117293, 56
  %v138580 = lshr i64 %v117277, %v138579
  br label %edge5500

block39119:                                       ; preds = %edge5474, %edge5486, %edge5490
  %t5277 = call { i64, i64, i64, i64, i64, i64, i64 } @mech_compact_checked_layout_continuation_44068(i64 %v117305, i64 %v112430, i64 %v112431, i64 %v112434, i64 %v112429, i64 %v117277, i64 %v0, i64 %v117301)
  %v138581 = extractvalue { i64, i64, i64, i64, i64, i64, i64 } %t5277, 0
  %v138583 = extractvalue { i64, i64, i64, i64, i64, i64, i64 } %t5277, 2
  %v138584 = extractvalue { i64, i64, i64, i64, i64, i64, i64 } %t5277, 3
  %v138585 = extractvalue { i64, i64, i64, i64, i64, i64, i64 } %t5277, 4
  %v138586 = extractvalue { i64, i64, i64, i64, i64, i64, i64 } %t5277, 5
  %v138587 = extractvalue { i64, i64, i64, i64, i64, i64, i64 } %t5277, 6
  %13 = icmp eq i64 %v138581, 2
  br i1 %13, label %edge5499, label %edge5500

block7887:                                        ; preds = %edge5503, %edge5541
  %v117575 = phi i64 [ %v138104, %edge5541 ], [ %v35973, %edge5503 ]
  %v117598 = phi i64 [ %v117887, %edge5541 ], [ 0, %edge5503 ]
  %v117599 = phi i64 [ %v138103, %edge5541 ], [ %v35968, %edge5503 ]
  %t5290.not = icmp eq i64 %v117575, 0
  br i1 %t5290.not, label %block7896, label %edge5514

block7896:                                        ; preds = %edge5514, %block7887
  %exitcond19779.not = icmp eq i64 %v117598, %v36009
  br i1 %exitcond19779.not, label %edge5552, label %edge5523

block38800:                                       ; preds = %edge5621, %edge5619
  %v126010 = or i64 %v49365, %v35967
  %v126011 = or i64 %v126010, %v125730
  %v126012 = or i64 %v126011, %v125560.sink
  %t5427.not = icmp eq i64 %v126012, 0
  br i1 %t5427.not, label %block38803, label %edge5625

block38803:                                       ; preds = %edge5625, %block38800
  %v126015 = or i64 %v125784, %v35997
  %v126016 = or i64 %v126015, %v125818
  %v126017 = or i64 %v126016, %v125830
  %t5429.not = icmp eq i64 %v126017, 0
  br i1 %t5429.not, label %block8065, label %edge5629

block38785:                                       ; preds = %edge5629, %edge5625, %edge5621
  %v125967 = phi i64 [ %v126013, %edge5625 ], [ %v126008, %edge5621 ], [ %v126018, %edge5629 ]
  %t5431 = insertvalue { i64, i64 } poison, i64 %v125967, 0
  %t5432 = insertvalue { i64, i64 } %t5431, i64 8190, 1
  br label %common.ret

block8065:                                        ; preds = %edge5629, %block38803
  %t5433.not = icmp eq i64 %v125950, 0
  br i1 %t5433.not, label %edge5660, label %edge5635

block38932:                                       ; preds = %edge5642, %edge5638
  %t5447 = call { i64, i64, i64 } @mech_compact_append_backing_byte_consume(i64 %v0, i64 %v125845, i64 %v125859, i64 %v125873, i64 %v125915, i64 %v137434)
  %v137612 = extractvalue { i64, i64, i64 } %t5447, 0
  %v137613 = extractvalue { i64, i64, i64 } %t5447, 1
  %v137614 = extractvalue { i64, i64, i64 } %t5447, 2
  %t5448.not = icmp eq i64 %v137612, 0
  br i1 %t5448.not, label %block38917, label %block38931

block38931:                                       ; preds = %block38932, %edge5642
  %v137464 = phi i64 [ %v125845, %edge5642 ], [ %v137612, %block38932 ]
  %v137466 = phi i64 [ %v125873, %edge5642 ], [ %v137614, %block38932 ]
  %v137469 = phi i64 [ %v125915, %edge5642 ], [ %v137613, %block38932 ]
  %v137476 = add i64 %v137464, %v125859
  %v137477 = trunc i64 %v125935 to i8
  %t5449 = inttoptr i64 %v137476 to ptr
  store i8 %v137477, ptr %t5449, align 1
  %t5450 = icmp eq i64 %v125915, %v137469
  %t5452.not161 = icmp eq i64 %v137469, 0
  %t5452.not = or i1 %t5450, %t5452.not161
  br i1 %t5452.not, label %block38936, label %edge5649

block38936:                                       ; preds = %block38931, %edge5649
  %t5456.not162 = icmp eq i64 %v125915, 0
  %t5456.not = or i1 %t5456.not162, %t5450
  br i1 %t5456.not, label %edge5660, label %edge5652

block38917:                                       ; preds = %edge5652, %block38932, %edge5635
  %v137428 = phi i64 [ %v137613, %block38932 ], [ 1, %edge5635 ], [ %v137487, %edge5652 ]
  %t5458 = insertvalue { i64, i64 } poison, i64 %v137428, 0
  %t5459 = insertvalue { i64, i64 } %t5458, i64 8214, 1
  br label %common.ret

block38973:                                       ; preds = %edge5661, %edge5660
  %t5464 = inttoptr i64 %v2 to ptr
  store i64 %v137525, ptr %t5464, align 1
  %t5466 = getelementptr i8, ptr %t5464, i64 8
  store i64 %v137526, ptr %t5466, align 1
  %t5468 = getelementptr i8, ptr %t5464, i64 16
  store i64 %v137527, ptr %t5468, align 1
  %t5470 = getelementptr i8, ptr %t5464, i64 24
  store i64 %v137528, ptr %t5470, align 1
  %t5472 = getelementptr i8, ptr %t5464, i64 32
  store i64 %v137526, ptr %t5472, align 1
  %t5474 = getelementptr i8, ptr %t5464, i64 40
  store i64 %v137530, ptr %t5474, align 1
  br label %common.ret

block39122.loopexit19908.split.loop.exit29280:    ; preds = %block6474
  %.mux10358.le = select i1 %29, i64 6583, i64 6584
  br label %block39122

block39122:                                       ; preds = %edge5014, %edge5004, %edge4995, %edge4785, %edge4777, %edge4766, %edge4765, %block6737, %edge2014, %edge1983, %edge1939, %edge1900, %edge375, %edge367, %edge5633, %edge428, %edge422, %block427, %edge1825, %edge1807, %edge1805, %edge1795, %edge1792, %edge1780, %edge1777, %block2258, %edge1956, %block2692, %edge1920, %edge1913, %edge2083, %edge2067, %block5528, %edge3963, %edge4051, %edge4209, %edge4284, %edge4447, %block6878, %edge5104, %edge5247, %edge5523, %edge856, %edge826, %edge807, %edge723, %edge665, %edge1750, %edge1743, %edge1738, %block2325, %edge1856, %edge3639, %edge3998, %edge4033, %edge4370, %edge4426, %edge4417, %edge4502, %edge4495, %edge4490, %edge2821, %edge3068, %edge3019, %edge3009, %edge3003, %edge3297, %edge3261, %edge3263, %edge3515, %edge3505, %edge3816, %edge3764, %edge3758, %block5249, %edge3679, %block4489, %edge3401, %edge3719, %edge158, %block39122.loopexit19908.split.loop.exit29280, %edge171, %edge8
  %v139107 = phi i64 [ 2559, %edge1920 ], [ 2355, %block2325 ], [ 7005, %block6878 ], [ 4211, %edge3003 ], [ 105, %edge8 ], [ 117, %edge171 ], [ 4950, %edge3505 ], [ %.mux10358.le, %block39122.loopexit19908.split.loop.exit29280 ], [ 441, %block427 ], [ 45, %edge158 ], [ 7493, %edge5247 ], [ 4617, %edge3261 ], [ 824, %edge856 ], [ 6418, %edge4447 ], [ 2215, %edge1738 ], [ 2269, %edge1777 ], [ 6377, %edge4426 ], [ 3934, %edge2821 ], [ 4754, %edge3401 ], [ 5169, %edge3639 ], [ 4558, %block4489 ], [ 8041, %edge5523 ], [ 2432, %edge1856 ], [ 5322, %edge3719 ], [ 6199, %edge4370 ], [ 5845, %edge4033 ], [ 5266, %edge3679 ], [ 378, %edge422 ], [ 2643, %edge1956 ], [ 6553, %edge4495 ], [ 2837, %edge2067 ], [ 2726, %block2692 ], [ 7256, %edge5104 ], [ 5728, %edge3998 ], [ 5433, %edge3816 ], [ 5416, %edge3764 ], [ 5391, %edge3758 ], [ 5334, %block5249 ], [ 5000, %edge3515 ], [ 4641, %edge3297 ], [ 4617, %edge3263 ], [ 4334, %edge3068 ], [ 4286, %edge3019 ], [ 4255, %edge3009 ], [ 6575, %edge4502 ], [ 6530, %edge4490 ], [ 6362, %edge4417 ], [ 2260, %edge1750 ], [ 2238, %edge1743 ], [ 586, %edge665 ], [ 626, %edge723 ], [ 709, %edge807 ], [ 756, %edge826 ], [ 6122, %edge4284 ], [ 5865, %edge4051 ], [ 5621, %edge3963 ], [ 5620, %block5528 ], [ 6001, %edge4209 ], [ 2879, %edge2083 ], [ 2535, %edge1913 ], [ 2282, %edge1795 ], [ 2288, %edge1805 ], [ 2289, %edge1807 ], [ 2268, %block2258 ], [ 2280, %edge1792 ], [ 2271, %edge1780 ], [ 2385, %edge1825 ], [ 392, %edge428 ], [ 7096, %edge4995 ], [ 2518, %edge1900 ], [ 6944, %edge4777 ], [ 2782, %edge2014 ], [ 7102, %edge5004 ], [ 6941, %edge4766 ], [ 6848, %block6737 ], [ 310, %edge5633 ], [ 6945, %edge4785 ], [ 2756, %edge1983 ], [ 329, %edge375 ], [ 7108, %edge5014 ], [ 319, %edge367 ], [ 2585, %edge1939 ], [ 6934, %edge4765 ]
  %t5480 = insertvalue { i64, i64 } { i64 1, i64 poison }, i64 %v139107, 1
  br label %common.ret

block39124:                                       ; preds = %block19254, %edge2370, %edge2369, %block13409, %edge1343, %block11732, %edge1015, %block10458, %edge708
  %v139111 = phi i64 [ 1546, %block13409 ], [ 998, %block11732 ], [ 591, %block10458 ], [ 591, %edge708 ], [ 998, %edge1015 ], [ 1546, %edge1343 ], [ 3238, %edge2369 ], [ 3238, %edge2370 ], [ 3238, %block19254 ]
  %t5484 = insertvalue { i64, i64 } { i64 9, i64 poison }, i64 %v139111, 1
  br label %common.ret

block39125:                                       ; preds = %edge1598, %edge2941
  %v139113 = phi i64 [ 4166, %edge2941 ], [ 1948, %edge1598 ]
  %t5486 = insertvalue { i64, i64 } { i64 103425, i64 poison }, i64 %v139113, 1
  br label %common.ret

edge0:                                            ; preds = %block0
  %t24 = inttoptr i64 %v1399 to ptr
  %v1586 = load i64, ptr %t24, align 1
  %v1587 = add i64 %v1586, 1
  store i64 %v1587, ptr %t24, align 1
  br label %block2

edge3:                                            ; preds = %block2
  %t27 = inttoptr i64 %v1405 to ptr
  %v1588 = load i64, ptr %t27, align 1
  %v1589 = add i64 %v1588, 1
  store i64 %v1589, ptr %t27, align 1
  br label %block11

edge7:                                            ; preds = %block11
  %t36 = icmp eq i64 %v1403, 1
  br i1 %t36, label %edge15, label %block8136

edge8:                                            ; preds = %block11
  %t197.not = icmp ugt i64 %v1395, -5000
  br i1 %t197.not, label %block39122, label %edge171

edge15:                                           ; preds = %edge7
  %v1701 = add nuw nsw i64 %v1395, 5
  %v1713 = tail call i64 @llvm.uadd.sat.i64(i64 %v1401, i64 %v1701)
  %t41 = icmp ugt i64 %v1713, %v1402
  br i1 %t41, label %edge17, label %block22

edge17:                                           ; preds = %edge15
  %t45 = tail call { i64, i64 } @mech_compact_writable_scalar_backing(i64 %v0, i64 %v1400, i64 %v1401, i64 %v1402, i64 %v1405, i64 %v1713, i64 3)
  %v1732 = extractvalue { i64, i64 } %t45, 0
  %v1733 = extractvalue { i64, i64 } %t45, 1
  %t46.not = icmp eq i64 %v1732, 0
  br i1 %t46.not, label %block8136, label %block8139

edge26:                                           ; preds = %block8139
  %t51 = inttoptr i64 %v1733 to ptr
  %v1737 = load i64, ptr %t51, align 1
  %v1738 = add i64 %v1737, 1
  store i64 %v1738, ptr %t51, align 1
  br label %block8145

edge29:                                           ; preds = %block8145
  %v1743 = tail call i64 @mech_compact_release_owner(i64 %v0, i64 %v1405)
  %t55.not = icmp eq i64 %v1743, 0
  br i1 %t55.not, label %block22, label %block8136

edge34:                                           ; preds = %block22
  br i1 %t23.not, label %block8165, label %edge36

edge36:                                           ; preds = %edge34
  %v1757 = tail call i64 @mech_compact_release_owner(i64 %v0, i64 %v1399)
  %t62.not = icmp eq i64 %v1757, 0
  br i1 %t62.not, label %block8165, label %edge38

edge38:                                           ; preds = %edge36
  %t63 = insertvalue { i64, i64 } poison, i64 %v1757, 0
  %t64 = insertvalue { i64, i64 } %t63, i64 19, 1
  br label %common.ret

edge40:                                           ; preds = %block8165
  %t69 = icmp ule i64 %v1774, %v1717188200
  %t71 = icmp ne i64 %v1720189199, 0
  %or.cond = and i1 %t69, %t71
  br i1 %or.cond, label %edge44, label %block8179

edge44:                                           ; preds = %edge40
  %t72 = inttoptr i64 %v1720189199 to ptr
  %v1810 = load i64, ptr %t72, align 1
  %t73 = icmp eq i64 %v1810, 1
  br i1 %t73, label %block8178, label %block8179

edge51:                                           ; preds = %block8178
  %t82 = inttoptr i64 %v1809 to ptr
  %v1821 = load i64, ptr %t82, align 1
  %v1822 = add i64 %v1821, 1
  store i64 %v1822, ptr %t82, align 1
  br label %block8183

edge54:                                           ; preds = %block8183
  %v1827 = tail call i64 @mech_compact_release_owner(i64 %v0, i64 %v1720189199)
  %t86.not = icmp eq i64 %v1827, 0
  br i1 %t86.not, label %edge58, label %block8164

edge58:                                           ; preds = %edge54, %block8183
  %t89 = tail call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %v1774, i64 4)
  %v1836 = extractvalue { i64, i1 } %t89, 0
  %t90 = extractvalue { i64, i1 } %t89, 1
  br i1 %t90, label %block8188, label %edge59

edge59:                                           ; preds = %edge58
  %t93 = icmp ule i64 %v1836, %v1806
  %t95 = icmp ne i64 %v1809, 0
  %or.cond15 = and i1 %t93, %t95
  br i1 %or.cond15, label %edge63, label %block8204

edge63:                                           ; preds = %edge59
  %t96 = inttoptr i64 %v1809 to ptr
  %v1872 = load i64, ptr %t96, align 1
  %t97 = icmp eq i64 %v1872, 1
  br i1 %t97, label %edge70, label %block8204

edge70:                                           ; preds = %block8204, %edge63
  %v1866 = phi i64 [ %v1804, %edge63 ], [ %v137549, %block8204 ]
  %v1868 = phi i64 [ %v1806, %edge63 ], [ %v137551, %block8204 ]
  %v1871 = phi i64 [ %v1809, %edge63 ], [ %v137550, %block8204 ]
  %v1881 = add i64 %v1866, %v1774
  %t102 = inttoptr i64 %v1881 to ptr
  store i8 0, ptr %t102, align 1
  %v1885 = add nuw i64 %v1774, 1
  %v1886 = add i64 %v1885, %v1866
  %t103 = inttoptr i64 %v1886 to ptr
  store i8 0, ptr %t103, align 1
  %v1890 = add nuw i64 %v1774, 2
  %v1891 = add i64 %v1890, %v1866
  %t104 = inttoptr i64 %v1891 to ptr
  store i8 -1, ptr %t104, align 1
  %v1895 = add nuw i64 %v1774, 3
  %v1896 = add i64 %v1895, %v1866
  %t105 = inttoptr i64 %v1896 to ptr
  store i8 -1, ptr %t105, align 1
  %t106 = icmp eq i64 %v1809, %v1871
  %t108.not171 = icmp eq i64 %v1871, 0
  %t108.not = or i1 %t106, %t108.not171
  br i1 %t108.not, label %block8224, label %edge75

edge75:                                           ; preds = %edge70
  %t109 = inttoptr i64 %v1871 to ptr
  %v1919 = load i64, ptr %t109, align 1
  %v1920 = add i64 %v1919, 1
  store i64 %v1920, ptr %t109, align 1
  br label %block8224

edge78:                                           ; preds = %block8224
  %t113 = inttoptr i64 %v1809 to ptr
  %v1923 = load i64, ptr %t113, align 1
  %v1924 = add i64 %v1923, -1
  store i64 %v1924, ptr %t113, align 1
  %t115.not = icmp eq i64 %v1924, 0
  br i1 %t115.not, label %edge81, label %edge5660

edge81:                                           ; preds = %edge78
  %v1925 = tail call i64 @mech_compact_free(i64 %v0, i64 %v1809)
  %t116.not = icmp eq i64 %v1925, 0
  br i1 %t116.not, label %edge5660, label %block8188

edge101:                                          ; preds = %block8275
  %t130 = tail call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %v137775, i64 1)
  %v2098 = extractvalue { i64, i1 } %t130, 0
  %t131 = extractvalue { i64, i1 } %t130, 1
  br i1 %t131, label %block8308, label %edge103

edge103:                                          ; preds = %edge101
  %t134 = icmp ule i64 %v2098, %v137776
  %t136 = icmp ne i64 %v137778, 0
  %or.cond16 = select i1 %t134, i1 %t136, i1 false
  br i1 %or.cond16, label %edge107, label %block8323

edge107:                                          ; preds = %edge103
  %t137 = inttoptr i64 %v137778 to ptr
  %v2134 = load i64, ptr %t137, align 1
  %t138 = icmp eq i64 %v2134, 1
  br i1 %t138, label %block8322, label %block8323

edge114:                                          ; preds = %block8322
  %t147 = inttoptr i64 %v2133 to ptr
  %v2145 = load i64, ptr %t147, align 1
  %v2146 = add i64 %v2145, 1
  store i64 %v2146, ptr %t147, align 1
  br label %block8327

edge117:                                          ; preds = %block8327
  %t151 = inttoptr i64 %v137778 to ptr
  %v2149 = load i64, ptr %t151, align 1
  %v2150 = add i64 %v2149, -1
  store i64 %v2150, ptr %t151, align 1
  %t153.not = icmp eq i64 %v2150, 0
  br i1 %t153.not, label %edge120, label %edge124

edge120:                                          ; preds = %edge117
  %v2151 = tail call i64 @mech_compact_free(i64 %v0, i64 %v137778)
  %t154.not = icmp eq i64 %v2151, 0
  br i1 %t154.not, label %edge124, label %block8308

edge124:                                          ; preds = %block8327, %edge117, %edge120
  %t157 = tail call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %v2098, i64 2)
  %v2264 = extractvalue { i64, i1 } %t157, 0
  %t158 = extractvalue { i64, i1 } %t157, 1
  br i1 %t158, label %block8377, label %edge125

edge125:                                          ; preds = %edge124
  %t161 = icmp ule i64 %v2264, %v2130
  %t163 = icmp ne i64 %v2133, 0
  %or.cond17 = and i1 %t161, %t163
  br i1 %or.cond17, label %edge129, label %block8393

edge129:                                          ; preds = %edge125
  %t164 = inttoptr i64 %v2133 to ptr
  %v2300 = load i64, ptr %t164, align 1
  %t165 = icmp eq i64 %v2300, 1
  br i1 %t165, label %edge136, label %block8393

edge136:                                          ; preds = %block8393, %edge129
  %v2294 = phi i64 [ %v2128, %edge129 ], [ %v137558, %block8393 ]
  %v2296 = phi i64 [ %v2130, %edge129 ], [ %v137560, %block8393 ]
  %v2299 = phi i64 [ %v2133, %edge129 ], [ %v137559, %block8393 ]
  %v2307 = trunc i64 %spec.select173 to i8
  %v2309 = add i64 %v2294, %v2098
  %t170 = inttoptr i64 %v2309 to ptr
  store i8 %v2307, ptr %t170, align 1
  %v2311 = lshr i64 %spec.select173, 8
  %v2312 = trunc nuw i64 %v2311 to i8
  %v2313 = add nuw i64 %v2098, 1
  %v2314 = add i64 %v2313, %v2294
  %t171 = inttoptr i64 %v2314 to ptr
  store i8 %v2312, ptr %t171, align 1
  %t172 = icmp eq i64 %v2133, %v2299
  %t174.not167 = icmp eq i64 %v2299, 0
  %t174.not = or i1 %t172, %t174.not167
  br i1 %t174.not, label %block8413, label %edge139

edge139:                                          ; preds = %edge136
  %t175 = inttoptr i64 %v2299 to ptr
  %v2347 = load i64, ptr %t175, align 1
  %v2348 = add i64 %v2347, 1
  store i64 %v2348, ptr %t175, align 1
  br label %block8413

edge142:                                          ; preds = %block8413
  %v2353 = tail call i64 @mech_compact_release_owner(i64 %v0, i64 %v2133)
  %t179.not = icmp eq i64 %v2353, 0
  br i1 %t179.not, label %block84, label %block8377

edge147:                                          ; preds = %block84
  %v138366 = extractvalue { i64, i64, i64, i64, i64, i64, i64, i64 } %t182, 1
  %v138374 = add i64 %v138367, 82
  %t185 = insertvalue { i64, i64 } poison, i64 %v138366, 0
  %t186 = insertvalue { i64, i64 } %t185, i64 %v138374, 1
  br label %common.ret

edge148:                                          ; preds = %block84
  %t187 = icmp eq i64 %v138368, %v1395
  br i1 %t187, label %edge150, label %edge158

edge150:                                          ; preds = %edge148
  br i1 %t23.not, label %edge5660, label %edge152

edge152:                                          ; preds = %edge150
  %t191 = inttoptr i64 %v1399 to ptr
  %v2543 = load i64, ptr %t191, align 1
  %v2544 = add i64 %v2543, -1
  store i64 %v2544, ptr %t191, align 1
  %t193.not = icmp eq i64 %v2544, 0
  br i1 %t193.not, label %edge155, label %edge5660

edge155:                                          ; preds = %edge152
  %v2545 = tail call i64 @mech_compact_free(i64 %v0, i64 %v1399)
  %t194.not = icmp eq i64 %v2545, 0
  br i1 %t194.not, label %edge5660, label %edge156

edge156:                                          ; preds = %edge155
  %t195 = insertvalue { i64, i64 } poison, i64 %v2545, 0
  %t196 = insertvalue { i64, i64 } %t195, i64 86, 1
  br label %common.ret

edge158:                                          ; preds = %edge148
  %t119.not = icmp ult i64 %v1395, %v138368
  br i1 %t119.not, label %block39122, label %block8275

edge171:                                          ; preds = %edge8
  %v2668 = add nuw i64 %v1395, 4999
  %v2677 = udiv i64 %v2668, 5000
  %14 = mul nuw nsw i64 %v2677, 5
  %v2754 = add i64 %14, %v1395
  %t210.not = icmp ult i64 %v2754, %14
  br i1 %t210.not, label %block39122, label %edge175

edge175:                                          ; preds = %edge171
  %t212 = icmp eq i64 %v1403, 1
  br i1 %t212, label %edge178, label %block8598

edge178:                                          ; preds = %edge175
  %v2766 = tail call i64 @llvm.uadd.sat.i64(i64 %v1401, i64 %v2754)
  %t217 = icmp ugt i64 %v2766, %v1402
  br i1 %t217, label %edge180, label %edge201

edge180:                                          ; preds = %edge178
  %t221 = tail call { i64, i64 } @mech_compact_writable_scalar_backing(i64 %v0, i64 %v1400, i64 %v1401, i64 %v1402, i64 %v1405, i64 %v2766, i64 3)
  %v2785 = extractvalue { i64, i64 } %t221, 0
  %v2786 = extractvalue { i64, i64 } %t221, 1
  %t222.not = icmp eq i64 %v2785, 0
  br i1 %t222.not, label %block8598, label %block8601

edge189:                                          ; preds = %block8601
  %t227 = inttoptr i64 %v2786 to ptr
  %v2790 = load i64, ptr %t227, align 1
  %v2791 = add i64 %v2790, 1
  store i64 %v2791, ptr %t227, align 1
  br label %block8607

edge192:                                          ; preds = %block8607
  %v2796 = tail call i64 @mech_compact_release_owner(i64 %v0, i64 %v1405)
  %t231.not = icmp eq i64 %v2796, 0
  br i1 %t231.not, label %edge201, label %block8598

edge198:                                          ; preds = %edge202
  %t237 = insertvalue { i64, i64 } poison, i64 %v2813, 0
  %t238 = insertvalue { i64, i64 } %t237, i64 120, 1
  br label %common.ret

edge199:                                          ; preds = %edge202
  %v3029 = tail call i64 @llvm.umin.i64(i64 %v1395, i64 6000)
  %v3032 = mul nuw nsw i64 %v3029, 257
  %v3132 = tail call i64 @llvm.umin.i64(i64 %v3032, i64 1500513)
  %t267 = tail call { i64, i64 } @mech_compact_allocate_backing(i64 %v0, i64 %v3132, i64 4, i64 4, i64 1)
  %v3170 = extractvalue { i64, i64 } %t267, 0
  %v3171 = extractvalue { i64, i64 } %t267, 1
  %t268.not = icmp eq i64 %v3170, 0
  br i1 %t268.not, label %block8737, label %edge237

edge201:                                          ; preds = %edge178, %block8607, %edge192
  %v2768208219 = phi i64 [ %v2785, %edge192 ], [ %v2785, %block8607 ], [ %v1400, %edge178 ]
  %v2770209218 = phi i64 [ %v2766, %edge192 ], [ %v2766, %block8607 ], [ %v1402, %edge178 ]
  %v2773210217 = phi i64 [ %v2786, %edge192 ], [ %v2786, %block8607 ], [ %v1405, %edge178 ]
  %t239 = tail call { i64, i64 } @mech_compact_allocate_backing(i64 %v0, i64 262144, i64 2, i64 2, i64 1)
  %v2855 = extractvalue { i64, i64 } %t239, 0
  %v2856 = extractvalue { i64, i64 } %t239, 1
  %t240.not = icmp eq i64 %v2855, 0
  br i1 %t240.not, label %edge203, label %edge202

edge202:                                          ; preds = %edge201
  %t241 = inttoptr i64 %v2856 to ptr
  store i64 2, ptr %t241, align 1
  %v2813 = tail call i64 @mech_compact_release_owner(i64 %v0, i64 %v2856)
  %t236.not = icmp eq i64 %v2813, 0
  br i1 %t236.not, label %edge199, label %edge198

edge203:                                          ; preds = %edge201
  %t242 = insertvalue { i64, i64 } poison, i64 %v2856, 0
  %t243 = insertvalue { i64, i64 } %t242, i64 124, 1
  br label %common.ret

edge223:                                          ; preds = %edge239
  %t255 = insertvalue { i64, i64 } poison, i64 %v3127, 0
  %t256 = insertvalue { i64, i64 } %t255, i64 152, 1
  br label %common.ret

edge237:                                          ; preds = %edge199
  %cond180 = icmp eq i64 %v3171, 0
  br i1 %cond180, label %block167, label %edge239

edge239:                                          ; preds = %edge237
  %t270 = inttoptr i64 %v3171 to ptr
  %v3174 = load i64, ptr %t270, align 1
  %v3123 = add i64 %v3174, 2
  store i64 %v3123, ptr %t270, align 1
  %v3127 = tail call i64 @mech_compact_release_owner(i64 %v0, i64 %v3171)
  %t254.not = icmp eq i64 %v3127, 0
  br i1 %t254.not, label %block167, label %edge223

edge249:                                          ; preds = %block167
  %t279.not = icmp eq i64 %v3366, 0
  br i1 %t279.not, label %edge259, label %edge251

edge250:                                          ; preds = %block167
  %t282 = insertvalue { i64, i64 } poison, i64 %v3366, 0
  %t283 = insertvalue { i64, i64 } %t282, i64 174, 1
  br label %common.ret

edge251:                                          ; preds = %edge249
  %t280 = inttoptr i64 %v3366 to ptr
  %v3369 = load i64, ptr %t280, align 1
  %v3370 = add i64 %v3369, 1
  store i64 %v3370, ptr %t280, align 1
  br label %edge259

edge256:                                          ; preds = %edge262
  %t287 = insertvalue { i64, i64 } poison, i64 %v3411, 0
  %t288 = insertvalue { i64, i64 } %t287, i64 176, 1
  br label %common.ret

edge259:                                          ; preds = %edge251, %edge249
  %t289 = tail call { i64, i64 } @mech_compact_allocate_backing(i64 %v0, i64 547, i64 4, i64 4, i64 1)
  %v3457 = extractvalue { i64, i64 } %t289, 0
  %v3458 = extractvalue { i64, i64 } %t289, 1
  %t290.not = icmp eq i64 %v3457, 0
  br i1 %t290.not, label %edge261, label %edge262

edge261:                                          ; preds = %edge259
  %t292 = insertvalue { i64, i64 } poison, i64 %v3458, 0
  %t293 = insertvalue { i64, i64 } %t292, i64 180, 1
  br label %common.ret

edge262:                                          ; preds = %edge259
  %t291 = inttoptr i64 %v3458 to ptr
  store i64 2, ptr %t291, align 1
  %v3411 = tail call i64 @mech_compact_release_owner(i64 %v0, i64 %v3458)
  %t286.not = icmp eq i64 %v3411, 0
  br i1 %t286.not, label %edge275, label %edge256

edge267:                                          ; preds = %edge278
  %t297 = insertvalue { i64, i64 } poison, i64 %v3610, 0
  %t298 = insertvalue { i64, i64 } %t297, i64 189, 1
  br label %common.ret

edge275:                                          ; preds = %edge262
  %t299 = tail call { i64, i64 } @mech_compact_allocate_backing(i64 %v0, i64 547, i64 4, i64 4, i64 1)
  %v3652 = extractvalue { i64, i64 } %t299, 0
  %v3653 = extractvalue { i64, i64 } %t299, 1
  %t300.not = icmp eq i64 %v3652, 0
  br i1 %t300.not, label %edge277, label %edge278

edge277:                                          ; preds = %edge275
  %t302 = insertvalue { i64, i64 } poison, i64 %v3653, 0
  %t303 = insertvalue { i64, i64 } %t302, i64 193, 1
  br label %common.ret

edge278:                                          ; preds = %edge275
  %t301 = inttoptr i64 %v3653 to ptr
  store i64 2, ptr %t301, align 1
  %v3610 = tail call i64 @mech_compact_release_owner(i64 %v0, i64 %v3653)
  %t296.not = icmp eq i64 %v3610, 0
  br i1 %t296.not, label %edge290, label %edge267

edge282:                                          ; preds = %edge293
  %t307 = insertvalue { i64, i64 } poison, i64 %v3817, 0
  %t308 = insertvalue { i64, i64 } %t307, i64 202, 1
  br label %common.ret

edge290:                                          ; preds = %edge278
  %t309 = tail call { i64, i64 } @mech_compact_allocate_backing(i64 %v0, i64 259, i64 4, i64 4, i64 1)
  %v3867 = extractvalue { i64, i64 } %t309, 0
  %v3868 = extractvalue { i64, i64 } %t309, 1
  %t310.not = icmp eq i64 %v3867, 0
  br i1 %t310.not, label %edge292, label %edge293

edge292:                                          ; preds = %edge290
  %t312 = insertvalue { i64, i64 } poison, i64 %v3868, 0
  %t313 = insertvalue { i64, i64 } %t312, i64 206, 1
  br label %common.ret

edge293:                                          ; preds = %edge290
  %t311 = inttoptr i64 %v3868 to ptr
  store i64 2, ptr %t311, align 1
  %v3817 = tail call i64 @mech_compact_release_owner(i64 %v0, i64 %v3868)
  %t306.not = icmp eq i64 %v3817, 0
  br i1 %t306.not, label %edge305, label %edge282

edge297:                                          ; preds = %edge308
  %t317 = insertvalue { i64, i64 } poison, i64 %v4044, 0
  %t318 = insertvalue { i64, i64 } %t317, i64 215, 1
  br label %common.ret

edge305:                                          ; preds = %edge293
  %t319 = tail call { i64, i64 } @mech_compact_allocate_backing(i64 %v0, i64 259, i64 4, i64 4, i64 1)
  %v4086 = extractvalue { i64, i64 } %t319, 0
  %v4087 = extractvalue { i64, i64 } %t319, 1
  %t320.not = icmp eq i64 %v4086, 0
  br i1 %t320.not, label %edge307, label %edge308

edge307:                                          ; preds = %edge305
  %t322 = insertvalue { i64, i64 } poison, i64 %v4087, 0
  %t323 = insertvalue { i64, i64 } %t322, i64 219, 1
  br label %common.ret

edge308:                                          ; preds = %edge305
  %t321 = inttoptr i64 %v4087 to ptr
  store i64 2, ptr %t321, align 1
  %v4044 = tail call i64 @mech_compact_release_owner(i64 %v0, i64 %v4087)
  %t316.not = icmp eq i64 %v4044, 0
  br i1 %t316.not, label %edge320, label %edge297

edge312:                                          ; preds = %edge323
  %t327 = insertvalue { i64, i64 } poison, i64 %v4275, 0
  %t328 = insertvalue { i64, i64 } %t327, i64 228, 1
  br label %common.ret

edge320:                                          ; preds = %edge308
  %t329 = tail call { i64, i64 } @mech_compact_allocate_backing(i64 %v0, i64 10, i64 4, i64 4, i64 1)
  %v4329 = extractvalue { i64, i64 } %t329, 0
  %v4330 = extractvalue { i64, i64 } %t329, 1
  %t330.not = icmp eq i64 %v4329, 0
  br i1 %t330.not, label %edge322, label %edge323

edge322:                                          ; preds = %edge320
  %t332 = insertvalue { i64, i64 } poison, i64 %v4330, 0
  %t333 = insertvalue { i64, i64 } %t332, i64 232, 1
  br label %common.ret

edge323:                                          ; preds = %edge320
  %t331 = inttoptr i64 %v4330 to ptr
  store i64 2, ptr %t331, align 1
  %v4275 = tail call i64 @mech_compact_release_owner(i64 %v0, i64 %v4330)
  %t326.not = icmp eq i64 %v4275, 0
  br i1 %t326.not, label %edge335, label %edge312

edge327:                                          ; preds = %edge338
  %t337 = insertvalue { i64, i64 } poison, i64 %v4530, 0
  %t338 = insertvalue { i64, i64 } %t337, i64 241, 1
  br label %common.ret

edge335:                                          ; preds = %edge323
  %t339 = tail call { i64, i64 } @mech_compact_allocate_backing(i64 %v0, i64 10, i64 4, i64 4, i64 1)
  %v4572 = extractvalue { i64, i64 } %t339, 0
  %v4573 = extractvalue { i64, i64 } %t339, 1
  %t340.not = icmp eq i64 %v4572, 0
  br i1 %t340.not, label %edge337, label %edge338

edge337:                                          ; preds = %edge335
  %t342 = insertvalue { i64, i64 } poison, i64 %v4573, 0
  %t343 = insertvalue { i64, i64 } %t342, i64 245, 1
  br label %common.ret

edge338:                                          ; preds = %edge335
  %t341 = inttoptr i64 %v4573 to ptr
  store i64 2, ptr %t341, align 1
  %v4530 = tail call i64 @mech_compact_release_owner(i64 %v0, i64 %v4573)
  %t336.not = icmp eq i64 %v4530, 0
  br i1 %t336.not, label %edge350, label %edge327

edge342:                                          ; preds = %edge351
  %t347 = insertvalue { i64, i64 } poison, i64 %v4785, 0
  %t348 = insertvalue { i64, i64 } %t347, i64 254, 1
  br label %common.ret

edge343:                                          ; preds = %edge351
  %spec.select18 = tail call i64 @llvm.umin.i64(i64 %v1395, i64 32768)
  %t386 = inttoptr i64 %v1399 to ptr
  %t388 = icmp eq i64 %v1397, 1
  %t389 = icmp eq i64 %v1398, 1
  %v636946 = or i1 %t388, %t389
  %v138697 = ptrtoint ptr %ss3 to i64
  %t403 = getelementptr inbounds nuw i8, ptr %ss3, i64 16
  %t408 = getelementptr inbounds nuw i8, ptr %ss3, i64 32
  %t410 = zext i64 %v1394 to i128
  %t411 = shl nuw i128 %t410, 64
  %v138704 = or disjoint i128 %t411, 256
  %t413 = getelementptr inbounds nuw i8, ptr %ss3, i64 48
  %t414 = zext i64 %v1395 to i128
  %t415 = zext i64 %v1397 to i128
  %t416 = shl nuw i128 %t415, 64
  %v138706 = or disjoint i128 %t416, %t414
  %t418 = getelementptr inbounds nuw i8, ptr %ss3, i64 64
  %t419 = zext i64 %v1398 to i128
  %t423 = getelementptr inbounds nuw i8, ptr %ss3, i64 80
  %t424 = getelementptr inbounds nuw i8, ptr %ss3, i64 96
  %v6374 = ptrtoint ptr %ss4 to i64
  %t583 = getelementptr inbounds nuw i8, ptr %ss3, i64 112
  %t585 = zext nneg i64 %v3132 to i128
  %t586 = shl nuw nsw i128 %t585, 64
  %t588 = getelementptr inbounds nuw i8, ptr %ss3, i64 128
  %t591 = shl nuw i128 %t414, 64
  %v138728 = or disjoint i128 %t591, %t410
  %t593 = getelementptr inbounds nuw i8, ptr %ss3, i64 144
  %t598 = getelementptr inbounds nuw i8, ptr %ss3, i64 160
  %t603 = getelementptr inbounds nuw i8, ptr %ss3, i64 176
  %t608 = getelementptr inbounds nuw i8, ptr %ss3, i64 192
  %t613 = getelementptr inbounds nuw i8, ptr %ss3, i64 208
  %t620 = getelementptr inbounds nuw i8, ptr %ss4, i64 8
  %t623 = getelementptr inbounds nuw i8, ptr %ss4, i64 24
  %t626 = getelementptr inbounds nuw i8, ptr %ss4, i64 40
  %t629 = getelementptr inbounds nuw i8, ptr %ss4, i64 56
  %t632 = getelementptr inbounds nuw i8, ptr %ss4, i64 72
  %t635 = getelementptr inbounds nuw i8, ptr %ss4, i64 88
  %t638 = getelementptr inbounds nuw i8, ptr %ss4, i64 104
  %t640 = getelementptr inbounds nuw i8, ptr %ss4, i64 120
  %v138789 = ptrtoint ptr %ss5 to i64
  %t730 = getelementptr inbounds nuw i8, ptr %ss5, i64 16
  %v10075 = add i64 %v1395, -4
  %v138793 = ptrtoint ptr %ss6 to i64
  %t931 = getelementptr inbounds nuw i8, ptr %ss6, i64 16
  %t933 = zext i64 %v0 to i128
  %t934 = shl nuw i128 %t933, 64
  %t936 = getelementptr inbounds nuw i8, ptr %ss6, i64 32
  %t937 = getelementptr inbounds nuw i8, ptr %ss6, i64 48
  %v16121 = add i64 %v1395, -8
  %v138810 = or disjoint i128 %t933, 184467440737095516160
  %v138816 = or disjoint i128 %t933, 4777706715090773868544
  %t692 = getelementptr inbounds nuw i8, ptr %ss4, i64 128
  %t2056 = icmp eq i64 %v1397, 0
  %v137568 = ptrtoint ptr %ss2 to i64
  %v138890 = or disjoint i128 %t586, 1
  %t2252 = zext i64 ptrtoint (ptr @mech_compact_table_18 to i64) to i128
  %v138896 = or disjoint i128 %t2252, 4722366482869645213696
  %t2274 = getelementptr inbounds nuw i8, ptr %ss4, i64 48
  %t2277 = getelementptr inbounds nuw i8, ptr %ss4, i64 64
  %t2280 = getelementptr inbounds nuw i8, ptr %ss4, i64 80
  %t2462 = zext i64 ptrtoint (ptr @mech_compact_table_7 to i64) to i128
  %t2463 = shl nuw i128 %t2462, 64
  %v138924 = or disjoint i128 %t2463, 320
  %t2473 = shl nuw i128 %t2252, 64
  %v138928 = or disjoint i128 %t2473, 259
  %v139034 = or disjoint i128 %t933, 313594649253062377472
  %t3606 = zext i64 ptrtoint (ptr @mech_compact_table_19 to i64) to i128
  %v139046 = or disjoint i128 %t3606, 4722366482869645213696
  %t4171 = zext i64 ptrtoint (ptr @mech_compact_table_11 to i64) to i128
  %t4172 = shl nuw i128 %t4171, 64
  %v139088 = or disjoint i128 %t4171, 10090369008319124733952
  %v139098 = or disjoint i128 %t585, 18446744073709551616
  br label %block9353

edge350:                                          ; preds = %edge338
  %t349 = tail call { i64, i64 } @mech_compact_allocate_backing(i64 %v0, i64 10, i64 4, i64 4, i64 1)
  %v4827 = extractvalue { i64, i64 } %t349, 0
  %v4828 = extractvalue { i64, i64 } %t349, 1
  %t350.not = icmp eq i64 %v4827, 0
  br i1 %t350.not, label %edge352, label %edge351

edge351:                                          ; preds = %edge350
  %t351 = inttoptr i64 %v4828 to ptr
  store i64 2, ptr %t351, align 1
  %v4785 = tail call i64 @mech_compact_release_owner(i64 %v0, i64 %v4828)
  %t346.not = icmp eq i64 %v4785, 0
  br i1 %t346.not, label %edge343, label %edge342

edge352:                                          ; preds = %edge350
  %t352 = insertvalue { i64, i64 } poison, i64 %v4828, 0
  %t353 = insertvalue { i64, i64 } %t352, i64 258, 1
  br label %common.ret

edge367:                                          ; preds = %block9353
  %v5669 = add nuw i64 %v137813, 300000
  %t362.not = icmp ugt i64 %v137813, -300001
  br i1 %t362.not, label %block39122, label %block323

edge375:                                          ; preds = %block323
  %t367.not = icmp ult i64 %v5790, %v137813
  br i1 %t367.not, label %block39122, label %edge377

edge377:                                          ; preds = %edge375
  %v5793 = sub nuw i64 %v5790, %v137813
  %t369 = icmp ult i64 %v5793, 512
  br i1 %t369, label %block473, label %edge391

edge388:                                          ; preds = %edge392
  %t375 = insertvalue { i64, i64 } poison, i64 %v6049, 0
  %t376 = insertvalue { i64, i64 } %t375, i64 339, 1
  br label %common.ret

edge389:                                          ; preds = %edge392
  %v6346 = call i64 @llvm.umin.i64(i64 %v5793, i64 4096)
  br i1 %t23.not, label %block364.preheader, label %edge401

edge391:                                          ; preds = %edge377
  %t377 = call { i64, i64 } @mech_compact_allocate_backing(i64 %v0, i64 256, i64 1, i64 1, i64 1)
  %v6111 = extractvalue { i64, i64 } %t377, 0
  %v6112 = extractvalue { i64, i64 } %t377, 1
  %t378.not = icmp eq i64 %v6111, 0
  br i1 %t378.not, label %edge393, label %edge392

edge392:                                          ; preds = %edge391
  %t379 = inttoptr i64 %v6112 to ptr
  store i64 2, ptr %t379, align 1
  %v6049 = call i64 @mech_compact_release_owner(i64 %v0, i64 %v6112)
  %t374.not = icmp eq i64 %v6049, 0
  br i1 %t374.not, label %edge389, label %edge388

edge393:                                          ; preds = %edge391
  %t380 = insertvalue { i64, i64 } poison, i64 %v6112, 0
  %t381 = insertvalue { i64, i64 } %t380, i64 343, 1
  br label %common.ret

edge401:                                          ; preds = %edge389
  %v6347 = load i64, ptr %t386, align 1
  %v6348 = add i64 %v6347, 1
  store i64 %v6348, ptr %t386, align 1
  br label %block364.preheader

block364.preheader:                               ; preds = %edge389, %edge401
  br label %block364

edge408:                                          ; preds = %block364
  %t392 = inttoptr i64 %v6393 to ptr
  %v6370 = load i64, ptr %t392, align 1
  %t393 = icmp eq i64 %v6370, 1
  br i1 %t393, label %edge410, label %block374

edge410:                                          ; preds = %edge408
  %t395 = zext i64 %v137813 to i128
  %t396 = zext nneg i64 %v6346 to i128
  %t397 = shl nuw nsw i128 %t396, 64
  %v138698 = or disjoint i128 %t397, %t395
  store i128 %v138698, ptr %ss3, align 16
  %t399 = zext nneg i64 %v6398 to i128
  %t400 = zext i64 %v6399 to i128
  %t401 = shl nuw i128 %t400, 64
  %v138700 = or disjoint i128 %t401, %t399
  store i128 %v138700, ptr %t403, align 16
  store i128 18446744073709551872, ptr %t408, align 16
  store i128 %v138704, ptr %t413, align 16
  store i128 %v138706, ptr %t418, align 16
  %t420 = zext i64 %v6393 to i128
  %t421 = shl nuw i128 %t420, 64
  %v138708 = or disjoint i128 %t421, %t419
  store i128 %v138708, ptr %t423, align 16
  store i64 256, ptr %t424, align 16
  %t425 = call { i64, i64 } @mech_compact_numeric_362_vector(i64 %v0, i64 %v138697, i64 %v6374)
  %v6377 = extractvalue { i64, i64 } %t425, 0
  %t426.not = icmp eq i64 %v6377, 0
  br i1 %t426.not, label %edge414, label %edge413

edge413:                                          ; preds = %edge410
  %v6378 = extractvalue { i64, i64 } %t425, 1
  %t427 = icmp eq i64 %v6377, 103169
  %v6383 = select i1 %t427, i64 103425, i64 %v6377
  %t429 = insertvalue { i64, i64 } poison, i64 %v6383, 0
  %t430 = insertvalue { i64, i64 } %t429, i64 %v6378, 1
  br label %common.ret

edge414:                                          ; preds = %edge410
  br i1 %t23.not, label %block427.preheader, label %edge415

edge415:                                          ; preds = %edge414
  %v6387 = call i64 @mech_compact_release_nullable(i64 %v0, i64 %v1399)
  %t432.not = icmp eq i64 %v6387, 0
  br i1 %t432.not, label %block427.preheader, label %edge417

edge417:                                          ; preds = %edge415
  %t433 = insertvalue { i64, i64 } poison, i64 %v6387, 0
  %t434 = insertvalue { i64, i64 } %t433, i64 362, 1
  br label %common.ret

edge422:                                          ; preds = %block374
  %v6527 = add i64 %v6398, %v137813
  %t438.not = icmp ult i64 %v6527, %v137813
  br i1 %t438.not, label %block39122, label %edge424

edge424:                                          ; preds = %edge422
  %t440 = call { i64, i64, i64 } @mech_compact_checked_layout_continuation_8603(i64 %v6527, i64 %v1395, i64 %v1397, i64 %v1398, i64 %v1394)
  %v138385 = extractvalue { i64, i64, i64 } %t440, 0
  %v138387 = extractvalue { i64, i64, i64 } %t440, 2
  %t441 = icmp eq i64 %v138385, 2
  br i1 %t441, label %edge427, label %edge428

edge427:                                          ; preds = %edge424
  %v138386 = extractvalue { i64, i64, i64 } %t440, 1
  %v138389 = add i64 %v138387, 379
  %t443 = insertvalue { i64, i64 } poison, i64 %v138386, 0
  %t444 = insertvalue { i64, i64 } %t443, i64 %v138389, 1
  br label %common.ret

edge428:                                          ; preds = %edge424
  %t445.not = icmp eq i64 %v138387, -1
  br i1 %t445.not, label %block39122, label %edge429

edge429:                                          ; preds = %edge428
  %t447 = icmp ult i64 %v138387, 256
  br i1 %t447, label %edge432, label %block9671

edge432:                                          ; preds = %edge429
  %v6668 = add i64 %v138387, %v6399
  %t449 = inttoptr i64 %v6668 to ptr
  %t450 = load i8, ptr %t449, align 1
  %t451 = icmp eq i8 %t450, 1
  br i1 %t451, label %block9674, label %edge435

edge435:                                          ; preds = %edge432
  br i1 %t391, label %edge436, label %block9676

edge436:                                          ; preds = %edge435
  %t454 = inttoptr i64 %v6393 to ptr
  %v6685 = load i64, ptr %t454, align 1
  %t455 = icmp eq i64 %v6685, 1
  br i1 %t455, label %block9675, label %block9676

edge444:                                          ; preds = %block9674
  %t464 = inttoptr i64 %v6678 to ptr
  %v6696 = load i64, ptr %t464, align 1
  %v6697 = add i64 %v6696, 1
  store i64 %v6697, ptr %t464, align 1
  br label %block9680

edge447:                                          ; preds = %block9680
  %v6702 = call i64 @mech_compact_release_owner(i64 %v0, i64 %v6393)
  %t468.not = icmp eq i64 %v6702, 0
  br i1 %t468.not, label %edge454, label %block9671

edge454:                                          ; preds = %block9680, %edge447
  %v6832 = add nuw nsw i64 %v6398, 1
  br label %block364

edge455:                                          ; preds = %block374
  br i1 %t23.not, label %block427.preheader, label %edge456

block427.preheader:                               ; preds = %edge415, %edge414, %edge459, %edge456, %edge455
  br label %block427

edge456:                                          ; preds = %edge455
  %v6753 = load i64, ptr %t386, align 1
  %v6754 = add i64 %v6753, -1
  store i64 %v6754, ptr %t386, align 1
  %t477.not = icmp eq i64 %v6754, 0
  br i1 %t477.not, label %edge459, label %block427.preheader

edge459:                                          ; preds = %edge456
  %v6755 = call i64 @mech_compact_free(i64 %v0, i64 %v1399)
  %t478.not = icmp eq i64 %v6755, 0
  br i1 %t478.not, label %block427.preheader, label %edge460

edge460:                                          ; preds = %edge459
  %t479 = insertvalue { i64, i64 } poison, i64 %v6755, 0
  %t480 = insertvalue { i64, i64 } %t479, i64 399, 1
  br label %common.ret

edge470:                                          ; preds = %edge485
  %t484.not = icmp eq i64 %v6393, 0
  br i1 %t484.not, label %block449, label %edge471

edge471:                                          ; preds = %edge470
  %t485 = inttoptr i64 %v6393 to ptr
  %v6943 = load i64, ptr %t485, align 1
  %v6944 = add i64 %v6943, -1
  store i64 %v6944, ptr %t485, align 1
  %t487.not = icmp eq i64 %v6944, 0
  br i1 %t487.not, label %edge474, label %block449

edge474:                                          ; preds = %edge471
  %v6945 = call i64 @mech_compact_free(i64 %v0, i64 %v6393)
  %t488.not = icmp eq i64 %v6945, 0
  br i1 %t488.not, label %block449, label %edge475

edge475:                                          ; preds = %edge474
  %t489 = insertvalue { i64, i64 } poison, i64 %v6945, 0
  %t490 = insertvalue { i64, i64 } %t489, i64 423, 1
  br label %common.ret

edge485:                                          ; preds = %block427
  %v7026 = add nuw nsw i64 %v137625, 1
  %exitcond19699.not = icmp eq i64 %v7026, 256
  br i1 %exitcond19699.not, label %edge470, label %block427

edge488:                                          ; preds = %block449
  %v7403 = add i64 %v7142, ptrtoint (ptr @mech_compact_table_6 to i64)
  %t503 = inttoptr i64 %v7403 to ptr
  %t504 = load i8, ptr %t503, align 1
  %v7404 = zext i8 %t504 to i64
  br label %block473

edge496:                                          ; preds = %block473
  %v7563 = load i64, ptr %t386, align 1
  %v7564 = add i64 %v7563, 1
  store i64 %v7564, ptr %t386, align 1
  br label %block9976.outer.preheader

block9976.outer.preheader:                        ; preds = %block473, %edge496
  br label %block9976.outer.outer

edge503:                                          ; preds = %block9976
  %t512 = inttoptr i64 %v138626 to ptr
  %v7608 = load i64, ptr %t512, align 1
  %t513 = icmp eq i64 %v7608, 1
  %t515 = icmp ne i64 %v138627, 0
  %or.cond21 = select i1 %t513, i1 %t515, i1 false
  br i1 %or.cond21, label %edge507, label %block503

edge507:                                          ; preds = %edge503
  %t516 = inttoptr i64 %v138627 to ptr
  %v7610 = load i64, ptr %t516, align 1
  %t517 = icmp eq i64 %v7610, 1
  %or.cond22 = select i1 %t517, i1 %t519, i1 false
  br i1 %or.cond22, label %edge511, label %block503

edge511:                                          ; preds = %edge507
  %v7612 = load i64, ptr %t520, align 1
  %t521 = icmp eq i64 %v7612, 1
  %t523 = icmp ne i64 %v138629, 0
  %or.cond23 = select i1 %t521, i1 %t523, i1 false
  br i1 %or.cond23, label %edge515, label %block503

edge515:                                          ; preds = %edge511
  %t524 = inttoptr i64 %v138629 to ptr
  %v7614 = load i64, ptr %t524, align 1
  %t525 = icmp eq i64 %v7614, 1
  %or.cond24 = select i1 %t525, i1 %t527, i1 false
  br i1 %or.cond24, label %edge519, label %block503

edge519:                                          ; preds = %edge515
  %v7616 = load i64, ptr %t528, align 1
  %t529 = icmp eq i64 %v7616, 1
  %t531 = icmp ne i64 %v138631, 0
  %or.cond25 = select i1 %t529, i1 %t531, i1 false
  br i1 %or.cond25, label %edge523, label %block503

edge523:                                          ; preds = %edge519
  %t532 = inttoptr i64 %v138631 to ptr
  %v7618 = load i64, ptr %t532, align 1
  %t533 = icmp eq i64 %v7618, 1
  br i1 %t533, label %edge529, label %block503

edge529:                                          ; preds = %edge523
  %t540 = icmp ule i64 %v138634, %v138635
  %t541 = icmp ule i64 %v138635, %v1395
  %v763850 = and i1 %t540, %t541
  %v7641 = or i64 %v138637, %v138636
  %t543 = icmp ult i64 %v7641, 65536
  %v764351 = and i1 %v763850, %t543
  br i1 %v764351, label %edge531, label %block503

edge531:                                          ; preds = %edge529
  %t545 = zext nneg i64 %v138636 to i128
  %t546 = zext nneg i64 %v138637 to i128
  %t547 = shl nuw nsw i128 %t546, 64
  %v138710 = or disjoint i128 %t547, %t545
  store i128 %v138710, ptr %ss3, align 16
  %t549 = zext i64 %v138634 to i128
  %t550 = zext i64 %v138638 to i128
  %t551 = shl nuw i128 %t550, 64
  %v138712 = or disjoint i128 %t551, %t549
  store i128 %v138712, ptr %t403, align 16
  %t554 = zext i64 %v138635 to i128
  %t555 = zext i64 %v138639 to i128
  %t556 = shl nuw i128 %t555, 64
  %v138714 = or disjoint i128 %t556, %t554
  store i128 %v138714, ptr %t408, align 16
  %t559 = zext i64 %v138640 to i128
  %t560 = zext i64 %v138641 to i128
  %t561 = shl nuw i128 %t560, 64
  %v138716 = or disjoint i128 %t561, %t559
  store i128 %v138716, ptr %t413, align 16
  %t564 = zext i64 %v138642 to i128
  %t565 = zext i64 %v138643 to i128
  %t566 = shl nuw i128 %t565, 64
  %v138718 = or disjoint i128 %t566, %t564
  store i128 %v138718, ptr %t418, align 16
  %t569 = zext i64 %v138644 to i128
  %t570 = zext i64 %v138645 to i128
  %t571 = shl nuw i128 %t570, 64
  %v138720 = or disjoint i128 %t571, %t569
  store i128 %v138720, ptr %t423, align 16
  %t574 = zext i64 %v138646 to i128
  %t575 = zext i64 %v138647 to i128
  %t576 = shl nuw i128 %t575, 64
  %v138722 = or disjoint i128 %t576, %t574
  store i128 %v138722, ptr %t424, align 16
  %t579 = zext i64 %v138648 to i128
  %t580 = zext i64 %v138649 to i128
  %t581 = shl nuw i128 %t580, 64
  %v138724 = or disjoint i128 %t581, %t579
  store i128 %v138724, ptr %t583, align 16
  %t584 = zext i64 %v138650 to i128
  %v138726 = or disjoint i128 %t586, %t584
  store i128 %v138726, ptr %t588, align 16
  store i128 %v138728, ptr %t593, align 16
  store i128 %v138730, ptr %t598, align 16
  %t599 = zext i64 %v138652 to i128
  %v138732 = or disjoint i128 %t599, 4777706715090773868544
  store i128 %v138732, ptr %t603, align 16
  store i128 %v138734, ptr %t608, align 16
  %t609 = zext i64 %v138654 to i128
  %v138736 = or disjoint i128 %t609, 184467440737095516160
  store i128 %v138736, ptr %t613, align 16
  %t614 = call { i64, i64 } @mech_compact_numeric_475_vector(i64 %v0, i64 %v138697, i64 %v6374)
  %v7648 = extractvalue { i64, i64 } %t614, 0
  %v7649 = extractvalue { i64, i64 } %t614, 1
  switch i64 %v7648, label %edge568 [
    i64 103172, label %edge534
    i64 0, label %edge569
  ]

edge534:                                          ; preds = %edge531
  %t617 = icmp eq i64 %v7649, 510
  br i1 %t617, label %edge536, label %common.ret

edge536:                                          ; preds = %edge534
  %v138738 = load i128, ptr %t620, align 8
  %v138739 = trunc i128 %v138738 to i64
  %t621 = lshr i128 %v138738, 64
  %v138740 = trunc nuw i128 %t621 to i64
  %v138742 = load i128, ptr %t623, align 8
  %v138743 = trunc i128 %v138742 to i64
  %t624 = lshr i128 %v138742, 64
  %v138744 = trunc nuw i128 %t624 to i64
  %v138746 = load i128, ptr %t626, align 8
  %v138747 = trunc i128 %v138746 to i64
  %t627 = lshr i128 %v138746, 64
  %v138748 = trunc nuw i128 %t627 to i64
  %v138750 = load i128, ptr %t629, align 8
  %v138751 = trunc i128 %v138750 to i64
  %t630 = lshr i128 %v138750, 64
  %v138752 = trunc nuw i128 %t630 to i64
  %v138754 = load i128, ptr %t632, align 8
  %v138755 = trunc i128 %v138754 to i64
  %t633 = lshr i128 %v138754, 64
  %v138756 = trunc nuw i128 %t633 to i64
  %v138758 = load i128, ptr %t635, align 8
  %v138759 = trunc i128 %v138758 to i64
  %t636 = lshr i128 %v138758, 64
  %v138760 = trunc nuw i128 %t636 to i64
  %v138762 = load i128, ptr %t638, align 8
  %v138763 = trunc i128 %v138762 to i64
  %t639 = lshr i128 %v138762, 64
  %v138764 = trunc nuw i128 %t639 to i64
  %v7668 = load i64, ptr %t640, align 8
  %v7669 = load i64, ptr %t512, align 1
  %v7670 = add i64 %v7669, 1
  store i64 %v7670, ptr %t512, align 1
  %v7671 = load i64, ptr %t516, align 1
  %v7672 = add i64 %v7671, 1
  store i64 %v7672, ptr %t516, align 1
  br i1 %t23.not, label %edge547, label %edge544

edge544:                                          ; preds = %edge536
  %v7673 = load i64, ptr %t386, align 1
  %v7674 = add i64 %v7673, 1
  store i64 %v7674, ptr %t386, align 1
  br label %edge547

edge547:                                          ; preds = %edge544, %edge536
  %v7675 = load i64, ptr %t520, align 1
  %v7676 = add i64 %v7675, 1
  store i64 %v7676, ptr %t520, align 1
  %v7677 = load i64, ptr %t524, align 1
  %v7678 = add i64 %v7677, 1
  store i64 %v7678, ptr %t524, align 1
  %v7679 = load i64, ptr %t528, align 1
  %v7680 = add i64 %v7679, 1
  store i64 %v7680, ptr %t528, align 1
  %v7681 = load i64, ptr %t532, align 1
  %v7682 = add i64 %v7681, 1
  store i64 %v7682, ptr %t532, align 1
  %v7687 = call i64 @mech_compact_release_four(i64 %v0, i64 %v138626, i64 %v138627, i64 %v1399, i64 %v138628.ph.ph)
  %t663.not = icmp eq i64 %v7687, 0
  br i1 %t663.not, label %edge563, label %block9974

edge563:                                          ; preds = %edge547
  %v7691 = call i64 @mech_compact_release_three(i64 %v0, i64 %v138629, i64 %v138630.ph.ph, i64 %v138631)
  %t665.not = icmp eq i64 %v7691, 0
  br i1 %t665.not, label %edge594, label %block9974

edge568:                                          ; preds = %edge531
  %t669 = icmp eq i64 %v7648, 103169
  %v7694 = select i1 %t669, i64 103425, i64 %v7648
  %t671 = insertvalue { i64, i64 } poison, i64 %v7694, 0
  %t672 = insertvalue { i64, i64 } %t671, i64 %v7649, 1
  br label %common.ret

edge569:                                          ; preds = %edge531
  %v138766 = load i128, ptr %t620, align 8
  %v138767 = trunc i128 %v138766 to i64
  %t675 = lshr i128 %v138766, 64
  %v138768 = trunc nuw i128 %t675 to i64
  %v7697 = load i64, ptr %t623, align 8
  %v138770 = load i128, ptr %t626, align 8
  %v138771 = trunc i128 %v138770 to i64
  %t679 = lshr i128 %v138770, 64
  %v138772 = trunc nuw i128 %t679 to i64
  %v138774 = load i128, ptr %t629, align 8
  %v138775 = trunc i128 %v138774 to i64
  %t682 = lshr i128 %v138774, 64
  %v138776 = trunc nuw i128 %t682 to i64
  %v138778 = load i128, ptr %t632, align 8
  %v138779 = trunc i128 %v138778 to i64
  %t685 = lshr i128 %v138778, 64
  %v138780 = trunc nuw i128 %t685 to i64
  %v138782 = load i128, ptr %t635, align 8
  %v138783 = trunc i128 %v138782 to i64
  %t688 = lshr i128 %v138782, 64
  %v138784 = trunc nuw i128 %t688 to i64
  %v138786 = load i128, ptr %t638, align 8
  %v138787 = trunc i128 %v138786 to i64
  %t691 = lshr i128 %v138786, 64
  %v138788 = trunc nuw i128 %t691 to i64
  %v7710 = load i64, ptr %t692, align 8
  br i1 %t23.not, label %edge2014, label %edge570

edge570:                                          ; preds = %edge569
  %v7721 = call i64 @mech_compact_release_nullable(i64 %v0, i64 %v1399)
  %t694.not = icmp eq i64 %v7721, 0
  br i1 %t694.not, label %edge2014, label %block9974

edge583:                                          ; preds = %edge639
  %t703 = inttoptr i64 %v8281 to ptr
  %v8225 = load i64, ptr %t703, align 1
  %v8226 = add i64 %v8225, 1
  store i64 %v8226, ptr %t703, align 1
  %v8230 = call i64 @mech_compact_release_owner(i64 %v0, i64 %v8281)
  %t705.not = icmp eq i64 %v8230, 0
  br i1 %t705.not, label %block535, label %block10134

edge594:                                          ; preds = %block503, %edge563
  %v8542 = phi i64 [ 1, %block503 ], [ %v7668, %edge563 ]
  %v8619 = phi i64 [ %v138634, %block503 ], [ %v138743, %edge563 ]
  %v8627 = phi i64 [ %v138638, %block503 ], [ %v138655, %edge563 ]
  %v8738 = phi i64 [ %v7942, %block503 ], [ %v138764, %edge563 ]
  %v8838 = phi i64 [ %v138634, %block503 ], [ %v138656, %edge563 ]
  %v8989 = phi i64 [ %v138643, %block503 ], [ %v138752, %edge563 ]
  %v10615 = phi i64 [ %v138636, %block503 ], [ %v138739, %edge563 ]
  %v12849 = phi i64 [ %v138639, %block503 ], [ %v138744, %edge563 ]
  %v13213 = phi i64 [ %v138637, %block503 ], [ %v138740, %edge563 ]
  %v24556 = phi i64 [ %v138642, %block503 ], [ %v138751, %edge563 ]
  %v25227 = phi i64 [ %v138641, %block503 ], [ %v138748, %edge563 ]
  %v25297 = phi i64 [ %v138646, %block503 ], [ %v138759, %edge563 ]
  %v27570 = phi i64 [ %v138645, %block503 ], [ %v138756, %edge563 ]
  %v27797 = phi i64 [ %v138644, %block503 ], [ %v138755, %edge563 ]
  %v28039 = phi i64 [ %v138640, %block503 ], [ %v138747, %edge563 ]
  %v31751 = phi i64 [ %v138647, %block503 ], [ %v138760, %edge563 ]
  %v31807 = phi i64 [ %v138648, %block503 ], [ %v138763, %edge563 ]
  %t720 = call { i64, i64 } @mech_compact_allocate_backing(i64 %v0, i64 262144, i64 2, i64 2, i64 0)
  %v8280 = extractvalue { i64, i64 } %t720, 0
  %v8281 = extractvalue { i64, i64 } %t720, 1
  %t721.not = icmp eq i64 %v8280, 0
  br i1 %t721.not, label %block10144, label %edge596

edge596:                                          ; preds = %edge594
  store i128 604462909807314587353088, ptr %ss5, align 16
  store i128 18446744073709551616, ptr %t730, align 16
  %v8285 = call i64 @mech_compact_word_collection_10(i64 %v138789, i64 %v138649, i64 %v8280, i64 262144)
  %t731 = icmp eq i64 %v8285, 0
  br i1 %t731, label %edge598, label %block10144

edge598:                                          ; preds = %edge596
  %t733.not = icmp eq i64 %v8281, 0
  br i1 %t733.not, label %block10145, label %edge600

edge600:                                          ; preds = %edge598
  %t734 = inttoptr i64 %v8281 to ptr
  %v8288 = load i64, ptr %t734, align 1
  %v8289 = add i64 %v8288, 1
  store i64 %v8289, ptr %t734, align 1
  br label %block10145

edge606:                                          ; preds = %block10145
  %v8297 = call i64 @mech_compact_release_owner(i64 %v0, i64 %v138626)
  %t739.not = icmp eq i64 %v8297, 0
  br i1 %t739.not, label %edge639, label %block10144

edge639:                                          ; preds = %edge606, %block10145
  br i1 %t733.not, label %block535, label %edge583

edge665:                                          ; preds = %block535
  %v9184 = sub i64 %v8618, %spec.select2
  %v9885 = add i64 %spec.select3, %v8618
  %t801.not = icmp ult i64 %v9885, %v8618
  br i1 %t801.not, label %block39122, label %edge690

edge690:                                          ; preds = %edge665
  %t803.not = icmp ugt i64 %v9885, %v1395
  br i1 %t803.not, label %edge695, label %edge694

edge694:                                          ; preds = %edge690
  %v9955 = add i64 %v8618, 1
  %t815.not = icmp ugt i64 %v9955, %v10075
  br i1 %t815.not, label %edge730, label %edge717

edge695:                                          ; preds = %edge690
  %v9921 = or i64 %v137795, %v1399
  %v9922 = or i64 %v9921, %v137809
  %v9923 = or i64 %v9922, %v137822
  %t805.not = icmp eq i64 %v9923, 0
  br i1 %t805.not, label %block10452, label %edge696

edge696:                                          ; preds = %edge695
  %v9924 = call i64 @mech_compact_release_four(i64 %v0, i64 %v1399, i64 %v137795, i64 %v137809, i64 %v137822)
  %t806.not = icmp eq i64 %v9924, 0
  br i1 %t806.not, label %block10452, label %block10437

edge700:                                          ; preds = %block10452
  %v9929 = call i64 @mech_compact_release_three(i64 %v0, i64 %v137828, i64 %v137836, i64 %v138627)
  %t808.not = icmp eq i64 %v9929, 0
  br i1 %t808.not, label %block10455, label %block10437

edge704:                                          ; preds = %block10455
  %v9934 = call i64 @mech_compact_release_four(i64 %v0, i64 %v1399, i64 %v138628.ph.ph, i64 %v138629, i64 %v138630.ph.ph)
  %t810.not = icmp eq i64 %v9934, 0
  br i1 %t810.not, label %block10458, label %block10437

edge708:                                          ; preds = %block10458
  %v9937 = call i64 @mech_compact_release_two(i64 %v0, i64 %v138631, i64 %v9871)
  %t812.not = icmp eq i64 %v9937, 0
  br i1 %t812.not, label %block39124, label %block10437

edge717:                                          ; preds = %edge694
  br i1 %v636946, label %edge723.thread, label %edge723

edge723.thread:                                   ; preds = %edge717
  %v10170 = add i64 %v9955, %v1394
  %t821 = inttoptr i64 %v10170 to ptr
  %t822 = load i32, ptr %t821, align 1
  %v10171 = zext i32 %t822 to i64
  br label %edge730

edge723:                                          ; preds = %edge717
  %v10173 = call i64 @mech_compact_matrix_word(i64 %v1394, i64 %v9955, i64 %v1397, i64 %v1398, i64 4)
  %t823 = icmp ult i64 %v10173, 4294967296
  br i1 %t823, label %edge730, label %block39122

edge730:                                          ; preds = %edge723.thread, %edge723, %edge694
  %v10368 = phi i64 [ %v10173, %edge723 ], [ 0, %edge694 ], [ %v10171, %edge723.thread ]
  %v10418 = and i64 %v10368, 16777215
  %v10475 = mul nuw nsw i64 %v10418, 506832829
  %v10479 = lshr i64 %v10475, 16
  %v10530 = and i64 %v10479, 65535
  %v10537 = mul nuw nsw i64 %v10368, 506832829
  %v10541 = lshr i64 %v10537, 16
  %v10553 = and i64 %v10541, 65535
  %v10561 = add i64 %v9184, 32768
  %v10601 = and i64 %v10561, 65535
  %v10617 = shl i64 %v10614, 1
  %v10656 = and i64 %v10617, 131070
  %v10703 = or disjoint i64 %v10656, 131073
  %v10696 = shl nuw nsw i64 %v10656, 1
  %v10712 = add i64 %v10729, 262144
  %v10713 = add i64 %v10712, %v10696
  %t829 = inttoptr i64 %v10713 to ptr
  %t830 = load i16, ptr %t829, align 1
  %v10714 = zext i16 %t830 to i64
  %v10739 = or disjoint i64 %v10696, 262146
  %v10740 = add i64 %v10739, %v10729
  %t833 = inttoptr i64 %v10740 to ptr
  %t834 = load i16, ptr %t833, align 1
  %v10741 = zext i16 %t834 to i64
  %t835.not = icmp eq i64 %v9871, 0
  br i1 %t835.not, label %block10615, label %edge757

edge757:                                          ; preds = %edge730
  %t837 = inttoptr i64 %v9871 to ptr
  %v10753 = load i64, ptr %t837, align 1
  %t838 = icmp eq i64 %v10753, 1
  br i1 %t838, label %edge761, label %block10615

edge761:                                          ; preds = %edge757
  %v10763 = trunc i64 %v10561 to i16
  store i16 %v10763, ptr %t829, align 1
  br label %block662.sink.split

edge770:                                          ; preds = %block10615
  %v138288 = extractvalue { i64, i64, i64, i64 } %t846, 1
  %v138292 = add i64 %v138289, 660
  %t849 = insertvalue { i64, i64 } poison, i64 %v138288, 0
  %t850 = insertvalue { i64, i64 } %t849, i64 %v138292, 1
  br label %common.ret

edge773:                                          ; preds = %block10615
  %v10856 = add i64 %v138289, %v10739
  %t853 = inttoptr i64 %v10856 to ptr
  %t854 = load i16, ptr %t853, align 1
  %t855 = icmp eq i16 %t854, %t830
  br i1 %t855, label %block662, label %edge776

edge776:                                          ; preds = %edge773
  %t857.not = icmp eq i64 %v138290, 0
  br i1 %t857.not, label %block10654, label %edge777

edge777:                                          ; preds = %edge776
  %t858 = inttoptr i64 %v138290 to ptr
  %v10873 = load i64, ptr %t858, align 1
  %t859 = icmp eq i64 %v10873, 1
  br i1 %t859, label %block662.sink.split, label %block10654

edge785:                                          ; preds = %block10652
  %t868 = inttoptr i64 %v10879 to ptr
  %v10884 = load i64, ptr %t868, align 1
  %v10885 = add i64 %v10884, 1
  store i64 %v10885, ptr %t868, align 1
  br label %block10658

edge788:                                          ; preds = %block10658
  %v10890 = call i64 @mech_compact_release_owner(i64 %v0, i64 %v138290)
  %t872.not = icmp eq i64 %v10890, 0
  br i1 %t872.not, label %block662, label %block10649

edge793:                                          ; preds = %block662
  %t877.not = icmp ult i64 %v9184, %v10714
  br i1 %t877.not, label %edge797, label %block866

edge797:                                          ; preds = %edge793
  %t880.not = icmp ugt i64 %v8618, %v10075
  br i1 %t880.not, label %edge814, label %edge801

edge801:                                          ; preds = %edge797
  br i1 %v636946, label %edge814.thread579, label %edge807

edge807:                                          ; preds = %edge801
  %v11270 = call i64 @mech_compact_matrix_word(i64 %v1394, i64 %v8618, i64 %v1397, i64 %v1398, i64 4)
  %t888 = icmp ult i64 %v11270, 4294967296
  br i1 %t888, label %edge814.thread, label %block39122

edge814:                                          ; preds = %edge797
  %v11488 = add i64 %spec.select2, -32768
  %v11496 = add i64 %v11488, %v10714
  %t890.not = icmp ugt i64 %v11496, %v10075
  br i1 %t890.not, label %edge833, label %edge820

edge814.thread579:                                ; preds = %edge801
  %v11267 = add i64 %v8618, %v1394
  %t886 = inttoptr i64 %v11267 to ptr
  %t887 = load i32, ptr %t886, align 1
  %15 = and i32 %t887, 16777215
  %v11473581 = zext nneg i32 %15 to i64
  %v11488582 = add i64 %spec.select2, -32768
  %v11496583 = add i64 %v11488582, %v10714
  %t890.not584 = icmp ugt i64 %v11496583, %v10075
  br i1 %t890.not584, label %edge833, label %edge826.thread

edge814.thread:                                   ; preds = %edge807
  %v11473565 = and i64 %v11270, 16777215
  %v11488566 = add i64 %spec.select2, -32768
  %v11496567 = add i64 %v11488566, %v10714
  %t890.not568 = icmp ugt i64 %v11496567, %v10075
  br i1 %t890.not568, label %edge833, label %edge826

edge820:                                          ; preds = %edge814
  br i1 %v636946, label %edge826.thread, label %edge826

edge826.thread:                                   ; preds = %edge820, %edge814.thread579
  %v11473569589 = phi i64 [ 0, %edge820 ], [ %v11473581, %edge814.thread579 ]
  %v11496571588 = phi i64 [ %v11496, %edge820 ], [ %v11496583, %edge814.thread579 ]
  %v11693 = add i64 %v11496571588, %v1394
  %t896 = inttoptr i64 %v11693 to ptr
  %t897 = load i32, ptr %t896, align 1
  %v11694 = zext i32 %t897 to i64
  br label %edge833

edge826:                                          ; preds = %edge814.thread, %edge820
  %v11473569578 = phi i64 [ 0, %edge820 ], [ %v11473565, %edge814.thread ]
  %v11496571575 = phi i64 [ %v11496, %edge820 ], [ %v11496567, %edge814.thread ]
  %v11696 = call i64 @mech_compact_matrix_word(i64 %v1394, i64 %v11496571575, i64 %v1397, i64 %v1398, i64 4)
  %t898 = icmp ult i64 %v11696, 4294967296
  br i1 %t898, label %edge833, label %block39122

edge833:                                          ; preds = %edge826.thread, %edge814.thread579, %edge814.thread, %edge826, %edge814
  %v11496572 = phi i64 [ %v11496571575, %edge826 ], [ %v11496, %edge814 ], [ %v11496567, %edge814.thread ], [ %v11496583, %edge814.thread579 ], [ %v11496571588, %edge826.thread ]
  %v11473570 = phi i64 [ %v11473569578, %edge826 ], [ 0, %edge814 ], [ %v11473565, %edge814.thread ], [ %v11473581, %edge814.thread579 ], [ %v11473569589, %edge826.thread ]
  %v11881 = phi i64 [ %v11696, %edge826 ], [ 0, %edge814 ], [ 0, %edge814.thread ], [ 0, %edge814.thread579 ], [ %v11694, %edge826.thread ]
  %v11899 = and i64 %v11881, 16777215
  %t900 = icmp eq i64 %v11473570, %v11899
  br i1 %t900, label %block850, label %edge837

edge837:                                          ; preds = %edge833
  %t903.not = icmp samesign ult i64 %v9184, %v10741
  br i1 %t903.not, label %edge844, label %block866

edge844:                                          ; preds = %edge837
  %v12133 = add i64 %spec.select2, -32768
  %v12137 = add i64 %v12133, %v10741
  %t906.not = icmp ugt i64 %v12137, %v10075
  br i1 %t906.not, label %edge863, label %edge850

edge850:                                          ; preds = %edge844
  br i1 %v636946, label %edge856.thread, label %edge856

edge856.thread:                                   ; preds = %edge850
  %v12330 = add i64 %v12137, %v1394
  %t912 = inttoptr i64 %v12330 to ptr
  %t913 = load i32, ptr %t912, align 1
  %v12331 = zext i32 %t913 to i64
  br label %edge863

edge856:                                          ; preds = %edge850
  %v12333 = call i64 @mech_compact_matrix_word(i64 %v1394, i64 %v12137, i64 %v1397, i64 %v1398, i64 4)
  %t914 = icmp ult i64 %v12333, 4294967296
  br i1 %t914, label %edge863, label %block39122

edge863:                                          ; preds = %edge856.thread, %edge856, %edge844
  %v12518 = phi i64 [ %v12333, %edge856 ], [ 0, %edge844 ], [ %v12331, %edge856.thread ]
  %v12536 = and i64 %v12518, 16777215
  %t916 = icmp eq i64 %v11473570, %v12536
  br i1 %t916, label %block850, label %block866

edge877:                                          ; preds = %block850
  %v12669 = sub i64 %v8618, %v11496572.pn
  %v12811 = shl i64 %v12669, 16
  %v12815 = and i64 %v12811, 4294901760
  %v12834 = or disjoint i64 %v12815, 3
  %v12877 = add i64 %v12848, 1
  %t923 = zext i64 %v12877 to i128
  %v138794 = or disjoint i128 %t586, %t923
  store i128 %v138794, ptr %ss6, align 16
  %t927 = zext i64 %v138650 to i128
  %t928 = zext nneg i64 %v12834 to i128
  %t929 = shl nuw nsw i128 %t928, 64
  %v138796 = or disjoint i128 %t929, %t927
  store i128 %v138796, ptr %t931, align 16
  %t932 = zext i64 %v138627 to i128
  %v138798 = or disjoint i128 %t934, %t932
  store i128 %v138798, ptr %t936, align 16
  store i64 %v3132, ptr %t937, align 16
  %t938 = call { i64, i64, i64, i64 } @mech_compact_checked_layout_16147(i64 %v138793)
  %v138171 = extractvalue { i64, i64, i64, i64 } %t938, 0
  %v138173 = extractvalue { i64, i64, i64, i64 } %t938, 2
  %v138174 = extractvalue { i64, i64, i64, i64 } %t938, 3
  %t939 = icmp ugt i64 %v138171, 1
  br i1 %t939, label %edge884, label %block866

edge884:                                          ; preds = %edge877
  %v138172 = extractvalue { i64, i64, i64, i64 } %t938, 1
  %v138176 = add i64 %v138171, 860
  %t941 = insertvalue { i64, i64 } poison, i64 %v138172, 0
  %t942 = insertvalue { i64, i64 } %t941, i64 %v138176, 1
  br label %common.ret

edge901:                                          ; preds = %block866, %block662
  %v13191 = phi i64 [ %v13155, %block866 ], [ %v138650, %block662 ]
  %v13196 = phi i64 [ %v13160, %block866 ], [ %v138627, %block662 ]
  %v13203 = phi i64 [ %v13161, %block866 ], [ %v12848, %block662 ]
  %v13230 = and i64 %v13212, 65535
  %v13291 = add nuw nsw i64 %v13230, 65537
  %v13286 = shl nuw nsw i64 %v13230, 1
  %v13313 = or disjoint i64 %v13286, 131072
  %v13314 = add i64 %v13313, %v13353
  %t948 = inttoptr i64 %v13314 to ptr
  %t949 = load i16, ptr %t948, align 1
  %v13315 = zext i16 %t949 to i64
  %t950 = call { i64, i64, i64, i64 } @mech_compact_checked_layout_continuation_9112(i64 %v13291, i64 262144, i64 %v13353, i64 %v10601, i64 262144, i64 %v13375, i64 %v0)
  %v138281 = extractvalue { i64, i64, i64, i64 } %t950, 0
  %v138283 = extractvalue { i64, i64, i64, i64 } %t950, 2
  %v138284 = extractvalue { i64, i64, i64, i64 } %t950, 3
  %t951 = icmp eq i64 %v138281, 2
  br i1 %t951, label %edge906, label %edge907

edge906:                                          ; preds = %edge901
  %v138282 = extractvalue { i64, i64, i64, i64 } %t950, 1
  %v138286 = add i64 %v138283, 890
  %t953 = insertvalue { i64, i64 } poison, i64 %v138282, 0
  %t954 = insertvalue { i64, i64 } %t953, i64 %v138286, 1
  br label %common.ret

edge907:                                          ; preds = %edge901
  %v13504 = shl i64 %v9184, 1
  %v13521 = and i64 %v13504, 65534
  %v13525 = or disjoint i64 %v13521, 1
  %t955.not = icmp ult i64 %v9184, %v13315
  br i1 %t955.not, label %edge913, label %edge912

edge912:                                          ; preds = %edge907
  %t958.not = icmp eq i64 %v138284, 0
  br i1 %t958.not, label %block11383, label %edge915

edge913:                                          ; preds = %edge907
  br i1 %t785, label %edge966, label %edge965

edge915:                                          ; preds = %edge912
  %t960 = inttoptr i64 %v138284 to ptr
  %v13617 = load i64, ptr %t960, align 1
  %t961 = icmp eq i64 %v13617, 1
  %v13625 = shl nuw nsw i64 %v13521, 1
  %v13626 = add i64 %v138283, %v13625
  %t963 = inttoptr i64 %v13626 to ptr
  br i1 %t961, label %edge917, label %block11383.thread

edge917:                                          ; preds = %edge915
  store i16 0, ptr %t963, align 1
  %t965 = getelementptr i8, ptr %t963, i64 2
  store i16 0, ptr %t965, align 1
  br label %edge1596

edge935:                                          ; preds = %block11405
  %t981 = inttoptr i64 %v13691 to ptr
  %v13696 = load i64, ptr %t981, align 1
  %v13697 = add i64 %v13696, 1
  store i64 %v13697, ptr %t981, align 1
  br label %block11411

edge938:                                          ; preds = %block11411
  %v13702 = call i64 @mech_compact_release_owner(i64 %v0, i64 %v138284)
  %t985.not = icmp eq i64 %v13702, 0
  br i1 %t985.not, label %edge943, label %block11382

edge943:                                          ; preds = %block11383, %block11383.thread, %block11411, %edge938
  %v13673253273 = phi i64 [ %v13690, %edge938 ], [ %v13690, %block11411 ], [ %v138283, %block11383.thread ], [ %v138283, %block11383 ]
  %v13678254272 = phi i64 [ %v13691, %edge938 ], [ %v13691, %block11411 ], [ %v138284, %block11383.thread ], [ 0, %block11383 ]
  %t980.not69257271 = phi i1 [ %t980.not69, %edge938 ], [ %t980.not69, %block11411 ], [ false, %block11383.thread ], [ true, %block11383 ]
  %v13764 = shl nuw nsw i64 %v13525, 1
  %v13765 = add i64 %v13673253273, %v13764
  %t990 = inttoptr i64 %v13765 to ptr
  %t991 = load i16, ptr %t990, align 1
  %t992 = icmp eq i16 %t991, 0
  br i1 %t992, label %edge1596, label %edge946

edge946:                                          ; preds = %edge943
  br i1 %t980.not69257271, label %block11422, label %edge947

edge947:                                          ; preds = %edge946
  %t995 = inttoptr i64 %v13678254272 to ptr
  %v13782 = load i64, ptr %t995, align 1
  %t996 = icmp eq i64 %v13782, 1
  br i1 %t996, label %block11420, label %block11422

edge955:                                          ; preds = %block11420
  %t1005 = inttoptr i64 %v13781 to ptr
  %v13793 = load i64, ptr %t1005, align 1
  %v13794 = add i64 %v13793, 1
  store i64 %v13794, ptr %t1005, align 1
  br label %block11426

edge958:                                          ; preds = %block11426
  %v13799 = call i64 @mech_compact_release_owner(i64 %v0, i64 %v13678254272)
  %t1009.not = icmp eq i64 %v13799, 0
  br i1 %t1009.not, label %edge1596, label %block11417

edge965:                                          ; preds = %edge913
  br i1 %t23.not, label %block913.preheader, label %edge967

edge966:                                          ; preds = %edge913
  br i1 %t23.not, label %edge1279, label %edge1276

edge967:                                          ; preds = %edge965
  %v14047 = load i64, ptr %t386, align 1
  %v14048 = add i64 %v14047, 1
  store i64 %v14048, ptr %t386, align 1
  br label %block913.preheader

block913.preheader:                               ; preds = %edge965, %edge967
  br label %block913

edge974:                                          ; preds = %block913
  %v14237 = sub nsw i64 %v9184, %v14127
  %v14242 = and i64 %v14237, 32767
  %v14344 = call i64 @llvm.usub.sat.i64(i64 %v8618, i64 %v14242)
  %v14345 = add i64 %v14135, %v14344
  %t1023 = call { i64, i64, i64 } @mech_compact_checked_layout_continuation_8603(i64 %v14345, i64 %v1395, i64 %v1397, i64 %v1398, i64 %v1394)
  %v138390 = extractvalue { i64, i64, i64 } %t1023, 0
  %v138392 = extractvalue { i64, i64, i64 } %t1023, 2
  %t1024 = icmp eq i64 %v138390, 2
  br i1 %t1024, label %edge986, label %edge987

edge986:                                          ; preds = %edge974
  %v138391 = extractvalue { i64, i64, i64 } %t1023, 1
  %v138394 = add i64 %v138392, 958
  %t1026 = insertvalue { i64, i64 } poison, i64 %v138391, 0
  %t1027 = insertvalue { i64, i64 } %t1026, i64 %v138394, 1
  br label %common.ret

edge987:                                          ; preds = %edge974
  %v14468 = add i64 %v14135, %v8618
  %t1028 = call { i64, i64, i64 } @mech_compact_checked_layout_continuation_8603(i64 %v14468, i64 %v1395, i64 %v1397, i64 %v1398, i64 %v1394)
  %v138395 = extractvalue { i64, i64, i64 } %t1028, 0
  %v138397 = extractvalue { i64, i64, i64 } %t1028, 2
  %t1029 = icmp eq i64 %v138395, 2
  br i1 %t1029, label %edge989, label %edge990

edge989:                                          ; preds = %edge987
  %v138396 = extractvalue { i64, i64, i64 } %t1028, 1
  %v138399 = add i64 %v138397, 972
  %t1031 = insertvalue { i64, i64 } poison, i64 %v138396, 0
  %t1032 = insertvalue { i64, i64 } %t1031, i64 %v138399, 1
  br label %common.ret

edge990:                                          ; preds = %edge987
  %t1033 = icmp eq i64 %v138392, %v138397
  br i1 %t1033, label %edge995, label %block1288

edge995:                                          ; preds = %edge990
  %v14675 = add nuw nsw i64 %v14135, 1
  %t1039 = icmp ult i64 %v14344, %v8618
  br i1 %t1039, label %edge1001, label %edge1002

edge1001:                                         ; preds = %edge995
  br i1 %t23.not, label %edge1027.preheader, label %edge1021

edge1002:                                         ; preds = %edge995
  %v14722 = or i64 %v137795, %v1399
  %v14723 = or i64 %v14722, %v137809
  %v14724 = or i64 %v14723, %v137822
  %t1041.not = icmp eq i64 %v14724, 0
  br i1 %t1041.not, label %block11726, label %edge1003

edge1003:                                         ; preds = %edge1002
  %v14725 = call i64 @mech_compact_release_four(i64 %v0, i64 %v1399, i64 %v137795, i64 %v137809, i64 %v137822)
  %t1042.not = icmp eq i64 %v14725, 0
  br i1 %t1042.not, label %block11726, label %block11711

edge1007:                                         ; preds = %block11726
  %v14730 = call i64 @mech_compact_release_three(i64 %v0, i64 %v137828, i64 %v137836, i64 %v1399)
  %t1044.not = icmp eq i64 %v14730, 0
  br i1 %t1044.not, label %block11729, label %block11711

edge1011:                                         ; preds = %block11729
  %v14735 = call i64 @mech_compact_release_four(i64 %v0, i64 %v138628.ph.ph, i64 %v138629, i64 %v138630.ph.ph, i64 %v138631)
  %t1046.not = icmp eq i64 %v14735, 0
  br i1 %t1046.not, label %block11732, label %block11711

edge1015:                                         ; preds = %block11732
  %v14739 = call i64 @mech_compact_release_three(i64 %v0, i64 %v14078, i64 %v14090, i64 %v1399)
  %t1048.not = icmp eq i64 %v14739, 0
  br i1 %t1048.not, label %block39124, label %block11711

edge1021:                                         ; preds = %edge1001
  %v15316 = load i64, ptr %t386, align 1
  %v15317 = add i64 %v15316, 1
  store i64 %v15317, ptr %t386, align 1
  br label %edge1027.preheader

edge1027.preheader:                               ; preds = %edge1001, %edge1021
  br label %edge1027

edge1027:                                         ; preds = %edge1027.preheader, %edge1088
  %v15354 = phi i64 [ %v15410, %edge1088 ], [ %v14675, %edge1027.preheader ]
  %v15410 = add nuw nsw i64 %v15354, 8
  %t1056.not = icmp ugt i64 %v15410, %spec.select3
  br i1 %t1056.not, label %block1017, label %edge1032

edge1032:                                         ; preds = %edge1027
  %v16029 = add i64 %v15354, %v8618
  %t1089.not = icmp ugt i64 %v16029, %v16121
  br i1 %t1089.not, label %edge1075, label %edge1066

edge1037:                                         ; preds = %block1017
  br i1 %t23.not, label %edge1103, label %edge1039

edge1038:                                         ; preds = %block1017
  %v15654 = add i64 %v15551, %v8618
  %t1069 = call { i64, i64, i64 } @mech_compact_checked_layout_continuation_8603(i64 %v15654, i64 %v1395, i64 %v1397, i64 %v1398, i64 %v1394)
  %v138400 = extractvalue { i64, i64, i64 } %t1069, 0
  %v138402 = extractvalue { i64, i64, i64 } %t1069, 2
  %t1070 = icmp eq i64 %v138400, 2
  br i1 %t1070, label %edge1046, label %edge1047

edge1039:                                         ; preds = %edge1037
  %v15565 = load i64, ptr %t386, align 1
  %v15566 = add i64 %v15565, -1
  store i64 %v15566, ptr %t386, align 1
  %t1065.not = icmp eq i64 %v15566, 0
  br i1 %t1065.not, label %edge1042, label %edge1103

edge1042:                                         ; preds = %edge1039
  %v15567 = call i64 @mech_compact_free(i64 %v0, i64 %v1399)
  %t1066.not = icmp eq i64 %v15567, 0
  br i1 %t1066.not, label %edge1103, label %edge1043

edge1043:                                         ; preds = %edge1042
  %t1067 = insertvalue { i64, i64 } poison, i64 %v15567, 0
  %t1068 = insertvalue { i64, i64 } %t1067, i64 1032, 1
  br label %common.ret

edge1046:                                         ; preds = %edge1038
  %v138401 = extractvalue { i64, i64, i64 } %t1069, 1
  %v138404 = add i64 %v138402, 1040
  %t1072 = insertvalue { i64, i64 } poison, i64 %v138401, 0
  %t1073 = insertvalue { i64, i64 } %t1072, i64 %v138404, 1
  br label %common.ret

edge1047:                                         ; preds = %edge1038
  %v15784 = add i64 %v15551, %v14344
  %t1074 = call { i64, i64, i64 } @mech_compact_checked_layout_continuation_8603(i64 %v15784, i64 %v1395, i64 %v1397, i64 %v1398, i64 %v1394)
  %v138405 = extractvalue { i64, i64, i64 } %t1074, 0
  %v138407 = extractvalue { i64, i64, i64 } %t1074, 2
  %t1075 = icmp eq i64 %v138405, 2
  br i1 %t1075, label %edge1049, label %edge1050

edge1049:                                         ; preds = %edge1047
  %v138406 = extractvalue { i64, i64, i64 } %t1074, 1
  %v138409 = add i64 %v138407, 1054
  %t1077 = insertvalue { i64, i64 } poison, i64 %v138406, 0
  %t1078 = insertvalue { i64, i64 } %t1077, i64 %v138409, 1
  br label %common.ret

edge1050:                                         ; preds = %edge1047
  %t1079 = icmp eq i64 %v138402, %v138407
  br i1 %t1079, label %edge1052, label %edge1053

edge1052:                                         ; preds = %edge1050
  %v15998 = add nuw nsw i64 %v15551, 1
  br label %block1017

edge1053:                                         ; preds = %edge1050
  br i1 %t23.not, label %edge1103, label %edge1054

edge1054:                                         ; preds = %edge1053
  %v15917 = load i64, ptr %t386, align 1
  %v15918 = add i64 %v15917, -1
  store i64 %v15918, ptr %t386, align 1
  %t1085.not = icmp eq i64 %v15918, 0
  br i1 %t1085.not, label %edge1057, label %edge1103

edge1057:                                         ; preds = %edge1054
  %v15919 = call i64 @mech_compact_free(i64 %v0, i64 %v1399)
  %t1086.not = icmp eq i64 %v15919, 0
  br i1 %t1086.not, label %edge1103, label %edge1058

edge1058:                                         ; preds = %edge1057
  %t1087 = insertvalue { i64, i64 } poison, i64 %v15919, 0
  %t1088 = insertvalue { i64, i64 } %t1087, i64 1068, 1
  br label %common.ret

edge1066:                                         ; preds = %edge1032
  br i1 %v636946, label %edge1075.thread615, label %edge1075.thread

edge1075:                                         ; preds = %edge1032
  %v16579 = add i64 %v15354, %v14344
  %t1096.not = icmp ugt i64 %v16579, %v16121
  br i1 %t1096.not, label %edge1088, label %edge1079

edge1075.thread615:                               ; preds = %edge1066
  %v16214 = add i64 %v16029, %v1394
  %t1095 = inttoptr i64 %v16214 to ptr
  %v16215 = load i64, ptr %t1095, align 1
  %v16579617 = add i64 %v15354, %v14344
  %t1096.not618 = icmp ugt i64 %v16579617, %v16121
  br i1 %t1096.not618, label %edge1088, label %edge1081

edge1075.thread:                                  ; preds = %edge1066
  %v16217 = call i64 @mech_compact_matrix_word(i64 %v1394, i64 %v16029, i64 %v1397, i64 %v1398, i64 8)
  %v16579606 = add i64 %v15354, %v14344
  %t1096.not607 = icmp ugt i64 %v16579606, %v16121
  br i1 %t1096.not607, label %edge1088, label %edge1082

edge1079:                                         ; preds = %edge1075
  br i1 %v636946, label %edge1081, label %edge1082

edge1081:                                         ; preds = %edge1075.thread615, %edge1079
  %v16569608623 = phi i64 [ 0, %edge1079 ], [ %v16215, %edge1075.thread615 ]
  %v16579610622 = phi i64 [ %v16579, %edge1079 ], [ %v16579617, %edge1075.thread615 ]
  %v16783 = add i64 %v16579610622, %v1394
  %t1102 = inttoptr i64 %v16783 to ptr
  %v16784 = load i64, ptr %t1102, align 1
  br label %edge1088

edge1082:                                         ; preds = %edge1075.thread, %edge1079
  %v16569608614 = phi i64 [ 0, %edge1079 ], [ %v16217, %edge1075.thread ]
  %v16579610613 = phi i64 [ %v16579, %edge1079 ], [ %v16579606, %edge1075.thread ]
  %v16786 = call i64 @mech_compact_matrix_word(i64 %v1394, i64 %v16579610613, i64 %v1397, i64 %v1398, i64 8)
  br label %edge1088

edge1088:                                         ; preds = %edge1075.thread615, %edge1075.thread, %edge1075, %edge1081, %edge1082
  %v16569609 = phi i64 [ %v16569608614, %edge1082 ], [ %v16569608623, %edge1081 ], [ 0, %edge1075 ], [ %v16217, %edge1075.thread ], [ %v16215, %edge1075.thread615 ]
  %v17142 = phi i64 [ %v16786, %edge1082 ], [ %v16784, %edge1081 ], [ 0, %edge1075 ], [ 0, %edge1075.thread ], [ 0, %edge1075.thread615 ]
  %t1103 = icmp eq i64 %v17142, %v16569609
  br i1 %t1103, label %edge1027, label %edge1091

edge1091:                                         ; preds = %edge1088
  %v17158.le = xor i64 %v17142, %v16569609
  br i1 %t23.not, label %block1221, label %edge1092

edge1092:                                         ; preds = %edge1091
  %v17170 = call i64 @mech_compact_release_owner(i64 %v0, i64 %v1399)
  %t1106.not = icmp eq i64 %v17170, 0
  br i1 %t1106.not, label %block1221, label %edge1094

edge1094:                                         ; preds = %edge1092
  %t1107 = insertvalue { i64, i64 } poison, i64 %v17170, 0
  %t1108 = insertvalue { i64, i64 } %t1107, i64 1217, 1
  br label %common.ret

edge1103:                                         ; preds = %block1221, %edge1057, %edge1054, %edge1053, %edge1042, %edge1039, %edge1037
  %v17253 = phi i64 [ %v17249, %block1221 ], [ %v15551, %edge1057 ], [ %v15551, %edge1054 ], [ %v15551, %edge1053 ], [ %v15551, %edge1042 ], [ %v15551, %edge1039 ], [ %v15551, %edge1037 ]
  %t1111 = icmp ugt i64 %v17253, %v14137
  br i1 %t1111, label %edge1106, label %block1288

edge1106:                                         ; preds = %edge1103
  %v17367 = sub i64 %v8618, %v14344
  %v17384 = and i64 %v17253, 65535
  %v17401 = shl i64 %v17367, 16
  %v17401.masked = and i64 %v17401, 4294901760
  %v17423 = or disjoint i64 %v17384, %v17401.masked
  %v17435 = add i64 %v14097, 1
  %t1115 = zext i64 %v17435 to i128
  %v138800 = or disjoint i128 %t586, %t1115
  store i128 %v138800, ptr %ss6, align 16
  %t1119 = zext i64 %v14085 to i128
  %t1120 = zext nneg i64 %v17423 to i128
  %t1121 = shl nuw nsw i128 %t1120, 64
  %v138802 = or disjoint i128 %t1121, %t1119
  store i128 %v138802, ptr %t931, align 16
  %t1124 = zext i64 %v14090 to i128
  %v138804 = or disjoint i128 %t934, %t1124
  store i128 %v138804, ptr %t936, align 16
  store i64 %v3132, ptr %t937, align 16
  %t1130 = call { i64, i64, i64, i64 } @mech_compact_checked_layout_16147(i64 %v138793)
  %v138164 = extractvalue { i64, i64, i64, i64 } %t1130, 0
  %t1131 = icmp ugt i64 %v138164, 1
  br i1 %t1131, label %edge1114, label %edge1115

edge1114:                                         ; preds = %edge1106
  %v138165 = extractvalue { i64, i64, i64, i64 } %t1130, 1
  %v138169 = add i64 %v138164, 1248
  %t1133 = insertvalue { i64, i64 } poison, i64 %v138165, 0
  %t1134 = insertvalue { i64, i64 } %t1133, i64 %v138169, 1
  br label %common.ret

edge1115:                                         ; preds = %edge1106
  %v138167 = extractvalue { i64, i64, i64, i64 } %t1130, 3
  %v138166 = extractvalue { i64, i64, i64, i64 } %t1130, 2
  %t1135.not = icmp ult i64 %v17253, %spec.select3
  br i1 %t1135.not, label %block1288, label %edge1120

edge1120:                                         ; preds = %edge1115
  %v17787 = shl nuw nsw i64 %v14127, 2
  %v17802 = and i64 %v17787, 131068
  %v17812 = add i64 %v17802, %v14073
  %t1138 = inttoptr i64 %v17812 to ptr
  %t1139 = load i16, ptr %t1138, align 1
  %v17813 = zext i16 %t1139 to i64
  %v17823 = add i64 %v14073, 2
  %v17824 = add i64 %v17823, %v17802
  %t1140 = inttoptr i64 %v17824 to ptr
  %t1141 = load i16, ptr %t1140, align 1
  %v17830 = add nuw nsw i64 %v14123, 1
  %t1142.not = icmp eq i64 %v14078, 0
  br i1 %t1142.not, label %block12531, label %edge1132

edge1132:                                         ; preds = %edge1120
  %t1144 = inttoptr i64 %v14078 to ptr
  %v17845 = load i64, ptr %t1144, align 1
  %t1145 = icmp eq i64 %v17845, 1
  br i1 %t1145, label %edge1136, label %block12531

edge1136:                                         ; preds = %edge1132
  %v17853 = shl nuw nsw i64 %v14123, 1
  %v17854 = add i64 %v17853, %v14073
  %t1149 = inttoptr i64 %v17854 to ptr
  store i16 %t1139, ptr %t1149, align 1
  %v17875 = shl nuw nsw i64 %v14125, 1
  %v17876 = add i64 %v17875, %v14073
  %t1152 = inttoptr i64 %v17876 to ptr
  store i16 %t1141, ptr %t1152, align 1
  br label %block12932

edge1145:                                         ; preds = %block12531
  %v138306 = extractvalue { i64, i64, i64, i64 } %t1153, 1
  %v138310 = add i64 %v138307, 1286
  %t1156 = insertvalue { i64, i64 } poison, i64 %v138306, 0
  %t1157 = insertvalue { i64, i64 } %t1156, i64 %v138310, 1
  br label %common.ret

edge1148:                                         ; preds = %block12531
  %v17942 = shl nuw nsw i64 %v14125, 1
  %v17943 = add i64 %v138307, %v17942
  %t1160 = inttoptr i64 %v17943 to ptr
  %t1161 = load i16, ptr %t1160, align 1
  %t1162 = icmp eq i16 %t1161, %t1141
  br i1 %t1162, label %block12932, label %edge1151

edge1151:                                         ; preds = %edge1148
  %t1164.not = icmp eq i64 %v138308, 0
  br i1 %t1164.not, label %block12570, label %edge1152

edge1152:                                         ; preds = %edge1151
  %t1165 = inttoptr i64 %v138308 to ptr
  %v17960 = load i64, ptr %t1165, align 1
  %t1166 = icmp eq i64 %v17960, 1
  br i1 %t1166, label %block12568.thread297, label %block12570

block12568.thread297:                             ; preds = %edge1152
  store i16 %t1141, ptr %t1160, align 1
  br label %block12932

edge1160:                                         ; preds = %block12568
  %t1175 = inttoptr i64 %v17966 to ptr
  %v17971 = load i64, ptr %t1175, align 1
  %v17972 = add i64 %v17971, 1
  store i64 %v17972, ptr %t1175, align 1
  br label %block12574

edge1163:                                         ; preds = %block12574
  %v17977 = call i64 @mech_compact_release_owner(i64 %v0, i64 %v138308)
  %t1179.not = icmp eq i64 %v17977, 0
  br i1 %t1179.not, label %block12932, label %block12565

edge1170:                                         ; preds = %block1288
  %v138411 = extractvalue { i64, i64, i64 } %t1182, 1
  %v138414 = add i64 %v138412, 1294
  %t1185 = insertvalue { i64, i64 } poison, i64 %v138411, 0
  %t1186 = insertvalue { i64, i64 } %t1185, i64 %v138414, 1
  br label %common.ret

edge1171:                                         ; preds = %block1288
  %v18137 = add i64 %v138588, %v8618
  %t1187 = call { i64, i64, i64 } @mech_compact_checked_layout_continuation_8603(i64 %v18137, i64 %v1395, i64 %v1397, i64 %v1398, i64 %v1394)
  %v138415 = extractvalue { i64, i64, i64 } %t1187, 0
  %v138417 = extractvalue { i64, i64, i64 } %t1187, 2
  %t1188 = icmp eq i64 %v138415, 2
  br i1 %t1188, label %edge1173, label %edge1174

edge1173:                                         ; preds = %edge1171
  %v138416 = extractvalue { i64, i64, i64 } %t1187, 1
  %v138419 = add i64 %v138417, 1308
  %t1190 = insertvalue { i64, i64 } poison, i64 %v138416, 0
  %t1191 = insertvalue { i64, i64 } %t1190, i64 %v138419, 1
  br label %common.ret

edge1174:                                         ; preds = %edge1171
  %t1192 = icmp ult i64 %v138412, %v138417
  %v18269 = shl nuw nsw i64 %v14127, 1
  %v18273 = and i64 %v18269, 65534
  %v18277 = or disjoint i64 %v18273, 1
  br i1 %t1192, label %edge1183, label %edge1182

edge1182:                                         ; preds = %edge1174
  br label %edge1183

edge1183:                                         ; preds = %edge1174, %edge1182
  %v18366 = phi i64 [ %v14125, %edge1182 ], [ %v14123, %edge1174 ]
  %v18368 = phi i64 [ %v18273, %edge1182 ], [ %v18277, %edge1174 ]
  %v18370 = phi i64 [ %v14123, %edge1182 ], [ %v18277, %edge1174 ]
  %v18372 = phi i64 [ %v18273, %edge1182 ], [ %v14125, %edge1174 ]
  %v18374 = phi i64 [ %v14131, %edge1182 ], [ %v138588, %edge1174 ]
  %v18376 = phi i64 [ %v138588, %edge1182 ], [ %v14133, %edge1174 ]
  %v18378 = phi i64 [ %v14131, %edge1182 ], [ %v14133, %edge1174 ]
  %v18382 = add nuw nsw i64 %v18366, 1
  %t1195 = call { i64, i64, i64, i64 } @mech_compact_checked_layout_continuation_9562(i64 %v18382, i64 262144, i64 %v14073, i64 %v14127, i64 %v14078, i64 %v0, i64 262144)
  %v138293 = extractvalue { i64, i64, i64, i64 } %t1195, 0
  %v138295 = extractvalue { i64, i64, i64, i64 } %t1195, 2
  %t1196 = icmp eq i64 %v138293, 2
  br i1 %t1196, label %edge1185, label %edge1188

edge1185:                                         ; preds = %edge1183
  %v138294 = extractvalue { i64, i64, i64, i64 } %t1195, 1
  %v138298 = add i64 %v138295, 1344
  %t1198 = insertvalue { i64, i64 } poison, i64 %v138294, 0
  %t1199 = insertvalue { i64, i64 } %t1198, i64 %v138298, 1
  br label %common.ret

edge1188:                                         ; preds = %edge1183
  %v138296 = extractvalue { i64, i64, i64, i64 } %t1195, 3
  %v18434 = shl nuw nsw i64 %v18368, 1
  %v18435 = add i64 %v138295, %v18434
  %t1202 = inttoptr i64 %v18435 to ptr
  %t1203 = load i16, ptr %t1202, align 1
  %v18436 = zext i16 %t1203 to i64
  %v18814 = call i64 @llvm.umin.i64(i64 %v18378, i64 %v138588)
  %v18531 = add nsw i64 %v14129, -1
  %t1207 = icmp ult i64 %v9184, %v18436
  %t1208 = icmp ne i64 %v18531, 0
  %v1854864.not = and i1 %t1208, %t1207
  br i1 %v1854864.not, label %block913, label %edge1201

edge1201:                                         ; preds = %edge1188
  %v18630 = add nuw nsw i64 %v18370, 1
  %t1211.not = icmp eq i64 %v138296, 0
  br i1 %t1211.not, label %block12810, label %edge1204

edge1204:                                         ; preds = %edge1201
  %t1213 = inttoptr i64 %v138296 to ptr
  %v18633 = load i64, ptr %t1213, align 1
  %t1214 = icmp eq i64 %v18633, 1
  br i1 %t1214, label %edge1208, label %block12810

edge1208:                                         ; preds = %edge1204
  %v18641 = shl nuw nsw i64 %v18370, 1
  %v18642 = add i64 %v138295, %v18641
  %t1218 = inttoptr i64 %v18642 to ptr
  store i16 0, ptr %t1218, align 1
  %v18663 = shl nuw nsw i64 %v18372, 1
  %v18664 = add i64 %v138295, %v18663
  %t1221 = inttoptr i64 %v18664 to ptr
  store i16 0, ptr %t1221, align 1
  br label %block12932

edge1217:                                         ; preds = %block12810
  %v138318 = extractvalue { i64, i64, i64, i64 } %t1222, 1
  %v138322 = add i64 %v138319, 1366
  %t1225 = insertvalue { i64, i64 } poison, i64 %v138318, 0
  %t1226 = insertvalue { i64, i64 } %t1225, i64 %v138322, 1
  br label %common.ret

edge1220:                                         ; preds = %block12810
  %v18743 = shl nuw nsw i64 %v18372, 1
  %v18744 = add i64 %v138319, %v18743
  %t1229 = inttoptr i64 %v18744 to ptr
  %t1230 = load i16, ptr %t1229, align 1
  %t1231 = icmp eq i16 %t1230, 0
  br i1 %t1231, label %block12932, label %edge1223

edge1223:                                         ; preds = %edge1220
  %t1233.not = icmp eq i64 %v138320, 0
  br i1 %t1233.not, label %block12849, label %edge1224

edge1224:                                         ; preds = %edge1223
  %t1234 = inttoptr i64 %v138320 to ptr
  %v18761 = load i64, ptr %t1234, align 1
  %t1235 = icmp eq i64 %v18761, 1
  br i1 %t1235, label %block12847.thread318, label %block12849

block12847.thread318:                             ; preds = %edge1224
  store i16 0, ptr %t1229, align 1
  br label %block12932

edge1232:                                         ; preds = %block12847
  %t1244 = inttoptr i64 %v18767 to ptr
  %v18772 = load i64, ptr %t1244, align 1
  %v18773 = add i64 %v18772, 1
  store i64 %v18773, ptr %t1244, align 1
  br label %block12853

edge1235:                                         ; preds = %block12853
  %v18778 = call i64 @mech_compact_release_owner(i64 %v0, i64 %v138320)
  %t1248.not = icmp eq i64 %v18778, 0
  br i1 %t1248.not, label %block12932, label %block12844

edge1250:                                         ; preds = %block12932
  %v18930 = call i64 @mech_compact_release_owner(i64 %v0, i64 %v1399)
  %t1254.not = icmp eq i64 %v18930, 0
  br i1 %t1254.not, label %edge1596, label %edge1252

edge1252:                                         ; preds = %edge1250
  %t1255 = insertvalue { i64, i64 } poison, i64 %v18930, 0
  %t1256 = insertvalue { i64, i64 } %t1255, i64 1403, 1
  br label %common.ret

edge1276:                                         ; preds = %edge966
  %v19450 = load i64, ptr %t386, align 1
  %v19451 = add i64 %v19450, 1
  store i64 %v19451, ptr %t386, align 1
  br label %edge1279

edge1279:                                         ; preds = %edge966, %edge1276
  %v19728 = and i64 %v8988, 65535
  %v9059 = lshr i64 %v8988, 16
  %v19734 = and i64 %v9059, 65535
  %t1280 = icmp samesign ugt i64 %v19734, 1
  %v19831 = add nsw i64 %v19734, -1
  %v19923 = call i64 @llvm.umin.i64(i64 %spec.select3, i64 %v19831)
  br label %block1421

edge1283:                                         ; preds = %block1421
  %v19615 = sub nsw i64 %v9184, %v19509
  %v19620 = and i64 %v19615, 32767
  %v19722 = call i64 @llvm.usub.sat.i64(i64 %v8618, i64 %v19620)
  %v19723 = sub i64 %v8618, %v19722
  %t1279 = icmp eq i64 %v19723, %v19728
  %v1974954 = and i1 %t1280, %t1279
  %t1286 = icmp ugt i64 %v19831, %v19517
  %or.cond10357 = select i1 %v1974954, i1 %t1286, i1 false
  br i1 %or.cond10357, label %edge1323, label %block1490

edge1313:                                         ; preds = %block1490
  %v138421 = extractvalue { i64, i64, i64 } %t1289, 1
  %v138424 = add i64 %v138422, 1497
  %t1292 = insertvalue { i64, i64 } poison, i64 %v138421, 0
  %t1293 = insertvalue { i64, i64 } %t1292, i64 %v138424, 1
  br label %common.ret

edge1314:                                         ; preds = %block1490
  %v20145 = add i64 %v19517, %v8618
  %t1294 = call { i64, i64, i64 } @mech_compact_checked_layout_continuation_8603(i64 %v20145, i64 %v1395, i64 %v1397, i64 %v1398, i64 %v1394)
  %v138425 = extractvalue { i64, i64, i64 } %t1294, 0
  %v138427 = extractvalue { i64, i64, i64 } %t1294, 2
  %t1295 = icmp eq i64 %v138425, 2
  br i1 %t1295, label %edge1316, label %edge1317

edge1316:                                         ; preds = %edge1314
  %v138426 = extractvalue { i64, i64, i64 } %t1294, 1
  %v138429 = add i64 %v138427, 1511
  %t1297 = insertvalue { i64, i64 } poison, i64 %v138426, 0
  %t1298 = insertvalue { i64, i64 } %t1297, i64 %v138429, 1
  br label %common.ret

edge1317:                                         ; preds = %edge1314
  %t1299.not = icmp eq i64 %v138422, %v138427
  %v20359 = add nuw nsw i64 %v19517, 1
  br i1 %t1299.not, label %edge1323, label %block1799

edge1323:                                         ; preds = %edge1283, %edge1317
  %v137629 = phi i64 [ %v19923, %edge1283 ], [ %v20359, %edge1317 ]
  %t1305 = icmp ult i64 %v19722, %v8618
  br i1 %t1305, label %edge1329, label %edge1330

edge1329:                                         ; preds = %edge1323
  br i1 %t23.not, label %edge1355.preheader, label %edge1349

edge1330:                                         ; preds = %edge1323
  %v20486 = or i64 %v137795, %v1399
  %v20487 = or i64 %v20486, %v137809
  %v20488 = or i64 %v20487, %v137822
  %t1307.not = icmp eq i64 %v20488, 0
  br i1 %t1307.not, label %block13403, label %edge1331

edge1331:                                         ; preds = %edge1330
  %v20489 = call i64 @mech_compact_release_four(i64 %v0, i64 %v1399, i64 %v137795, i64 %v137809, i64 %v137822)
  %t1308.not = icmp eq i64 %v20489, 0
  br i1 %t1308.not, label %block13403, label %block13388

edge1335:                                         ; preds = %block13403
  %v20494 = call i64 @mech_compact_release_three(i64 %v0, i64 %v137828, i64 %v137836, i64 %v1399)
  %t1310.not = icmp eq i64 %v20494, 0
  br i1 %t1310.not, label %block13406, label %block13388

edge1339:                                         ; preds = %block13406
  %v20499 = call i64 @mech_compact_release_four(i64 %v0, i64 %v138628.ph.ph, i64 %v138629, i64 %v138630.ph.ph, i64 %v138631)
  %t1312.not = icmp eq i64 %v20499, 0
  br i1 %t1312.not, label %block13409, label %block13388

edge1343:                                         ; preds = %block13409
  %v20503 = call i64 @mech_compact_release_three(i64 %v0, i64 %v13196, i64 %v19480, i64 %v1399)
  %t1314.not = icmp eq i64 %v20503, 0
  br i1 %t1314.not, label %block39124, label %block13388

edge1349:                                         ; preds = %edge1329
  %v20513 = load i64, ptr %t386, align 1
  %v20514 = add i64 %v20513, 1
  store i64 %v20514, ptr %t386, align 1
  br label %edge1355.preheader

edge1355.preheader:                               ; preds = %edge1329, %edge1349
  br label %edge1355

edge1355:                                         ; preds = %edge1355.preheader, %edge1416
  %v20551 = phi i64 [ %v20559, %edge1416 ], [ %v137629, %edge1355.preheader ]
  %v20559 = add nuw nsw i64 %v20551, 8
  %t1322.not = icmp ugt i64 %v20559, %spec.select3
  br i1 %t1322.not, label %block1561, label %edge1360

edge1360:                                         ; preds = %edge1355
  %v21169 = add i64 %v20551, %v8618
  %t1355.not = icmp ugt i64 %v21169, %v16121
  br i1 %t1355.not, label %edge1403, label %edge1394

edge1365:                                         ; preds = %block1561
  br i1 %t23.not, label %edge1431, label %edge1367

edge1366:                                         ; preds = %block1561
  %v20794 = add i64 %v20691, %v8618
  %t1335 = call { i64, i64, i64 } @mech_compact_checked_layout_continuation_8603(i64 %v20794, i64 %v1395, i64 %v1397, i64 %v1398, i64 %v1394)
  %v138430 = extractvalue { i64, i64, i64 } %t1335, 0
  %v138432 = extractvalue { i64, i64, i64 } %t1335, 2
  %t1336 = icmp eq i64 %v138430, 2
  br i1 %t1336, label %edge1374, label %edge1375

edge1367:                                         ; preds = %edge1365
  %v20705 = load i64, ptr %t386, align 1
  %v20706 = add i64 %v20705, -1
  store i64 %v20706, ptr %t386, align 1
  %t1331.not = icmp eq i64 %v20706, 0
  br i1 %t1331.not, label %edge1370, label %edge1431

edge1370:                                         ; preds = %edge1367
  %v20707 = call i64 @mech_compact_free(i64 %v0, i64 %v1399)
  %t1332.not = icmp eq i64 %v20707, 0
  br i1 %t1332.not, label %edge1431, label %edge1371

edge1371:                                         ; preds = %edge1370
  %t1333 = insertvalue { i64, i64 } poison, i64 %v20707, 0
  %t1334 = insertvalue { i64, i64 } %t1333, i64 1580, 1
  br label %common.ret

edge1374:                                         ; preds = %edge1366
  %v138431 = extractvalue { i64, i64, i64 } %t1335, 1
  %v138434 = add i64 %v138432, 1588
  %t1338 = insertvalue { i64, i64 } poison, i64 %v138431, 0
  %t1339 = insertvalue { i64, i64 } %t1338, i64 %v138434, 1
  br label %common.ret

edge1375:                                         ; preds = %edge1366
  %v20924 = add i64 %v20691, %v19722
  %t1340 = call { i64, i64, i64 } @mech_compact_checked_layout_continuation_8603(i64 %v20924, i64 %v1395, i64 %v1397, i64 %v1398, i64 %v1394)
  %v138435 = extractvalue { i64, i64, i64 } %t1340, 0
  %v138437 = extractvalue { i64, i64, i64 } %t1340, 2
  %t1341 = icmp eq i64 %v138435, 2
  br i1 %t1341, label %edge1377, label %edge1378

edge1377:                                         ; preds = %edge1375
  %v138436 = extractvalue { i64, i64, i64 } %t1340, 1
  %v138439 = add i64 %v138437, 1602
  %t1343 = insertvalue { i64, i64 } poison, i64 %v138436, 0
  %t1344 = insertvalue { i64, i64 } %t1343, i64 %v138439, 1
  br label %common.ret

edge1378:                                         ; preds = %edge1375
  %t1345 = icmp eq i64 %v138432, %v138437
  br i1 %t1345, label %edge1380, label %edge1381

edge1380:                                         ; preds = %edge1378
  %v21138 = add nuw nsw i64 %v20691, 1
  br label %block1561

edge1381:                                         ; preds = %edge1378
  br i1 %t23.not, label %edge1431, label %edge1382

edge1382:                                         ; preds = %edge1381
  %v21057 = load i64, ptr %t386, align 1
  %v21058 = add i64 %v21057, -1
  store i64 %v21058, ptr %t386, align 1
  %t1351.not = icmp eq i64 %v21058, 0
  br i1 %t1351.not, label %edge1385, label %edge1431

edge1385:                                         ; preds = %edge1382
  %v21059 = call i64 @mech_compact_free(i64 %v0, i64 %v1399)
  %t1352.not = icmp eq i64 %v21059, 0
  br i1 %t1352.not, label %edge1431, label %edge1386

edge1386:                                         ; preds = %edge1385
  %t1353 = insertvalue { i64, i64 } poison, i64 %v21059, 0
  %t1354 = insertvalue { i64, i64 } %t1353, i64 1616, 1
  br label %common.ret

edge1394:                                         ; preds = %edge1360
  br i1 %v636946, label %edge1403.thread634, label %edge1403.thread

edge1403:                                         ; preds = %edge1360
  %v21719 = add i64 %v20551, %v19722
  %t1362.not = icmp ugt i64 %v21719, %v16121
  br i1 %t1362.not, label %edge1416, label %edge1407

edge1403.thread634:                               ; preds = %edge1394
  %v21354 = add i64 %v21169, %v1394
  %t1361 = inttoptr i64 %v21354 to ptr
  %v21355 = load i64, ptr %t1361, align 1
  %v21719636 = add i64 %v20551, %v19722
  %t1362.not637 = icmp ugt i64 %v21719636, %v16121
  br i1 %t1362.not637, label %edge1416, label %edge1409

edge1403.thread:                                  ; preds = %edge1394
  %v21357 = call i64 @mech_compact_matrix_word(i64 %v1394, i64 %v21169, i64 %v1397, i64 %v1398, i64 8)
  %v21719625 = add i64 %v20551, %v19722
  %t1362.not626 = icmp ugt i64 %v21719625, %v16121
  br i1 %t1362.not626, label %edge1416, label %edge1410

edge1407:                                         ; preds = %edge1403
  br i1 %v636946, label %edge1409, label %edge1410

edge1409:                                         ; preds = %edge1403.thread634, %edge1407
  %v21709627642 = phi i64 [ 0, %edge1407 ], [ %v21355, %edge1403.thread634 ]
  %v21719629641 = phi i64 [ %v21719, %edge1407 ], [ %v21719636, %edge1403.thread634 ]
  %v21923 = add i64 %v21719629641, %v1394
  %t1368 = inttoptr i64 %v21923 to ptr
  %v21924 = load i64, ptr %t1368, align 1
  br label %edge1416

edge1410:                                         ; preds = %edge1403.thread, %edge1407
  %v21709627633 = phi i64 [ 0, %edge1407 ], [ %v21357, %edge1403.thread ]
  %v21719629632 = phi i64 [ %v21719, %edge1407 ], [ %v21719625, %edge1403.thread ]
  %v21926 = call i64 @mech_compact_matrix_word(i64 %v1394, i64 %v21719629632, i64 %v1397, i64 %v1398, i64 8)
  br label %edge1416

edge1416:                                         ; preds = %edge1403.thread634, %edge1403.thread, %edge1403, %edge1409, %edge1410
  %v21709628 = phi i64 [ %v21709627633, %edge1410 ], [ %v21709627642, %edge1409 ], [ 0, %edge1403 ], [ %v21357, %edge1403.thread ], [ %v21355, %edge1403.thread634 ]
  %v22282 = phi i64 [ %v21926, %edge1410 ], [ %v21924, %edge1409 ], [ 0, %edge1403 ], [ 0, %edge1403.thread ], [ 0, %edge1403.thread634 ]
  %t1369 = icmp eq i64 %v22282, %v21709628
  br i1 %t1369, label %edge1355, label %edge1419

edge1419:                                         ; preds = %edge1416
  %v22298.le = xor i64 %v22282, %v21709628
  br i1 %t23.not, label %block1765, label %edge1420

edge1420:                                         ; preds = %edge1419
  %v22310 = call i64 @mech_compact_release_owner(i64 %v0, i64 %v1399)
  %t1372.not = icmp eq i64 %v22310, 0
  br i1 %t1372.not, label %block1765, label %edge1422

edge1422:                                         ; preds = %edge1420
  %t1373 = insertvalue { i64, i64 } poison, i64 %v22310, 0
  %t1374 = insertvalue { i64, i64 } %t1373, i64 1765, 1
  br label %common.ret

edge1431:                                         ; preds = %block1765, %edge1385, %edge1382, %edge1381, %edge1370, %edge1367, %edge1365
  %v22393 = phi i64 [ %v22389, %block1765 ], [ %v20691, %edge1385 ], [ %v20691, %edge1382 ], [ %v20691, %edge1381 ], [ %v20691, %edge1370 ], [ %v20691, %edge1367 ], [ %v20691, %edge1365 ]
  %t1377.not = icmp ult i64 %v22393, %spec.select3
  br i1 %t1377.not, label %edge1431.block1799_crit_edge, label %edge1434

edge1431.block1799_crit_edge:                     ; preds = %edge1431
  %.pre = add i64 %v22393, %v19722
  br label %block1799

edge1434:                                         ; preds = %edge1431
  %v22866 = shl nuw nsw i64 %v19509, 2
  %v22881 = and i64 %v22866, 131068
  %v22893 = add i64 %v22881, %v19475
  %t1380 = inttoptr i64 %v22893 to ptr
  %t1381 = load i16, ptr %t1380, align 1
  %v22894 = zext i16 %t1381 to i64
  %v22904 = add i64 %v19475, 2
  %v22905 = add i64 %v22904, %v22881
  %t1382 = inttoptr i64 %v22905 to ptr
  %t1383 = load i16, ptr %t1382, align 1
  %v22911 = add nuw nsw i64 %v19505, 1
  %t1384.not = icmp eq i64 %v19480, 0
  br i1 %t1384.not, label %block14076, label %edge1445

edge1445:                                         ; preds = %edge1434
  %t1386 = inttoptr i64 %v19480 to ptr
  %v22914 = load i64, ptr %t1386, align 1
  %t1387 = icmp eq i64 %v22914, 1
  br i1 %t1387, label %edge1449, label %block14076

edge1449:                                         ; preds = %edge1445
  %v22922 = shl nuw nsw i64 %v19505, 1
  %v22923 = add i64 %v22922, %v19475
  %t1391 = inttoptr i64 %v22923 to ptr
  store i16 %t1381, ptr %t1391, align 1
  %v22944 = shl nuw nsw i64 %v19507, 1
  %v22945 = add i64 %v22944, %v19475
  %t1394 = inttoptr i64 %v22945 to ptr
  br label %block1793.sink.split

edge1458:                                         ; preds = %block14076
  %v138312 = extractvalue { i64, i64, i64, i64 } %t1395, 1
  %v138316 = add i64 %v138313, 1799
  %t1398 = insertvalue { i64, i64 } poison, i64 %v138312, 0
  %t1399 = insertvalue { i64, i64 } %t1398, i64 %v138316, 1
  br label %common.ret

edge1461:                                         ; preds = %block14076
  %v23011 = shl nuw nsw i64 %v19507, 1
  %v23012 = add i64 %v138313, %v23011
  %t1402 = inttoptr i64 %v23012 to ptr
  %t1403 = load i16, ptr %t1402, align 1
  %t1404 = icmp eq i16 %t1403, %t1383
  br i1 %t1404, label %block1793, label %edge1464

edge1464:                                         ; preds = %edge1461
  %t1406.not = icmp eq i64 %v138314, 0
  br i1 %t1406.not, label %block14115, label %edge1465

edge1465:                                         ; preds = %edge1464
  %t1407 = inttoptr i64 %v138314 to ptr
  %v23029 = load i64, ptr %t1407, align 1
  %t1408 = icmp eq i64 %v23029, 1
  br i1 %t1408, label %block1793.sink.split, label %block14115

edge1473:                                         ; preds = %block14113
  %t1417 = inttoptr i64 %v23035 to ptr
  %v23040 = load i64, ptr %t1417, align 1
  %v23041 = add i64 %v23040, 1
  store i64 %v23041, ptr %t1417, align 1
  br label %block14119

edge1476:                                         ; preds = %block14119
  %v23046 = call i64 @mech_compact_release_owner(i64 %v0, i64 %v138314)
  %t1421.not = icmp eq i64 %v23046, 0
  br i1 %t1421.not, label %block1793, label %block14110

edge1485:                                         ; preds = %block1799
  %v138441 = extractvalue { i64, i64, i64 } %t1425, 1
  %v138444 = add i64 %v138442, 1809
  %t1428 = insertvalue { i64, i64 } poison, i64 %v138441, 0
  %t1429 = insertvalue { i64, i64 } %t1428, i64 %v138444, 1
  br label %common.ret

edge1486:                                         ; preds = %block1799
  %v23229 = add i64 %v137630, %v8618
  %t1430 = call { i64, i64, i64 } @mech_compact_checked_layout_continuation_8603(i64 %v23229, i64 %v1395, i64 %v1397, i64 %v1398, i64 %v1394)
  %v138445 = extractvalue { i64, i64, i64 } %t1430, 0
  %v138447 = extractvalue { i64, i64, i64 } %t1430, 2
  %t1431 = icmp eq i64 %v138445, 2
  br i1 %t1431, label %edge1488, label %edge1489

edge1488:                                         ; preds = %edge1486
  %v138446 = extractvalue { i64, i64, i64 } %t1430, 1
  %v138449 = add i64 %v138447, 1823
  %t1433 = insertvalue { i64, i64 } poison, i64 %v138446, 0
  %t1434 = insertvalue { i64, i64 } %t1433, i64 %v138449, 1
  br label %common.ret

edge1489:                                         ; preds = %edge1486
  %t1435 = icmp ult i64 %v138442, %v138447
  %v23361 = shl nuw nsw i64 %v19509, 1
  %v23365 = and i64 %v23361, 65534
  %v23369 = or disjoint i64 %v23365, 1
  br i1 %t1435, label %edge1498, label %edge1497

edge1497:                                         ; preds = %edge1489
  br label %edge1498

edge1498:                                         ; preds = %edge1489, %edge1497
  %v23458 = phi i64 [ %v19507, %edge1497 ], [ %v19505, %edge1489 ]
  %v23460 = phi i64 [ %v23365, %edge1497 ], [ %v23369, %edge1489 ]
  %v23462 = phi i64 [ %v19505, %edge1497 ], [ %v23369, %edge1489 ]
  %v23464 = phi i64 [ %v23365, %edge1497 ], [ %v19507, %edge1489 ]
  %v23466 = phi i64 [ %v19513, %edge1497 ], [ %v137630, %edge1489 ]
  %v23468 = phi i64 [ %v137630, %edge1497 ], [ %v19515, %edge1489 ]
  %v23470 = phi i64 [ %v19513, %edge1497 ], [ %v19515, %edge1489 ]
  %v23474 = add nuw nsw i64 %v23458, 1
  %t1438 = call { i64, i64, i64, i64 } @mech_compact_checked_layout_continuation_9562(i64 %v23474, i64 262144, i64 %v19475, i64 %v19509, i64 %v19480, i64 %v0, i64 262144)
  %v138299 = extractvalue { i64, i64, i64, i64 } %t1438, 0
  %v138301 = extractvalue { i64, i64, i64, i64 } %t1438, 2
  %t1439 = icmp eq i64 %v138299, 2
  br i1 %t1439, label %edge1500, label %edge1503

edge1500:                                         ; preds = %edge1498
  %v138300 = extractvalue { i64, i64, i64, i64 } %t1438, 1
  %v138304 = add i64 %v138301, 1859
  %t1441 = insertvalue { i64, i64 } poison, i64 %v138300, 0
  %t1442 = insertvalue { i64, i64 } %t1441, i64 %v138304, 1
  br label %common.ret

edge1503:                                         ; preds = %edge1498
  %v138302 = extractvalue { i64, i64, i64, i64 } %t1438, 3
  %v23526 = shl nuw nsw i64 %v23460, 1
  %v23527 = add i64 %v138301, %v23526
  %t1445 = inttoptr i64 %v23527 to ptr
  %t1446 = load i16, ptr %t1445, align 1
  %v23528 = zext i16 %t1446 to i64
  %v23906 = call i64 @llvm.umin.i64(i64 %v23470, i64 %v137630)
  %v23623 = add nsw i64 %v19511, -1
  %t1450 = icmp ult i64 %v9184, %v23528
  %t1451 = icmp ne i64 %v23623, 0
  %v2364057.not = and i1 %t1451, %t1450
  br i1 %v2364057.not, label %block1421, label %edge1516

edge1516:                                         ; preds = %edge1503
  %v23722 = add nuw nsw i64 %v23462, 1
  %t1454.not = icmp eq i64 %v138302, 0
  br i1 %t1454.not, label %block14359, label %edge1519

edge1519:                                         ; preds = %edge1516
  %t1456 = inttoptr i64 %v138302 to ptr
  %v23725 = load i64, ptr %t1456, align 1
  %t1457 = icmp eq i64 %v23725, 1
  br i1 %t1457, label %edge1523, label %block14359

edge1523:                                         ; preds = %edge1519
  %v23733 = shl nuw nsw i64 %v23462, 1
  %v23734 = add i64 %v138301, %v23733
  %t1461 = inttoptr i64 %v23734 to ptr
  store i16 0, ptr %t1461, align 1
  %v23755 = shl nuw nsw i64 %v23464, 1
  %v23756 = add i64 %v138301, %v23755
  %t1464 = inttoptr i64 %v23756 to ptr
  store i16 0, ptr %t1464, align 1
  br label %block14480

edge1532:                                         ; preds = %block14359
  %v138324 = extractvalue { i64, i64, i64, i64 } %t1465, 1
  %v138328 = add i64 %v138325, 1881
  %t1468 = insertvalue { i64, i64 } poison, i64 %v138324, 0
  %t1469 = insertvalue { i64, i64 } %t1468, i64 %v138328, 1
  br label %common.ret

edge1535:                                         ; preds = %block14359
  %v23835 = shl nuw nsw i64 %v23464, 1
  %v23836 = add i64 %v138325, %v23835
  %t1472 = inttoptr i64 %v23836 to ptr
  %t1473 = load i16, ptr %t1472, align 1
  %t1474 = icmp eq i16 %t1473, 0
  br i1 %t1474, label %block14480, label %edge1538

edge1538:                                         ; preds = %edge1535
  %t1476.not = icmp eq i64 %v138326, 0
  br i1 %t1476.not, label %block14398, label %edge1539

edge1539:                                         ; preds = %edge1538
  %t1477 = inttoptr i64 %v138326 to ptr
  %v23853 = load i64, ptr %t1477, align 1
  %t1478 = icmp eq i64 %v23853, 1
  br i1 %t1478, label %block14396.thread362, label %block14398

block14396.thread362:                             ; preds = %edge1539
  store i16 0, ptr %t1472, align 1
  br label %block14480

edge1547:                                         ; preds = %block14396
  %t1487 = inttoptr i64 %v23859 to ptr
  %v23864 = load i64, ptr %t1487, align 1
  %v23865 = add i64 %v23864, 1
  store i64 %v23865, ptr %t1487, align 1
  br label %block14402

edge1550:                                         ; preds = %block14402
  %v23870 = call i64 @mech_compact_release_owner(i64 %v0, i64 %v138326)
  %t1491.not = icmp eq i64 %v23870, 0
  br i1 %t1491.not, label %block14480, label %block14393

edge1565:                                         ; preds = %block14480
  %v24014 = call i64 @mech_compact_release_owner(i64 %v0, i64 %v1399)
  %t1497.not = icmp eq i64 %v24014, 0
  br i1 %t1497.not, label %edge1596, label %edge1567

edge1567:                                         ; preds = %edge1565
  %t1498 = insertvalue { i64, i64 } poison, i64 %v24014, 0
  %t1499 = insertvalue { i64, i64 } %t1498, i64 1916, 1
  br label %common.ret

edge1596:                                         ; preds = %edge943, %block14480, %edge1565, %block12932, %edge1250, %block11426, %edge958, %edge917
  %v24244 = phi i64 [ %v137864, %block12932 ], [ %v13776, %block11426 ], [ %v138283, %edge917 ], [ %v13776, %edge958 ], [ %v13673253273, %edge943 ], [ %v137864, %edge1250 ], [ %v137870, %edge1565 ], [ %v137870, %block14480 ]
  %v24249 = phi i64 [ %v137865, %block12932 ], [ %v13781, %block11426 ], [ %v138284, %edge917 ], [ %v13781, %edge958 ], [ %v13678254272, %edge943 ], [ %v137865, %edge1250 ], [ %v137871, %edge1565 ], [ %v137871, %block14480 ]
  %v24256 = phi i64 [ %v137866, %block12932 ], [ %v13191, %block11426 ], [ %v13191, %edge917 ], [ %v13191, %edge958 ], [ %v13191, %edge943 ], [ %v137866, %edge1250 ], [ %v13191, %edge1565 ], [ %v13191, %block14480 ]
  %v24261 = phi i64 [ %v137867, %block12932 ], [ %v13196, %block11426 ], [ %v13196, %edge917 ], [ %v13196, %edge958 ], [ %v13196, %edge943 ], [ %v137867, %edge1250 ], [ %v13196, %edge1565 ], [ %v13196, %block14480 ]
  %v24272 = phi i64 [ %v137868, %block12932 ], [ %v13203, %block11426 ], [ %v13203, %edge917 ], [ %v13203, %edge958 ], [ %v13203, %edge943 ], [ %v137868, %edge1250 ], [ %v13203, %edge1565 ], [ %v13203, %block14480 ]
  %v27197 = phi i64 [ 0, %block12932 ], [ 0, %block11426 ], [ 0, %edge917 ], [ 0, %edge958 ], [ 0, %edge943 ], [ 0, %edge1250 ], [ %v137873, %edge1565 ], [ %v137873, %block14480 ]
  %t1512 = icmp ugt i64 %v24272, %v12848
  br i1 %t1512, label %edge1598, label %block1945

edge1598:                                         ; preds = %edge1596
  %v24390 = add i64 %v24272, -1
  %t1515 = icmp ult i64 %v24390, %v3132
  br i1 %t1515, label %edge1600, label %block39125

edge1600:                                         ; preds = %edge1598
  %v24393 = shl nuw nsw i64 %v24390, 2
  %v24394 = add i64 %v24393, %v24256
  %t1517 = inttoptr i64 %v24394 to ptr
  %t1518 = load i32, ptr %t1517, align 1
  %v24395 = zext i32 %t1518 to i64
  br label %block1945

edge1611:                                         ; preds = %block1945
  %t1524.not = icmp ult i64 %v24417, %v25296
  br i1 %t1524.not, label %edge1615, label %edge1629

edge1615:                                         ; preds = %edge1611
  %t1582 = call { i64, i64, i64 } @mech_compact_checked_layout_continuation_8603(i64 %v8618, i64 %v1395, i64 %v1397, i64 %v1398, i64 %v1394)
  %v138450 = extractvalue { i64, i64, i64 } %t1582, 0
  %v138452 = extractvalue { i64, i64, i64 } %t1582, 2
  %t1583 = icmp eq i64 %v138450, 2
  br i1 %t1583, label %edge1645, label %edge1646

edge1629:                                         ; preds = %edge1611
  %t1527 = icmp samesign ugt i64 %v24417, 8
  %v25601 = select i1 %t1527, i64 9, i64 8
  %v25698 = shl nuw nsw i64 %v25601, 2
  %v25699 = add i64 %v25698, %v138654
  %t1535 = inttoptr i64 %v25699 to ptr
  %t1536 = load i32, ptr %t1535, align 1
  %16 = add i32 %t1536, 1
  %v25690 = add nuw nsw i64 %v25601, 1
  %t1539 = zext nneg i64 %v25690 to i128
  %t1540 = zext i64 %v138654 to i128
  %t1541 = shl nuw i128 %t1540, 64
  %v138806 = or disjoint i128 %t1541, %t1539
  store i128 %v138806, ptr %ss6, align 16
  %t1543 = zext i32 %16 to i128
  %t1544 = zext i64 %v138631 to i128
  %t1545 = shl nuw i128 %t1544, 64
  %v138808 = or disjoint i128 %t1545, %t1543
  store i128 %v138808, ptr %t931, align 16
  store i128 %v138810, ptr %t936, align 16
  %t1553 = call { i64, i64, i64, i64 } @mech_compact_checked_layout_13100(i64 %v138793)
  %v138243 = extractvalue { i64, i64, i64, i64 } %t1553, 0
  %t1554 = icmp ugt i64 %v138243, 1
  br i1 %t1554, label %edge1632, label %edge1633

edge1632:                                         ; preds = %edge1629
  %v138244 = extractvalue { i64, i64, i64, i64 } %t1553, 1
  %v138248 = add i64 %v138243, 1998
  %t1556 = insertvalue { i64, i64 } poison, i64 %v138244, 0
  %t1557 = insertvalue { i64, i64 } %t1556, i64 %v138248, 1
  br label %common.ret

edge1633:                                         ; preds = %edge1629
  %v138246 = extractvalue { i64, i64, i64, i64 } %t1553, 3
  %v138245 = extractvalue { i64, i64, i64, i64 } %t1553, 2
  %v25836 = add i64 %v25226, 1
  %v25840 = add i64 %v24417, %v8618
  %t1558 = icmp samesign ult i64 %v24417, 259
  %v25926 = add nuw nsw i64 %v24417, 1
  %v25934 = shl nuw nsw i64 %v24417, 2
  %v25935 = add i64 %v25934, %v138652
  %v139120 = select i1 %t1558, i64 %v25935, i64 ptrtoint (ptr @mech_compact_llvm_anonymous_data_1 to i64)
  %t1561 = inttoptr i64 %v139120 to ptr
  %t1562 = load i32, ptr %t1561, align 1
  %17 = add i32 %t1562, 1
  %t1563 = zext nneg i64 %v25926 to i128
  %t1564 = zext i64 %v138652 to i128
  %t1565 = shl nuw i128 %t1564, 64
  %v138812 = or disjoint i128 %t1565, %t1563
  store i128 %v138812, ptr %ss6, align 16
  %t1567 = zext i32 %17 to i128
  %t1568 = zext i64 %v138629 to i128
  %t1569 = shl nuw i128 %t1568, 64
  %v138814 = or disjoint i128 %t1569, %t1567
  store i128 %v138814, ptr %t931, align 16
  store i128 %v138816, ptr %t936, align 16
  %t1577 = call { i64, i64, i64, i64 } @mech_compact_checked_layout_13100(i64 %v138793)
  %v138235 = extractvalue { i64, i64, i64, i64 } %t1577, 0
  %v138237 = extractvalue { i64, i64, i64, i64 } %t1577, 2
  %v138238 = extractvalue { i64, i64, i64, i64 } %t1577, 3
  %t1578 = icmp ugt i64 %v138235, 1
  br i1 %t1578, label %edge1642, label %edge1667

edge1642:                                         ; preds = %edge1633
  %v138236 = extractvalue { i64, i64, i64, i64 } %t1577, 1
  %v138240 = add i64 %v138235, 2018
  %t1580 = insertvalue { i64, i64 } poison, i64 %v138236, 0
  %t1581 = insertvalue { i64, i64 } %t1580, i64 %v138240, 1
  br label %common.ret

edge1645:                                         ; preds = %edge1615
  %v138451 = extractvalue { i64, i64, i64 } %t1582, 1
  %v138454 = add i64 %v138452, 2025
  %t1585 = insertvalue { i64, i64 } poison, i64 %v138451, 0
  %t1586 = insertvalue { i64, i64 } %t1585, i64 %v138454, 1
  br label %common.ret

edge1646:                                         ; preds = %edge1615
  %v26320 = lshr i64 %v138452, 5
  %v26403 = and i64 %v26320, 6
  %v26407 = and i64 %v138452, 1
  %v26411 = or disjoint i64 %v26403, %v26407
  %v26497 = add nuw nsw i64 %v26411, 1
  %v26505 = shl nuw nsw i64 %v26411, 2
  %v26506 = add i64 %v26505, %v138654
  %t1588 = inttoptr i64 %v26506 to ptr
  %t1589 = load i32, ptr %t1588, align 1
  %18 = add i32 %t1589, 1
  %t1590 = zext nneg i64 %v26497 to i128
  %t1591 = zext i64 %v138654 to i128
  %t1592 = shl nuw i128 %t1591, 64
  %v138818 = or disjoint i128 %t1592, %t1590
  store i128 %v138818, ptr %ss6, align 16
  %t1594 = zext i32 %18 to i128
  %t1595 = zext i64 %v138631 to i128
  %t1596 = shl nuw i128 %t1595, 64
  %v138820 = or disjoint i128 %t1596, %t1594
  store i128 %v138820, ptr %t931, align 16
  store i128 %v138810, ptr %t936, align 16
  %t1604 = call { i64, i64, i64, i64 } @mech_compact_checked_layout_13100(i64 %v138793)
  %v138227 = extractvalue { i64, i64, i64, i64 } %t1604, 0
  %t1605 = icmp ugt i64 %v138227, 1
  br i1 %t1605, label %edge1657, label %edge1658

edge1657:                                         ; preds = %edge1646
  %v138228 = extractvalue { i64, i64, i64, i64 } %t1604, 1
  %v138232 = add i64 %v138227, 2057
  %t1607 = insertvalue { i64, i64 } poison, i64 %v138228, 0
  %t1608 = insertvalue { i64, i64 } %t1607, i64 %v138232, 1
  br label %common.ret

edge1658:                                         ; preds = %edge1646
  %v138230 = extractvalue { i64, i64, i64, i64 } %t1604, 3
  %v138229 = extractvalue { i64, i64, i64, i64 } %t1604, 2
  %v26587 = add i64 %v25226, 1
  %v26591 = add i64 %v8618, 1
  br label %edge1667

edge1667:                                         ; preds = %block1945, %edge1633, %edge1658
  %v26656 = phi i64 [ %v138237, %edge1633 ], [ %v138652, %block1945 ], [ %v138652, %edge1658 ]
  %v26661 = phi i64 [ %v138238, %edge1633 ], [ %v138629, %block1945 ], [ %v138629, %edge1658 ]
  %v26668 = phi i64 [ %v138245, %edge1633 ], [ %v138654, %block1945 ], [ %v138229, %edge1658 ]
  %v26673 = phi i64 [ %v138246, %edge1633 ], [ %v138631, %block1945 ], [ %v138230, %edge1658 ]
  %v26680 = phi i64 [ %v25836, %edge1633 ], [ %v25226, %block1945 ], [ %v26587, %edge1658 ]
  %v26682 = phi i64 [ %v25840, %edge1633 ], [ %v24555, %block1945 ], [ %v26591, %edge1658 ]
  %t1609 = call { i64, i64, i64 } @mech_compact_checked_layout_continuation_8603(i64 %v8618, i64 %v1395, i64 %v1397, i64 %v1398, i64 %v1394)
  %v138455 = extractvalue { i64, i64, i64 } %t1609, 0
  %v138457 = extractvalue { i64, i64, i64 } %t1609, 2
  %t1610 = icmp eq i64 %v138455, 2
  br i1 %t1610, label %edge1669, label %edge1670

edge1669:                                         ; preds = %edge1667
  %v138456 = extractvalue { i64, i64, i64 } %t1609, 1
  %v138459 = add i64 %v138457, 2075
  %t1612 = insertvalue { i64, i64 } poison, i64 %v138456, 0
  %t1613 = insertvalue { i64, i64 } %t1612, i64 %v138459, 1
  br label %common.ret

edge1670:                                         ; preds = %edge1667
  %v26686 = sub i64 %v24272658, %v12848
  %v26806 = and i64 %v26686, 65535
  %v26815 = shl i64 %v138457, 16
  %v26815.masked = and i64 %v26815, 4294901760
  %v26823 = or disjoint i64 %v26815.masked, %v26806
  %v26833 = add i64 %v24272658, 1
  %t1615 = zext i64 %v26833 to i128
  %v138824 = or disjoint i128 %t586, %t1615
  store i128 %v138824, ptr %ss6, align 16
  %t1619 = zext i64 %v24256654 to i128
  %t1620 = zext nneg i64 %v26823 to i128
  %t1621 = shl nuw nsw i128 %t1620, 64
  %v138826 = or disjoint i128 %t1621, %t1619
  store i128 %v138826, ptr %t931, align 16
  %t1624 = zext i64 %v24261655 to i128
  %v138828 = or disjoint i128 %t934, %t1624
  store i128 %v138828, ptr %t936, align 16
  store i64 %v3132, ptr %t937, align 16
  %t1630 = call { i64, i64, i64, i64 } @mech_compact_checked_layout_16147(i64 %v138793)
  %v138157 = extractvalue { i64, i64, i64, i64 } %t1630, 0
  %v138159 = extractvalue { i64, i64, i64, i64 } %t1630, 2
  %v138160 = extractvalue { i64, i64, i64, i64 } %t1630, 3
  %t1631 = icmp ugt i64 %v138157, 1
  br i1 %t1631, label %edge1676, label %edge1677

edge1676:                                         ; preds = %edge1670
  %v138158 = extractvalue { i64, i64, i64, i64 } %t1630, 1
  %v138162 = add i64 %v138157, 2092
  %t1633 = insertvalue { i64, i64 } poison, i64 %v138158, 0
  %t1634 = insertvalue { i64, i64 } %t1633, i64 %v138162, 1
  br label %common.ret

edge1677:                                         ; preds = %edge1670
  br i1 %t785, label %edge1679, label %edge1678

edge1678:                                         ; preds = %edge1677
  %t1637 = icmp samesign ugt i64 %v24417, 2
  %t1638 = icmp samesign uge i64 %v24417, %spec.select3
  %v2700073 = and i1 %t1637, %t1638
  %v27080 = add nsw i64 %v24417, -1
  %v27089 = select i1 %v2700073, i64 %v27080, i64 0
  br label %block2107

edge1679:                                         ; preds = %edge1677
  %v27098 = add nsw i64 %v9023, -1
  br label %block2107

edge1708:                                         ; preds = %block2107
  %t1652 = icmp ult i64 %v27344, %v27569
  %t1653 = icmp ult i64 %v26833, 1500000
  %v2770874.not = and i1 %t1652, %t1653
  %t1654 = icmp ugt i64 %v26680, 511
  %v27842 = sub i64 %v27344, %v27796
  %t1655 = icmp ugt i64 %v27842, 4999
  %19 = and i1 %t1655, %t1654
  %v27938 = sub i64 %v1395, %v27344
  %t1656 = icmp ugt i64 %v27938, 4999
  %20 = and i1 %t1656, %19
  %v2794777 = and i1 %v2770874.not, %20
  br i1 %v2794777, label %edge1722, label %edge1708.block2462_crit_edge

edge1708.block2462_crit_edge:                     ; preds = %edge1708
  br i1 %v2770874.not, label %block9976.outer, label %edge1891

edge1722:                                         ; preds = %edge1708
  %t1659.not = icmp eq i64 %v28038, 0
  br i1 %t1659.not, label %block2325.preheader, label %edge1726

edge1726:                                         ; preds = %edge1722
  %t1662.not = icmp eq i64 %v26673, 0
  br i1 %t1662.not, label %block15387, label %edge1728

edge1728:                                         ; preds = %edge1726
  %t1663 = inttoptr i64 %v26673 to ptr
  %v28431 = load i64, ptr %t1663, align 1
  %v28432 = add i64 %v28431, 1
  store i64 %v28432, ptr %t1663, align 1
  br label %block15387

edge1731:                                         ; preds = %block15387
  %v28433 = load i64, ptr %t528, align 1
  %v28434 = add i64 %v28433, 1
  store i64 %v28434, ptr %t528, align 1
  br label %block2176.preheader

edge1738:                                         ; preds = %block2176
  %v28734 = shl nuw nsw i64 %v28481, 2
  %v28735 = add i64 %v28734, %v138653.ph.ph
  %t1671 = inttoptr i64 %v28735 to ptr
  %t1672 = load i32, ptr %t1671, align 1
  %21 = zext i32 %t1672 to i64
  %umul = call { i64, i1 } @llvm.umul.with.overflow.i64(i64 %21, i64 %v26680)
  %22 = extractvalue { i64, i1 } %umul, 1
  br i1 %22, label %block39122, label %edge1743

edge1743:                                         ; preds = %edge1738
  %v28949 = add i64 %v28734, %v26668
  %t1679 = inttoptr i64 %v28949 to ptr
  %t1680 = load i32, ptr %t1679, align 1
  %23 = zext i32 %t1680 to i64
  %umul78 = call { i64, i1 } @llvm.umul.with.overflow.i64(i64 %23, i64 %v28038)
  %24 = extractvalue { i64, i1 } %umul78, 1
  br i1 %24, label %block39122, label %edge1750

edge1750:                                         ; preds = %edge1743
  %v28756 = mul i64 %v26680, %21
  %v28969 = mul i64 %v28038, %23
  %t1687 = icmp ugt i64 %v28969, %v28756
  %v29070 = sub i64 %v28969, %v28756
  %v29083382 = sub i64 %v28756, %v28969
  %v29181378 = select i1 %t1687, i64 %v29070, i64 %v29083382
  %v29174 = add nuw nsw i64 %v28481, 1
  %v29182 = add i64 %v29181378, %v28483
  %t1699.not = icmp ult i64 %v29182, %v28483
  br i1 %t1699.not, label %block39122, label %block2176

edge1767:                                         ; preds = %block2176
  %v29096 = or i64 %v26673, %v138630.ph.ph
  %t1695.not = icmp eq i64 %v29096, 0
  br i1 %t1695.not, label %block2258, label %edge1768

edge1768:                                         ; preds = %edge1767
  %v29097 = call i64 @mech_compact_release_two(i64 %v0, i64 %v26673, i64 %v138630.ph.ph)
  %t1696.not = icmp eq i64 %v29097, 0
  br i1 %t1696.not, label %block2258, label %edge1770

edge1770:                                         ; preds = %edge1768
  %t1697 = insertvalue { i64, i64 } poison, i64 %v29097, 0
  %t1698 = insertvalue { i64, i64 } %t1697, i64 2255, 1
  br label %common.ret

edge1777:                                         ; preds = %block2258
  %t1707 = icmp ult i64 %v26680, 92233720368547759
  br i1 %t1707, label %edge1780, label %block39122

edge1780:                                         ; preds = %edge1777
  %v29302 = mul nuw i64 %v26680, 200
  %v2931079 = lshr i64 %v29302, 9
  %umul80 = call { i64, i1 } @llvm.umul.with.overflow.i64(i64 %v2931079, i64 %v28038)
  %25 = extractvalue { i64, i1 } %umul80, 1
  br i1 %25, label %block39122, label %edge1785

edge1785:                                         ; preds = %edge1780
  %v29318 = mul i64 %v2931079, %v28038
  %t1717 = icmp ult i64 %v27842, 10000
  %t1718 = icmp ult i64 %v29208, 8192
  %v2950181 = and i1 %t1717, %t1718
  br i1 %v2950181, label %edge1792, label %edge1805

edge1792:                                         ; preds = %edge1785
  %v29583 = sub nuw nsw i64 8192, %v29208
  %umul82 = call { i64, i1 } @llvm.umul.with.overflow.i64(i64 %v29318, i64 %v29583)
  %26 = extractvalue { i64, i1 } %umul82, 1
  br i1 %26, label %block39122, label %edge1795

edge1795:                                         ; preds = %edge1792
  %v29591 = mul i64 %v29318, %v29583
  %v2959883 = lshr i64 %v29591, 13
  %v29603 = add i64 %v2959883, %v29318
  %t1729.not = icmp ult i64 %v29603, %v29318
  br i1 %t1729.not, label %block39122, label %edge1805

edge1805:                                         ; preds = %edge1785, %edge1795
  %v29702 = phi i64 [ %v29603, %edge1795 ], [ %v29318, %edge1785 ]
  %v2968284 = lshr i64 %v27842, 12
  %umul85 = call { i64, i1 } @llvm.umul.with.overflow.i64(i64 %v2968284, i64 %v28038)
  %27 = extractvalue { i64, i1 } %umul85, 1
  br i1 %27, label %block39122, label %edge1807

edge1807:                                         ; preds = %edge1805
  %v29690 = mul i64 %v2968284, %v28038
  %v29695 = add i64 %v28483, %v29690
  %t1739.not = icmp ult i64 %v29695, %v28483
  br i1 %t1739.not, label %block39122, label %edge1811

edge1811:                                         ; preds = %edge1807
  %t1741.not = icmp ult i64 %v29695, %v29702
  br i1 %t1741.not, label %block2325.preheader, label %edge1891

block2325.preheader:                              ; preds = %edge1722, %edge1811
  br label %block2325

edge1825:                                         ; preds = %edge1840
  %v30581 = add i64 %v26680, %v28038
  %t1787.not = icmp ult i64 %v30581, %v28038
  br i1 %t1787.not, label %block39122, label %block2378.outer

edge1832:                                         ; preds = %block2325
  %t1753 = zext nneg i64 %v30138 to i128
  %t1754 = zext i64 %v138597 to i128
  %t1755 = shl nuw i128 %t1754, 64
  %v138830 = or disjoint i128 %t1755, %t1753
  store i128 %v138830, ptr %ss6, align 16
  %t1757 = zext nneg i64 %v30276 to i128
  %t1758 = zext i64 %v138598 to i128
  %t1759 = shl nuw i128 %t1758, 64
  %v138832 = or disjoint i128 %t1759, %t1757
  store i128 %v138832, ptr %t931, align 16
  store i128 %v138810, ptr %t936, align 16
  %t1767 = call { i64, i64, i64, i64 } @mech_compact_checked_layout_13100(i64 %v138793)
  %v138219 = extractvalue { i64, i64, i64, i64 } %t1767, 0
  %v138221 = extractvalue { i64, i64, i64, i64 } %t1767, 2
  %v138222 = extractvalue { i64, i64, i64, i64 } %t1767, 3
  %t1768 = icmp ugt i64 %v138219, 1
  br i1 %t1768, label %edge1836, label %edge1837

edge1836:                                         ; preds = %edge1832
  %v138220 = extractvalue { i64, i64, i64, i64 } %t1767, 1
  %v138224 = add i64 %v138219, 2355
  %t1770 = insertvalue { i64, i64 } poison, i64 %v138220, 0
  %t1771 = insertvalue { i64, i64 } %t1770, i64 %v138224, 1
  br label %common.ret

edge1837:                                         ; preds = %edge1832
  %t1773 = zext i64 %v138595 to i128
  %t1774 = shl nuw i128 %t1773, 64
  %v138836 = or disjoint i128 %t1774, %t1753
  store i128 %v138836, ptr %ss6, align 16
  %t1776 = zext i64 %v138596 to i128
  %v138838 = or disjoint i128 %t934, %t1776
  store i128 %v138838, ptr %t931, align 16
  store i64 10, ptr %t936, align 16
  %t1782 = call { i64, i64, i64, i64 } @mech_compact_checked_layout_10939(i64 %v138793)
  %v138275 = extractvalue { i64, i64, i64, i64 } %t1782, 0
  %t1783 = icmp ugt i64 %v138275, 1
  br i1 %t1783, label %edge1839, label %edge1840

edge1839:                                         ; preds = %edge1837
  %v138276 = extractvalue { i64, i64, i64, i64 } %t1782, 1
  %v138280 = add i64 %v138275, 2358
  %t1785 = insertvalue { i64, i64 } poison, i64 %v138276, 0
  %t1786 = insertvalue { i64, i64 } %t1785, i64 %v138280, 1
  br label %common.ret

edge1840:                                         ; preds = %edge1837
  %v138278 = extractvalue { i64, i64, i64, i64 } %t1782, 3
  %v138277 = extractvalue { i64, i64, i64, i64 } %t1782, 2
  %exitcond19701.not = icmp eq i64 %v30138, 10
  br i1 %exitcond19701.not, label %edge1825, label %block2325

edge1850:                                         ; preds = %block2378
  %v31159 = add nuw nsw i64 %v30934, 1
  %v31167 = shl nuw nsw i64 %v30934, 2
  %v31168 = add i64 %v31167, %v30922.ph
  %t1792 = inttoptr i64 %v31168 to ptr
  %t1793 = load i32, ptr %t1792, align 1
  %t1794.not = icmp eq i32 %t1793, 0
  br i1 %t1794.not, label %block2378, label %edge1856

edge1856:                                         ; preds = %edge1850
  %v31169 = zext i32 %t1793 to i64
  %v31355 = add i64 %v31167, %v30910.ph
  %t1797 = inttoptr i64 %v31355 to ptr
  %t1798 = load i32, ptr %t1797, align 1
  %v31356 = zext i32 %t1798 to i64
  %v31369 = add nuw nsw i64 %v31356, %v31169
  %t1799 = icmp samesign ult i64 %v31369, 4294967296
  br i1 %t1799, label %edge1861, label %block39122

edge1861:                                         ; preds = %edge1856
  %t1801 = zext nneg i64 %v31159 to i128
  %t1802 = zext i64 %v30910.ph to i128
  %t1803 = shl nuw i128 %t1802, 64
  %v138840 = or disjoint i128 %t1803, %t1801
  store i128 %v138840, ptr %ss6, align 16
  %t1805 = zext nneg i64 %v31369 to i128
  %t1806 = zext i64 %v30915.ph to i128
  %t1807 = shl nuw i128 %t1806, 64
  %v138842 = or disjoint i128 %t1807, %t1805
  store i128 %v138842, ptr %t931, align 16
  store i128 %v138816, ptr %t936, align 16
  %t1815 = call { i64, i64, i64, i64 } @mech_compact_checked_layout_13100(i64 %v138793)
  %v138211 = extractvalue { i64, i64, i64, i64 } %t1815, 0
  %t1816 = icmp ugt i64 %v138211, 1
  br i1 %t1816, label %edge1865, label %edge1866

edge1865:                                         ; preds = %edge1861
  %v138212 = extractvalue { i64, i64, i64, i64 } %t1815, 1
  %v138216 = add i64 %v138211, 2432
  %t1818 = insertvalue { i64, i64 } poison, i64 %v138212, 0
  %t1819 = insertvalue { i64, i64 } %t1818, i64 %v138216, 1
  br label %common.ret

edge1866:                                         ; preds = %edge1861
  %v138214 = extractvalue { i64, i64, i64, i64 } %t1815, 3
  %v138213 = extractvalue { i64, i64, i64, i64 } %t1815, 2
  %t1821 = zext i64 %v30922.ph to i128
  %t1822 = shl nuw i128 %t1821, 64
  %v138846 = or disjoint i128 %t1822, %t1801
  store i128 %v138846, ptr %ss6, align 16
  %t1824 = zext i64 %v30927.ph to i128
  %v138848 = or disjoint i128 %t934, %t1824
  store i128 %v138848, ptr %t931, align 16
  store i64 259, ptr %t936, align 16
  %t1830 = call { i64, i64, i64, i64 } @mech_compact_checked_layout_10939(i64 %v138793)
  %v138267 = extractvalue { i64, i64, i64, i64 } %t1830, 0
  %v138269 = extractvalue { i64, i64, i64, i64 } %t1830, 2
  %v138270 = extractvalue { i64, i64, i64, i64 } %t1830, 3
  %t1831 = icmp ugt i64 %v138267, 1
  br i1 %t1831, label %edge1868, label %block2378.outer

block2378.outer:                                  ; preds = %edge1825, %edge1866
  %v30910.ph = phi i64 [ %v138213, %edge1866 ], [ %v138651.ph.ph, %edge1825 ]
  %v30915.ph = phi i64 [ %v138214, %edge1866 ], [ %v138628.ph.ph, %edge1825 ]
  %v30922.ph = phi i64 [ %v138269, %edge1866 ], [ %v26656, %edge1825 ]
  %v30927.ph = phi i64 [ %v138270, %edge1866 ], [ %v26661, %edge1825 ]
  %v30934.ph = phi i64 [ %v31159, %edge1866 ], [ 0, %edge1825 ]
  br label %block2378

edge1868:                                         ; preds = %edge1866
  %v138268 = extractvalue { i64, i64, i64, i64 } %t1830, 1
  %v138272 = add i64 %v138267, 2434
  %t1833 = insertvalue { i64, i64 } poison, i64 %v138268, 0
  %t1834 = insertvalue { i64, i64 } %t1833, i64 %v138272, 1
  br label %common.ret

edge1891:                                         ; preds = %edge1811, %edge1708.block2462_crit_edge
  %v137638384 = phi i64 [ 0, %edge1708.block2462_crit_edge ], [ 1, %edge1811 ]
  br i1 %t23.not, label %block2491, label %edge1892

edge1892:                                         ; preds = %edge1891
  %v31990 = call i64 @mech_compact_release_owner(i64 %v0, i64 %v1399)
  %t1842.not = icmp eq i64 %v31990, 0
  br i1 %t1842.not, label %block2491, label %edge1894

edge1894:                                         ; preds = %edge1892
  %t1843 = insertvalue { i64, i64 } poison, i64 %v31990, 0
  %t1844 = insertvalue { i64, i64 } %t1843, i64 2494, 1
  br label %common.ret

edge1900:                                         ; preds = %block2491
  %t1849.not = icmp ult i64 %v27344, %v31750
  br i1 %t1849.not, label %block39122, label %edge1902

edge1902:                                         ; preds = %edge1900
  %v33539 = sub nuw i64 %v27344, %v31750
  %t1851.not = icmp eq i64 %v138160, 0
  br i1 %t1851.not, label %edge1909, label %edge1906

edge1906:                                         ; preds = %edge1902
  %t1852 = inttoptr i64 %v138160 to ptr
  %v33542 = load i64, ptr %t1852, align 1
  %v33543 = add i64 %v33542, 1
  store i64 %v33543, ptr %t1852, align 1
  br label %edge1909

edge1909:                                         ; preds = %edge1902, %edge1906
  %v33852 = add i64 %v138159, -4
  br label %block2509

edge1913:                                         ; preds = %block2509
  %t1857.not = icmp eq i64 %v33576, 0
  br i1 %t1857.not, label %block39122, label %edge1915

edge1914:                                         ; preds = %block2509
  br i1 %t1851.not, label %edge1939, label %edge1930

edge1915:                                         ; preds = %edge1913
  %v33668 = add i64 %v33576, -1
  %t1859 = icmp ult i64 %v33668, %v3132
  br i1 %t1859, label %edge1920, label %block16699

edge1920:                                         ; preds = %edge1915
  %v33849 = shl i64 %v33576, 2
  %v33853 = add i64 %v33852, %v33849
  %t1862 = inttoptr i64 %v33853 to ptr
  %t1863 = load i32, ptr %t1862, align 1
  %28 = and i32 %t1863, 65535
  %v33872 = zext nneg i32 %28 to i64
  %t1864.not = icmp ult i64 %v33668, %v33872
  br i1 %t1864.not, label %block39122, label %block16699

edge1930:                                         ; preds = %edge1914
  %t1867 = inttoptr i64 %v138160 to ptr
  %v33897 = load i64, ptr %t1867, align 1
  %v33898 = add i64 %v33897, -1
  store i64 %v33898, ptr %t1867, align 1
  %t1869.not = icmp eq i64 %v33898, 0
  br i1 %t1869.not, label %edge1933, label %edge1939

edge1933:                                         ; preds = %edge1930
  %v33899 = call i64 @mech_compact_free(i64 %v0, i64 %v138160)
  %t1870.not = icmp eq i64 %v33899, 0
  br i1 %t1870.not, label %edge1939, label %edge1934

edge1934:                                         ; preds = %edge1933
  %t1871 = insertvalue { i64, i64 } poison, i64 %v33899, 0
  %t1872 = insertvalue { i64, i64 } %t1871, i64 2565, 1
  br label %common.ret

edge1939:                                         ; preds = %edge1914, %edge1930, %edge1933
  %t1873.not = icmp ult i64 %v26833, %v33576
  br i1 %t1873.not, label %block39122, label %edge1940

edge1940:                                         ; preds = %edge1939
  %v34091 = sub nuw i64 %v26833, %v33576
  br label %block2744

edge1956:                                         ; preds = %block2606
  %v34426 = zext i32 %t1879 to i64
  %v34613 = add i64 %v34424, %v138600
  %t1883 = inttoptr i64 %v34613 to ptr
  %t1884 = load i32, ptr %t1883, align 1
  %v34614 = zext i32 %t1884 to i64
  %v34627 = add nuw nsw i64 %v34614, %v34426
  %t1885 = icmp samesign ult i64 %v34627, 4294967296
  br i1 %t1885, label %edge1961, label %block39122

edge1961:                                         ; preds = %edge1956
  %t1887 = zext nneg i64 %v34416 to i128
  %t1888 = zext i64 %v138600 to i128
  %t1889 = shl nuw i128 %t1888, 64
  %v138850 = or disjoint i128 %t1889, %t1887
  store i128 %v138850, ptr %ss6, align 16
  %t1891 = zext nneg i64 %v34627 to i128
  %t1892 = zext i64 %v138601 to i128
  %t1893 = shl nuw i128 %t1892, 64
  %v138852 = or disjoint i128 %t1893, %t1891
  store i128 %v138852, ptr %t931, align 16
  store i128 %v138816, ptr %t936, align 16
  %t1901 = call { i64, i64, i64, i64 } @mech_compact_checked_layout_13100(i64 %v138793)
  %v138203 = extractvalue { i64, i64, i64, i64 } %t1901, 0
  %t1902 = icmp ugt i64 %v138203, 1
  br i1 %t1902, label %edge1965, label %edge1966

edge1965:                                         ; preds = %edge1961
  %v138204 = extractvalue { i64, i64, i64, i64 } %t1901, 1
  %v138208 = add i64 %v138203, 2643
  %t1904 = insertvalue { i64, i64 } poison, i64 %v138204, 0
  %t1905 = insertvalue { i64, i64 } %t1904, i64 %v138208, 1
  br label %common.ret

edge1966:                                         ; preds = %edge1961
  %v138206 = extractvalue { i64, i64, i64, i64 } %t1901, 3
  %v138205 = extractvalue { i64, i64, i64, i64 } %t1901, 2
  %t1907 = zext i64 %v138602 to i128
  %t1908 = shl nuw i128 %t1907, 64
  %v138856 = or disjoint i128 %t1908, %t1887
  store i128 %v138856, ptr %ss6, align 16
  %t1910 = zext i64 %v138603 to i128
  %v138858 = or disjoint i128 %t934, %t1910
  store i128 %v138858, ptr %t931, align 16
  store i64 259, ptr %t936, align 16
  %t1916 = call { i64, i64, i64, i64 } @mech_compact_checked_layout_10939(i64 %v138793)
  %v138259 = extractvalue { i64, i64, i64, i64 } %t1916, 0
  %v138261 = extractvalue { i64, i64, i64, i64 } %t1916, 2
  %v138262 = extractvalue { i64, i64, i64, i64 } %t1916, 3
  %t1917 = icmp ugt i64 %v138259, 1
  br i1 %t1917, label %edge1968, label %edge1974

edge1968:                                         ; preds = %edge1966
  %v138260 = extractvalue { i64, i64, i64, i64 } %t1916, 1
  %v138264 = add i64 %v138259, 2645
  %t1919 = insertvalue { i64, i64 } poison, i64 %v138260, 0
  %t1920 = insertvalue { i64, i64 } %t1919, i64 %v138264, 1
  br label %common.ret

edge1974:                                         ; preds = %block2606, %edge1966
  %v34757 = phi i64 [ %v138205, %edge1966 ], [ %v138600, %block2606 ]
  %v34762 = phi i64 [ %v138206, %edge1966 ], [ %v138601, %block2606 ]
  %v34763 = phi i64 [ %v138261, %edge1966 ], [ %v138602, %block2606 ]
  %v34768 = phi i64 [ %v138262, %edge1966 ], [ %v138603, %block2606 ]
  %exitcond19703.not = icmp eq i64 %v34416, 259
  br i1 %exitcond19703.not, label %block2692, label %block2606

edge1983:                                         ; preds = %edge1998
  %v35706 = add i64 %v26680, %v28038
  %t1966.not = icmp ult i64 %v35706, %v28038
  br i1 %t1966.not, label %block39122, label %block2744

edge1990:                                         ; preds = %block2692
  %t1932 = zext nneg i64 %v35269 to i128
  %t1933 = zext i64 %v138607 to i128
  %t1934 = shl nuw i128 %t1933, 64
  %v138860 = or disjoint i128 %t1934, %t1932
  store i128 %v138860, ptr %ss6, align 16
  %t1936 = zext nneg i64 %v35406 to i128
  %t1937 = zext i64 %v138608 to i128
  %t1938 = shl nuw i128 %t1937, 64
  %v138862 = or disjoint i128 %t1938, %t1936
  store i128 %v138862, ptr %t931, align 16
  store i128 %v138810, ptr %t936, align 16
  %t1946 = call { i64, i64, i64, i64 } @mech_compact_checked_layout_13100(i64 %v138793)
  %v138195 = extractvalue { i64, i64, i64, i64 } %t1946, 0
  %v138197 = extractvalue { i64, i64, i64, i64 } %t1946, 2
  %v138198 = extractvalue { i64, i64, i64, i64 } %t1946, 3
  %t1947 = icmp ugt i64 %v138195, 1
  br i1 %t1947, label %edge1994, label %edge1995

edge1994:                                         ; preds = %edge1990
  %v138196 = extractvalue { i64, i64, i64, i64 } %t1946, 1
  %v138200 = add i64 %v138195, 2726
  %t1949 = insertvalue { i64, i64 } poison, i64 %v138196, 0
  %t1950 = insertvalue { i64, i64 } %t1949, i64 %v138200, 1
  br label %common.ret

edge1995:                                         ; preds = %edge1990
  %t1952 = zext i64 %v138605 to i128
  %t1953 = shl nuw i128 %t1952, 64
  %v138866 = or disjoint i128 %t1953, %t1932
  store i128 %v138866, ptr %ss6, align 16
  %t1955 = zext i64 %v138606 to i128
  %v138868 = or disjoint i128 %t934, %t1955
  store i128 %v138868, ptr %t931, align 16
  store i64 10, ptr %t936, align 16
  %t1961 = call { i64, i64, i64, i64 } @mech_compact_checked_layout_10939(i64 %v138793)
  %v138251 = extractvalue { i64, i64, i64, i64 } %t1961, 0
  %t1962 = icmp ugt i64 %v138251, 1
  br i1 %t1962, label %edge1997, label %edge1998

edge1997:                                         ; preds = %edge1995
  %v138252 = extractvalue { i64, i64, i64, i64 } %t1961, 1
  %v138256 = add i64 %v138251, 2729
  %t1964 = insertvalue { i64, i64 } poison, i64 %v138252, 0
  %t1965 = insertvalue { i64, i64 } %t1964, i64 %v138256, 1
  br label %common.ret

edge1998:                                         ; preds = %edge1995
  %v138254 = extractvalue { i64, i64, i64, i64 } %t1961, 3
  %v138253 = extractvalue { i64, i64, i64, i64 } %t1961, 2
  %exitcond19704.not = icmp eq i64 %v35269, 10
  br i1 %exitcond19704.not, label %edge1983, label %block2692

edge2014:                                         ; preds = %edge569, %edge570, %block2744
  %v35962 = phi i64 [ %v24244652, %block2744 ], [ %v138649, %edge570 ], [ %v138649, %edge569 ]
  %v35967 = phi i64 [ %v24249653, %block2744 ], [ %v138626, %edge570 ], [ %v138626, %edge569 ]
  %v35968 = phi i64 [ %v138159, %block2744 ], [ %v138650, %edge570 ], [ %v138650, %edge569 ]
  %v35973 = phi i64 [ %v138160, %block2744 ], [ %v138627, %edge570 ], [ %v138627, %edge569 ]
  %v35974 = phi i64 [ %v24268656, %block2744 ], [ %v138767, %edge570 ], [ %v138767, %edge569 ]
  %v35975 = phi i64 [ %v24270657, %block2744 ], [ %v138768, %edge570 ], [ %v138768, %edge569 ]
  %v35976 = phi i64 [ %v27344, %block2744 ], [ %v7697, %edge570 ], [ %v7697, %edge569 ]
  %v35978 = phi i64 [ %spec.select2, %block2744 ], [ %v138771, %edge570 ], [ %v138771, %edge569 ]
  %v35979 = phi i64 [ %v27392, %block2744 ], [ %v138772, %edge570 ], [ %v138772, %edge569 ]
  %v35980 = phi i64 [ %v35821, %block2744 ], [ %v138651.ph.ph, %edge570 ], [ %v138651.ph.ph, %edge569 ]
  %v35985 = phi i64 [ %v35836, %block2744 ], [ %v138628.ph.ph, %edge570 ], [ %v138628.ph.ph, %edge569 ]
  %v35986 = phi i64 [ %v35845, %block2744 ], [ %v138652, %edge570 ], [ %v138652, %edge569 ]
  %v35991 = phi i64 [ %v35860, %block2744 ], [ %v138629, %edge570 ], [ %v138629, %edge569 ]
  %v35992 = phi i64 [ %v35869, %block2744 ], [ %v138653.ph.ph, %edge570 ], [ %v138653.ph.ph, %edge569 ]
  %v35997 = phi i64 [ %v35874, %block2744 ], [ %v138630.ph.ph, %edge570 ], [ %v138630.ph.ph, %edge569 ]
  %v35998 = phi i64 [ %v35881, %block2744 ], [ %v138654, %edge570 ], [ %v138654, %edge569 ]
  %v36003 = phi i64 [ %v35886, %block2744 ], [ %v138631, %edge570 ], [ %v138631, %edge569 ]
  %v36004 = phi i64 [ %v35893, %block2744 ], [ %v138775, %edge570 ], [ %v138775, %edge569 ]
  %v36005 = phi i64 [ %v35895, %block2744 ], [ %v138776, %edge570 ], [ %v138776, %edge569 ]
  %v36006 = phi i64 [ %v27796, %block2744 ], [ %v138779, %edge570 ], [ %v138779, %edge569 ]
  %v36007 = phi i64 [ %v35915, %block2744 ], [ %v138780, %edge570 ], [ %v138780, %edge569 ]
  %v36008 = phi i64 [ %v35922, %block2744 ], [ %v138783, %edge570 ], [ %v138783, %edge569 ]
  %v36009 = phi i64 [ %v35926, %block2744 ], [ %v138784, %edge570 ], [ %v138784, %edge569 ]
  %v36010 = phi i64 [ %v35931, %block2744 ], [ %v138787, %edge570 ], [ %v138787, %edge569 ]
  %v36011 = phi i64 [ %v137638384, %block2744 ], [ %v138788, %edge570 ], [ %v138788, %edge569 ]
  %v36013 = phi i64 [ %v31806, %block2744 ], [ %v7710, %edge570 ], [ %v7710, %edge569 ]
  %v129095 = phi i64 [ %v8626, %block2744 ], [ %v138655, %edge570 ], [ %v138655, %edge569 ]
  %v129198 = phi i64 [ %v8837, %block2744 ], [ %v138656, %edge570 ], [ %v138656, %edge569 ]
  %t1971.not = icmp ult i64 %v36007, %v36006
  br i1 %t1971.not, label %block39122, label %edge2015

edge2015:                                         ; preds = %edge2014
  %v36030 = sub nuw i64 %v36007, %v36006
  %t1973 = icmp ne i64 %v36006, 0
  %t1977 = icmp ne i64 %v36010, 1
  %t1978 = icmp ne i64 %v36008, %v36030
  %.not137 = or i1 %t1978, %t1977
  %v3614990.not = or i1 %t1973, %.not137
  %t1979.not = icmp eq i64 %v35973, 0
  br i1 %t1979.not, label %block2789, label %edge2029

edge2029:                                         ; preds = %edge2015
  %t1980 = inttoptr i64 %v35973 to ptr
  %v36158 = load i64, ptr %t1980, align 1
  %v36159 = add i64 %v36158, 1
  store i64 %v36159, ptr %t1980, align 1
  br label %block2789

edge2032:                                         ; preds = %block2789
  %t1983 = inttoptr i64 %v35997 to ptr
  %v36162 = load i64, ptr %t1983, align 1
  %v36163 = add i64 %v36162, 1
  store i64 %v36163, ptr %t1983, align 1
  br label %edge2041

edge2038:                                         ; preds = %edge2044
  %t1988 = insertvalue { i64, i64 } poison, i64 %v36762, 0
  %t1989 = insertvalue { i64, i64 } %t1988, i64 2807, 1
  br label %common.ret

edge2039:                                         ; preds = %edge2044
  br i1 %t23.not, label %block2806.preheader, label %edge2047

edge2041:                                         ; preds = %edge2032, %block2789
  %t1990 = call { i64, i64 } @mech_compact_allocate_backing(i64 %v0, i64 320, i64 4, i64 4, i64 1)
  %v36901 = extractvalue { i64, i64 } %t1990, 0
  %v36902 = extractvalue { i64, i64 } %t1990, 1
  %t1991.not = icmp eq i64 %v36901, 0
  br i1 %t1991.not, label %edge2043, label %edge2044

edge2043:                                         ; preds = %edge2041
  %t1993 = insertvalue { i64, i64 } poison, i64 %v36902, 0
  %t1994 = insertvalue { i64, i64 } %t1993, i64 2811, 1
  br label %common.ret

edge2044:                                         ; preds = %edge2041
  %t1992 = inttoptr i64 %v36902 to ptr
  store i64 2, ptr %t1992, align 1
  %v36762 = call i64 @mech_compact_release_owner(i64 %v0, i64 %v36902)
  %t1987.not = icmp eq i64 %v36762, 0
  br i1 %t1987.not, label %edge2039, label %edge2038

edge2047:                                         ; preds = %edge2039
  %v37015 = load i64, ptr %t386, align 1
  %v37016 = add i64 %v37015, 1
  store i64 %v37016, ptr %t386, align 1
  br label %block2806.preheader

block2806.preheader:                              ; preds = %edge2039, %edge2047
  br label %block2806

edge2053:                                         ; preds = %block2806
  %t2002 = inttoptr i64 %v37061 to ptr
  %v37038 = load i64, ptr %t2002, align 1
  %t2003 = icmp eq i64 %v37038, 1
  br i1 %t2003, label %edge2055, label %block2816

edge2055:                                         ; preds = %edge2053
  %t2005 = zext i64 %v36006 to i128
  %t2006 = zext i64 %v36030 to i128
  %t2007 = shl nuw i128 %t2006, 64
  %v138870 = or disjoint i128 %t2007, %t2005
  store i128 %v138870, ptr %ss3, align 16
  %t2009 = zext i64 %v37066 to i128
  %v138872 = or disjoint i128 %t411, %t2009
  store i128 %v138872, ptr %t403, align 16
  store i128 %v138706, ptr %t408, align 16
  %t2020 = zext i64 %v37069 to i128
  %t2021 = shl nuw i128 %t2020, 64
  %v138876 = or disjoint i128 %t2021, %t419
  store i128 %v138876, ptr %t413, align 16
  store i128 18446744073709551936, ptr %t418, align 16
  %t2030 = zext i64 %v37061 to i128
  %t2031 = shl nuw i128 %t2030, 64
  %v138880 = or disjoint i128 %t2031, 320
  store i128 %v138880, ptr %t423, align 16
  store i64 320, ptr %t424, align 16
  %t2035 = call { i64, i64 } @mech_compact_numeric_2821_vector(i64 %v0, i64 %v138697, i64 %v6374)
  %v37045 = extractvalue { i64, i64 } %t2035, 0
  %t2036.not = icmp eq i64 %v37045, 0
  br i1 %t2036.not, label %edge2059, label %edge2058

edge2058:                                         ; preds = %edge2055
  %v37046 = extractvalue { i64, i64 } %t2035, 1
  %t2037 = icmp eq i64 %v37045, 103169
  %v37051 = select i1 %t2037, i64 103425, i64 %v37045
  %t2039 = insertvalue { i64, i64 } poison, i64 %v37051, 0
  %t2040 = insertvalue { i64, i64 } %t2039, i64 %v37046, 1
  br label %common.ret

edge2059:                                         ; preds = %edge2055
  br i1 %t23.not, label %edge2125.thread, label %edge2060

edge2060:                                         ; preds = %edge2059
  %v37055 = call i64 @mech_compact_release_nullable(i64 %v0, i64 %v1399)
  %t2042.not = icmp eq i64 %v37055, 0
  br i1 %t2042.not, label %edge2125.thread, label %edge2062

edge2062:                                         ; preds = %edge2060
  %t2043 = insertvalue { i64, i64 } poison, i64 %v37055, 0
  %t2044 = insertvalue { i64, i64 } %t2043, i64 2821, 1
  br label %common.ret

edge2067:                                         ; preds = %block2816
  %v37204 = add i64 %v37066, %v36006
  %t2048.not = icmp ult i64 %v37204, %v36006
  br i1 %t2048.not, label %block39122, label %edge2069

edge2068:                                         ; preds = %block2816
  br i1 %t2001, label %edge2108, label %edge2113

edge2069:                                         ; preds = %edge2067
  %t2050 = icmp ult i64 %v37204, %v1395
  br i1 %t2050, label %edge2073, label %edge2083

edge2073:                                         ; preds = %edge2069
  br i1 %v636946, label %block17807, label %edge2078

edge2078:                                         ; preds = %edge2073
  br i1 %t2056, label %trap2057, label %ok2057

edge2083:                                         ; preds = %edge2069, %block17807
  %v37427 = phi i64 [ %0, %block17807 ], [ 0, %edge2069 ]
  %v37544 = add i64 %v37427, %v37069
  %t2063 = inttoptr i64 %v37544 to ptr
  %t2064 = load i32, ptr %t2063, align 1
  %v37664 = add i32 %t2064, 1
  %t2065.not = icmp eq i32 %t2064, -1
  br i1 %t2065.not, label %block39122, label %edge2094

edge2094:                                         ; preds = %edge2083
  br i1 %t2001, label %edge2095, label %block17888

edge2095:                                         ; preds = %edge2094
  %t2074 = inttoptr i64 %v37061 to ptr
  %v37696 = load i64, ptr %t2074, align 1
  %t2075 = icmp eq i64 %v37696, 1
  br i1 %t2075, label %block17887, label %block17888

edge2103:                                         ; preds = %block17887
  %t2084 = inttoptr i64 %v37695 to ptr
  %v37707 = load i64, ptr %t2084, align 1
  %v37708 = add i64 %v37707, 1
  store i64 %v37708, ptr %t2084, align 1
  br label %edge2112

edge2108:                                         ; preds = %edge2068
  %t2090 = inttoptr i64 %v37061 to ptr
  %v37723 = load i64, ptr %t2090, align 1
  %v37724 = add i64 %v37723, 1
  store i64 %v37724, ptr %t2090, align 1
  br label %edge2113

edge2112:                                         ; preds = %block17887, %edge2103
  %t2096.not866 = icmp eq i64 %v37061, 0
  %t2096.not = or i1 %t2096.not866, %t2081
  br i1 %t2096.not, label %block2872, label %edge2118

edge2113:                                         ; preds = %edge2108, %edge2068
  %v37730 = or i64 %v37061, %v1399
  %t2094.not = icmp eq i64 %v37730, 0
  br i1 %t2094.not, label %edge2125, label %edge2114

edge2114:                                         ; preds = %edge2113
  %v37731 = call i64 @mech_compact_release_two(i64 %v0, i64 %v1399, i64 %v37061)
  %t2095.not = icmp eq i64 %v37731, 0
  br i1 %t2095.not, label %edge2125, label %block17903

edge2118:                                         ; preds = %edge2112
  %v37735 = call i64 @mech_compact_release_owner(i64 %v0, i64 %v37061)
  %t2097.not = icmp eq i64 %v37735, 0
  br i1 %t2097.not, label %block2872, label %block17903

edge2125.thread:                                  ; preds = %edge2059, %edge2060
  %v3805719822 = add i64 %v37069, 1024
  %t210019823 = inttoptr i64 %v3805719822 to ptr
  %t210119824 = load i32, ptr %t210019823, align 1
  %v3808219825 = add i32 %t210119824, 1
  br label %edge2135

edge2125:                                         ; preds = %edge2113, %edge2114
  %v38057 = add i64 %v37069, 1024
  %t2100 = inttoptr i64 %v38057 to ptr
  %t2101 = load i32, ptr %t2100, align 1
  %v38082 = add i32 %t2101, 1
  %t2106.not = icmp eq i64 %v37061, 0
  br i1 %t2106.not, label %block18037, label %edge2135

edge2135:                                         ; preds = %edge2125.thread, %edge2125
  %v3808219830 = phi i32 [ %v3808219825, %edge2125.thread ], [ %v38082, %edge2125 ]
  %t210019827 = phi ptr [ %t210019823, %edge2125.thread ], [ %t2100, %edge2125 ]
  %t2107 = inttoptr i64 %v37061 to ptr
  %v38133 = load i64, ptr %t2107, align 1
  %t2108 = icmp eq i64 %v38133, 1
  br i1 %t2108, label %block18036, label %block18037

edge2143:                                         ; preds = %block18036
  %t2117 = inttoptr i64 %v38132 to ptr
  %v38144 = load i64, ptr %t2117, align 1
  %v38145 = add i64 %v38144, 1
  store i64 %v38145, ptr %t2117, align 1
  br label %block18041

edge2146:                                         ; preds = %block18041
  %t2121 = inttoptr i64 %v37061 to ptr
  %v38148 = load i64, ptr %t2121, align 1
  %v38149 = add i64 %v38148, -1
  store i64 %v38149, ptr %t2121, align 1
  %t2123.not = icmp eq i64 %v38149, 0
  br i1 %t2123.not, label %edge2149, label %block18054

edge2149:                                         ; preds = %edge2146
  %v38150 = call i64 @mech_compact_free(i64 %v0, i64 %v37061)
  %t2124.not = icmp eq i64 %v38150, 0
  br i1 %t2124.not, label %block18054, label %block18032

edge2152:                                         ; preds = %block18054
  %t2128 = inttoptr i64 %v38132 to ptr
  %v43046 = load i64, ptr %t2128, align 1
  %v43065 = add i64 %v43046, 5
  store i64 %v43065, ptr %t2128, align 1
  br label %edge2167

edge2167:                                         ; preds = %block18054, %edge2152
  %t2418.pre-phi = phi ptr [ %t2128, %edge2152 ], [ null, %block18054 ]
  %t2200 = inttoptr i64 %v35973 to ptr
  %v45752 = add i64 %v35968, -4
  %t2232 = zext i64 %v35968 to i128
  %v138888 = or disjoint i128 %t586, %t2232
  %v50224 = add i64 %v36030, 257
  %t2437 = zext i64 %v50224 to i128
  %t2441 = zext i64 %v36030 to i128
  %t4264 = icmp ult i64 %v36030, 16384
  %t4313 = icmp ult i64 %v36030, 10001
  %v91857 = lshr i64 %v36030, 11
  %t4382.not = icmp eq i64 %v35985, 0
  %t4383 = inttoptr i64 %v35985 to ptr
  %t4442 = inttoptr i64 %v35997 to ptr
  %t4444.not = icmp eq i64 %v137836, 0
  %t4445 = inttoptr i64 %v137836 to ptr
  %v98262 = or i64 %v35997, %v137836
  %t4474.not = icmp eq i64 %v98262, 0
  %umul142 = call { i64, i1 } @llvm.umul.with.overflow.i64(i64 %v137837, i64 %v36004)
  %29 = extractvalue { i64, i1 } %umul142, 1
  %v98414 = mul i64 %v36004, %v137837
  %t4490 = icmp ugt i64 %v98414, 92233720368547758
  %v98496 = mul nuw i64 %v98414, 200
  %v98577143 = lshr i64 %v98496, 9
  %v98587 = mul nuw nsw i64 %v98577143, 3
  %v98737 = mul nuw nsw i64 %v98577143, 9
  %brmerge = or i1 %29, %t4490
  br label %block2907

edge2176:                                         ; preds = %block2907
  %t2148.not = icmp eq i64 %v43260, 0
  br i1 %t2148.not, label %block2966, label %edge2178

edge2178:                                         ; preds = %edge2176
  %t2149 = inttoptr i64 %v43260 to ptr
  %v44191 = load i64, ptr %t2149, align 1
  %v44192 = add i64 %v44191, 1
  store i64 %v44192, ptr %t2149, align 1
  br label %block2966

edge2186:                                         ; preds = %block2966
  %t2153 = icmp eq i64 %v43246, 1
  br i1 %t2153, label %edge2190, label %common.ret

edge2190:                                         ; preds = %edge2186
  %t2157 = icmp ugt i64 %v43245, 257
  br i1 %t2157, label %block18425, label %edge2193

edge2193:                                         ; preds = %edge2190
  call preserve_allcc void @mech_compact_expand_capacity_preserving(i64 %v43245, i64 258, i64 3, i64 %v137568)
  %v137569 = load i64, ptr %ss2, align 8
  %t2159.not = icmp eq i64 %v137569, 0
  br i1 %t2159.not, label %block18420, label %block18425

edge2196:                                         ; preds = %block18425
  %t2161 = inttoptr i64 %v43248 to ptr
  %v45223 = load i64, ptr %t2161, align 1
  %t2162 = icmp eq i64 %v45223, 1
  %t2163 = icmp ule i64 %v45192, %v43245
  %v4522695 = and i1 %t2163, %t2162
  br i1 %v4522695, label %edge2203, label %block18436

edge2200:                                         ; preds = %block18436
  %t2167 = call i64 @llvm.umax.i64(i64 %v43245, i64 %v45192)
  br label %edge2203

edge2203:                                         ; preds = %edge2200, %edge2196
  %v45217 = phi i64 [ %v45228, %edge2200 ], [ %v43243, %edge2196 ]
  %v45219 = phi i64 [ %t2167, %edge2200 ], [ %v43245, %edge2196 ]
  %v45222 = phi i64 [ %v45229, %edge2200 ], [ %v43248, %edge2196 ]
  %v45236 = call i64 @memmove(i64 %v45217, i64 ptrtoint (ptr @mech_compact_table_8 to i64), i64 2064)
  %t2169 = icmp eq i64 %v43248, %v45222
  %t2171.not96 = icmp eq i64 %v45222, 0
  %t2171.not = or i1 %t2169, %t2171.not96
  br i1 %t2171.not, label %block18442, label %edge2206

edge2206:                                         ; preds = %edge2203
  %t2172 = inttoptr i64 %v45222 to ptr
  %v45239 = load i64, ptr %t2172, align 1
  %v45240 = add i64 %v45239, 1
  store i64 %v45240, ptr %t2172, align 1
  br label %block18442

edge2209:                                         ; preds = %block18442
  %v45245 = call i64 @mech_compact_release_owner(i64 %v0, i64 %v43248)
  %t2176.not = icmp eq i64 %v45245, 0
  br i1 %t2176.not, label %edge2214, label %block18420

edge2214:                                         ; preds = %block18442, %edge2209
  br i1 %t1979.not, label %block18491, label %edge2250

edge2250:                                         ; preds = %edge2214
  %v45337 = load i64, ptr %t2200, align 1
  %v45338 = add i64 %v45337, 1
  store i64 %v45338, ptr %t2200, align 1
  br label %block18491

edge2253:                                         ; preds = %block18491
  %t2203 = inttoptr i64 %v44640 to ptr
  %v45339 = load i64, ptr %t2203, align 1
  %v45340 = add i64 %v45339, 1
  store i64 %v45340, ptr %t2203, align 1
  br label %edge2256

edge2256:                                         ; preds = %block18491, %edge2253
  %v46215 = add i64 %v45333, 1036
  %v47048 = add i64 %v45333, 2060
  br label %block2989

edge2257:                                         ; preds = %block2989
  %t2206 = inttoptr i64 %v45358 to ptr
  %v45359 = load i64, ptr %t2206, align 1
  %t2207 = icmp eq i64 %v45359, 1
  br i1 %t2207, label %edge2263, label %block3000

edge2263:                                         ; preds = %edge2257
  %t2212 = icmp ule i64 %v45407, %v45413
  %v45370 = sub i64 %v45413, %v45407
  %t2213 = icmp ule i64 %v45414, %v45370
  %v4537298 = and i1 %t2212, %t2213
  %t2214 = icmp uge i64 %v45415, %v45414
  %t2215 = icmp ule i64 %v45415, %v3132
  %v4537699 = and i1 %t2214, %t2215
  %v45378100 = and i1 %v4537298, %v4537699
  br i1 %v45378100, label %edge2264, label %block3000

edge2264:                                         ; preds = %edge2263
  %t2218 = zext i64 %v45414 to i128
  %t2219 = zext nneg i64 %v45415 to i128
  %t2220 = shl nuw nsw i128 %t2219, 64
  %v138882 = or disjoint i128 %t2220, %t2218
  store i128 %v138882, ptr %ss3, align 16
  %t2222 = zext i64 %v45417 to i128
  %t2223 = zext i64 %v45407 to i128
  %t2224 = shl nuw i128 %t2223, 64
  %v138884 = or disjoint i128 %t2224, %t2222
  store i128 %v138884, ptr %t403, align 16
  %v138886 = or disjoint i128 %t2224, 1
  store i128 %v138886, ptr %t408, align 16
  store i128 %v138888, ptr %t413, align 16
  store i128 %v138890, ptr %t418, align 16
  %t2242 = zext i64 %v45333 to i128
  %v138892 = or disjoint i128 %t2242, 10090369008319124733952
  store i128 %v138892, ptr %t423, align 16
  store i128 10090369008319124733953, ptr %t424, align 16
  store i128 %v138896, ptr %t583, align 16
  store i128 4722366482869645213697, ptr %t588, align 16
  %t2262 = zext i64 %v45413 to i128
  %t2263 = zext i64 %v45358 to i128
  %t2264 = shl nuw i128 %t2263, 64
  %v138900 = or disjoint i128 %t2264, %t2262
  store i128 %v138900, ptr %t593, align 16
  %t2267 = call { i64, i64 } @mech_compact_numeric_3009_no_growth_composed(i64 %v0, i64 %v138697, i64 %v6374)
  %v45381 = extractvalue { i64, i64 } %t2267, 0
  %t2268.not = icmp eq i64 %v45381, 0
  br i1 %t2268.not, label %edge2267, label %edge2266

edge2266:                                         ; preds = %edge2264
  %v45382 = extractvalue { i64, i64 } %t2267, 1
  %t2269 = icmp eq i64 %v45381, 103169
  %v45385 = select i1 %t2269, i64 103425, i64 %v45381
  %t2271 = insertvalue { i64, i64 } poison, i64 %v45385, 0
  %t2272 = insertvalue { i64, i64 } %t2271, i64 %v45382, 1
  br label %common.ret

edge2267:                                         ; preds = %edge2264
  %v138902 = load i128, ptr %t2274, align 8
  %v138903 = trunc i128 %v138902 to i64
  %t2275 = lshr i128 %v138902, 64
  %v138904 = trunc nuw i128 %t2275 to i64
  %v138906 = load i128, ptr %t2277, align 8
  %v138907 = trunc i128 %v138906 to i64
  %t2278 = lshr i128 %v138906, 64
  %v138908 = trunc nuw i128 %t2278 to i64
  %v138910 = load i128, ptr %t2280, align 8
  %v138911 = trunc i128 %v138910 to i64
  %t2281 = lshr i128 %v138910, 64
  %v138912 = trunc nuw i128 %t2281 to i64
  %v45401 = or i64 %v44640, %v35973
  %t2282.not = icmp eq i64 %v45401, 0
  br i1 %t2282.not, label %block3390, label %edge2268

edge2268:                                         ; preds = %edge2267
  %v45403 = call i64 @mech_compact_release_two(i64 %v0, i64 %v35973, i64 %v44640)
  %t2283.not = icmp eq i64 %v45403, 0
  br i1 %t2283.not, label %block3390, label %edge2270

edge2270:                                         ; preds = %edge2268
  %t2284 = insertvalue { i64, i64 } poison, i64 %v45403, 0
  %t2285 = insertvalue { i64, i64 } %t2284, i64 3009, 1
  br label %common.ret

edge2300:                                         ; preds = %block3000.thread, %block3000
  %v45599 = add i64 %v45414, -1
  %v45603 = add i64 %v45415, -1
  %t2289 = icmp ult i64 %v45603, %v3132
  %v45749 = shl i64 %v45415, 2
  %v45753 = add i64 %v45752, %v45749
  %v139122 = select i1 %t2289, i64 %v45753, i64 ptrtoint (ptr @mech_compact_llvm_anonymous_data_1 to i64)
  %t2292 = inttoptr i64 %v139122 to ptr
  %t2293 = load i32, ptr %t2292, align 1
  %v45754 = zext i32 %t2293 to i64
  %v45790 = and i64 %v45754, 65535
  %v45977 = lshr i64 %v45754, 16
  %t2300 = icmp ult i32 %t2293, 18874368
  %v46066 = shl nuw nsw i64 %v45977, 2
  %v46216 = add i64 %v46215, %v46066
  %30 = inttoptr i64 %v46216 to ptr
  %t2303 = select i1 %t2300, ptr %30, ptr @mech_compact_llvm_anonymous_data_1
  %t2304 = load i32, ptr %t2303, align 1
  %v46382 = shl i64 %v45407, 3
  %v46385 = add i64 %v46382, -8
  %v46386 = add i64 %v46385, %v45417
  %t2308 = inttoptr i64 %v46386 to ptr
  %v46387 = load i64, ptr %t2308, align 1
  %31 = trunc i64 %v46387 to i32
  %v46423.narrow = add i32 %t2304, %31
  %v46427 = zext i32 %v46423.narrow to i64
  %v46465 = shl nuw nsw i64 %v45977, 9
  %v46469 = or disjoint i64 %v46465, 1
  %v46483 = sub i64 %v45603, %v45790
  br label %block3108

edge2336:                                         ; preds = %edge2420
  %v47329 = add nsw i64 %v47236, -2
  %v48037 = shl nuw nsw i64 %v46701, 9
  %umax = call i64 @llvm.umax.i64(i64 %v46518, i64 %v47329)
  br label %block3215

edge2337:                                         ; preds = %edge2420
  %v47275 = or i64 %v137795, %v1399
  %v47277 = or i64 %v47275, %v35967
  %t2336.not = icmp eq i64 %v47277, 0
  br i1 %t2336.not, label %block19236, label %edge2338

edge2338:                                         ; preds = %edge2337
  %v47278 = call i64 @mech_compact_release_three(i64 %v0, i64 %v1399, i64 %v137795, i64 %v35967)
  %t2337.not = icmp eq i64 %v47278, 0
  br i1 %t2337.not, label %block19236, label %block19221

edge2342:                                         ; preds = %block19236
  %v47283 = call i64 @mech_compact_release_four(i64 %v0, i64 %v35973, i64 %v35991, i64 %v35997, i64 %v36003)
  %t2339.not = icmp eq i64 %v47283, 0
  br i1 %t2339.not, label %block19239, label %block19221

edge2346:                                         ; preds = %block19239
  %v47288 = call i64 @mech_compact_release_three(i64 %v0, i64 %v35985, i64 %v137836, i64 %v35997)
  %t2341.not = icmp eq i64 %v47288, 0
  br i1 %t2341.not, label %block19242, label %block19221

edge2350:                                         ; preds = %block19242
  %v47293 = call i64 @mech_compact_release_nullable(i64 %v0, i64 %v43260)
  %t2343.not = icmp eq i64 %v47293, 0
  br i1 %t2343.not, label %block19245, label %block19221

edge2354:                                         ; preds = %block19245
  %v47298 = call i64 @mech_compact_release_four(i64 %v0, i64 %v43272, i64 %v43288, i64 %v43300, i64 %v35973)
  %t2345.not = icmp eq i64 %v47298, 0
  br i1 %t2345.not, label %block19248, label %block19221

edge2358:                                         ; preds = %block19248
  %v47303 = call i64 @mech_compact_release_nullable(i64 %v0, i64 %v38132)
  %t2347.not = icmp eq i64 %v47303, 0
  br i1 %t2347.not, label %block19251, label %block19221

edge2362:                                         ; preds = %block19251
  %v47308 = call i64 @mech_compact_release_two(i64 %v0, i64 %v43406, i64 %v43418)
  %t2349.not = icmp eq i64 %v47308, 0
  br i1 %t2349.not, label %block19254, label %block19221

edge2366:                                         ; preds = %block19254
  %v47313 = call i64 @mech_compact_release_four(i64 %v0, i64 %v43430, i64 %v44640, i64 %v45358, i64 %v35973)
  %t2351.not = icmp eq i64 %v47313, 0
  br i1 %t2351.not, label %edge2369, label %block19221

edge2369:                                         ; preds = %edge2366
  br i1 %t2202.not, label %block39124, label %edge2370

edge2370:                                         ; preds = %edge2369
  %v47316 = call i64 @mech_compact_release_nullable(i64 %v0, i64 %v44640)
  %t2353.not = icmp eq i64 %v47316, 0
  br i1 %t2353.not, label %block39124, label %block19221

edge2388:                                         ; preds = %edge2415
  %v47714 = shl i64 %v47565, 3
  %v47715 = add i64 %v47714, %v45417
  %t2364 = inttoptr i64 %v47715 to ptr
  %v47716 = load i64, ptr %t2364, align 1
  %32 = trunc i64 %v47716 to i32
  br label %edge2395

edge2395:                                         ; preds = %edge2415, %edge2388
  %v47730 = phi i32 [ %32, %edge2388 ], [ 0, %edge2415 ]
  %v47750.narrow = add i32 %v47550.narrow, %v47730
  %v47754 = zext i32 %v47750.narrow to i64
  %t2365 = icmp samesign ugt i64 %v47366, %v47754
  %v48064 = call i64 @llvm.umin.i64(i64 %v47366, i64 %v47754)
  %v47375.masked = and i64 %v47375, 4294967295
  %v48045 = or i64 %v47375.masked, %v48037
  %v48065 = select i1 %t2365, i64 %v48045, i64 %v47371
  %v48062 = add i64 %v47361, 1
  br label %block3215

edge2415:                                         ; preds = %block3215
  %v47375 = add i64 %v47361, 3
  %t2356 = icmp ult i64 %v47375, 547
  %v47524 = shl i64 %v47375, 2
  %v47525 = add i64 %v47524, %v45333
  %v139129 = select i1 %t2356, i64 %v47525, i64 ptrtoint (ptr @mech_compact_llvm_anonymous_data_1 to i64)
  %t2359 = inttoptr i64 %v139129 to ptr
  %t2360 = load i32, ptr %t2359, align 1
  %v47550.narrow = add i32 %t2360, %t2328
  %v47565 = sub i64 %v45407, %v47375
  %t2361 = icmp ult i64 %v47565, %v45407
  br i1 %t2361, label %edge2388, label %edge2395

edge2420:                                         ; preds = %block3108
  %t2310 = icmp ult i64 %v46513, %v3132
  %v46672 = add i64 %v46513, 1
  %v46677 = shl i64 %v46513, 2
  %v46678 = add i64 %v46677, %v35968
  %v139125 = select i1 %t2310, i64 %v46678, i64 ptrtoint (ptr @mech_compact_llvm_anonymous_data_1 to i64)
  %t2313 = inttoptr i64 %v139125 to ptr
  %t2314 = load i32, ptr %t2313, align 1
  %v46679 = zext i32 %t2314 to i64
  %v46701 = lshr i64 %v46679, 16
  %v46718 = sub nsw i64 256, %v46701
  %v46722 = lshr i64 %v46718, 29
  %v46727 = and i64 %v46722, 7
  %v46731 = add nsw i64 %v46701, -1
  %v46736 = lshr i64 %v46731, %v46727
  %t2318 = icmp ult i64 %v46736, 256
  %v46873 = add i64 %v46736, ptrtoint (ptr @mech_compact_table_18 to i64)
  %v139126 = select i1 %t2318, i64 %v46873, i64 ptrtoint (ptr @mech_compact_llvm_anonymous_data_1 to i64)
  %t2321 = inttoptr i64 %v139126 to ptr
  %t2322 = load i8, ptr %t2321, align 1
  %v46874 = zext i8 %t2322 to i64
  %v46891 = shl nuw nsw i64 %v46727, 1
  %v46895 = add nuw nsw i64 %v46891, %v46874
  %t2324 = icmp samesign ult i64 %v46895, 32
  %v46899 = shl nuw nsw i64 %v46895, 2
  %v47049 = add i64 %v47048, %v46899
  %v139127 = select i1 %t2324, i64 %v47049, i64 ptrtoint (ptr @mech_compact_llvm_anonymous_data_1 to i64)
  %t2327 = inttoptr i64 %v139127 to ptr
  %t2328 = load i32, ptr %t2327, align 1
  %v47236 = and i64 %v46679, 65535
  %v137615 = add nsw i64 %v47236, -3
  %t2334 = icmp ult i64 %v137615, 256
  br i1 %t2334, label %edge2336, label %edge2337

edge2422:                                         ; preds = %block3108
  %v48868 = shl nuw i64 %v46528, 32
  %v48872 = or i64 %v48868, %v46523
  %t2377 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %v45407, i64 1)
  %v48879 = extractvalue { i64, i1 } %t2377, 0
  %t2378 = extractvalue { i64, i1 } %t2377, 1
  br i1 %t2378, label %block19708, label %edge2426

edge2426:                                         ; preds = %edge2422
  %t2381.not = icmp ugt i64 %v48879, %v45413
  br i1 %t2381.not, label %edge2429, label %block19712

edge2429:                                         ; preds = %edge2426
  call preserve_allcc void @mech_compact_expand_capacity_preserving(i64 %v45413, i64 %v48879, i64 3, i64 %v137568)
  %v137573 = load i64, ptr %ss2, align 8
  %t2383.not = icmp eq i64 %v137573, 0
  br i1 %t2383.not, label %block19708, label %block19712

edge2432:                                         ; preds = %block19712
  %t2385 = inttoptr i64 %v45358 to ptr
  %v48915 = load i64, ptr %t2385, align 1
  %t2386 = icmp eq i64 %v48915, 1
  %t2387 = icmp ule i64 %v48884, %v45413
  %v48918101 = and i1 %t2387, %t2386
  br i1 %v48918101, label %block19722, label %block19723

edge2436:                                         ; preds = %block19723
  %t2391 = call i64 @llvm.umax.i64(i64 %v45413, i64 %v48884)
  br label %block19722

edge2439:                                         ; preds = %block19722
  %t2396 = inttoptr i64 %v48914 to ptr
  %v48928 = load i64, ptr %t2396, align 1
  %v48929 = add i64 %v48928, 1
  store i64 %v48929, ptr %t2396, align 1
  br label %edge2448

edge2444:                                         ; preds = %block3000
  %v48952 = add i64 %v45359, 1
  store i64 %v48952, ptr %t2206, align 1
  br label %edge2450

edge2448:                                         ; preds = %edge2439, %block19722
  %t2408.not = or i1 %t2205.not, %t2393
  br i1 %t2408.not, label %block2989.backedge, label %edge2455

edge2450:                                         ; preds = %block3000.thread, %edge2444
  %v48981 = or i64 %v44640, %v35973
  %v48983 = or i64 %v48981, %v45358
  %t2406.not = icmp eq i64 %v48983, 0
  br i1 %t2406.not, label %block3390, label %edge2451

edge2451:                                         ; preds = %edge2450
  %v48984 = call i64 @mech_compact_release_three(i64 %v0, i64 %v35973, i64 %v44640, i64 %v45358)
  %t2407.not = icmp eq i64 %v48984, 0
  br i1 %t2407.not, label %block3390, label %block19756

edge2455:                                         ; preds = %edge2448
  %t2409 = inttoptr i64 %v45358 to ptr
  %v48986 = load i64, ptr %t2409, align 1
  %v48987 = add i64 %v48986, -1
  store i64 %v48987, ptr %t2409, align 1
  %t2411.not = icmp eq i64 %v48987, 0
  br i1 %t2411.not, label %edge2458, label %block2989.backedge

edge2458:                                         ; preds = %edge2455
  %v48988 = call i64 @mech_compact_free(i64 %v0, i64 %v45358)
  %t2412.not = icmp eq i64 %v48988, 0
  br i1 %t2412.not, label %block2989.backedge, label %block19756

block2989.backedge:                               ; preds = %edge2458, %edge2455, %edge2448
  br label %block2989

edge2467:                                         ; preds = %block3390
  br i1 %t2116.not92, label %block3637, label %edge2469

edge2468:                                         ; preds = %block3390
  %t2420.not = icmp eq i64 %v49365, 0
  br i1 %t2420.not, label %edge2482, label %edge2473

edge2469:                                         ; preds = %edge2467
  %v49352 = load i64, ptr %t2418.pre-phi, align 1
  %v49353 = add i64 %v49352, 1
  store i64 %v49353, ptr %t2418.pre-phi, align 1
  br label %block3637

edge2473:                                         ; preds = %edge2468
  %t2421 = inttoptr i64 %v49365 to ptr
  %v49366 = load i64, ptr %t2421, align 1
  %v49367 = add i64 %v49366, 1
  store i64 %v49367, ptr %t2421, align 1
  br label %edge2482

edge2479:                                         ; preds = %edge2485
  %t2426 = insertvalue { i64, i64 } poison, i64 %v50049, 0
  %t2427 = insertvalue { i64, i64 } %t2426, i64 3431, 1
  br label %common.ret

edge2482:                                         ; preds = %edge2473, %edge2468
  %t2428 = call { i64, i64 } @mech_compact_allocate_backing(i64 %v0, i64 320, i64 4, i64 4, i64 1)
  %v50105 = extractvalue { i64, i64 } %t2428, 0
  %v50106 = extractvalue { i64, i64 } %t2428, 1
  %t2429.not = icmp eq i64 %v50105, 0
  br i1 %t2429.not, label %edge2484, label %edge2485

edge2484:                                         ; preds = %edge2482
  %t2431 = insertvalue { i64, i64 } poison, i64 %v50106, 0
  %t2432 = insertvalue { i64, i64 } %t2431, i64 3435, 1
  br label %common.ret

edge2485:                                         ; preds = %edge2482
  %t2430 = inttoptr i64 %v50106 to ptr
  store i64 2, ptr %t2430, align 1
  %v50049 = call i64 @mech_compact_release_owner(i64 %v0, i64 %v50106)
  %t2425.not = icmp eq i64 %v50049, 0
  br i1 %t2425.not, label %block3417, label %edge2479

edge2491:                                         ; preds = %block3417
  %t2434 = inttoptr i64 %v50254 to ptr
  %v50255 = load i64, ptr %t2434, align 1
  %t2435 = icmp eq i64 %v50255, 1
  br i1 %t2435, label %edge2493, label %block3429.thread

edge2493:                                         ; preds = %edge2491
  %t2438 = zext i64 %v50277 to i128
  %t2439 = shl nuw i128 %t2438, 64
  %v138914 = or disjoint i128 %t2439, %t2437
  store i128 %v138914, ptr %ss3, align 16
  %t2442 = zext i64 %v49360 to i128
  %t2443 = shl nuw i128 %t2442, 64
  %v138916 = or disjoint i128 %t2443, %t2441
  store i128 %v138916, ptr %t403, align 16
  %t2446 = zext i64 %v49361 to i128
  %t2447 = zext i64 %v49363 to i128
  %t2448 = shl nuw i128 %t2447, 64
  %v138918 = or disjoint i128 %t2448, %t2446
  store i128 %v138918, ptr %t408, align 16
  %t2451 = zext i64 %v49364 to i128
  %t2452 = zext i64 %v50283 to i128
  %t2453 = shl nuw i128 %t2452, 64
  %v138920 = or disjoint i128 %t2453, %t2451
  store i128 %v138920, ptr %t413, align 16
  store i128 18446744073709551936, ptr %t418, align 16
  store i128 %v138924, ptr %t423, align 16
  store i128 18446744073709551875, ptr %t424, align 16
  store i128 %v138928, ptr %t583, align 16
  store i128 18446744073709551872, ptr %t588, align 16
  %t2482 = zext i64 %v50254 to i128
  %t2483 = shl nuw i128 %t2482, 64
  %v138932 = or disjoint i128 %t2483, 256
  store i128 %v138932, ptr %t593, align 16
  store i64 320, ptr %t598, align 16
  %t2487 = call { i64, i64 } @mech_compact_numeric_3447_seeded_entry(i64 %v0, i64 %v138697, i64 %v6374, i64 %v1394, i64 %v1395, i64 %v36006, i64 %v38127, i64 320)
  %v50260 = extractvalue { i64, i64 } %t2487, 0
  %t2488.not = icmp eq i64 %v50260, 0
  br i1 %t2488.not, label %edge2496, label %edge2495

edge2495:                                         ; preds = %edge2493
  %v50261 = extractvalue { i64, i64 } %t2487, 1
  %t2489 = icmp eq i64 %v50260, 103169
  %v50264 = select i1 %t2489, i64 103425, i64 %v50260
  %t2491 = insertvalue { i64, i64 } poison, i64 %v50264, 0
  %t2492 = insertvalue { i64, i64 } %t2491, i64 %v50261, 1
  br label %common.ret

edge2496:                                         ; preds = %edge2493
  br i1 %t2420.not, label %edge2635.thread, label %edge2497

edge2497:                                         ; preds = %edge2496
  %v50270 = call i64 @mech_compact_release_nullable(i64 %v0, i64 %v49365)
  %t2494.not = icmp eq i64 %v50270, 0
  br i1 %t2494.not, label %edge2635.thread, label %edge2499

edge2499:                                         ; preds = %edge2497
  %t2495 = insertvalue { i64, i64 } poison, i64 %v50270, 0
  %t2496 = insertvalue { i64, i64 } %t2495, i64 3447, 1
  br label %common.ret

edge2504:                                         ; preds = %block3429.thread, %block3429
  %v50470 = sub i64 %v50224, %v50277
  %t2500 = icmp ult i64 %v50470, %v49361
  br i1 %t2500, label %edge2515, label %edge2522.thread

edge2515:                                         ; preds = %edge2504
  %v50622 = shl i64 %v50470, 3
  %v50623 = add i64 %v50622, %v49360
  %t2503 = inttoptr i64 %v50623 to ptr
  %v50624 = load i64, ptr %t2503, align 1
  %v50624.fr = freeze i64 %v50624
  %33 = lshr i64 %v50624.fr, 32
  %v50785 = and i64 %33, 511
  %v50798 = lshr i64 %v50624.fr, 41
  %t2506 = icmp eq i64 %v50785, 1
  br i1 %t2506, label %edge2521, label %edge2522

edge2521:                                         ; preds = %edge2515
  %v51044 = shl nuw nsw i64 %v50798, 2
  %v51195 = and i64 %v51044, 1020
  %v51196 = add i64 %v51195, %v50283
  %t2509 = inttoptr i64 %v51196 to ptr
  %t2510 = load i32, ptr %t2509, align 1
  %v51219 = add i32 %t2510, 1
  br i1 %t2433.not, label %block20258, label %edge2533

edge2522:                                         ; preds = %edge2515
  %t2531 = icmp samesign ult i64 %v50785, 259
  %v51435 = add i64 %v50785, ptrtoint (ptr @mech_compact_table_7 to i64)
  %spec.select863 = select i1 %t2531, i64 %v51435, i64 ptrtoint (ptr @mech_compact_llvm_anonymous_data_1 to i64)
  %34 = inttoptr i64 %spec.select863 to ptr
  br label %edge2522.thread

edge2522.thread:                                  ; preds = %edge2522, %edge2504
  %v50785694704 = phi i64 [ %v50785, %edge2522 ], [ 0, %edge2504 ]
  %v50798695702 = phi i64 [ %v50798, %edge2522 ], [ 0, %edge2504 ]
  %t2534 = phi ptr [ %34, %edge2522 ], [ @mech_compact_table_7, %edge2504 ]
  %t2535 = load i8, ptr %t2534, align 1
  %v51436 = zext i8 %t2535 to i64
  %t2536 = icmp ult i8 %t2535, 63
  %v51574 = shl nuw nsw i64 %v51436, 2
  %v51725 = add nuw nsw i64 %v51574, 1028
  %v51726 = add i64 %v51725, %v50283
  %35 = inttoptr i64 %v51726 to ptr
  %t2539 = select i1 %t2536, ptr %35, ptr @mech_compact_llvm_anonymous_data_1
  %t2540 = load i32, ptr %t2539, align 1
  %36 = add i32 %t2540, 1
  br i1 %t2536, label %edge2556, label %block20424

edge2533:                                         ; preds = %edge2521
  %t2516 = inttoptr i64 %v50254 to ptr
  %v51258 = load i64, ptr %t2516, align 1
  %t2517 = icmp eq i64 %v51258, 1
  br i1 %t2517, label %block20257, label %block20258

edge2538:                                         ; preds = %block20258
  %t2529 = insertvalue { i64, i64 } poison, i64 %v51264, 0
  %t2530 = insertvalue { i64, i64 } %t2529, i64 3524, 1
  br label %common.ret

edge2541:                                         ; preds = %block20257
  %t2526 = inttoptr i64 %v51257 to ptr
  %v51269 = load i64, ptr %t2526, align 1
  %v51270 = add i64 %v51269, 1
  store i64 %v51270, ptr %t2526, align 1
  br label %block20262

edge2556:                                         ; preds = %edge2522.thread
  %t2544 = load i32, ptr %35, align 1
  %t2545 = icmp eq i32 %t2544, %36
  br i1 %t2545, label %block20427, label %edge2559

edge2559:                                         ; preds = %edge2556
  br i1 %t2433.not, label %block20429, label %edge2560

edge2560:                                         ; preds = %edge2559
  %t2548 = inttoptr i64 %v50254 to ptr
  %v51787 = load i64, ptr %t2548, align 1
  %t2549 = icmp eq i64 %v51787, 1
  br i1 %t2549, label %block20428, label %block20429

edge2568:                                         ; preds = %block20427
  %t2558 = inttoptr i64 %v51780 to ptr
  %v51798 = load i64, ptr %t2558, align 1
  %v51799 = add i64 %v51798, 1
  store i64 %v51799, ptr %t2558, align 1
  br label %block20433

edge2590:                                         ; preds = %block20433
  %t2578 = inttoptr i64 %v52281 to ptr
  %t2579 = load i32, ptr %t2578, align 1
  %t2580 = icmp eq i32 %t2579, %2
  br i1 %t2580, label %block20582, label %edge2593

edge2593:                                         ; preds = %edge2590
  %t2582.not = icmp eq i64 %v51800, 0
  br i1 %t2582.not, label %block20585, label %edge2594

edge2594:                                         ; preds = %edge2593
  %v52339 = call i64 @mech_compact_release_owner(i64 %v0, i64 %v51800)
  %t2583.not = icmp eq i64 %v52339, 0
  br i1 %t2583.not, label %block20585, label %block20579

edge2598:                                         ; preds = %block20585
  %t2585 = inttoptr i64 %v51780 to ptr
  %v52346 = load i64, ptr %t2585, align 1
  %t2586 = icmp eq i64 %v52346, 1
  br i1 %t2586, label %block20587, label %block20588

edge2606:                                         ; preds = %block20582
  %t2595 = inttoptr i64 %v52335 to ptr
  %v52357 = load i64, ptr %t2595, align 1
  %v52358 = add i64 %v52357, 1
  store i64 %v52358, ptr %t2595, align 1
  br label %block20592

edge2609:                                         ; preds = %block20592
  %v52363 = call i64 @mech_compact_release_owner(i64 %v0, i64 %v51780)
  %t2599.not = icmp eq i64 %v52363, 0
  br i1 %t2599.not, label %edge2621, label %block20579

edge2616:                                         ; preds = %block3429.thread
  %v52400 = add i64 %v50255, 1
  store i64 %v52400, ptr %t2434, align 1
  br label %edge2622

edge2621:                                         ; preds = %block20262, %block20592, %edge2609
  %v50785693 = phi i64 [ 1, %block20262 ], [ %v50785694704, %edge2609 ], [ %v50785694704, %block20592 ]
  %v52376 = phi i64 [ %v51252, %block20262 ], [ %v52330, %edge2609 ], [ %v52330, %block20592 ]
  %v52381 = phi i64 [ %v51257, %block20262 ], [ %v52335, %edge2609 ], [ %v52335, %block20592 ]
  %v52436 = phi i64 [ %v50254, %block20262 ], [ %v52437, %edge2609 ], [ %v52437, %block20592 ]
  %t2609.not = icmp eq i64 %v52436, 0
  br i1 %t2609.not, label %edge2633, label %edge2627

edge2622:                                         ; preds = %block3429, %edge2616
  %v52428 = or i64 %v50254, %v49365
  %t2607.not = icmp eq i64 %v52428, 0
  br i1 %t2607.not, label %edge2635, label %edge2623

edge2623:                                         ; preds = %edge2622
  %v52429 = call i64 @mech_compact_release_two(i64 %v0, i64 %v49365, i64 %v50254)
  %t2608.not = icmp eq i64 %v52429, 0
  br i1 %t2608.not, label %edge2635, label %block20629

edge2627:                                         ; preds = %edge2621
  %t2610 = inttoptr i64 %v52436 to ptr
  %v52431 = load i64, ptr %t2610, align 1
  %v52432 = add i64 %v52431, -1
  store i64 %v52432, ptr %t2610, align 1
  %t2612.not = icmp eq i64 %v52432, 0
  br i1 %t2612.not, label %edge2630, label %edge2633

edge2630:                                         ; preds = %edge2627
  %v52433 = call i64 @mech_compact_free(i64 %v0, i64 %v52436)
  %t2613.not = icmp eq i64 %v52433, 0
  br i1 %t2613.not, label %edge2633, label %block20629

edge2633:                                         ; preds = %block20262, %edge2630, %edge2627, %edge2621
  %v50785.pn = phi i64 [ %v50785693, %edge2621 ], [ %v50785693, %edge2630 ], [ %v50785693, %edge2627 ], [ 1, %block20262 ]
  %v52381722 = phi i64 [ %v52381, %edge2621 ], [ %v52381, %edge2630 ], [ %v52381, %edge2627 ], [ %v50254, %block20262 ]
  %v52376721 = phi i64 [ %v52376, %edge2621 ], [ %v52376, %edge2630 ], [ %v52376, %edge2627 ], [ %v51252, %block20262 ]
  %v52374723 = add i64 %v50785.pn, %v50277
  br label %block3417

edge2635.thread:                                  ; preds = %edge2496, %edge2497
  %v5273219835 = add i64 %v50283, 1024
  %t261619836 = inttoptr i64 %v5273219835 to ptr
  %t261719837 = load i32, ptr %t261619836, align 1
  %v5275419838 = add i32 %t261719837, 1
  br label %edge2645

edge2635:                                         ; preds = %edge2622, %edge2623
  %v52732 = add i64 %v50283, 1024
  %t2616 = inttoptr i64 %v52732 to ptr
  %t2617 = load i32, ptr %t2616, align 1
  %v52754 = add i32 %t2617, 1
  %t2622.not = icmp eq i64 %v50254, 0
  br i1 %t2622.not, label %block20785, label %edge2645

edge2645:                                         ; preds = %edge2635.thread, %edge2635
  %v5275419846 = phi i32 [ %v5275419838, %edge2635.thread ], [ %v52754, %edge2635 ]
  %t261619843 = phi ptr [ %t261619836, %edge2635.thread ], [ %t2616, %edge2635 ]
  %t2623 = inttoptr i64 %v50254 to ptr
  %v52793 = load i64, ptr %t2623, align 1
  %t2624 = icmp eq i64 %v52793, 1
  br i1 %t2624, label %block20789.thread, label %block20785

block20789.thread:                                ; preds = %edge2645
  store i32 %v5275419846, ptr %t261619843, align 1
  br label %block3637

edge2653:                                         ; preds = %block20784
  %t2633 = inttoptr i64 %v52799 to ptr
  %v52804 = load i64, ptr %t2633, align 1
  %v52805 = add i64 %v52804, 1
  store i64 %v52805, ptr %t2633, align 1
  br label %block20789

edge2656:                                         ; preds = %block20789
  %v52810 = call i64 @mech_compact_release_owner(i64 %v0, i64 %v5258219841)
  %t2637.not = icmp eq i64 %v52810, 0
  br i1 %t2637.not, label %block3637, label %block20780

edge2662:                                         ; preds = %block3637
  %t2642.not = icmp eq i64 %v43288, 0
  br i1 %t2642.not, label %block21241, label %edge2664

edge2663:                                         ; preds = %block3637
  br i1 %t2143, label %edge2668, label %edge2669

edge2664:                                         ; preds = %edge2662
  %v52830 = call i64 @mech_compact_release_owner(i64 %v0, i64 %v43288)
  %t2643.not = icmp eq i64 %v52830, 0
  br i1 %t2643.not, label %block21241, label %edge2666

edge2666:                                         ; preds = %edge2664
  %t2644 = insertvalue { i64, i64 } poison, i64 %v52830, 0
  %t2645 = insertvalue { i64, i64 } %t2644, i64 3675, 1
  br label %common.ret

edge2668:                                         ; preds = %edge2663
  %t2648.not = icmp eq i64 %v43288, 0
  br i1 %t2648.not, label %edge3909, label %edge2670

edge2669:                                         ; preds = %edge2663
  %t2652 = icmp eq i64 %v43239, 1
  br i1 %t2652, label %edge2675, label %edge2676

edge2670:                                         ; preds = %edge2668
  %v52974 = call i64 @mech_compact_release_owner(i64 %v0, i64 %v43288)
  %t2649.not = icmp eq i64 %v52974, 0
  br i1 %t2649.not, label %edge3909, label %edge2672

edge2672:                                         ; preds = %edge2670
  %t2650 = insertvalue { i64, i64 } poison, i64 %v52974, 0
  %t2651 = insertvalue { i64, i64 } %t2650, i64 3682, 1
  br label %common.ret

edge2675:                                         ; preds = %edge2669
  %t2658.not = icmp eq i64 %v53385, 0
  br i1 %t2658.not, label %block3684.preheader, label %edge2682

edge2676:                                         ; preds = %edge2669
  %t2654.not = icmp eq i64 %v43288, 0
  br i1 %t2654.not, label %block21241, label %edge2677

edge2677:                                         ; preds = %edge2676
  %v53101 = call i64 @mech_compact_release_owner(i64 %v0, i64 %v43288)
  %t2655.not = icmp eq i64 %v53101, 0
  br i1 %t2655.not, label %block21241, label %edge2679

edge2679:                                         ; preds = %edge2677
  %t2656 = insertvalue { i64, i64 } poison, i64 %v53101, 0
  %t2657 = insertvalue { i64, i64 } %t2656, i64 3689, 1
  br label %common.ret

edge2682:                                         ; preds = %edge2675
  %t2659 = inttoptr i64 %v53385 to ptr
  %v53394 = load i64, ptr %t2659, align 1
  %v53395 = add i64 %v53394, 1
  store i64 %v53395, ptr %t2659, align 1
  br label %block3684.preheader

block3684.preheader:                              ; preds = %edge2675, %edge2682
  br label %block3684

edge2688:                                         ; preds = %edge2701
  %v53457 = or i64 %v53385, %v43288
  %t2664.not = icmp eq i64 %v53457, 0
  br i1 %t2664.not, label %edge3909, label %edge2689

edge2689:                                         ; preds = %edge2688
  %v53458 = call i64 @mech_compact_release_two(i64 %v0, i64 %v53385, i64 %v43288)
  %t2665.not = icmp eq i64 %v53458, 0
  br i1 %t2665.not, label %edge3909, label %edge2691

edge2691:                                         ; preds = %edge2689
  %t2666 = insertvalue { i64, i64 } poison, i64 %v53458, 0
  %t2667 = insertvalue { i64, i64 } %t2666, i64 3706, 1
  br label %common.ret

edge2701:                                         ; preds = %block3684
  %v53715 = add nuw nsw i64 %v138610, 1
  %exitcond19707.not = icmp eq i64 %v53715, 320
  br i1 %exitcond19707.not, label %edge2688, label %block3684

edge2702:                                         ; preds = %block3684
  %v53914 = or i64 %v53385, %v43288
  %t2675.not = icmp eq i64 %v53914, 0
  br i1 %t2675.not, label %block21241, label %edge2703

edge2703:                                         ; preds = %edge2702
  %v53915 = call i64 @mech_compact_release_two(i64 %v0, i64 %v53385, i64 %v43288)
  %t2676.not = icmp eq i64 %v53915, 0
  br i1 %t2676.not, label %block21241, label %edge2705

edge2705:                                         ; preds = %edge2703
  %t2677 = insertvalue { i64, i64 } poison, i64 %v53915, 0
  %t2678 = insertvalue { i64, i64 } %t2677, i64 3751, 1
  br label %common.ret

edge2713:                                         ; preds = %block21241
  %v54084 = call i64 @mech_compact_release_four(i64 %v0, i64 %v43300, i64 %v43406, i64 %v43418, i64 %v43430)
  %t2680.not = icmp eq i64 %v54084, 0
  br i1 %t2680.not, label %block3743, label %edge2715

edge2715:                                         ; preds = %edge2713
  %t2681 = insertvalue { i64, i64 } poison, i64 %v54084, 0
  %t2682 = insertvalue { i64, i64 } %t2681, i64 3773, 1
  br label %common.ret

edge2719:                                         ; preds = %block3743
  %t2684 = inttoptr i64 %v53385 to ptr
  %v54403 = load i64, ptr %t2684, align 1
  %v54410 = add i64 %v54403, 4
  store i64 %v54410, ptr %t2684, align 1
  br label %edge2732

edge2732:                                         ; preds = %block3743, %edge2719
  %t3954.pre-phi = phi ptr [ %t2684, %edge2719 ], [ null, %block3743 ]
  br label %block3784

edge2737:                                         ; preds = %edge2752
  %t2698 = insertvalue { i64, i64 } poison, i64 %v55788, 0
  %t2699 = insertvalue { i64, i64 } %t2698, i64 3828, 1
  br label %common.ret

edge2750:                                         ; preds = %block3784
  %t2708.not = icmp eq i64 %v55832, 0
  br i1 %t2708.not, label %edge2770, label %edge2752

edge2752:                                         ; preds = %edge2750
  %t2709 = inttoptr i64 %v55832 to ptr
  %v55835 = load i64, ptr %t2709, align 1
  %v55784 = add i64 %v55835, 2
  store i64 %v55784, ptr %t2709, align 1
  %v55788 = call i64 @mech_compact_release_owner(i64 %v0, i64 %v55832)
  %t2697.not = icmp eq i64 %v55788, 0
  br i1 %t2697.not, label %edge2770, label %edge2737

edge2759:                                         ; preds = %edge2774
  %t2716 = insertvalue { i64, i64 } poison, i64 %v56678, 0
  %t2717 = insertvalue { i64, i64 } %t2716, i64 3841, 1
  br label %common.ret

edge2770:                                         ; preds = %edge2752, %edge2750
  %t2724 = call { i64, i64 } @mech_compact_allocate_backing(i64 %v0, i64 %v137690, i64 4, i64 4, i64 1)
  %v56720 = extractvalue { i64, i64 } %t2724, 0
  %v56721 = extractvalue { i64, i64 } %t2724, 1
  %t2725.not = icmp eq i64 %v56720, 0
  br i1 %t2725.not, label %block21479, label %edge2772

edge2772:                                         ; preds = %edge2770
  %t2726.not = icmp eq i64 %v56721, 0
  br i1 %t2726.not, label %block3810, label %edge2774

edge2774:                                         ; preds = %edge2772
  %t2727 = inttoptr i64 %v56721 to ptr
  %v56724 = load i64, ptr %t2727, align 1
  %v56674 = add i64 %v56724, 2
  store i64 %v56674, ptr %t2727, align 1
  %v56678 = call i64 @mech_compact_release_owner(i64 %v0, i64 %v56721)
  %t2715.not = icmp eq i64 %v56678, 0
  br i1 %t2715.not, label %block3810, label %edge2759

edge2781:                                         ; preds = %block3810
  %t2735.not = icmp eq i64 %v137671, 0
  br i1 %t2735.not, label %edge2912, label %edge2783

edge2783:                                         ; preds = %edge2781
  %t2736 = inttoptr i64 %v137671 to ptr
  %v56970 = load i64, ptr %t2736, align 1
  %v56971 = add i64 %v56970, -1
  store i64 %v56971, ptr %t2736, align 1
  %t2738.not = icmp eq i64 %v56971, 0
  br i1 %t2738.not, label %edge2786, label %edge2912

edge2786:                                         ; preds = %edge2783
  %v56972 = call i64 @mech_compact_free(i64 %v0, i64 %v137671)
  %t2739.not = icmp eq i64 %v56972, 0
  br i1 %t2739.not, label %edge2912, label %edge2787

edge2787:                                         ; preds = %edge2786
  %t2740 = insertvalue { i64, i64 } poison, i64 %v56972, 0
  %t2741 = insertvalue { i64, i64 } %t2740, i64 3862, 1
  br label %common.ret

edge2791:                                         ; preds = %block3829
  %t2743 = inttoptr i64 %v57319 to ptr
  %v57320 = load i64, ptr %t2743, align 1
  %t2744 = icmp eq i64 %v57320, 1
  br i1 %t2744, label %edge2793, label %block3840

edge2793:                                         ; preds = %edge2791
  %t2746 = zext nneg i64 %.mux to i128
  %v138934 = or disjoint i128 %t2805, %t2746
  store i128 %v138934, ptr %ss3, align 16
  %t2750 = zext nneg i64 %v57342 to i128
  %t2751 = zext i64 %v57343 to i128
  %t2752 = shl nuw i128 %t2751, 64
  %v138936 = or disjoint i128 %t2752, %t2750
  store i128 %v138936, ptr %t403, align 16
  %t2755 = zext i64 %v137667 to i128
  %t2756 = zext nneg i64 %v137668 to i128
  %t2757 = shl nuw nsw i128 %t2756, 64
  %v138938 = or disjoint i128 %t2757, %t2755
  store i128 %v138938, ptr %t408, align 16
  %v138940 = or disjoint i128 %t2757, 1
  store i128 %v138940, ptr %t413, align 16
  %t2765 = zext i64 %v57348 to i128
  %v138942 = or disjoint i128 %t2805, %t2765
  store i128 %v138942, ptr %t418, align 16
  %v138944 = or disjoint i128 %t2805, 1
  store i128 %v138944, ptr %t423, align 16
  %t2775 = zext i64 %v57319 to i128
  %v138946 = or disjoint i128 %t2805, %t2775
  store i128 %v138946, ptr %t424, align 16
  %t2780 = call { i64, i64 } @mech_compact_numeric_3872(i64 %v0, i64 %v138697, i64 %v6374)
  %v57325 = extractvalue { i64, i64 } %t2780, 0
  %t2781.not = icmp eq i64 %v57325, 0
  br i1 %t2781.not, label %edge2796, label %edge2795

edge2795:                                         ; preds = %edge2793
  %v57326 = extractvalue { i64, i64 } %t2780, 1
  %t2782 = icmp eq i64 %v57325, 103169
  %v57329 = select i1 %t2782, i64 103425, i64 %v57325
  %t2784 = insertvalue { i64, i64 } poison, i64 %v57329, 0
  %t2785 = insertvalue { i64, i64 } %t2784, i64 %v57326, 1
  br label %common.ret

edge2796:                                         ; preds = %edge2793
  %v57330 = load i64, ptr %t626, align 8
  %t2787.not = icmp eq i64 %v137671, 0
  br i1 %t2787.not, label %edge2838, label %edge2797

edge2797:                                         ; preds = %edge2796
  %v57334 = call i64 @mech_compact_release_nullable(i64 %v0, i64 %v137671)
  %t2788.not = icmp eq i64 %v57334, 0
  br i1 %t2788.not, label %edge2838, label %edge2799

edge2799:                                         ; preds = %edge2797
  %t2789 = insertvalue { i64, i64 } poison, i64 %v57334, 0
  %t2790 = insertvalue { i64, i64 } %t2789, i64 3872, 1
  br label %common.ret

edge2812:                                         ; preds = %block3840
  %v57508 = add nuw nsw i64 %v57342, %.mux
  %t2794 = icmp samesign ult i64 %v57508, %v137668
  %v57664 = shl nuw nsw i64 %v57508, 2
  %v57665 = add i64 %v57664, %v137667
  %v139134 = select i1 %t2794, i64 %v57665, i64 ptrtoint (ptr @mech_compact_llvm_anonymous_data_1 to i64)
  %t2797 = inttoptr i64 %v139134 to ptr
  %t2798 = load i32, ptr %t2797, align 1
  %t2799.not = icmp eq i32 %t2798, 0
  br i1 %t2799.not, label %edge2826, label %edge2817

edge2817:                                         ; preds = %edge2812
  %v57666 = zext i32 %t2798 to i64
  %v57725 = shl nuw nsw i64 %v57666, 10
  %v57729 = or i64 %v57725, %v57342
  %v57744 = and i64 %v57729, 4294967295
  %v57877 = add i64 %v57343, 1
  %t2803 = zext i64 %v57877 to i128
  %v138948 = or disjoint i128 %t2805, %t2803
  store i128 %v138948, ptr %ss6, align 16
  %t2807 = zext i64 %v57348 to i128
  %t2808 = zext nneg i64 %v57744 to i128
  %t2809 = shl nuw nsw i128 %t2808, 64
  %v138950 = or disjoint i128 %t2809, %t2807
  store i128 %v138950, ptr %t931, align 16
  %t2812 = zext i64 %v57319 to i128
  %v138952 = or disjoint i128 %t934, %t2812
  store i128 %v138952, ptr %t936, align 16
  store i64 %v137690, ptr %t937, align 16
  %t2818 = call { i64, i64, i64, i64 } @mech_compact_checked_layout_16147(i64 %v138793)
  %v138150 = extractvalue { i64, i64, i64, i64 } %t2818, 0
  %t2819 = icmp ugt i64 %v138150, 1
  br i1 %t2819, label %edge2820, label %edge2821

edge2820:                                         ; preds = %edge2817
  %v138151 = extractvalue { i64, i64, i64, i64 } %t2818, 1
  %v138155 = add i64 %v138150, 3923
  %t2821 = insertvalue { i64, i64 } poison, i64 %v138151, 0
  %t2822 = insertvalue { i64, i64 } %t2821, i64 %v138155, 1
  br label %common.ret

edge2821:                                         ; preds = %edge2817
  %v138153 = extractvalue { i64, i64, i64, i64 } %t2818, 3
  %v138152 = extractvalue { i64, i64, i64, i64 } %t2818, 2
  %t2823.not = icmp eq i64 %v57343, -1
  br i1 %t2823.not, label %block39122, label %edge2826

edge2826:                                         ; preds = %edge2821, %edge2812
  %v58215.ph = phi i64 [ %v57877, %edge2821 ], [ %v57343, %edge2812 ]
  %v137701.ph = phi i64 [ %v138152, %edge2821 ], [ %v57348, %edge2812 ]
  %v137702.ph = phi i64 [ %v138153, %edge2821 ], [ %v57319, %edge2812 ]
  %v58204 = add nuw nsw i64 %v57342, 1
  br label %block3829

edge2827:                                         ; preds = %block3840
  %t2827.not = icmp eq i64 %v137671, 0
  br i1 %t2827.not, label %edge2838, label %edge2828

edge2828:                                         ; preds = %edge2827
  %t2828 = inttoptr i64 %v137671 to ptr
  %v58080 = load i64, ptr %t2828, align 1
  %v58081 = add i64 %v58080, -1
  store i64 %v58081, ptr %t2828, align 1
  %t2830.not = icmp eq i64 %v58081, 0
  br i1 %t2830.not, label %edge2831, label %edge2838

edge2831:                                         ; preds = %edge2828
  %v58082 = call i64 @mech_compact_free(i64 %v0, i64 %v137671)
  %t2831.not = icmp eq i64 %v58082, 0
  br i1 %t2831.not, label %edge2838, label %edge2832

edge2832:                                         ; preds = %edge2831
  %t2832 = insertvalue { i64, i64 } poison, i64 %v58082, 0
  %t2833 = insertvalue { i64, i64 } %t2832, i64 3939, 1
  br label %common.ret

edge2838:                                         ; preds = %edge2797, %edge2796, %edge2831, %edge2828, %edge2827
  %v58255 = phi i64 [ %v57330, %edge2796 ], [ %v57330, %edge2797 ], [ %v57343, %edge2831 ], [ %v57343, %edge2828 ], [ %v57343, %edge2827 ]
  %t2839.not = icmp ugt i64 %v58255, %v137690
  br label %block3911

edge2839:                                         ; preds = %block3911
  %t2835 = inttoptr i64 %v58406 to ptr
  %v58407 = load i64, ptr %t2835, align 1
  %t2836 = icmp ne i64 %v58407, 1
  %or.cond177 = select i1 %t2836, i1 true, i1 %t2839.not
  br i1 %or.cond177, label %block3919, label %edge2843

edge2843:                                         ; preds = %edge2839
  %t2841 = zext nneg i64 %v58255 to i128
  %t2842 = zext nneg i64 %v58441 to i128
  %t2843 = shl nuw nsw i128 %t2842, 64
  %v138954 = or disjoint i128 %t2843, %t2841
  store i128 %v138954, ptr %ss3, align 16
  %t2845 = zext i64 %v58442 to i128
  %v138956 = or disjoint i128 %t2805, %t2845
  store i128 %v138956, ptr %t403, align 16
  %v138958 = or disjoint i128 %t2805, 1
  store i128 %v138958, ptr %t408, align 16
  %t2855 = zext i64 %v58406 to i128
  %v138960 = or disjoint i128 %t2805, %t2855
  store i128 %v138960, ptr %t413, align 16
  %t2860 = call { i64, i64 } @mech_compact_fixed_transform(i64 %v0, i64 %v138697, i64 %v6374, i64 ptrtoint (ptr @mech_compact_numeric_3956_vector to i64), i64 2)
  %v58421 = extractvalue { i64, i64 } %t2860, 0
  %t2861.not = icmp eq i64 %v58421, 0
  br i1 %t2861.not, label %edge2906, label %edge2847

edge2847:                                         ; preds = %edge2843
  %v58422 = extractvalue { i64, i64 } %t2860, 1
  %t2862 = icmp eq i64 %v58421, 103169
  %v58429 = select i1 %t2862, i64 103425, i64 %v58421
  %t2864 = insertvalue { i64, i64 } poison, i64 %v58429, 0
  %t2865 = insertvalue { i64, i64 } %t2864, i64 %v58422, 1
  br label %common.ret

edge2861:                                         ; preds = %block3929
  %t2873 = icmp ult i64 %v58655, %v137690
  %v58928 = add i64 %v58655, 1
  %v58933 = shl i64 %v58655, 2
  %v58934 = add i64 %v58933, %v58639
  %v139135 = select i1 %t2873, i64 %v58934, i64 ptrtoint (ptr @mech_compact_llvm_anonymous_data_1 to i64)
  %t2876 = inttoptr i64 %v139135 to ptr
  %t2877 = load i32, ptr %t2876, align 1
  %v58935 = zext i32 %t2877 to i64
  br label %block3964

edge2875:                                         ; preds = %block3964
  %t2883 = icmp ult i64 %spec.select5, %v137690
  br i1 %t2883, label %edge2878, label %block4019

edge2878:                                         ; preds = %edge2875
  %v59407 = shl nuw nsw i64 %spec.select5, 2
  %v59408 = add i64 %v59407, %v58978
  %t2886 = inttoptr i64 %v59408 to ptr
  %t2887 = load i32, ptr %t2886, align 1
  %v59409 = zext i32 %t2887 to i64
  br label %block4010

edge2891:                                         ; preds = %block4019
  %v138144 = extractvalue { i64, i64, i64, i64 } %t2906, 1
  %v138148 = add i64 %v138143, 4068
  %t2909 = insertvalue { i64, i64 } poison, i64 %v138144, 0
  %t2910 = insertvalue { i64, i64 } %t2909, i64 %v138148, 1
  br label %common.ret

edge2892:                                         ; preds = %block4019
  %v138146 = extractvalue { i64, i64, i64, i64 } %t2906, 3
  %v138145 = extractvalue { i64, i64, i64, i64 } %t2906, 2
  br i1 %v137703, label %block3929, label %block3964

edge2899:                                         ; preds = %block4052
  %v60140 = lshr i64 %v58441, 8
  br label %block3911

edge2906:                                         ; preds = %block4052, %edge2843
  %v60211 = phi i64 [ %v58442, %edge2843 ], [ %v60142, %block4052 ]
  %v60216 = phi i64 [ %v58406, %edge2843 ], [ %v60147, %block4052 ]
  %t2916 = icmp ult i64 %v58255, 2
  br i1 %t2916, label %edge2908, label %edge2909

edge2908:                                         ; preds = %edge2906
  %t2919 = icmp eq i64 %v58255, 1
  br i1 %t2919, label %edge2918, label %edge2912

edge2909:                                         ; preds = %edge2906
  %v61388 = add i64 %v58255, -1
  br label %block4122

edge2912:                                         ; preds = %edge2781, %edge2786, %edge2783, %edge2908
  %v60216731737 = phi i64 [ %v60216, %edge2908 ], [ %v56721, %edge2783 ], [ %v56721, %edge2786 ], [ %v56721, %edge2781 ]
  %t2922.not = icmp eq i64 %v60216731737, 0
  br i1 %t2922.not, label %block4113, label %edge2913

edge2913:                                         ; preds = %edge2912
  %v60387 = call i64 @mech_compact_release_owner(i64 %v0, i64 %v60216731737)
  %t2923.not = icmp eq i64 %v60387, 0
  br i1 %t2923.not, label %block4113, label %edge2915

edge2915:                                         ; preds = %edge2913
  %t2924 = insertvalue { i64, i64 } poison, i64 %v60387, 0
  %t2925 = insertvalue { i64, i64 } %t2924, i64 4124, 1
  br label %common.ret

edge2918:                                         ; preds = %edge2908
  %t2933 = inttoptr i64 %v60211 to ptr
  %t2934 = load i32, ptr %t2933, align 1
  %t2935.not = icmp eq i64 %v60216, 0
  br i1 %t2935.not, label %block4098, label %edge2924

edge2924:                                         ; preds = %edge2918
  %t2936 = inttoptr i64 %v60216 to ptr
  %v60665 = load i64, ptr %t2936, align 1
  %v60666 = add i64 %v60665, -1
  store i64 %v60666, ptr %t2936, align 1
  %t2938.not = icmp eq i64 %v60666, 0
  br i1 %t2938.not, label %edge2927, label %block4098

edge2927:                                         ; preds = %edge2924
  %v60667 = call i64 @mech_compact_free(i64 %v0, i64 %v60216)
  %t2939.not = icmp eq i64 %v60667, 0
  br i1 %t2939.not, label %block4098, label %edge2928

edge2928:                                         ; preds = %edge2927
  %t2940 = insertvalue { i64, i64 } poison, i64 %v60667, 0
  %t2941 = insertvalue { i64, i64 } %t2940, i64 4142, 1
  br label %common.ret

edge2937:                                         ; preds = %block4113
  %t2947 = inttoptr i64 %v55832 to ptr
  %v60971 = load i64, ptr %t2947, align 1
  %t2948 = icmp eq i64 %v60971, 1
  %t2952 = inttoptr i64 %v55831 to ptr
  br i1 %t2948, label %edge2941, label %edge2950.thread

edge2941:                                         ; preds = %edge2937
  store i32 65536, ptr %t2952, align 1
  %t2953 = icmp samesign ult i64 %v137704, %v137690
  br i1 %t2953, label %edge2944, label %block39125

edge2944:                                         ; preds = %edge2941
  %v61001 = shl nuw nsw i64 %v137704, 2
  %v61002 = add i64 %v61001, %v55831
  %t2955 = inttoptr i64 %v61002 to ptr
  store i32 65537, ptr %t2955, align 1
  br label %block4954

edge2950:                                         ; preds = %block4113
  %t2958 = inttoptr i64 %v55831 to ptr
  %t2959 = load i32, ptr %t2958, align 1
  %t2960 = icmp eq i32 %t2959, 65536
  br i1 %t2960, label %block4114, label %block23009

edge2950.thread:                                  ; preds = %edge2937
  %t2959739 = load i32, ptr %t2952, align 1
  %t2960740 = icmp eq i32 %t2959739, 65536
  br i1 %t2960740, label %block4114, label %block23009

edge2962:                                         ; preds = %block23007
  %t2973 = inttoptr i64 %v61045 to ptr
  %v61050 = load i64, ptr %t2973, align 1
  %v61051 = add i64 %v61050, 1
  store i64 %v61051, ptr %t2973, align 1
  br label %block23013

edge2965:                                         ; preds = %block23013
  %v61056 = call i64 @mech_compact_release_owner(i64 %v0, i64 %v55832)
  %t2977.not = icmp eq i64 %v61056, 0
  br i1 %t2977.not, label %block4114, label %block22984

edge2970:                                         ; preds = %block4114
  %v61329 = shl nuw nsw i64 %v137704, 2
  %v61330 = add i64 %v61027395414, %v61329
  %t2982 = inttoptr i64 %v61330 to ptr
  %t2983 = load i32, ptr %t2982, align 1
  %t2984 = icmp eq i32 %t2983, 65537
  br i1 %t2984, label %block4954, label %edge2973

edge2973:                                         ; preds = %edge2970
  br i1 %t2972.not127399412, label %block23024, label %edge2974

edge2974:                                         ; preds = %edge2973
  %t2987 = inttoptr i64 %v61032396413 to ptr
  %v61347 = load i64, ptr %t2987, align 1
  %t2988 = icmp eq i64 %v61347, 1
  br i1 %t2988, label %block23022, label %block23024

edge2982:                                         ; preds = %block23022
  %t2997 = inttoptr i64 %v61346 to ptr
  %v61358 = load i64, ptr %t2997, align 1
  %v61359 = add i64 %v61358, 1
  store i64 %v61359, ptr %t2997, align 1
  br label %block23028

edge2985:                                         ; preds = %block23028
  %v61364 = call i64 @mech_compact_release_owner(i64 %v0, i64 %v61032396413)
  %t3001.not = icmp eq i64 %v61364, 0
  br i1 %t3001.not, label %block4954, label %block23019

edge2994:                                         ; preds = %block4122
  %t3005 = inttoptr i64 %v61405 to ptr
  %v61406 = load i64, ptr %t3005, align 1
  %t3006 = icmp eq i64 %v61406, 1
  br i1 %t3006, label %edge2996, label %block4132

edge2996:                                         ; preds = %edge2994
  %t3008 = zext i64 %v61428 to i128
  %t3009 = zext i64 %v61429 to i128
  %t3010 = shl nuw i128 %t3009, 64
  %v138968 = or disjoint i128 %t3010, %t3008
  store i128 %v138968, ptr %ss3, align 16
  %t3012 = zext i64 %v61430 to i128
  %t3013 = zext i64 %v61388 to i128
  %t3014 = shl nuw i128 %t3013, 64
  %v138970 = or disjoint i128 %t3014, %t3012
  store i128 %v138970, ptr %t403, align 16
  %t3017 = zext i64 %v61432 to i128
  %v138972 = or disjoint i128 %t2805, %t3017
  store i128 %v138972, ptr %t408, align 16
  %v138974 = or disjoint i128 %t2805, 1
  store i128 %v138974, ptr %t413, align 16
  %t3027 = zext i64 %v61405 to i128
  %v138976 = or disjoint i128 %t2805, %t3027
  store i128 %v138976, ptr %t418, align 16
  %t3032 = call { i64, i64 } @mech_compact_fixed_transform(i64 %v0, i64 %v138697, i64 %v6374, i64 ptrtoint (ptr @mech_compact_numeric_4173 to i64), i64 4)
  %v61413 = extractvalue { i64, i64 } %t3032, 0
  %t3033.not = icmp eq i64 %v61413, 0
  br i1 %t3033.not, label %edge3114, label %edge2998

edge2998:                                         ; preds = %edge2996
  %v61414 = extractvalue { i64, i64 } %t3032, 1
  %t3034 = icmp eq i64 %v61413, 103169
  %v61417 = select i1 %t3034, i64 103425, i64 %v61413
  %t3036 = insertvalue { i64, i64 } poison, i64 %v61417, 0
  %t3037 = insertvalue { i64, i64 } %t3036, i64 %v61414, 1
  br label %common.ret

edge3003:                                         ; preds = %block4132
  %t3041 = icmp ult i64 %v61428, %v137690
  %v61724 = add i64 %v61428, 1
  %v61729 = shl i64 %v61428, 2
  %v61730 = add i64 %v61432, %v61729
  %v139136 = select i1 %t3041, i64 %v61730, i64 ptrtoint (ptr @mech_compact_llvm_anonymous_data_1 to i64)
  %t3044 = inttoptr i64 %v139136 to ptr
  %t3045 = load i32, ptr %t3044, align 1
  %37 = and i32 %t3045, -1024
  %v61884 = zext i32 %37 to i64
  %t3046.not = icmp eq i64 %v61428, -1
  br i1 %t3046.not, label %block39122, label %edge3009

edge3009:                                         ; preds = %edge3003
  %t3048 = icmp ult i64 %v61724, %v137690
  %v62040 = shl i64 %v61724, 2
  %v62041 = add i64 %v61432, %v62040
  %v139137 = select i1 %t3048, i64 %v62041, i64 ptrtoint (ptr @mech_compact_llvm_anonymous_data_1 to i64)
  %t3051 = inttoptr i64 %v139137 to ptr
  %t3052 = load i32, ptr %t3051, align 1
  %38 = and i32 %t3052, -1024
  %v62063 = zext i32 %38 to i64
  %t3053 = icmp ult i64 %v61429, %v137690
  %v62207 = add i64 %v61429, 1
  %v62212 = shl i64 %v61429, 2
  %v62213 = add i64 %v61432, %v62212
  %v139138 = select i1 %t3053, i64 %v62213, i64 ptrtoint (ptr @mech_compact_llvm_anonymous_data_1 to i64)
  %t3056 = inttoptr i64 %v139138 to ptr
  %t3057 = load i32, ptr %t3056, align 1
  %v62214 = zext i32 %t3057 to i64
  %t3058.not = icmp eq i64 %v61429, -1
  br i1 %t3058.not, label %block39122, label %edge3019

edge3019:                                         ; preds = %edge3009
  %t3060 = icmp ult i64 %v62207, %v137690
  %v62382 = add i64 %v61429, 2
  %v62387 = shl i64 %v62207, 2
  %v62388 = add i64 %v61432, %v62387
  %v139139 = select i1 %t3060, i64 %v62388, i64 ptrtoint (ptr @mech_compact_llvm_anonymous_data_1 to i64)
  %t3063 = inttoptr i64 %v139139 to ptr
  %t3064 = load i32, ptr %t3063, align 1
  %v62389 = zext i32 %t3064 to i64
  %v62410 = and i64 %v62214, 4294966272
  %v62414 = and i64 %v62389, 4294966272
  %t3068.not = icmp eq i64 %v61429, -2
  br i1 %t3068.not, label %block39122, label %edge3034

edge3034:                                         ; preds = %edge3019
  %t3065 = icmp ugt i64 %v61724, %v61388
  %t3066 = icmp ne i64 %v61429, %v61430
  %t3067 = icmp samesign ult i64 %v62410, %v62063
  %v62440110.not114 = and i1 %t3066, %t3067
  %v62444111.not = or i1 %t3065, %v62440110.not114
  %t3070 = icmp ule i64 %v62382, %v61430
  %t3071 = icmp ugt i64 %v61428, %v61388
  %t3072 = icmp samesign ult i64 %v62414, %v61884
  %v62475112 = or i1 %t3071, %t3072
  %v62479113 = and i1 %t3070, %v62475112
  %narrow = and i1 %v62444111.not, %v62479113
  br i1 %v62444111.not, label %edge3045, label %edge3068

edge3045:                                         ; preds = %edge3034
  %v62496 = shl i64 %v61430, 10
  %v62633 = and i64 %v62214, 1023
  %v62496.masked = and i64 %v62496, 4294966272
  %v62649 = or disjoint i64 %v62633, %v62496.masked
  %t3076 = zext i64 %v62207 to i128
  %v138978 = or disjoint i128 %t2805, %t3076
  store i128 %v138978, ptr %ss6, align 16
  %t3080 = zext i64 %v61432 to i128
  %t3081 = zext nneg i64 %v62649 to i128
  %t3082 = shl nuw nsw i128 %t3081, 64
  %v138980 = or disjoint i128 %t3082, %t3080
  store i128 %v138980, ptr %t931, align 16
  %t3085 = zext i64 %v61405 to i128
  %v138982 = or disjoint i128 %t934, %t3085
  store i128 %v138982, ptr %t936, align 16
  store i64 %v137690, ptr %t937, align 16
  %t3091 = call { i64, i64, i64, i64 } @mech_compact_checked_layout_16147(i64 %v138793)
  %v138136 = extractvalue { i64, i64, i64, i64 } %t3091, 0
  %v138138 = extractvalue { i64, i64, i64, i64 } %t3091, 2
  %v138139 = extractvalue { i64, i64, i64, i64 } %t3091, 3
  %t3092 = icmp ugt i64 %v138136, 1
  br i1 %t3092, label %edge3051, label %block4252

edge3051:                                         ; preds = %edge3045
  %v138137 = extractvalue { i64, i64, i64, i64 } %t3091, 1
  %v138141 = add i64 %v138136, 4304
  %t3094 = insertvalue { i64, i64 } poison, i64 %v138137, 0
  %t3095 = insertvalue { i64, i64 } %t3094, i64 %v138141, 1
  br label %common.ret

edge3054:                                         ; preds = %block4252
  %v62840 = and i64 %v62389, 1023
  %v62848 = or disjoint i64 %v62840, %v62496.masked
  %t3098 = zext i64 %v62382 to i128
  %v138984 = or disjoint i128 %t2805, %t3098
  store i128 %v138984, ptr %ss6, align 16
  %t3102 = zext i64 %v138138 to i128
  %t3103 = zext nneg i64 %v62848 to i128
  %t3104 = shl nuw nsw i128 %t3103, 64
  %v138986 = or disjoint i128 %t3104, %t3102
  store i128 %v138986, ptr %t931, align 16
  %t3107 = zext i64 %v138139 to i128
  %v138988 = or disjoint i128 %t934, %t3107
  store i128 %v138988, ptr %t936, align 16
  store i64 %v137690, ptr %t937, align 16
  %t3113 = call { i64, i64, i64, i64 } @mech_compact_checked_layout_16147(i64 %v138793)
  %v138129 = extractvalue { i64, i64, i64, i64 } %t3113, 0
  %v138131 = extractvalue { i64, i64, i64, i64 } %t3113, 2
  %v138132 = extractvalue { i64, i64, i64, i64 } %t3113, 3
  %t3114 = icmp ugt i64 %v138129, 1
  br i1 %t3114, label %edge3061, label %block4285

edge3061:                                         ; preds = %edge3054
  %v138130 = extractvalue { i64, i64, i64, i64 } %t3113, 1
  %v138134 = add i64 %v138129, 4316
  %t3116 = insertvalue { i64, i64 } poison, i64 %v138130, 0
  %t3117 = insertvalue { i64, i64 } %t3116, i64 %v138134, 1
  br label %common.ret

edge3068:                                         ; preds = %edge3034
  %v63176 = add nuw i64 %v61428, 2
  %t3122.not = icmp eq i64 %v61428, -2
  br i1 %t3122.not, label %block39122, label %block4285

edge3106:                                         ; preds = %block4285
  %v138123 = extractvalue { i64, i64, i64, i64 } %t3152, 1
  %v138127 = add i64 %v138122, 4402
  %t3155 = insertvalue { i64, i64 } poison, i64 %v138123, 0
  %t3156 = insertvalue { i64, i64 } %t3155, i64 %v138127, 1
  br label %common.ret

edge3107:                                         ; preds = %block4285
  %v63466 = select i1 %v62479113, i64 %v62382, i64 %v62207
  %spec.select174 = select i1 %v62444111.not, i64 %v63466, i64 %v61429
  %v138125 = extractvalue { i64, i64, i64, i64 } %t3152, 3
  %v138124 = extractvalue { i64, i64, i64, i64 } %t3152, 2
  br label %block4122

edge3114:                                         ; preds = %block4132, %edge2996
  %t3004.not22203 = phi i1 [ false, %edge2996 ], [ %t3004.not, %block4132 ]
  %v64199 = add i64 %v58255, -2
  %v64216 = add nuw nsw i64 %v64207, 2
  %t3170 = call { i64, i64 } @mech_compact_allocate_backing(i64 %v0, i64 %v64216, i64 8, i64 8, i64 1)
  %v65056 = extractvalue { i64, i64 } %t3170, 0
  %v65057 = extractvalue { i64, i64 } %t3170, 1
  %t3171.not = icmp eq i64 %v65056, 0
  br i1 %t3171.not, label %block24119, label %edge3135

edge3122:                                         ; preds = %edge3137
  %t3162 = insertvalue { i64, i64 } poison, i64 %v65015, 0
  %t3163 = insertvalue { i64, i64 } %t3162, i64 4430, 1
  br label %common.ret

edge3135:                                         ; preds = %edge3114
  %t3172.not = icmp eq i64 %v65057, 0
  br i1 %t3172.not, label %edge3142, label %edge3137

edge3137:                                         ; preds = %edge3135
  %t3173 = inttoptr i64 %v65057 to ptr
  %v65060 = load i64, ptr %t3173, align 1
  %v65011 = add i64 %v65060, 2
  store i64 %v65011, ptr %t3173, align 1
  %v65015 = call i64 @mech_compact_release_owner(i64 %v0, i64 %v65057)
  %t3161.not = icmp eq i64 %v65015, 0
  br i1 %t3161.not, label %edge3142.thread, label %edge3122

edge3142:                                         ; preds = %edge3135
  %v65168 = add i64 %v65056, 8
  %t3179 = inttoptr i64 %v65168 to ptr
  %v65169 = load i64, ptr %t3179, align 1
  %t3180 = icmp eq i64 %v65169, 2
  br i1 %t3180, label %block4394, label %block24161

edge3142.thread:                                  ; preds = %edge3137
  %v65168741 = add i64 %v65056, 8
  %t3179742 = inttoptr i64 %v65168741 to ptr
  %v65169743 = load i64, ptr %t3179742, align 1
  %t3180744 = icmp eq i64 %v65169743, 2
  br i1 %t3180744, label %block4394, label %edge3146

edge3146:                                         ; preds = %edge3142.thread
  %v65185 = load i64, ptr %t3173, align 1
  %t3184 = icmp eq i64 %v65185, 1
  br i1 %t3184, label %block24159.thread445, label %block24161

block24159.thread445:                             ; preds = %edge3146
  store i64 2, ptr %t3179742, align 1
  br label %block4394

edge3154:                                         ; preds = %block24159
  %t3193 = inttoptr i64 %v65191 to ptr
  %v65195 = load i64, ptr %t3193, align 1
  %v65196 = add i64 %v65195, 1
  store i64 %v65196, ptr %t3193, align 1
  br label %block24165

edge3157:                                         ; preds = %block24165
  %t3197 = inttoptr i64 %v65057 to ptr
  %v65199 = load i64, ptr %t3197, align 1
  %v65200 = add i64 %v65199, -1
  store i64 %v65200, ptr %t3197, align 1
  %t3199.not = icmp eq i64 %v65200, 0
  br i1 %t3199.not, label %edge3160, label %block4394

edge3160:                                         ; preds = %edge3157
  %v65201 = call i64 @mech_compact_free(i64 %v0, i64 %v65057)
  %t3200.not = icmp eq i64 %v65201, 0
  br i1 %t3200.not, label %block4394, label %block24156

edge3169:                                         ; preds = %block4394
  %t3210 = inttoptr i64 %v65360 to ptr
  %t3211 = load i32, ptr %t3210, align 1
  %t3212 = icmp eq i32 %t3211, %5
  br i1 %t3212, label %block24252, label %edge3172

edge3172:                                         ; preds = %edge3169
  br i1 %t3004.not22203, label %block24254, label %edge3173

edge3173:                                         ; preds = %edge3172
  %t3215 = inttoptr i64 %v61405 to ptr
  %v65427 = load i64, ptr %t3215, align 1
  %t3216 = icmp eq i64 %v65427, 1
  br i1 %t3216, label %block24253, label %block24254

edge3181:                                         ; preds = %block24252
  %t3225 = inttoptr i64 %v65420 to ptr
  %v65438 = load i64, ptr %t3225, align 1
  %v65439 = add i64 %v65438, 1
  store i64 %v65439, ptr %t3225, align 1
  br label %block24258

edge3184:                                         ; preds = %block24258
  %t3229 = inttoptr i64 %v61405 to ptr
  %v65442 = load i64, ptr %t3229, align 1
  %v65443 = add i64 %v65442, -1
  store i64 %v65443, ptr %t3229, align 1
  %t3231.not = icmp eq i64 %v65443, 0
  br i1 %t3231.not, label %edge3187, label %block4414.preheader

edge3187:                                         ; preds = %edge3184
  %v65444 = call i64 @mech_compact_free(i64 %v0, i64 %v61405)
  %t3232.not = icmp eq i64 %v65444, 0
  br i1 %t3232.not, label %block4414.preheader, label %block24249

block4414.preheader:                              ; preds = %edge3187, %edge3184, %block24258
  br label %block4414

edge3194:                                         ; preds = %block4414
  %v65633 = add nsw i64 %v65495, -1
  %v65785 = shl nuw nsw i64 %v65633, 2
  %v65786 = add i64 %v65785, %v65471
  %t3241 = inttoptr i64 %v65786 to ptr
  %t3242 = load i32, ptr %t3241, align 1
  %v65787 = zext i32 %t3242 to i64
  %v65813 = lshr i64 %v65787, 10
  %t3244 = icmp samesign ult i64 %v65813, %v137690
  %v65964 = shl nuw nsw i64 %v65813, 2
  %v65965 = add i64 %v65964, %v65471
  %v139143 = select i1 %t3244, i64 %v65965, i64 ptrtoint (ptr @mech_compact_llvm_anonymous_data_1 to i64)
  %t3247 = inttoptr i64 %v139143 to ptr
  %t3248 = load i32, ptr %t3247, align 1
  %39 = lshr i32 %t3248, 10
  %narrow120 = add nuw nsw i32 %39, 1
  %v65992 = zext nneg i32 %narrow120 to i64
  %v66000 = and i64 %v65787, 1023
  %v66019 = shl nuw nsw i64 %v65992, 10
  %v66019.masked = and i64 %v66019, 4294966272
  %v66027 = or disjoint i64 %v66019.masked, %v66000
  %t3257 = icmp eq i64 %v66027, %v65787
  br i1 %t3257, label %block24504, label %edge3217

edge3195:                                         ; preds = %block4414
  %t3353.not = icmp eq i64 %v65476, 0
  br i1 %t3353.not, label %block24935, label %edge3329

edge3217:                                         ; preds = %edge3194
  %t3259.not = icmp eq i64 %v65476, 0
  br i1 %t3259.not, label %block24506, label %edge3218

edge3218:                                         ; preds = %edge3217
  %t3260 = inttoptr i64 %v65476 to ptr
  %v66062 = load i64, ptr %t3260, align 1
  %t3261 = icmp eq i64 %v66062, 1
  br i1 %t3261, label %block24505, label %block24506

edge3226:                                         ; preds = %block24504
  %t3270 = inttoptr i64 %v66055 to ptr
  %v66073 = load i64, ptr %t3270, align 1
  %v66074 = add i64 %v66073, 1
  store i64 %v66074, ptr %t3270, align 1
  br label %block24510

edge3231:                                         ; preds = %block24510
  %t3278.not = icmp eq i64 %v65488, 0
  br i1 %t3278.not, label %edge3236, label %edge3233

edge3233:                                         ; preds = %edge3231
  %t3279 = inttoptr i64 %v65488 to ptr
  %v66208 = load i64, ptr %t3279, align 1
  %v66209 = add i64 %v66208, 1
  store i64 %v66209, ptr %t3279, align 1
  br label %edge3236

edge3236:                                         ; preds = %edge3231, %edge3233
  %v66409 = add i64 %v65483, -8
  br label %block4489

edge3239:                                         ; preds = %block4489
  %v66249 = add nsw i64 %v66242, -1
  %v66406 = shl i64 %v66242, 3
  %v66410 = add i64 %v66409, %v66406
  %t3286 = inttoptr i64 %v66410 to ptr
  %v66411 = load i64, ptr %t3286, align 1
  %t3287.not = icmp eq i64 %v66411, 0
  br i1 %t3287.not, label %block4489, label %edge3250

edge3250:                                         ; preds = %edge3239
  br i1 %t3278.not, label %edge3261, label %edge3252

edge3252:                                         ; preds = %edge3250
  %v66440 = call i64 @mech_compact_release_owner(i64 %v0, i64 %v65488)
  %t3291.not = icmp eq i64 %v66440, 0
  br i1 %t3291.not, label %edge3261, label %edge3254

edge3254:                                         ; preds = %edge3252
  %t3292 = insertvalue { i64, i64 } poison, i64 %v66440, 0
  %t3293 = insertvalue { i64, i64 } %t3292, i64 4580, 1
  br label %common.ret

edge3261:                                         ; preds = %edge3250, %edge3252, %block24510
  %v66612 = phi i64 [ %v65992, %block24510 ], [ %v66249, %edge3252 ], [ %v66249, %edge3250 ]
  %t3294 = icmp ult i64 %v66612, %v64216
  br i1 %t3294, label %edge3263, label %block39122

edge3263:                                         ; preds = %edge3261
  %v66761 = add nuw nsw i64 %v66612, 1
  %v66766 = shl nuw nsw i64 %v66612, 3
  %v66767 = add i64 %v66766, %v65483
  %t3297 = inttoptr i64 %v66767 to ptr
  %v66768 = load i64, ptr %t3297, align 1
  %t3298.not = icmp eq i64 %v66768, 0
  br i1 %t3298.not, label %block39122, label %edge3268

edge3268:                                         ; preds = %edge3263
  %v66789 = add i64 %v66768, -1
  %t3303.not = icmp eq i64 %v65488, 0
  br i1 %t3303.not, label %block24816, label %edge3276

edge3276:                                         ; preds = %edge3268
  %t3304 = inttoptr i64 %v65488 to ptr
  %v66819 = load i64, ptr %t3304, align 1
  %t3305 = icmp eq i64 %v66819, 1
  br i1 %t3305, label %block24815, label %block24816

edge3281:                                         ; preds = %block24816
  %t3317 = insertvalue { i64, i64 } poison, i64 %v66825, 0
  %t3318 = insertvalue { i64, i64 } %t3317, i64 4619, 1
  br label %common.ret

edge3284:                                         ; preds = %block24815
  %t3314 = inttoptr i64 %v66818 to ptr
  %v66829 = load i64, ptr %t3314, align 1
  %v66830 = add i64 %v66829, 1
  store i64 %v66830, ptr %t3314, align 1
  br label %block24820

edge3297:                                         ; preds = %block24820
  %v66997 = shl nuw nsw i64 %v66761, 3
  %v66998 = add i64 %v66813, %v66997
  %t3322 = inttoptr i64 %v66998 to ptr
  %v66999 = load i64, ptr %t3322, align 1
  %v67020 = add i64 %v66999, 2
  %t3323.not = icmp ugt i64 %v66999, -3
  br i1 %t3323.not, label %block39122, label %edge3306

edge3306:                                         ; preds = %edge3297
  %t3330.not = icmp eq i64 %v66831, 0
  br i1 %t3330.not, label %block24911, label %edge3307

edge3307:                                         ; preds = %edge3306
  %v67056 = call i64 @mech_compact_release_owner(i64 %v0, i64 %v66831)
  %t3331.not = icmp eq i64 %v67056, 0
  br i1 %t3331.not, label %block24911, label %block24905

edge3311:                                         ; preds = %block24911
  %t3333 = inttoptr i64 %v66818 to ptr
  %v67063 = load i64, ptr %t3333, align 1
  %t3334 = icmp eq i64 %v67063, 1
  br i1 %t3334, label %block24908, label %block24914

edge3319:                                         ; preds = %block24908
  %t3343 = inttoptr i64 %v67062 to ptr
  %v67073 = load i64, ptr %t3343, align 1
  %v67074 = add i64 %v67073, 1
  store i64 %v67074, ptr %t3343, align 1
  br label %block24918

edge3322:                                         ; preds = %block24918
  %t3347 = inttoptr i64 %v66818 to ptr
  %v67077 = load i64, ptr %t3347, align 1
  %v67078 = add i64 %v67077, -1
  store i64 %v67078, ptr %t3347, align 1
  %t3349.not = icmp eq i64 %v67078, 0
  br i1 %t3349.not, label %edge3325, label %edge3337

edge3325:                                         ; preds = %edge3322
  %v67079 = call i64 @mech_compact_free(i64 %v0, i64 %v66818)
  %t3350.not = icmp eq i64 %v67079, 0
  br i1 %t3350.not, label %edge3337, label %block24905

edge3329:                                         ; preds = %edge3195
  %t3354 = inttoptr i64 %v65476 to ptr
  %v67099 = load i64, ptr %t3354, align 1
  %v67100 = add i64 %v67099, 1
  store i64 %v67100, ptr %t3354, align 1
  br label %block24935

edge3332:                                         ; preds = %block24935
  %t3357 = inttoptr i64 %v65488 to ptr
  %v67101 = load i64, ptr %t3357, align 1
  %v67102 = add i64 %v67101, 1
  store i64 %v67102, ptr %t3357, align 1
  br label %edge3338

edge3337:                                         ; preds = %edge3325, %edge3322, %block24918
  %t3363.not = icmp eq i64 %v66075, 0
  br i1 %t3363.not, label %block4414.backedge, label %edge3343

edge3338:                                         ; preds = %block24935, %edge3332
  %v67140 = or i64 %v65488, %v65476
  %t3361.not = icmp eq i64 %v67140, 0
  br i1 %t3361.not, label %block4605, label %edge3339

edge3339:                                         ; preds = %edge3338
  %v67141 = call i64 @mech_compact_release_two(i64 %v0, i64 %v65476, i64 %v65488)
  %t3362.not = icmp eq i64 %v67141, 0
  br i1 %t3362.not, label %block4605, label %block24953

edge3343:                                         ; preds = %edge3337
  %v67144 = call i64 @mech_compact_release_two(i64 %v0, i64 %v66075, i64 0)
  %t3364.not = icmp eq i64 %v67144, 0
  br i1 %t3364.not, label %block4414.backedge, label %block24953

block4414.backedge:                               ; preds = %edge3343, %edge3337
  br label %block4414

edge3348:                                         ; preds = %block4605
  %t3368 = inttoptr i64 %v65488 to ptr
  %v67344 = load i64, ptr %t3368, align 1
  %v67345 = add i64 %v67344, 1
  store i64 %v67345, ptr %t3368, align 1
  br label %edge3351

edge3351:                                         ; preds = %block4605, %edge3348
  %t3431 = inttoptr i64 %v65476 to ptr
  br label %block4608

edge3352:                                         ; preds = %block4608
  %t3371 = inttoptr i64 %v67371 to ptr
  %v67372 = load i64, ptr %t3371, align 1
  %t3372 = icmp eq i64 %v67372, 1
  br i1 %t3372, label %edge3354, label %block4618

edge3354:                                         ; preds = %edge3352
  %t3374 = zext i64 %v67405 to i128
  %t3375 = zext i64 %v67406 to i128
  %t3376 = shl nuw i128 %t3375, 64
  %v138996 = or disjoint i128 %t3376, %t3374
  store i128 %v138996, ptr %ss3, align 16
  %t3378 = zext i64 %v65471 to i128
  %v138998 = or disjoint i128 %t2805, %t3378
  store i128 %v138998, ptr %t403, align 16
  %v139000 = or disjoint i128 %t2805, 1
  store i128 %v139000, ptr %t408, align 16
  %t3388 = zext i64 %v67411 to i128
  %v139002 = or disjoint i128 %t2805, %t3388
  store i128 %v139002, ptr %t413, align 16
  store i128 %v139000, ptr %t418, align 16
  %t3398 = zext i64 %v65483 to i128
  %t3399 = zext nneg i64 %v64216 to i128
  %t3400 = shl nuw nsw i128 %t3399, 64
  %v139006 = or disjoint i128 %t3400, %t3398
  store i128 %v139006, ptr %t423, align 16
  %v139008 = or disjoint i128 %t3400, 1
  store i128 %v139008, ptr %t424, align 16
  %t3408 = zext i64 %v67371 to i128
  %v139010 = or disjoint i128 %t2805, %t3408
  store i128 %v139010, ptr %t583, align 16
  %t3413 = call { i64, i64 } @mech_compact_numeric_4673_vector(i64 %v0, i64 %v138697, i64 %v6374)
  %v67388 = extractvalue { i64, i64 } %t3413, 0
  %t3414.not = icmp eq i64 %v67388, 0
  br i1 %t3414.not, label %edge3359, label %edge3358

edge3358:                                         ; preds = %edge3354
  %v67389 = extractvalue { i64, i64 } %t3413, 1
  %t3415 = icmp eq i64 %v67388, 103169
  %v67394 = select i1 %t3415, i64 103425, i64 %v67388
  %t3417 = insertvalue { i64, i64 } poison, i64 %v67394, 0
  %t3418 = insertvalue { i64, i64 } %t3417, i64 %v67389, 1
  br label %common.ret

edge3359:                                         ; preds = %edge3354
  br i1 %t3361.not, label %edge3425, label %edge3360

edge3360:                                         ; preds = %edge3359
  %v67399 = call i64 @mech_compact_release_two(i64 %v0, i64 %v65476, i64 %v65488)
  %t3420.not = icmp eq i64 %v67399, 0
  br i1 %t3420.not, label %edge3425, label %edge3362

edge3362:                                         ; preds = %edge3360
  %t3421 = insertvalue { i64, i64 } poison, i64 %v67399, 0
  %t3422 = insertvalue { i64, i64 } %t3421, i64 4673, 1
  br label %common.ret

edge3367:                                         ; preds = %block4618
  %t3426 = icmp ult i64 %v67405, %v64216
  br i1 %t3426, label %edge3370, label %edge3377

edge3368:                                         ; preds = %block4618
  br i1 %t3361.not, label %edge3425, label %edge3409

edge3370:                                         ; preds = %edge3367
  %v67734 = shl nuw nsw i64 %v67405, 3
  %v67735 = add i64 %v67734, %v65483
  %t3429 = inttoptr i64 %v67735 to ptr
  %v67736 = load i64, ptr %t3429, align 1
  br label %edge3377

edge3377:                                         ; preds = %edge3367, %edge3370
  %v67751 = phi i64 [ %v67736, %edge3370 ], [ 0, %edge3367 ]
  br i1 %t3353.not, label %edge3381, label %edge3378

edge3378:                                         ; preds = %edge3377
  %v67753 = load i64, ptr %t3431, align 1
  %v67754 = add i64 %v67753, 1
  store i64 %v67754, ptr %t3431, align 1
  br label %edge3381

edge3381:                                         ; preds = %edge3377, %edge3378
  %v68163 = shl i64 %v67405, 16
  %v68169 = and i64 %v68163, 4294901760
  %t3454 = zext nneg i64 %v68169 to i128
  %t3455 = shl nuw nsw i128 %t3454, 64
  br label %block4644

edge3385:                                         ; preds = %block4644
  %t3443 = icmp ult i64 %v67804, %v137690
  %v68102 = shl i64 %v67804, 2
  %v68103 = add i64 %v68102, %v65471
  %v139144 = select i1 %t3443, i64 %v68103, i64 ptrtoint (ptr @mech_compact_llvm_anonymous_data_1 to i64)
  %t3446 = inttoptr i64 %v139144 to ptr
  %t3447 = load i32, ptr %t3446, align 1
  %40 = and i32 %t3447, 1023
  %narrow125 = add nuw nsw i32 %40, 1
  %t3449 = zext nneg i32 %narrow125 to i128
  %v139012 = or disjoint i128 %t2805, %t3449
  store i128 %v139012, ptr %ss6, align 16
  %t3453 = zext i64 %v67790 to i128
  %v139014 = or disjoint i128 %t3455, %t3453
  store i128 %v139014, ptr %t931, align 16
  %t3458 = zext i64 %v67795 to i128
  %v139016 = or disjoint i128 %t934, %t3458
  store i128 %v139016, ptr %t936, align 16
  store i64 %v137690, ptr %t937, align 16
  %t3464 = call { i64, i64, i64, i64 } @mech_compact_checked_layout_16147(i64 %v138793)
  %v138115 = extractvalue { i64, i64, i64, i64 } %t3464, 0
  %t3465 = icmp ugt i64 %v138115, 1
  br i1 %t3465, label %edge3400, label %edge3401

edge3386:                                         ; preds = %block4644
  br i1 %t3353.not, label %edge3408, label %edge3387

edge3387:                                         ; preds = %edge3386
  %v67819 = load i64, ptr %t3431, align 1
  %v67820 = add i64 %v67819, -1
  store i64 %v67820, ptr %t3431, align 1
  %t3439.not = icmp eq i64 %v67820, 0
  br i1 %t3439.not, label %edge3390, label %edge3408

edge3390:                                         ; preds = %edge3387
  %v67821 = call i64 @mech_compact_free(i64 %v0, i64 %v65476)
  %t3440.not = icmp eq i64 %v67821, 0
  br i1 %t3440.not, label %edge3408, label %edge3391

edge3391:                                         ; preds = %edge3390
  %t3441 = insertvalue { i64, i64 } poison, i64 %v67821, 0
  %t3442 = insertvalue { i64, i64 } %t3441, i64 4723, 1
  br label %common.ret

edge3400:                                         ; preds = %edge3385
  %v138116 = extractvalue { i64, i64, i64, i64 } %t3464, 1
  %v138120 = add i64 %v138115, 4751
  %t3467 = insertvalue { i64, i64 } poison, i64 %v138116, 0
  %t3468 = insertvalue { i64, i64 } %t3467, i64 %v138120, 1
  br label %common.ret

edge3401:                                         ; preds = %edge3385
  %v138118 = extractvalue { i64, i64, i64, i64 } %t3464, 3
  %v138117 = extractvalue { i64, i64, i64, i64 } %t3464, 2
  %v68097 = add nuw i64 %v67804, 1
  %t3469.not = icmp eq i64 %v67804, -1
  %v68235 = add i64 %v67806, -1
  br i1 %t3469.not, label %block39122, label %block4644

edge3408:                                         ; preds = %edge3386, %edge3387, %edge3390
  %v68449 = add nsw i64 %v67405, -1
  br label %block4608

edge3409:                                         ; preds = %edge3368
  %v68320 = call i64 @mech_compact_release_two(i64 %v0, i64 %v65476, i64 %v65488)
  %t3472.not = icmp eq i64 %v68320, 0
  br i1 %t3472.not, label %edge3425, label %edge3411

edge3411:                                         ; preds = %edge3409
  %t3473 = insertvalue { i64, i64 } poison, i64 %v68320, 0
  %t3474 = insertvalue { i64, i64 } %t3473, i64 4771, 1
  br label %common.ret

edge3425:                                         ; preds = %edge3368, %edge3409, %edge3359, %edge3360
  %t3483 = call { i64, i64 } @mech_compact_allocate_backing(i64 %v0, i64 17, i64 4, i64 4, i64 1)
  %v69535 = extractvalue { i64, i64 } %t3483, 0
  %v69536 = extractvalue { i64, i64 } %t3483, 1
  %t3484.not = icmp eq i64 %v69535, 0
  br i1 %t3484.not, label %edge3427, label %edge3426

edge3426:                                         ; preds = %edge3425
  %t3485 = inttoptr i64 %v69536 to ptr
  store i64 1, ptr %t3485, align 1
  %41 = add nuw nsw i64 %v64207, 1
  br label %block4730

edge3427:                                         ; preds = %edge3425
  %t3486 = insertvalue { i64, i64 } poison, i64 %v69536, 0
  %t3487 = insertvalue { i64, i64 } %t3486, i64 4788, 1
  br label %common.ret

edge3431:                                         ; preds = %block4730
  %t3489 = inttoptr i64 %v69675 to ptr
  %v69676 = load i64, ptr %t3489, align 1
  %t3490 = icmp eq i64 %v69676, 1
  br i1 %t3490, label %edge3433, label %block4739

edge3433:                                         ; preds = %edge3431
  %t3492 = zext nneg i64 %v64207 to i128
  %t3493 = zext nneg i64 %v69696 to i128
  %t3494 = shl nuw nsw i128 %t3493, 64
  %v139018 = or disjoint i128 %t3494, %t3492
  store i128 %v139018, ptr %ss3, align 16
  %t3496 = zext i64 %v65483 to i128
  %t3497 = zext nneg i64 %v64216 to i128
  %t3498 = shl nuw nsw i128 %t3497, 64
  %v139020 = or disjoint i128 %t3498, %t3496
  store i128 %v139020, ptr %t403, align 16
  %v139022 = or disjoint i128 %t3498, 1
  store i128 %v139022, ptr %t408, align 16
  %t3506 = zext i64 %v69701 to i128
  %v139024 = or disjoint i128 %t3506, 313594649253062377472
  store i128 %v139024, ptr %t413, align 16
  store i128 313594649253062377473, ptr %t418, align 16
  %t3516 = zext i64 %v69675 to i128
  %v139028 = or disjoint i128 %t3516, 313594649253062377472
  store i128 %v139028, ptr %t423, align 16
  %t3521 = call { i64, i64 } @mech_compact_numeric_4799(i64 %v0, i64 %v138697, i64 %v6374)
  %v69681 = extractvalue { i64, i64 } %t3521, 0
  %t3522.not = icmp eq i64 %v69681, 0
  br i1 %t3522.not, label %edge3436, label %edge3435

edge3435:                                         ; preds = %edge3433
  %v69682 = extractvalue { i64, i64 } %t3521, 1
  %t3523 = icmp eq i64 %v69681, 103169
  %v69685 = select i1 %t3523, i64 103425, i64 %v69681
  %t3525 = insertvalue { i64, i64 } poison, i64 %v69685, 0
  %t3526 = insertvalue { i64, i64 } %t3525, i64 %v69682, 1
  br label %common.ret

edge3436:                                         ; preds = %edge3433
  br i1 %t3367.not, label %block4807.preheader, label %edge3437

block4807.preheader:                              ; preds = %edge3448, %edge3445, %edge3444, %edge3437, %edge3436
  br label %block4807.outer

edge3437:                                         ; preds = %edge3436
  %v69689 = call i64 @mech_compact_release_nullable(i64 %v0, i64 %v65488)
  %t3528.not = icmp eq i64 %v69689, 0
  br i1 %t3528.not, label %block4807.preheader, label %edge3439

edge3439:                                         ; preds = %edge3437
  %t3529 = insertvalue { i64, i64 } poison, i64 %v69689, 0
  %t3530 = insertvalue { i64, i64 } %t3529, i64 4799, 1
  br label %common.ret

edge3444:                                         ; preds = %block4739
  br i1 %t3367.not, label %block4807.preheader, label %edge3445

edge3445:                                         ; preds = %edge3444
  %t3535 = inttoptr i64 %v65488 to ptr
  %v69741 = load i64, ptr %t3535, align 1
  %v69742 = add i64 %v69741, -1
  store i64 %v69742, ptr %t3535, align 1
  %t3537.not = icmp eq i64 %v69742, 0
  br i1 %t3537.not, label %edge3448, label %block4807.preheader

edge3448:                                         ; preds = %edge3445
  %v69743 = call i64 @mech_compact_free(i64 %v0, i64 %v65488)
  %t3538.not = icmp eq i64 %v69743, 0
  br i1 %t3538.not, label %block4807.preheader, label %edge3449

edge3449:                                         ; preds = %edge3448
  %t3539 = insertvalue { i64, i64 } poison, i64 %v69743, 0
  %t3540 = insertvalue { i64, i64 } %t3539, i64 4810, 1
  br label %common.ret

edge3467:                                         ; preds = %block4739
  %v69871 = add nsw i64 %v69696, -1
  %v70023 = shl nuw nsw i64 %v69871, 2
  %v70024 = add i64 %v70023, %v69701
  %t3546 = inttoptr i64 %v70024 to ptr
  %t3547 = load i32, ptr %t3546, align 1
  %v70198 = shl nuw nsw i64 %v69871, 3
  %v70199 = add i64 %v70198, %v65483
  %t3551 = inttoptr i64 %v70199 to ptr
  %v70200 = load i64, ptr %t3551, align 1
  %42 = trunc i64 %v70200 to i32
  %v70239.narrow = add i32 %t3547, %42
  %v70243 = zext i32 %v70239.narrow to i64
  %v70257 = shl nuw nsw i64 %v70243, 1
  %v70261 = and i64 %v70257, 4294967294
  %v70271 = add nuw nsw i64 %v69696, 1
  %t3553 = zext nneg i64 %v70271 to i128
  %t3554 = zext i64 %v69701 to i128
  %t3555 = shl nuw i128 %t3554, 64
  %v139030 = or disjoint i128 %t3555, %t3553
  store i128 %v139030, ptr %ss6, align 16
  %t3557 = zext nneg i64 %v70261 to i128
  %t3558 = zext i64 %v69675 to i128
  %t3559 = shl nuw i128 %t3558, 64
  %v139032 = or disjoint i128 %t3559, %t3557
  store i128 %v139032, ptr %t931, align 16
  store i128 %v139034, ptr %t936, align 16
  %t3567 = call { i64, i64, i64, i64 } @mech_compact_checked_layout_13100(i64 %v138793)
  %v138187 = extractvalue { i64, i64, i64, i64 } %t3567, 0
  %t3568 = icmp ugt i64 %v138187, 1
  br i1 %t3568, label %edge3474, label %edge3475

edge3474:                                         ; preds = %edge3467
  %v138188 = extractvalue { i64, i64, i64, i64 } %t3567, 1
  %v138192 = add i64 %v138187, 4866
  %t3570 = insertvalue { i64, i64 } poison, i64 %v138188, 0
  %t3571 = insertvalue { i64, i64 } %t3570, i64 %v138192, 1
  br label %common.ret

edge3475:                                         ; preds = %edge3467
  %v138190 = extractvalue { i64, i64, i64, i64 } %t3567, 3
  %v138189 = extractvalue { i64, i64, i64, i64 } %t3567, 2
  br label %block4730

edge3481:                                         ; preds = %block4807
  %v70412 = load i64, ptr %t3575, align 1
  %t3576 = icmp eq i64 %v70412, 1
  %or.cond30 = select i1 %t3576, i1 %t3578, i1 false
  br i1 %or.cond30, label %edge3485, label %block4817

edge3485:                                         ; preds = %edge3481
  %v70414 = load i64, ptr %t3579, align 1
  %t3580 = icmp eq i64 %v70414, 1
  br i1 %t3580, label %edge3487, label %block4817

edge3487:                                         ; preds = %edge3485
  %t3583 = zext nneg i64 %v70439 to i128
  %t3584 = shl nuw nsw i128 %t3583, 64
  %v139036 = or disjoint i128 %t3584, %t2804
  store i128 %v139036, ptr %ss3, align 16
  %t3586 = zext i64 %v70440.ph to i128
  %v139038 = or disjoint i128 %t2805, %t3586
  store i128 %v139038, ptr %t403, align 16
  %v139040 = or disjoint i128 %t2805, 1
  store i128 %v139040, ptr %t408, align 16
  %t3596 = zext i64 %v70443.ph to i128
  %v139042 = or disjoint i128 %t3596, 313594649253062377472
  store i128 %v139042, ptr %t413, align 16
  store i128 313594649253062377473, ptr %t418, align 16
  store i128 %v139046, ptr %t423, align 16
  store i128 4722366482869645213697, ptr %t424, align 16
  %t3616 = zext i64 %v70411.ph to i128
  %t3617 = zext i64 %v70433.ph to i128
  %t3618 = shl nuw i128 %t3617, 64
  %v139050 = or disjoint i128 %t3618, %t3616
  store i128 %v139050, ptr %t583, align 16
  %v139052 = or disjoint i128 %t2804, 313594649253062377472
  store i128 %v139052, ptr %t588, align 16
  %t3626 = call { i64, i64 } @mech_compact_numeric_4879(i64 %v0, i64 %v138697, i64 %v6374)
  %v70420 = extractvalue { i64, i64 } %t3626, 0
  %t3627.not = icmp eq i64 %v70420, 0
  br i1 %t3627.not, label %edge3491, label %edge3489

edge3489:                                         ; preds = %edge3487
  %v70421 = extractvalue { i64, i64 } %t3626, 1
  %t3628 = icmp eq i64 %v70420, 103169
  %v70424 = select i1 %t3628, i64 103425, i64 %v70420
  %t3630 = insertvalue { i64, i64 } poison, i64 %v70424, 0
  %t3631 = insertvalue { i64, i64 } %t3630, i64 %v70421, 1
  br label %common.ret

edge3491:                                         ; preds = %edge3487
  %v70429 = call i64 @mech_compact_release_nullable(i64 %v0, i64 %v70433.ph)
  %t3632.not = icmp eq i64 %v70429, 0
  br i1 %t3632.not, label %block4954, label %edge3492

edge3492:                                         ; preds = %edge3491
  %t3633 = insertvalue { i64, i64 } poison, i64 %v70429, 0
  %t3634 = insertvalue { i64, i64 } %t3633, i64 4879, 1
  br label %common.ret

edge3497:                                         ; preds = %block4817
  %v70755 = add nuw nsw i64 %v70439, 1
  %v70760 = shl nuw nsw i64 %v70439, 2
  %v70761 = add i64 %v70440.ph, %v70760
  %t3641 = inttoptr i64 %v70761 to ptr
  %t3642 = load i32, ptr %t3641, align 1
  %43 = lshr i32 %t3642, 16
  %t3644 = icmp eq i32 %43, 0
  br i1 %t3644, label %block4807, label %edge3505

edge3498:                                         ; preds = %block4817
  %t3706.not = icmp eq i64 %v70433.ph, 0
  br i1 %t3706.not, label %block4954, label %edge3542

edge3505:                                         ; preds = %edge3497
  %v70789.le = zext nneg i32 %43 to i64
  %t3647 = icmp ult i32 %t3642, 1114112
  %v71092 = shl nuw nsw i64 %v70789.le, 2
  %v71093 = add i64 %v71092, %v70443.ph
  %44 = inttoptr i64 %v71093 to ptr
  %t3650 = select i1 %t3647, ptr %44, ptr @mech_compact_llvm_anonymous_data_1
  %t3651 = load i32, ptr %t3650, align 1
  %v71094 = zext i32 %t3651 to i64
  %t3652.not = icmp eq i32 %t3651, -1
  br i1 %t3652.not, label %block39122, label %edge3510

edge3510:                                         ; preds = %edge3505
  %v71156 = add nuw nsw i64 %v71094, 1
  %v71087 = add nuw nsw i64 %v70789.le, 1
  %t3654 = zext nneg i64 %v71087 to i128
  %t3655 = zext i64 %v70443.ph to i128
  %t3656 = shl nuw i128 %t3655, 64
  %v139054 = or disjoint i128 %t3656, %t3654
  store i128 %v139054, ptr %ss6, align 16
  %t3658 = zext nneg i64 %v71156 to i128
  %t3659 = zext i64 %v70433.ph to i128
  %t3660 = shl nuw i128 %t3659, 64
  %v139056 = or disjoint i128 %t3660, %t3658
  store i128 %v139056, ptr %t931, align 16
  store i128 %v139034, ptr %t936, align 16
  %t3668 = call { i64, i64, i64, i64 } @mech_compact_checked_layout_13100(i64 %v138793)
  %v138179 = extractvalue { i64, i64, i64, i64 } %t3668, 0
  %v138181 = extractvalue { i64, i64, i64, i64 } %t3668, 2
  %v138182 = extractvalue { i64, i64, i64, i64 } %t3668, 3
  %t3669 = icmp ugt i64 %v138179, 1
  br i1 %t3669, label %edge3514, label %edge3515

edge3514:                                         ; preds = %edge3510
  %v138180 = extractvalue { i64, i64, i64, i64 } %t3668, 1
  %v138184 = add i64 %v138179, 4950
  %t3671 = insertvalue { i64, i64 } poison, i64 %v138180, 0
  %t3672 = insertvalue { i64, i64 } %t3671, i64 %v138184, 1
  br label %common.ret

edge3515:                                         ; preds = %edge3510
  br i1 %t3647, label %edge3526, label %block39122

edge3526:                                         ; preds = %edge3515
  %v71228 = and i64 %v71094, 255
  %v71380 = add i64 %v71228, ptrtoint (ptr @mech_compact_table_19 to i64)
  %t3673 = inttoptr i64 %v71380 to ptr
  %t3674 = load i8, ptr %t3673, align 1
  %v71381 = zext i8 %t3674 to i64
  %v71623 = shl nuw nsw i64 %v71381, 8
  %t3676 = icmp ult i32 %t3651, 65536
  %v71448 = lshr i64 %v71094, 8
  %v71600 = add i64 %v71448, ptrtoint (ptr @mech_compact_table_19 to i64)
  %45 = inttoptr i64 %v71600 to ptr
  %t3679 = select i1 %t3676, ptr %45, ptr @mech_compact_llvm_anonymous_data_1
  %t3680 = load i8, ptr %t3679, align 1
  %v71601 = zext i8 %t3680 to i64
  %v71627 = or disjoint i64 %v71623, %v71601
  %v71633 = sub nuw nsw i64 16, %v70789.le
  %v71639 = lshr i64 %v71627, %v71633
  %v71658 = shl nuw nsw i64 %v70789.le, 16
  %v71662 = or disjoint i64 %v71639, %v71658
  %t3686 = zext nneg i64 %v70755 to i128
  %v139060 = or disjoint i128 %t2805, %t3686
  store i128 %v139060, ptr %ss6, align 16
  %t3690 = zext i64 %v70440.ph to i128
  %t3691 = zext nneg i64 %v71662 to i128
  %t3692 = shl nuw nsw i128 %t3691, 64
  %v139062 = or disjoint i128 %t3692, %t3690
  store i128 %v139062, ptr %t931, align 16
  %t3695 = zext i64 %v70411.ph to i128
  %v139064 = or disjoint i128 %t934, %t3695
  store i128 %v139064, ptr %t936, align 16
  store i64 %v137690, ptr %t937, align 16
  %t3701 = call { i64, i64, i64, i64 } @mech_compact_checked_layout_16147(i64 %v138793)
  %v138108 = extractvalue { i64, i64, i64, i64 } %t3701, 0
  %v138110 = extractvalue { i64, i64, i64, i64 } %t3701, 2
  %v138111 = extractvalue { i64, i64, i64, i64 } %t3701, 3
  %t3702 = icmp ugt i64 %v138108, 1
  br i1 %t3702, label %edge3536, label %block4807.outer

block4807.outer:                                  ; preds = %block4807.preheader, %edge3526
  %v70411.ph = phi i64 [ %v67371, %block4807.preheader ], [ %v138111, %edge3526 ]
  %v70433.ph = phi i64 [ %v69675, %block4807.preheader ], [ %v138182, %edge3526 ]
  %v70439.ph = phi i64 [ 0, %block4807.preheader ], [ %v70755, %edge3526 ]
  %v70440.ph = phi i64 [ %v67411, %block4807.preheader ], [ %v138110, %edge3526 ]
  %v70443.ph = phi i64 [ %v69701, %block4807.preheader ], [ %v138181, %edge3526 ]
  %t3574.not = icmp eq i64 %v70411.ph, 0
  %t3575 = inttoptr i64 %v70411.ph to ptr
  %t3578 = icmp ne i64 %v70433.ph, 0
  %t3579 = inttoptr i64 %v70433.ph to ptr
  br label %block4807

edge3536:                                         ; preds = %edge3526
  %v138109 = extractvalue { i64, i64, i64, i64 } %t3701, 1
  %v138113 = add i64 %v138108, 5011
  %t3704 = insertvalue { i64, i64 } poison, i64 %v138109, 0
  %t3705 = insertvalue { i64, i64 } %t3704, i64 %v138113, 1
  br label %common.ret

edge3542:                                         ; preds = %edge3498
  %v71773 = call i64 @mech_compact_release_nullable(i64 %v0, i64 %v70433.ph)
  %t3707.not = icmp eq i64 %v71773, 0
  br i1 %t3707.not, label %block4954, label %edge3544

edge3544:                                         ; preds = %edge3542
  %t3708 = insertvalue { i64, i64 } poison, i64 %v71773, 0
  %t3709 = insertvalue { i64, i64 } %t3708, i64 5018, 1
  br label %common.ret

edge3552:                                         ; preds = %block4954
  %t3713.not = icmp eq i64 %v72080, 0
  br i1 %t3713.not, label %edge3584, label %edge3584.thread

edge3553:                                         ; preds = %block4954
  br i1 %v137688, label %edge3560, label %edge3559

edge3559:                                         ; preds = %edge3553
  %t3736.not = icmp eq i64 %v137677, 0
  br i1 %t3736.not, label %edge3586, label %edge3578

edge3560:                                         ; preds = %edge3553
  %t3719 = call i64 @llvm.umin.i64(i64 %v137690, i64 32)
  %t3720 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %v137673, i64 %t3719)
  %v72239 = extractvalue { i64, i1 } %t3720, 0
  %t3721 = extractvalue { i64, i1 } %t3720, 1
  br i1 %t3721, label %block26585, label %edge3561

edge3561:                                         ; preds = %edge3560
  %t3724.not = icmp ugt i64 %v72239, %v137674
  br i1 %t3724.not, label %edge3564, label %edge3567

edge3564:                                         ; preds = %edge3561
  call preserve_allcc void @mech_compact_expand_capacity_preserving(i64 %v137674, i64 %v72239, i64 2, i64 %v137568)
  %v137577 = load i64, ptr %ss2, align 8
  %t3726.not = icmp eq i64 %v137577, 0
  br i1 %t3726.not, label %block26585, label %edge3567

edge3567:                                         ; preds = %edge3564, %edge3561
  %v72244 = phi i64 [ %v137674, %edge3561 ], [ %v137577, %edge3564 ]
  %t3727 = call { i64, i64 } @mech_compact_writable_scalar_backing(i64 %v0, i64 %v137672, i64 %v137673, i64 %v137674, i64 %v137677, i64 %v72244, i64 8)
  %v72276 = extractvalue { i64, i64 } %t3727, 0
  %v72277 = extractvalue { i64, i64 } %t3727, 1
  %t3728.not = icmp eq i64 %v72276, 0
  br i1 %t3728.not, label %block26585, label %edge3568

edge3568:                                         ; preds = %edge3567
  %t3729 = call i64 @llvm.umax.i64(i64 %v137674, i64 %v72244)
  %v72283 = shl nuw nsw i64 %t3719, 2
  %v72279 = shl i64 %v137673, 2
  %v72280 = add i64 %v72276, %v72279
  %v72284 = call i64 @memmove(i64 %v72280, i64 %v72075, i64 %v72283)
  %t3731.not = icmp eq i64 %v72277, 0
  br i1 %t3731.not, label %edge3590, label %edge3585.thread851

edge3585.thread851:                               ; preds = %edge3568
  %t3732 = inttoptr i64 %v72277 to ptr
  %v72285 = load i64, ptr %t3732, align 1
  %v72286 = add i64 %v72285, 1
  store i64 %v72286, ptr %t3732, align 1
  br label %edge3587

edge3578:                                         ; preds = %edge3559
  %t3737 = inttoptr i64 %v137677 to ptr
  %v72324 = load i64, ptr %t3737, align 1
  %v72325 = add i64 %v72324, 1
  store i64 %v72325, ptr %t3737, align 1
  br label %edge3586

edge3584:                                         ; preds = %edge3552
  br i1 %v137688, label %edge3590, label %edge3586

edge3584.thread:                                  ; preds = %edge3552
  %t3714 = inttoptr i64 %v72080 to ptr
  %v72081 = load i64, ptr %t3714, align 1
  %v72082 = add i64 %v72081, 1
  store i64 %v72082, ptr %t3714, align 1
  br i1 %v137688, label %edge3585.edge3587_crit_edge, label %edge3586

edge3585.edge3587_crit_edge:                      ; preds = %edge3584.thread
  %t3742.phi.trans.insert = inttoptr i64 %v72080 to ptr
  %v72561.pre = load i64, ptr %t3742.phi.trans.insert, align 1
  br label %edge3587

edge3586:                                         ; preds = %edge3584.thread, %edge3559, %edge3578, %edge3584
  %v72510784 = phi i64 [ %v72080, %edge3584 ], [ %v137677, %edge3578 ], [ 0, %edge3559 ], [ %v72080, %edge3584.thread ]
  %v72507783 = phi i64 [ %v137690, %edge3584 ], [ %v137674, %edge3578 ], [ %v137674, %edge3559 ], [ %v137690, %edge3584.thread ]
  %v72506782 = phi i64 [ %v137690, %edge3584 ], [ %v137673, %edge3578 ], [ %v137673, %edge3559 ], [ %v137690, %edge3584.thread ]
  %v72505781 = phi i64 [ %v72075, %edge3584 ], [ %v137672, %edge3578 ], [ %v137672, %edge3559 ], [ %v72075, %edge3584.thread ]
  %t3945.not = icmp eq i64 %v137682, 0
  br i1 %t3945.not, label %block28337, label %edge3843

edge3587:                                         ; preds = %edge3585.edge3587_crit_edge, %edge3585.thread851
  %t3742.pre-phi = phi ptr [ %t3742.phi.trans.insert, %edge3585.edge3587_crit_edge ], [ %t3732, %edge3585.thread851 ]
  %v72561 = phi i64 [ %v72561.pre, %edge3585.edge3587_crit_edge ], [ %v72286, %edge3585.thread851 ]
  %v72505766860 = phi i64 [ %v72075, %edge3585.edge3587_crit_edge ], [ %v72276, %edge3585.thread851 ]
  %v72506768859 = phi i64 [ %v137690, %edge3585.edge3587_crit_edge ], [ %v72239, %edge3585.thread851 ]
  %v72507771858 = phi i64 [ %v137690, %edge3585.edge3587_crit_edge ], [ %t3729, %edge3585.thread851 ]
  %v72510772857 = phi i64 [ %v72080, %edge3585.edge3587_crit_edge ], [ %v72277, %edge3585.thread851 ]
  %v72562 = add i64 %v72561, 1
  store i64 %v72562, ptr %t3742.pre-phi, align 1
  br label %edge3590

edge3590:                                         ; preds = %edge3584, %edge3568, %edge3587
  %t3741.not850 = phi i1 [ false, %edge3587 ], [ true, %edge3568 ], [ true, %edge3584 ]
  %v72505766849 = phi i64 [ %v72505766860, %edge3587 ], [ %v72276, %edge3568 ], [ %v72075, %edge3584 ]
  %v72506768848 = phi i64 [ %v72506768859, %edge3587 ], [ %v72239, %edge3568 ], [ %v137690, %edge3584 ]
  %v72507771847 = phi i64 [ %v72507771858, %edge3587 ], [ %t3729, %edge3568 ], [ %v137690, %edge3584 ]
  %v72510772846 = phi i64 [ %v72510772857, %edge3587 ], [ 0, %edge3568 ], [ 0, %edge3584 ]
  %v72886 = add i64 %v72505766849, -4
  br label %block4979

edge3594:                                         ; preds = %block4979
  %v72734 = add nsw i64 %v72595, -1
  %t3747 = icmp ult i64 %v72734, %v72506768848
  %v72883 = shl i64 %v72595, 2
  %v72887 = add i64 %v72886, %v72883
  %v139149 = select i1 %t3747, i64 %v72887, i64 ptrtoint (ptr @mech_compact_llvm_anonymous_data_1 to i64)
  %t3750 = inttoptr i64 %v139149 to ptr
  %t3751 = load i32, ptr %t3750, align 1
  %t3753 = icmp ult i32 %t3751, 65536
  br i1 %t3753, label %block4979, label %block26823

edge3605:                                         ; preds = %block26823
  %t3757 = inttoptr i64 %v72510772846 to ptr
  %v72938 = load i64, ptr %t3757, align 1
  %v72939 = add i64 %v72938, -1
  store i64 %v72939, ptr %t3757, align 1
  %t3759.not = icmp eq i64 %v72939, 0
  br i1 %t3759.not, label %edge3608, label %edge3613

edge3608:                                         ; preds = %edge3605
  %v72940 = call i64 @mech_compact_free(i64 %v0, i64 %v72510772846)
  %t3760.not = icmp eq i64 %v72940, 0
  br i1 %t3760.not, label %edge3608.edge3613_crit_edge, label %edge3609

edge3608.edge3613_crit_edge:                      ; preds = %edge3608
  %v73267.pre = load i64, ptr %t3757, align 1
  %46 = add i64 %v73267.pre, 1
  br label %edge3613

edge3609:                                         ; preds = %edge3608
  %t3761 = insertvalue { i64, i64 } poison, i64 %v72940, 0
  %t3762 = insertvalue { i64, i64 } %t3761, i64 5099, 1
  br label %common.ret

edge3613:                                         ; preds = %edge3608.edge3613_crit_edge, %edge3605
  %v73267 = phi i64 [ %46, %edge3608.edge3613_crit_edge ], [ %v72938, %edge3605 ]
  store i64 %v73267, ptr %t3757, align 1
  br label %block5034.preheader

edge3620:                                         ; preds = %block5034
  %v73439 = add nsw i64 %v73301, -1
  %t3769 = icmp ult i64 %v73439, %v72506768848
  %v73588 = shl i64 %v73301, 2
  %v73592 = add i64 %v72886, %v73588
  %v139150 = select i1 %t3769, i64 %v73592, i64 ptrtoint (ptr @mech_compact_llvm_anonymous_data_1 to i64)
  %t3772 = inttoptr i64 %v139150 to ptr
  %t3773 = load i32, ptr %t3772, align 1
  %t3775 = icmp ult i32 %t3773, 65536
  br i1 %t3775, label %block5034, label %block27041

edge3631:                                         ; preds = %block27041
  %t3779 = inttoptr i64 %v72510772846 to ptr
  %v73641 = load i64, ptr %t3779, align 1
  %v73642 = add i64 %v73641, -1
  store i64 %v73642, ptr %t3779, align 1
  %t3781.not = icmp eq i64 %v73642, 0
  br i1 %t3781.not, label %edge3634, label %edge3639

edge3634:                                         ; preds = %edge3631
  %v73643 = call i64 @mech_compact_free(i64 %v0, i64 %v72510772846)
  %t3782.not = icmp eq i64 %v73643, 0
  br i1 %t3782.not, label %edge3639, label %edge3635

edge3635:                                         ; preds = %edge3634
  %t3783 = insertvalue { i64, i64 } poison, i64 %v73643, 0
  %t3784 = insertvalue { i64, i64 } %t3783, i64 5156, 1
  br label %common.ret

edge3639:                                         ; preds = %block27041, %edge3631, %edge3634
  %v73796 = add i64 %v73301.lcssa, -288
  %v73801 = add i64 %v73796, %v72595.lcssa
  %t3787.not = icmp ult i64 %v73801, %v72595.lcssa
  br i1 %t3787.not, label %block39122, label %edge3652

edge3649:                                         ; preds = %edge3655
  %t3792 = insertvalue { i64, i64 } poison, i64 %v74690, 0
  %t3793 = insertvalue { i64, i64 } %t3792, i64 5171, 1
  br label %common.ret

edge3652:                                         ; preds = %edge3639
  %t3794 = call { i64, i64 } @mech_compact_allocate_backing(i64 %v0, i64 19, i64 4, i64 4, i64 1)
  %v74758 = extractvalue { i64, i64 } %t3794, 0
  %v74759 = extractvalue { i64, i64 } %t3794, 1
  %t3795.not = icmp eq i64 %v74758, 0
  br i1 %t3795.not, label %edge3654, label %edge3655

edge3654:                                         ; preds = %edge3652
  %t3797 = insertvalue { i64, i64 } poison, i64 %v74759, 0
  %t3798 = insertvalue { i64, i64 } %t3797, i64 5175, 1
  br label %common.ret

edge3655:                                         ; preds = %edge3652
  %t3796 = inttoptr i64 %v74759 to ptr
  store i64 2, ptr %t3796, align 1
  %v74690 = call i64 @mech_compact_release_owner(i64 %v0, i64 %v74759)
  %t3791.not = icmp eq i64 %v74690, 0
  br i1 %t3791.not, label %edge3663, label %edge3649

edge3660:                                         ; preds = %edge3666
  %t3802 = insertvalue { i64, i64 } poison, i64 %v75757, 0
  %t3803 = insertvalue { i64, i64 } %t3802, i64 5184, 1
  br label %common.ret

edge3661:                                         ; preds = %edge3666
  %.pre19788 = inttoptr i64 %v72510772846 to ptr
  br i1 %t3741.not850, label %edge3672, label %edge3669

edge3663:                                         ; preds = %edge3655
  %t3804 = call { i64, i64 } @mech_compact_allocate_backing(i64 %v0, i64 320, i64 4, i64 4, i64 1)
  %v75802 = extractvalue { i64, i64 } %t3804, 0
  %v75803 = extractvalue { i64, i64 } %t3804, 1
  %t3805.not = icmp eq i64 %v75802, 0
  br i1 %t3805.not, label %edge3665, label %edge3666

edge3665:                                         ; preds = %edge3663
  %t3807 = insertvalue { i64, i64 } poison, i64 %v75803, 0
  %t3808 = insertvalue { i64, i64 } %t3807, i64 5188, 1
  br label %common.ret

edge3666:                                         ; preds = %edge3663
  %t3806 = inttoptr i64 %v75803 to ptr
  store i64 2, ptr %t3806, align 1
  %v75757 = call i64 @mech_compact_release_owner(i64 %v0, i64 %v75803)
  %t3801.not = icmp eq i64 %v75757, 0
  br i1 %t3801.not, label %edge3661, label %edge3660

edge3669:                                         ; preds = %edge3661
  %v75944 = load i64, ptr %.pre19788, align 1
  %v75945 = add i64 %v75944, 1
  store i64 %v75945, ptr %.pre19788, align 1
  br label %edge3672

edge3672:                                         ; preds = %edge3661, %edge3669
  %v76441 = sub i64 288, %v72595.lcssa
  br label %block5117

edge3676:                                         ; preds = %block5117
  %t3815 = icmp ne i64 %v76012, %v76014
  br i1 %t3815, label %block5249, label %edge3679

edge3677:                                         ; preds = %block5117
  %t3931.not = icmp eq i64 %v75991, 0
  br i1 %t3931.not, label %block28215, label %edge3823

edge3679:                                         ; preds = %edge3676
  %t3818 = icmp ult i64 %v76012, %v72595.lcssa
  %v76445 = select i1 %t3818, i64 0, i64 %v76441
  %v76448 = add i64 %v76445, %v76012
  %t3821 = icmp ult i64 %v76448, %v72506768848
  %v76610 = shl i64 %v76448, 2
  %v76611 = add i64 %v76610, %v72505766849
  %v139151 = select i1 %t3821, i64 %v76611, i64 ptrtoint (ptr @mech_compact_llvm_anonymous_data_1 to i64)
  %t3824 = inttoptr i64 %v139151 to ptr
  %t3825 = load i32, ptr %t3824, align 1
  %47 = lshr i32 %t3825, 16
  %48 = and i32 %47, 255
  %v76652 = zext nneg i32 %48 to i64
  %t3827.not = icmp eq i64 %v76012, -1
  br i1 %t3827.not, label %block39122, label %edge3694

edge3694:                                         ; preds = %edge3679
  br i1 %t3741.not850, label %block5186.preheader, label %edge3697

edge3697:                                         ; preds = %edge3694
  %v76805 = load i64, ptr %.pre19788, align 1
  %v76806 = add i64 %v76805, 1
  store i64 %v76806, ptr %.pre19788, align 1
  br label %block5186.preheader

block5186.preheader:                              ; preds = %edge3694, %edge3697
  br label %block5186

edge3719:                                         ; preds = %block5186
  %t3852.not = icmp eq i64 %v76845, -1
  br i1 %t3852.not, label %block39122, label %block5186

edge3720:                                         ; preds = %block5186
  br i1 %t3741.not850, label %block5249, label %edge3721

edge3721:                                         ; preds = %edge3720
  %v77214 = load i64, ptr %.pre19788, align 1
  %v77215 = add i64 %v77214, -1
  store i64 %v77215, ptr %.pre19788, align 1
  %t3848.not = icmp eq i64 %v77215, 0
  br i1 %t3848.not, label %edge3724, label %block5249

edge3724:                                         ; preds = %edge3721
  %v77216 = call i64 @mech_compact_free(i64 %v0, i64 %v72510772846)
  %t3849.not = icmp eq i64 %v77216, 0
  br i1 %t3849.not, label %block5249, label %edge3725

edge3725:                                         ; preds = %edge3724
  %t3850 = insertvalue { i64, i64 } poison, i64 %v77216, 0
  %t3851 = insertvalue { i64, i64 } %t3850, i64 5318, 1
  br label %common.ret

edge3732:                                         ; preds = %block5249
  %v77384 = sub nuw i64 %v77381, %v76012
  %t3856 = icmp eq i64 %v77389, 0
  br i1 %t3856, label %edge3737, label %edge3738

edge3737:                                         ; preds = %edge3732
  %t3859 = icmp ugt i64 %v77384, 10
  br i1 %t3859, label %edge3758, label %edge3741

edge3738:                                         ; preds = %edge3732
  %t3865 = icmp ugt i64 %v77384, 2
  %v78370132 = and i1 %t3815, %t3865
  %v78574 = select i1 %v78370132, i64 16, i64 %v77389
  %v78575 = select i1 %v78370132, i64 3, i64 1
  %v78576 = select i1 %v78370132, i64 6, i64 1
  br label %edge3758

edge3741:                                         ; preds = %edge3737
  %t3862 = icmp samesign ugt i64 %v77384, 2
  %v78346 = select i1 %t3862, i64 17, i64 0
  %v78347 = select i1 %t3862, i64 3, i64 1
  %v78348 = select i1 %t3862, i64 10, i64 1
  br label %edge3758

edge3758:                                         ; preds = %edge3741, %edge3737, %edge3738
  %v78578 = phi i64 [ %v78574, %edge3738 ], [ %v78346, %edge3741 ], [ 18, %edge3737 ]
  %v78580 = phi i64 [ %v78575, %edge3738 ], [ %v78347, %edge3741 ], [ 11, %edge3737 ]
  %v78582 = phi i64 [ %v78576, %edge3738 ], [ %v78348, %edge3741 ], [ 138, %edge3737 ]
  %v78728 = call i64 @llvm.umin.i64(i64 %v77384, i64 %v78582)
  %t3871.not = icmp samesign ult i64 %v78728, %v78580
  br i1 %t3871.not, label %block39122, label %edge3764

edge3764:                                         ; preds = %edge3758
  %v78731 = sub nuw nsw i64 %v78728, %v78580
  %t3873 = icmp ult i64 %v78578, 19
  %v78896 = shl nuw nsw i64 %v78578, 2
  %v78897 = add i64 %v78896, %v75986
  %v139153 = select i1 %t3873, i64 %v78897, i64 ptrtoint (ptr @mech_compact_llvm_anonymous_data_1 to i64)
  %t3876 = inttoptr i64 %v139153 to ptr
  %t3877 = load i32, ptr %t3876, align 1
  %v78898 = zext i32 %t3877 to i64
  %v78927 = add nuw nsw i64 %v78898, 1
  %t3878.not = icmp eq i32 %t3877, -1
  br i1 %t3878.not, label %block39122, label %edge3771

edge3771:                                         ; preds = %edge3764
  br i1 %t3873, label %edge3775, label %block28150

edge3775:                                         ; preds = %edge3771
  %t3882 = inttoptr i64 %v78897 to ptr
  %t3883 = load i32, ptr %t3882, align 1
  %v78943 = zext i32 %t3883 to i64
  %t3884 = icmp eq i64 %v78927, %v78943
  br i1 %t3884, label %block28153, label %edge3778

edge3778:                                         ; preds = %edge3775
  %t3886.not = icmp eq i64 %v75991, 0
  br i1 %t3886.not, label %block28155, label %edge3779

edge3779:                                         ; preds = %edge3778
  %t3887 = inttoptr i64 %v75991 to ptr
  %v78959 = load i64, ptr %t3887, align 1
  %t3888 = icmp eq i64 %v78959, 1
  br i1 %t3888, label %block28154, label %block28155

edge3787:                                         ; preds = %block28153
  %t3897 = inttoptr i64 %v78952 to ptr
  %v78970 = load i64, ptr %t3897, align 1
  %v78971 = add i64 %v78970, 1
  store i64 %v78971, ptr %t3897, align 1
  br label %block28159

edge3796:                                         ; preds = %block28159
  %v79090 = shl nuw nsw i64 %v76010, 2
  %v79091 = add i64 %v79090, %v75998
  %t3905 = inttoptr i64 %v79091 to ptr
  %t3906 = load i32, ptr %t3905, align 1
  %v79092 = zext i32 %t3906 to i64
  %t3907 = icmp eq i64 %v79071, %v79092
  br i1 %t3907, label %block28173, label %edge3799

edge3799:                                         ; preds = %edge3796
  %t3909.not = icmp eq i64 %v78972, 0
  br i1 %t3909.not, label %block28176, label %edge3800

edge3800:                                         ; preds = %edge3799
  %v79105 = call i64 @mech_compact_release_owner(i64 %v0, i64 %v78972)
  %t3910.not = icmp eq i64 %v79105, 0
  br i1 %t3910.not, label %block28176, label %block28170

edge3804:                                         ; preds = %block28176
  %t3912 = inttoptr i64 %v76003 to ptr
  %v79112 = load i64, ptr %t3912, align 1
  %t3913 = icmp eq i64 %v79112, 1
  br i1 %t3913, label %block28178, label %block28179

edge3812:                                         ; preds = %block28173
  %t3922 = inttoptr i64 %v79101 to ptr
  %v79123 = load i64, ptr %t3922, align 1
  %v79124 = add i64 %v79123, 1
  store i64 %v79124, ptr %t3922, align 1
  br label %edge3816

edge3816:                                         ; preds = %edge3812, %block28173
  %v79125 = select i1 %t3919, i64 0, i64 %v76003
  %v79155 = add i64 %v78728, %v76012
  %t3929.not = icmp ult i64 %v79155, %v76012
  br i1 %t3929.not, label %block39122, label %edge3831

edge3823:                                         ; preds = %edge3677
  %t3932 = inttoptr i64 %v75991 to ptr
  %v79175 = load i64, ptr %t3932, align 1
  %v79176 = add i64 %v79175, 1
  store i64 %v79176, ptr %t3932, align 1
  br label %block28215

edge3826:                                         ; preds = %block28215
  %t3935 = inttoptr i64 %v76003 to ptr
  %v79177 = load i64, ptr %t3935, align 1
  %v79178 = add i64 %v79177, 1
  store i64 %v79178, ptr %t3935, align 1
  br label %edge3832

edge3831:                                         ; preds = %edge3816
  %v79226 = or i64 %v79125, %v79233
  %t3941.not = icmp eq i64 %v79226, 0
  br i1 %t3941.not, label %block5117.backedge, label %edge3837

edge3832:                                         ; preds = %block28215, %edge3826
  %v79222 = or i64 %v75991, %v72510772846
  %v79223 = or i64 %v79222, %v76003
  %t3939.not = icmp eq i64 %v79223, 0
  br i1 %t3939.not, label %block5380, label %edge3833

edge3833:                                         ; preds = %edge3832
  %v79224 = call i64 @mech_compact_release_three(i64 %v0, i64 %v72510772846, i64 %v75991, i64 %v76003)
  %t3940.not = icmp eq i64 %v79224, 0
  br i1 %t3940.not, label %block5380, label %block28236

edge3837:                                         ; preds = %edge3831
  %v79227 = call i64 @mech_compact_release_two(i64 %v0, i64 %v79233, i64 %v79125)
  %t3942.not = icmp eq i64 %v79227, 0
  br i1 %t3942.not, label %block5117.backedge, label %block28236

block5117.backedge:                               ; preds = %edge3837, %edge3831
  br label %block5117

edge3843:                                         ; preds = %edge3586
  %t3946 = inttoptr i64 %v137682 to ptr
  %v79441 = load i64, ptr %t3946, align 1
  %v79442 = add i64 %v79441, 1
  store i64 %v79442, ptr %t3946, align 1
  br label %block28337

edge3846:                                         ; preds = %block28337
  %t3949 = inttoptr i64 %v137684 to ptr
  %v79443 = load i64, ptr %t3949, align 1
  %v79444 = add i64 %v79443, 1
  store i64 %v79444, ptr %t3949, align 1
  br label %block5380

edge3850:                                         ; preds = %block5380
  br i1 %t2683.not, label %edge3861, label %edge3852

edge3851:                                         ; preds = %block5380
  %t3956.not = icmp eq i64 %v79616, 0
  br i1 %t3956.not, label %block5389, label %edge3856

edge3852:                                         ; preds = %edge3850
  %v79603 = load i64, ptr %t3954.pre-phi, align 1
  %v79604 = add i64 %v79603, 1
  store i64 %v79604, ptr %t3954.pre-phi, align 1
  br label %edge3861

edge3856:                                         ; preds = %edge3851
  %t3957 = inttoptr i64 %v79616 to ptr
  %v79617 = load i64, ptr %t3957, align 1
  %v79618 = add i64 %v79617, 1
  store i64 %v79618, ptr %t3957, align 1
  br label %block5389

edge3861:                                         ; preds = %edge3850, %edge3852, %block5389
  %v79869465 = phi i64 [ %v79612, %block5389 ], [ 320, %edge3852 ], [ 320, %edge3850 ]
  %v79868464 = phi i64 [ %v79611, %block5389 ], [ %v53387, %edge3852 ], [ %v53387, %edge3850 ]
  %v79679463 = phi i64 [ %v79616, %block5389 ], [ %v53385, %edge3852 ], [ 0, %edge3850 ]
  %v79656 = or i64 %v137682, %v137677
  %v79657 = or i64 %v79656, %v137684
  %v79658 = or i64 %v79657, %v72080
  %t3969.not = icmp eq i64 %v79658, 0
  br i1 %t3969.not, label %block5394, label %edge3873

edge3862:                                         ; preds = %block5389
  %v79648 = or i64 %v79616, %v72510773
  %v79649 = or i64 %v79648, %v79678
  %t3962.not = icmp eq i64 %v79649, 0
  br i1 %t3962.not, label %block28402, label %edge3863

edge3863:                                         ; preds = %edge3862
  %v79650 = call i64 @mech_compact_release_three(i64 %v0, i64 %v72510773, i64 %v79616, i64 %v79678)
  %t3963.not = icmp eq i64 %v79650, 0
  br i1 %t3963.not, label %block28402, label %block28398

edge3867:                                         ; preds = %block28402
  %t3965 = inttoptr i64 %v79616 to ptr
  %v79652 = load i64, ptr %t3965, align 1
  %v79653 = add i64 %v79652, -1
  store i64 %v79653, ptr %t3965, align 1
  %t3967.not = icmp eq i64 %v79653, 0
  br i1 %t3967.not, label %edge3870, label %block5405

edge3870:                                         ; preds = %edge3867
  %v79654 = call i64 @mech_compact_free(i64 %v0, i64 %v79616)
  %t3968.not = icmp eq i64 %v79654, 0
  br i1 %t3968.not, label %block5405, label %block28398

edge3873:                                         ; preds = %edge3861
  %v79659 = call i64 @mech_compact_release_four(i64 %v0, i64 %v137677, i64 %v72080, i64 %v137682, i64 %v137684)
  %t3970.not = icmp eq i64 %v79659, 0
  br i1 %t3970.not, label %block5394, label %block28398

edge3879:                                         ; preds = %block5405
  %t3974 = inttoptr i64 %v72080 to ptr
  %v82304 = load i64, ptr %t3974, align 1
  %v82305 = add i64 %v82304, 1
  store i64 %v82305, ptr %t3974, align 1
  br label %block5407.preheader

edge3886:                                         ; preds = %block5407
  %v82690 = add i64 %v82353, add (i64 ptrtoint (ptr @mech_compact_table_15 to i64), i64 -1)
  %t3982 = inttoptr i64 %v82690 to ptr
  %t3983 = load i8, ptr %t3982, align 1
  %v82691 = zext i8 %t3983 to i64
  %t3984 = icmp samesign ugt i64 %v137690, %v82691
  %v82987 = shl nuw nsw i64 %v82691, 2
  %v82988 = add i64 %v82987, %v72075
  %v139155 = select i1 %t3984, i64 %v82988, i64 ptrtoint (ptr @mech_compact_llvm_anonymous_data_1 to i64)
  %t3987 = inttoptr i64 %v139155 to ptr
  %t3988 = load i32, ptr %t3987, align 1
  %t3990 = icmp ult i32 %t3988, 65536
  br i1 %t3990, label %edge3900, label %block28771

edge3900:                                         ; preds = %edge3886
  %v82539 = add nsw i64 %v82353, -1
  br label %block5407

edge3902:                                         ; preds = %block28771
  %v83038 = call i64 @mech_compact_release_nullable(i64 %v0, i64 %v72080)
  %t3994.not = icmp eq i64 %v83038, 0
  br i1 %t3994.not, label %edge3909, label %edge3904

edge3904:                                         ; preds = %edge3902
  %t3995 = insertvalue { i64, i64 } poison, i64 %v83038, 0
  %t3996 = insertvalue { i64, i64 } %t3995, i64 5565, 1
  br label %common.ret

edge3909:                                         ; preds = %block28771, %edge3902, %edge2670, %edge2668, %edge2688, %edge2689
  %v83268 = phi i64 [ %v43295, %edge2670 ], [ %v43295, %edge2689 ], [ %v43295, %edge2688 ], [ %v43295, %edge2668 ], [ %v137672, %edge3902 ], [ %v137672, %block28771 ]
  %v83269 = phi i64 [ %v43296, %edge2670 ], [ %v43296, %edge2689 ], [ %v43296, %edge2688 ], [ %v43296, %edge2668 ], [ %v137673, %edge3902 ], [ %v137673, %block28771 ]
  %v83273 = phi i64 [ %v43300, %edge2670 ], [ %v43300, %edge2689 ], [ %v43300, %edge2688 ], [ %v43300, %edge2668 ], [ %v137677, %edge3902 ], [ %v137677, %block28771 ]
  %v83279 = phi i64 [ %v43401, %edge2670 ], [ %v43401, %edge2689 ], [ %v43401, %edge2688 ], [ %v43401, %edge2668 ], [ %v137678, %edge3902 ], [ %v137678, %block28771 ]
  %v83284 = phi i64 [ %v43406, %edge2670 ], [ %v43406, %edge2689 ], [ %v43406, %edge2688 ], [ %v43406, %edge2668 ], [ %v137682, %edge3902 ], [ %v137682, %block28771 ]
  %v83285 = phi i64 [ %v43413, %edge2670 ], [ %v43413, %edge2689 ], [ %v43413, %edge2688 ], [ %v43413, %edge2668 ], [ %v72075, %edge3902 ], [ %v72075, %block28771 ]
  %v83286 = phi i64 [ %v43414, %edge2670 ], [ %v43414, %edge2689 ], [ %v43414, %edge2688 ], [ %v43414, %edge2668 ], [ %v137690, %edge3902 ], [ %v137690, %block28771 ]
  %v83290 = phi i64 [ %v43418, %edge2670 ], [ %v43418, %edge2689 ], [ %v43418, %edge2688 ], [ %v43418, %edge2668 ], [ %v72080, %edge3902 ], [ 0, %block28771 ]
  %v83291 = phi i64 [ %v43425, %edge2670 ], [ %v43425, %edge2689 ], [ %v43425, %edge2688 ], [ %v43425, %edge2668 ], [ %v137683, %edge3902 ], [ %v137683, %block28771 ]
  %v83296 = phi i64 [ %v43430, %edge2670 ], [ %v43430, %edge2689 ], [ %v43430, %edge2688 ], [ %v43430, %edge2668 ], [ %v137684, %edge3902 ], [ %v137684, %block28771 ]
  %v83297 = phi i64 [ %v43437, %edge2670 ], [ %v43437, %edge2689 ], [ %v43437, %edge2688 ], [ %v43437, %edge2668 ], [ %v137685, %edge3902 ], [ %v137685, %block28771 ]
  %v83298 = phi i64 [ %v43439, %edge2670 ], [ %v43439, %edge2689 ], [ %v43439, %edge2688 ], [ %v43439, %edge2668 ], [ %v137686, %edge3902 ], [ %v137686, %block28771 ]
  %v83299 = phi i64 [ %v43441, %edge2670 ], [ %v43441, %edge2689 ], [ %v43441, %edge2688 ], [ %v43441, %edge2668 ], [ %v137687, %edge3902 ], [ %v137687, %block28771 ]
  %v83300 = phi i64 [ %v43443, %edge2670 ], [ %v43443, %edge2689 ], [ %v43443, %edge2688 ], [ %v43443, %edge2668 ], [ %v82353.lcssa, %edge3902 ], [ %v82353.lcssa, %block28771 ]
  %v83612 = phi i64 [ 1, %edge2670 ], [ 1, %edge2689 ], [ 1, %edge2688 ], [ 1, %edge2668 ], [ 0, %edge3902 ], [ 0, %block28771 ]
  %t3997 = icmp eq i64 %v43279, -1
  %49 = select i1 %t2144, i1 true, i1 %t3997
  %v83806 = select i1 %49, i64 %v43337, i64 %v43279
  %v83650 = or i64 %v83612, %v43485
  %t4002.not = icmp eq i64 %v83650, 0
  br i1 %t4002.not, label %edge3922, label %block5762

edge3922:                                         ; preds = %edge3909
  %t4022.not = icmp eq i64 %v83273, 0
  br i1 %t4022.not, label %block5527, label %edge3955

edge3955:                                         ; preds = %edge3922
  %t4023 = inttoptr i64 %v83273 to ptr
  %v83813 = load i64, ptr %t4023, align 1
  %v83814 = add i64 %v83813, 1
  store i64 %v83814, ptr %t4023, align 1
  br label %block5527

edge3958:                                         ; preds = %block5527
  %t4026 = inttoptr i64 %v53385 to ptr
  %v83816 = load i64, ptr %t4026, align 1
  %v83817 = add i64 %v83816, 1
  store i64 %v83817, ptr %t4026, align 1
  br label %block5528

edge3963:                                         ; preds = %block5528
  %v83844 = mul nuw i64 %v83300, 3
  %v83849 = add i64 %v83844, 14
  %t4034 = icmp samesign ult i64 %v83300, 6148914691236517201
  br i1 %t4034, label %edge3967, label %block39122

edge3967:                                         ; preds = %edge3963
  %t4036.not = icmp eq i64 %v83284, 0
  br i1 %t4036.not, label %block5534, label %edge3970

edge3970:                                         ; preds = %edge3967
  %t4037 = inttoptr i64 %v83284 to ptr
  %v83854 = load i64, ptr %t4037, align 1
  %v83855 = add i64 %v83854, 1
  store i64 %v83855, ptr %t4037, align 1
  br label %block5534

edge3973:                                         ; preds = %block5534
  %t4040 = inttoptr i64 %v83290 to ptr
  %v83857 = load i64, ptr %t4040, align 1
  %v83858 = add i64 %v83857, 1
  store i64 %v83858, ptr %t4040, align 1
  br label %block5537.preheader

edge3998:                                         ; preds = %block5537
  %v84215 = add nuw i64 %v83923, ptrtoint (ptr @mech_compact_table_14 to i64)
  %t4045 = inttoptr i64 %v84215 to ptr
  %t4046 = load i8, ptr %t4045, align 1
  %v84216 = zext i8 %t4046 to i64
  %v84521 = shl nuw nsw i64 %v83923, 2
  %v84522 = add i64 %v84521, %v83279
  %t4050 = inttoptr i64 %v84522 to ptr
  %t4051 = load i32, ptr %t4050, align 1
  %v84523 = zext i32 %t4051 to i64
  %t4052 = icmp ult i64 %v83923, %v83286
  %v84829 = add i64 %v84521, %v83285
  %v139157 = select i1 %t4052, i64 %v84829, i64 ptrtoint (ptr @mech_compact_llvm_anonymous_data_1 to i64)
  %t4055 = inttoptr i64 %v139157 to ptr
  %t4056 = load i32, ptr %t4055, align 1
  %50 = lshr i32 %t4056, 16
  %v84854 = zext nneg i32 %50 to i64
  %51 = add nuw nsw i64 %v84854, %v84216
  %52 = mul nuw nsw i64 %51, %v84523
  %v84882 = add i64 %52, %v83925
  %t4066.not = icmp ult i64 %v84882, %v83925
  %v85015 = add nuw nsw i64 %v83923, 1
  br i1 %t4066.not, label %block39122, label %block5537

edge4006:                                         ; preds = %block5537
  %v84891 = or i64 %v83290, %v83284
  %t4070.not = icmp eq i64 %v84891, 0
  br i1 %t4070.not, label %block5650.preheader, label %edge4007

block5650.preheader:                              ; preds = %edge4007, %edge4006
  br label %block5650

edge4007:                                         ; preds = %edge4006
  %v84893 = call i64 @mech_compact_release_two(i64 %v0, i64 %v83284, i64 %v83290)
  %t4071.not = icmp eq i64 %v84893, 0
  br i1 %t4071.not, label %block5650.preheader, label %edge4009

edge4009:                                         ; preds = %edge4007
  %t4072 = insertvalue { i64, i64 } poison, i64 %v84893, 0
  %t4073 = insertvalue { i64, i64 } %t4072, i64 5729, 1
  br label %common.ret

edge4033:                                         ; preds = %block5650
  %v86174 = add nuw i64 %v85890, ptrtoint (ptr @mech_compact_table_21 to i64)
  %t4077 = inttoptr i64 %v86174 to ptr
  %t4078 = load i8, ptr %t4077, align 1
  %v86175 = zext i8 %t4078 to i64
  %v86471 = shl nuw nsw i64 %v85890, 2
  %v86472 = add i64 %v86471, %v53387
  %t4079 = inttoptr i64 %v86472 to ptr
  %t4080 = load i32, ptr %t4079, align 1
  %v86473 = zext i32 %t4080 to i64
  %t4081 = icmp ult i64 %v85890, %v83269
  %v86770 = add i64 %v86471, %v83268
  %v139158 = select i1 %t4081, i64 %v86770, i64 ptrtoint (ptr @mech_compact_llvm_anonymous_data_1 to i64)
  %t4084 = inttoptr i64 %v139158 to ptr
  %t4085 = load i32, ptr %t4084, align 1
  %53 = lshr i32 %t4085, 16
  %v86794 = zext nneg i32 %53 to i64
  %54 = add nuw nsw i64 %v86794, %v86175
  %55 = mul nuw nsw i64 %54, %v86473
  %v86822 = add i64 %55, %v85892
  %t4095.not = icmp ult i64 %v86822, %v85892
  %v86948 = add nuw nsw i64 %v85890, 1
  br i1 %t4095.not, label %block39122, label %block5650

edge4041:                                         ; preds = %block5650
  %v86831 = or i64 %v83273, %v53385
  %t4099.not = icmp eq i64 %v86831, 0
  br i1 %t4099.not, label %block5762, label %edge4042

edge4042:                                         ; preds = %edge4041
  %v86833 = call i64 @mech_compact_release_two(i64 %v0, i64 %v53385, i64 %v83273)
  %t4100.not = icmp eq i64 %v86833, 0
  br i1 %t4100.not, label %block5762, label %edge4044

edge4044:                                         ; preds = %edge4042
  %t4101 = insertvalue { i64, i64 } poison, i64 %v86833, 0
  %t4102 = insertvalue { i64, i64 } %t4101, i64 5846, 1
  br label %common.ret

edge4051:                                         ; preds = %block5762
  %t4105.not = icmp eq i64 %v87196, -1
  br i1 %t4105.not, label %block39122, label %block5774

edge4063:                                         ; preds = %block5774
  %t4112.not = icmp eq i64 %v43272, 0
  br i1 %t4112.not, label %block5786, label %edge4065

edge4065:                                         ; preds = %edge4063
  %v87297 = call i64 @mech_compact_release_owner(i64 %v0, i64 %v43272)
  %t4113.not = icmp eq i64 %v87297, 0
  br i1 %t4113.not, label %block5786, label %edge4067

edge4067:                                         ; preds = %edge4065
  %t4114 = insertvalue { i64, i64 } poison, i64 %v87297, 0
  %t4115 = insertvalue { i64, i64 } %t4114, i64 5879, 1
  br label %common.ret

edge4069:                                         ; preds = %block5786
  %t4117 = inttoptr i64 %v44640 to ptr
  %v87644 = load i64, ptr %t4117, align 1
  %v87645 = add i64 %v87644, 1
  store i64 %v87645, ptr %t4117, align 1
  br label %block5790

edge4075:                                         ; preds = %block5790
  %t4141.not = icmp eq i64 %v83273, 0
  br i1 %t4141.not, label %block5796, label %edge4111

edge4111:                                         ; preds = %edge4075
  %t4142 = inttoptr i64 %v83273 to ptr
  %v87731 = load i64, ptr %t4142, align 1
  %v87732 = add i64 %v87731, 1
  store i64 %v87732, ptr %t4142, align 1
  br label %block5796

edge4114:                                         ; preds = %block5796
  %t4145 = inttoptr i64 %v44640 to ptr
  %v88532 = load i64, ptr %t4145, align 1
  %v88533 = add i64 %v88532, 1
  store i64 %v88533, ptr %t4145, align 1
  br label %block5798.preheader

edge4118:                                         ; preds = %block5798
  %t4148 = inttoptr i64 %v88550 to ptr
  %v88551 = load i64, ptr %t4148, align 1
  %t4149 = icmp eq i64 %v88551, 1
  br i1 %t4149, label %edge4122, label %block5807.thread

edge4122:                                         ; preds = %edge4118
  %t4151 = zext nneg i64 %v88571 to i128
  %t4152 = zext i64 %v88572 to i128
  %t4153 = shl nuw i128 %t4152, 64
  %v139066 = or disjoint i128 %t4153, %t4151
  store i128 %v139066, ptr %ss3, align 16
  store i128 18446744073709552163, ptr %t403, align 16
  %t4161 = zext i64 %v83268 to i128
  %t4162 = shl nuw i128 %t4161, 64
  %v139070 = or disjoint i128 %t4162, 547
  store i128 %v139070, ptr %t408, align 16
  %t4165 = zext i64 %v83269 to i128
  %v139072 = or disjoint i128 %t4165, 18446744073709551616
  store i128 %v139072, ptr %t413, align 16
  %v139074 = or disjoint i128 %t4172, %t4165
  store i128 %v139074, ptr %t418, align 16
  store i128 18446744073709552163, ptr %t423, align 16
  %t4181 = zext i64 %v88550 to i128
  %t4182 = shl nuw i128 %t4181, 64
  %v139078 = or disjoint i128 %t4182, 547
  store i128 %v139078, ptr %t424, align 16
  store i64 547, ptr %t583, align 16
  %t4186 = call { i64, i64 } @mech_compact_numeric_5895(i64 %v0, i64 %v138697, i64 %v6374)
  %v88556 = extractvalue { i64, i64 } %t4186, 0
  %t4187.not = icmp eq i64 %v88556, 0
  br i1 %t4187.not, label %edge4124, label %edge4123

edge4123:                                         ; preds = %edge4122
  %v88557 = extractvalue { i64, i64 } %t4186, 1
  %t4188 = icmp eq i64 %v88556, 103169
  %v88560 = select i1 %t4188, i64 103425, i64 %v88556
  %t4190 = insertvalue { i64, i64 } poison, i64 %v88560, 0
  %t4191 = insertvalue { i64, i64 } %t4190, i64 %v88557, 1
  br label %common.ret

edge4124:                                         ; preds = %edge4122
  br i1 %t4141.not, label %edge4206, label %edge4125

edge4125:                                         ; preds = %edge4124
  %v88565 = call i64 @mech_compact_release_nullable(i64 %v0, i64 %v83273)
  %t4193.not = icmp eq i64 %v88565, 0
  br i1 %t4193.not, label %edge4206, label %edge4127

edge4127:                                         ; preds = %edge4125
  %t4194 = insertvalue { i64, i64 } poison, i64 %v88565, 0
  %t4195 = insertvalue { i64, i64 } %t4194, i64 5895, 1
  br label %common.ret

edge4132:                                         ; preds = %block5807.thread, %block5807
  %v88810 = shl nuw nsw i64 %v88571, 1
  %v88811 = add i64 %v88810, ptrtoint (ptr @mech_compact_table_11 to i64)
  %t4199 = inttoptr i64 %v88811 to ptr
  %t4200 = load i16, ptr %t4199, align 1
  %v88812 = zext i16 %t4200 to i64
  %v88945 = and i64 %v88812, 511
  %v88997 = lshr i64 %v88812, 9
  %t4204 = icmp ult i64 %v88945, %v83269
  %v89267 = shl nuw nsw i64 %v88945, 2
  %v89268 = add i64 %v89267, %v83268
  %v139159 = select i1 %t4204, i64 %v89268, i64 ptrtoint (ptr @mech_compact_llvm_anonymous_data_1 to i64)
  %t4207 = inttoptr i64 %v139159 to ptr
  %t4208 = load i32, ptr %t4207, align 1
  %56 = lshr i32 %t4208, 16
  %v89295 = zext nneg i32 %56 to i64
  %t4213.not = icmp eq i32 %56, 0
  %t4210 = icmp samesign ult i64 %v88945, 288
  %spec.select10 = select i1 %t4210, i64 13, i64 10
  %v89869 = select i1 %t4213.not, i64 %spec.select10, i64 %v89295
  %v89870 = add nuw nsw i64 %v89869, %v88997
  %v89880 = shl nuw nsw i64 %v89870, 4
  %v89908 = shl nuw nsw i64 %v88571, 2
  %v89909 = add i64 %v88572, %v89908
  %t4228 = inttoptr i64 %v89909 to ptr
  %t4229 = load i32, ptr %t4228, align 1
  %v89910 = zext i32 %t4229 to i64
  %t4230 = icmp eq i64 %v89880, %v89910
  br i1 %t4230, label %block30569, label %edge4174

edge4174:                                         ; preds = %edge4132
  br i1 %t4147.not, label %block30571, label %edge4175

edge4175:                                         ; preds = %edge4174
  %t4233 = inttoptr i64 %v88550 to ptr
  %v89926 = load i64, ptr %t4233, align 1
  %t4234 = icmp eq i64 %v89926, 1
  br i1 %t4234, label %block30570, label %block30571

edge4183:                                         ; preds = %block30569
  %t4243 = inttoptr i64 %v89919 to ptr
  %v89937 = load i64, ptr %t4243, align 1
  %v89938 = add i64 %v89937, 1
  store i64 %v89938, ptr %t4243, align 1
  br label %edge4192

edge4188:                                         ; preds = %block5807.thread
  %v89954 = add i64 %v88551, 1
  store i64 %v89954, ptr %t4148, align 1
  br label %edge4193

edge4192:                                         ; preds = %block30569, %edge4183
  %t4255.not = or i1 %t4147.not, %t4240
  br i1 %t4255.not, label %block5886, label %edge4198

edge4193:                                         ; preds = %block5807, %edge4188
  %v89961 = or i64 %v88550, %v83273
  %t4253.not = icmp eq i64 %v89961, 0
  br i1 %t4253.not, label %edge4206, label %edge4194

edge4194:                                         ; preds = %edge4193
  %v89962 = call i64 @mech_compact_release_two(i64 %v0, i64 %v83273, i64 %v88550)
  %t4254.not = icmp eq i64 %v89962, 0
  br i1 %t4254.not, label %edge4206, label %block30586

edge4198:                                         ; preds = %edge4192
  %v89966 = call i64 @mech_compact_release_owner(i64 %v0, i64 %v88550)
  %t4256.not = icmp eq i64 %v89966, 0
  br i1 %t4256.not, label %block5886, label %block30586

edge4206:                                         ; preds = %edge4125, %edge4124, %edge4194, %edge4193
  br i1 %t4108.not470, label %block5907, label %edge4209

edge4209:                                         ; preds = %edge4206
  %t4261.not = icmp eq i64 %v43281, 0
  br i1 %t4261.not, label %block39122, label %edge4211

edge4211:                                         ; preds = %edge4209
  %v90220 = add i64 %v43281, -1
  br label %block5907

edge4221:                                         ; preds = %block5907
  %t4271.not = icmp eq i64 %v88550, 0
  br i1 %t4271.not, label %block5917.preheader, label %edge4227

edge4222:                                         ; preds = %block5907
  br i1 %t4144.not, label %block5990, label %edge4223

edge4223:                                         ; preds = %edge4222
  %v90415 = call i64 @mech_compact_release_owner(i64 %v0, i64 %v44640)
  %t4268.not = icmp eq i64 %v90415, 0
  br i1 %t4268.not, label %block5990, label %edge4225

edge4225:                                         ; preds = %edge4223
  %t4269 = insertvalue { i64, i64 } poison, i64 %v90415, 0
  %t4270 = insertvalue { i64, i64 } %t4269, i64 6010, 1
  br label %common.ret

edge4227:                                         ; preds = %edge4221
  %t4272 = inttoptr i64 %v88550 to ptr
  %v90488 = load i64, ptr %t4272, align 1
  %v90489 = add i64 %v90488, 1
  store i64 %v90489, ptr %t4272, align 1
  br label %block5917.preheader

block5917.preheader:                              ; preds = %edge4221, %edge4227
  br label %block5917

edge4234:                                         ; preds = %block5917
  %v90813 = shl nuw nsw i64 %v90537, 2
  %v90814 = add i64 %v90813, %v45333
  %t4281 = inttoptr i64 %v90814 to ptr
  %t4282 = load i32, ptr %t4281, align 1
  %v90981 = add i64 %v90813, %v88572
  %t4286 = inttoptr i64 %v90981 to ptr
  %t4287 = load i32, ptr %t4286, align 1
  %t4288 = icmp eq i32 %t4282, %t4287
  %v90808 = add nuw nsw i64 %v90537, 1
  br i1 %t4288, label %block5917, label %edge4250

edge4235:                                         ; preds = %block5917
  %v90551 = or i64 %v88550, %v44640
  %t4277.not = icmp eq i64 %v90551, 0
  br i1 %t4277.not, label %block5990, label %edge4236

edge4236:                                         ; preds = %edge4235
  %v90552 = call i64 @mech_compact_release_two(i64 %v0, i64 %v44640, i64 %v88550)
  %t4278.not = icmp eq i64 %v90552, 0
  br i1 %t4278.not, label %block5990, label %edge4238

edge4238:                                         ; preds = %edge4236
  %t4279 = insertvalue { i64, i64 } poison, i64 %v90552, 0
  %t4280 = insertvalue { i64, i64 } %t4279, i64 6027, 1
  br label %common.ret

edge4250:                                         ; preds = %edge4234
  %v91007 = or i64 %v88550, %v44640
  %t4291.not = icmp eq i64 %v91007, 0
  br i1 %t4291.not, label %block5990, label %edge4251

edge4251:                                         ; preds = %edge4250
  %v91008 = call i64 @mech_compact_release_two(i64 %v0, i64 %v44640, i64 %v88550)
  %t4292.not = icmp eq i64 %v91008, 0
  br i1 %t4292.not, label %block5990, label %edge4253

edge4253:                                         ; preds = %edge4251
  %t4293 = insertvalue { i64, i64 } poison, i64 %v91008, 0
  %t4294 = insertvalue { i64, i64 } %t4293, i64 6072, 1
  br label %common.ret

edge4284:                                         ; preds = %block5990
  %t4302.not = icmp eq i64 %spec.select9471, -1
  br i1 %t4302.not, label %block39122, label %block6026

edge4293:                                         ; preds = %block6026
  %t4307.not = icmp eq i64 %v87729, 0
  br i1 %t4307.not, label %block6035, label %block6035.sink.split

edge4294:                                         ; preds = %block6026.thread, %block6026
  %v91551483 = phi i64 [ %v91551478, %block6026.thread ], [ %v91551, %block6026 ]
  %t4310.not = icmp eq i64 %v91524, 0
  br i1 %t4310.not, label %block6035, label %block6035.sink.split

edge4312:                                         ; preds = %block6035
  %t4318.not = icmp eq i64 %v91778, 0
  br i1 %t4318.not, label %block6048, label %edge4318

edge4313:                                         ; preds = %block6035
  %t4316.not = icmp eq i64 %v43260, 0
  br i1 %t4316.not, label %block6652, label %edge4314

edge4314:                                         ; preds = %edge4313
  %v91772 = call i64 @mech_compact_release_owner(i64 %v0, i64 %v43260)
  %t4317.not = icmp eq i64 %v91772, 0
  br i1 %t4317.not, label %block6652, label %block31232

edge4318:                                         ; preds = %edge4312
  %v91776 = call i64 @mech_compact_release_owner(i64 %v0, i64 %v91778)
  %t4319.not = icmp eq i64 %v91776, 0
  br i1 %t4319.not, label %block6048, label %block31232

edge4356:                                         ; preds = %block6048
  %t4343 = inttoptr i64 %v53385 to ptr
  %v91844 = load i64, ptr %t4343, align 1
  %v91845 = add i64 %v91844, 1
  store i64 %v91845, ptr %t4343, align 1
  br label %block6078.preheader

edge4365:                                         ; preds = %edge4377
  br i1 %t4342.not, label %block6112, label %edge4378

edge4370:                                         ; preds = %block6078
  %v92373 = add nuw i64 %v138672, 1
  %t4354.not = icmp eq i64 %v138672, -1
  br i1 %t4354.not, label %block39122, label %edge4377

edge4377:                                         ; preds = %block6078, %edge4370
  %v92511 = phi i64 [ %v92373, %edge4370 ], [ %v138672, %block6078 ]
  %exitcond19718.not = icmp eq i64 %v92213, 256
  br i1 %exitcond19718.not, label %edge4365, label %block6078

edge4378:                                         ; preds = %edge4365
  %t4357 = inttoptr i64 %v53385 to ptr
  %v92389 = load i64, ptr %t4357, align 1
  %v92390 = add i64 %v92389, -1
  store i64 %v92390, ptr %t4357, align 1
  %t4359.not = icmp eq i64 %v92390, 0
  br i1 %t4359.not, label %edge4381, label %block6112

edge4381:                                         ; preds = %edge4378
  %v92391 = call i64 @mech_compact_free(i64 %v0, i64 %v53385)
  %t4360.not = icmp eq i64 %v92391, 0
  br i1 %t4360.not, label %block6112, label %edge4382

edge4382:                                         ; preds = %edge4381
  %t4361 = insertvalue { i64, i64 } poison, i64 %v92391, 0
  %t4362 = insertvalue { i64, i64 } %t4361, i64 6204, 1
  br label %common.ret

edge4405:                                         ; preds = %block6112
  %v93830 = add i64 %spec.select12, ptrtoint (ptr @mech_compact_table_6 to i64)
  %t4380 = inttoptr i64 %v93830 to ptr
  %t4381 = load i8, ptr %t4380, align 1
  %v93831 = zext i8 %t4381 to i64
  br label %block6219

edge4410:                                         ; preds = %block6219
  %v95411 = load i64, ptr %t4383, align 1
  %v95412 = add i64 %v95411, 1
  store i64 %v95412, ptr %t4383, align 1
  br label %block6221.preheader

edge4417:                                         ; preds = %block6221
  %v95761 = add nuw nsw i64 %v95445, 1
  %v95766 = shl nuw nsw i64 %v95445, 2
  %v95767 = add i64 %v95766, %v35980
  %t4388 = inttoptr i64 %v95767 to ptr
  %t4389 = load i32, ptr %t4388, align 1
  %v95768 = zext i32 %t4389 to i64
  %t4390 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v95447, i64 %v95768)
  %v95796 = extractvalue { i64, i1 } %t4390, 0
  %t4391 = extractvalue { i64, i1 } %t4390, 1
  br i1 %t4391, label %block39122, label %edge4426

edge4418:                                         ; preds = %block6221
  br i1 %t4382.not, label %block6295, label %edge4432

edge4426:                                         ; preds = %edge4417
  %t4394 = mul nuw nsw i64 %v95445, %v95768
  %t4398 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v95449, i64 %t4394)
  %t4399 = extractvalue { i64, i1 } %t4398, 1
  br i1 %t4399, label %block39122, label %edge4429

edge4429:                                         ; preds = %edge4426
  %v95970 = extractvalue { i64, i1 } %t4398, 0
  br label %block6221

edge4432:                                         ; preds = %edge4418
  %v95993 = load i64, ptr %t4383, align 1
  %v95994 = add i64 %v95993, -1
  store i64 %v95994, ptr %t4383, align 1
  %t4405.not = icmp eq i64 %v95994, 0
  br i1 %t4405.not, label %edge4435, label %block6295

edge4435:                                         ; preds = %edge4432
  %v95995 = call i64 @mech_compact_free(i64 %v0, i64 %v35985)
  %t4406.not = icmp eq i64 %v95995, 0
  br i1 %t4406.not, label %block6295, label %edge4436

edge4436:                                         ; preds = %edge4435
  %t4407 = insertvalue { i64, i64 } poison, i64 %v95995, 0
  %t4408 = insertvalue { i64, i64 } %t4407, i64 6386, 1
  br label %common.ret

edge4447:                                         ; preds = %block6295
  %57 = add i64 %v95447, 2305843009213693952
  %t4416 = icmp ult i64 %57, 4611686018427387904
  br i1 %t4416, label %block6323, label %block39122

edge4478:                                         ; preds = %.thread
  br i1 %t1982.not, label %block32770, label %edge4480

edge4480:                                         ; preds = %edge4478
  %v97456 = load i64, ptr %t4442, align 1
  %v97457 = add i64 %v97456, 1
  store i64 %v97457, ptr %t4442, align 1
  br label %block32770

edge4483:                                         ; preds = %block32770
  %v97458 = load i64, ptr %t4445, align 1
  %v97459 = add i64 %v97458, 1
  store i64 %v97459, ptr %t4445, align 1
  br label %block6392.preheader

edge4490:                                         ; preds = %block6392
  %v97777 = shl nuw nsw i64 %v97506, 2
  %v97778 = add i64 %v97777, %v137835
  %t4450 = inttoptr i64 %v97778 to ptr
  %t4451 = load i32, ptr %t4450, align 1
  %58 = zext i32 %t4451 to i64
  %umul140 = call { i64, i1 } @llvm.umul.with.overflow.i64(i64 %58, i64 %v36004)
  %59 = extractvalue { i64, i1 } %umul140, 1
  br i1 %59, label %block39122, label %edge4495

edge4495:                                         ; preds = %edge4490
  %v98074 = add i64 %v97777, %v35992
  %t4458 = inttoptr i64 %v98074 to ptr
  %t4459 = load i32, ptr %t4458, align 1
  %60 = zext i32 %t4459 to i64
  %umul141 = call { i64, i1 } @llvm.umul.with.overflow.i64(i64 %60, i64 %v137837)
  %61 = extractvalue { i64, i1 } %umul141, 1
  br i1 %61, label %block39122, label %edge4502

edge4502:                                         ; preds = %edge4495
  %v97799 = mul i64 %v36004, %58
  %v98094 = mul i64 %v137837, %60
  %t4466 = icmp ugt i64 %v98094, %v97799
  %v98236 = sub i64 %v98094, %v97799
  %v98249502 = sub i64 %v97799, %v98094
  %v98385498 = select i1 %t4466, i64 %v98236, i64 %v98249502
  %v98378 = add nuw nsw i64 %v97506, 1
  %v98386 = add i64 %v98385498, %v97508
  %t4478.not = icmp ult i64 %v98386, %v97508
  br i1 %t4478.not, label %block39122, label %block6392

edge4519:                                         ; preds = %block6392
  br i1 %t4474.not, label %block6474, label %edge4520

edge4520:                                         ; preds = %edge4519
  %v98263 = call i64 @mech_compact_release_two(i64 %v0, i64 %v35997, i64 %v137836)
  %t4475.not = icmp eq i64 %v98263, 0
  br i1 %t4475.not, label %block6474, label %edge4522

edge4522:                                         ; preds = %edge4520
  %t4476 = insertvalue { i64, i64 } poison, i64 %v98263, 0
  %t4477 = insertvalue { i64, i64 } %t4476, i64 6570, 1
  br label %common.ret

edge4533:                                         ; preds = %block6474
  %t4494 = icmp ugt i64 %v97508, %v98587
  br i1 %t4494, label %edge4566, label %edge4541

edge4541:                                         ; preds = %edge4533
  %v98723 = shl nuw nsw i64 %v97508, 2
  %t4497 = icmp samesign ugt i64 %v98723, %v98737
  br i1 %t4497, label %edge4566, label %edge4547

edge4547:                                         ; preds = %edge4541
  %v98881 = shl nuw nsw i64 %v97508, 1
  %t4500 = icmp samesign ugt i64 %v98881, %v98587
  br i1 %t4500, label %edge4566, label %edge4553

edge4553:                                         ; preds = %edge4547
  %t4503 = icmp samesign ugt i64 %v98881, %v98577143
  %v99153 = select i1 %t4503, i64 4, i64 2
  br label %edge4566

edge4566:                                         ; preds = %.thread, %edge4541, %edge4547, %edge4553, %edge4533
  %v99201 = phi i64 [ 8, %.thread ], [ 8, %edge4533 ], [ 6, %edge4541 ], [ %v99153, %edge4553 ], [ 5, %edge4547 ]
  %v100308 = sub nuw nsw i64 8, %v99201
  br label %block6524

edge4567:                                         ; preds = %block6524
  %t4507 = inttoptr i64 %v99218 to ptr
  %v99219 = load i64, ptr %t4507, align 1
  %t4508 = icmp eq i64 %v99219, 1
  br i1 %t4508, label %edge4571, label %block6535

edge4571:                                         ; preds = %edge4567
  %t4510 = zext i8 %t4432 to i128
  %t4511 = zext i8 %t4437 to i128
  %t4512 = shl nuw nsw i128 %t4511, 64
  %v139080 = or disjoint i128 %t4512, %t4510
  store i128 %v139080, ptr %ss3, align 16
  %t4514 = zext nneg i64 %v99201 to i128
  %t4515 = zext nneg i64 %v99241 to i128
  %t4516 = shl nuw nsw i128 %t4515, 64
  %v139082 = or disjoint i128 %t4516, %t4514
  store i128 %v139082, ptr %t403, align 16
  %t4519 = zext i64 %v99242 to i128
  %v139084 = or disjoint i128 %t4519, 10090369008319124733952
  store i128 %v139084, ptr %t408, align 16
  store i128 10090369008319124733953, ptr %t413, align 16
  store i128 %v139088, ptr %t418, align 16
  store i128 10090369008319124733953, ptr %t423, align 16
  %t4539 = zext i64 %v99218 to i128
  %v139092 = or disjoint i128 %t4539, 10090369008319124733952
  store i128 %v139092, ptr %t424, align 16
  %t4544 = call { i64, i64 } @mech_compact_numeric_6633(i64 %v0, i64 %v138697, i64 %v6374)
  %v99224 = extractvalue { i64, i64 } %t4544, 0
  %t4545.not = icmp eq i64 %v99224, 0
  br i1 %t4545.not, label %edge4663, label %edge4572

edge4572:                                         ; preds = %edge4571
  %v99225 = extractvalue { i64, i64 } %t4544, 1
  %t4546 = icmp eq i64 %v99224, 103169
  %v99228 = select i1 %t4546, i64 103425, i64 %v99224
  %t4548 = insertvalue { i64, i64 } poison, i64 %v99228, 0
  %t4549 = insertvalue { i64, i64 } %t4548, i64 %v99225, 1
  br label %common.ret

edge4577:                                         ; preds = %block6535
  %v99417 = shl nuw nsw i64 %v99241, 1
  %v99418 = add nuw i64 %v99417, ptrtoint (ptr @mech_compact_table_11 to i64)
  %t4553 = inttoptr i64 %v99418 to ptr
  %t4554 = load i16, ptr %t4553, align 1
  %62 = lshr i16 %t4554, 5
  %63 = and i16 %62, 2032
  %64 = zext nneg i16 %63 to i64
  br label %edge4584

edge4584:                                         ; preds = %block6535, %edge4577
  %v99439 = phi i64 [ %64, %edge4577 ], [ 0, %block6535 ]
  %t4556 = icmp samesign ult i64 %v99241, 259
  %t4559 = icmp samesign ult i64 %v99241, 515
  %v99983 = select i1 %t4559, i64 %v97130, i64 78
  %v100284 = select i1 %t4556, i64 %v97298, i64 %v99983
  %v100238 = add nuw nsw i64 %v99241, 1
  %v100243 = shl i64 %v99241, 2
  %v100244 = add i64 %v99242, %v100243
  %v139163 = select i1 %t4550, i64 %v100244, i64 ptrtoint (ptr @mech_compact_llvm_anonymous_data_1 to i64)
  %t4564 = inttoptr i64 %v139163 to ptr
  %t4565 = load i32, ptr %t4564, align 1
  %v100245 = zext i32 %t4565 to i64
  %v100285 = add nuw nsw i64 %v99439, %v100284
  %v100299 = mul nuw nsw i64 %v100285, %v99201
  %v100316 = mul nuw nsw i64 %v100308, %v100245
  %v100321 = add nuw nsw i64 %v100316, %v100299
  %v100330144 = lshr i64 %v100321, 3
  %exitcond19721.not = icmp eq i64 %v99241, 547
  br i1 %exitcond19721.not, label %edge4622, label %edge4624

edge4622:                                         ; preds = %edge4584
  br i1 %t4506.not, label %edge4663, label %edge4651

edge4624:                                         ; preds = %edge4584
  %t4596 = inttoptr i64 %v100244 to ptr
  %t4597 = load i32, ptr %t4596, align 1
  %v100478 = zext i32 %t4597 to i64
  %t4598 = icmp eq i64 %v100330144, %v100478
  br i1 %t4598, label %block33701, label %edge4627

edge4627:                                         ; preds = %edge4624
  %t4600.not = icmp eq i64 %v100513, 0
  br i1 %t4600.not, label %block33704, label %edge4628

edge4628:                                         ; preds = %edge4627
  %v100491 = call i64 @mech_compact_release_owner(i64 %v0, i64 %v100513)
  %t4601.not = icmp eq i64 %v100491, 0
  br i1 %t4601.not, label %block33704, label %block33698

edge4632:                                         ; preds = %block33704
  %t4603 = inttoptr i64 %v99218 to ptr
  %v100498 = load i64, ptr %t4603, align 1
  %t4604 = icmp eq i64 %v100498, 1
  br i1 %t4604, label %block33706, label %block33707

edge4640:                                         ; preds = %block33701
  %t4613 = inttoptr i64 %v100487 to ptr
  %v100509 = load i64, ptr %t4613, align 1
  %v100510 = add i64 %v100509, 1
  store i64 %v100510, ptr %t4613, align 1
  br label %edge4649

edge4649:                                         ; preds = %block33701, %edge4640
  %t4625.not = or i1 %t4506.not, %t4610
  br i1 %t4625.not, label %block6524.backedge, label %edge4655

edge4651:                                         ; preds = %edge4622
  %t4619 = inttoptr i64 %v99218 to ptr
  %v100530 = load i64, ptr %t4619, align 1
  %v100531 = add i64 %v100530, 1
  store i64 %v100531, ptr %t4619, align 1
  %v100538 = call i64 @mech_compact_release_nullable(i64 %v0, i64 %v99218)
  %t4624.not = icmp eq i64 %v100538, 0
  br i1 %t4624.not, label %edge4663, label %block33722

edge4655:                                         ; preds = %edge4649
  %v100542 = call i64 @mech_compact_release_owner(i64 %v0, i64 %v99218)
  %t4626.not = icmp eq i64 %v100542, 0
  br i1 %t4626.not, label %block6524.backedge, label %block33722

block6524.backedge:                               ; preds = %edge4655, %edge4649
  br label %block6524

edge4663:                                         ; preds = %edge4622, %edge4571, %edge4651
  br i1 %t2143, label %edge4666, label %block6652

edge4666:                                         ; preds = %edge4663
  %t4631.not = icmp eq i64 %v49361, 0
  br i1 %t4631.not, label %block6652, label %edge4671

edge4671:                                         ; preds = %edge4666
  %v101250 = shl i64 %v49361, 3
  %v101253 = add i64 %v49360, -8
  %v101254 = add i64 %v101253, %v101250
  %t4636 = inttoptr i64 %v101254 to ptr
  %v101255 = load i64, ptr %t4636, align 1
  %65 = lshr i64 %v101255, 4
  %66 = and i64 %65, 268435455
  %67 = add nuw nsw i64 %66, 7
  br label %block6652

edge4683:                                         ; preds = %block6652
  %t4641.not = icmp eq i64 %v91338, 0
  br i1 %t4641.not, label %edge4686, label %block6676

edge4686:                                         ; preds = %edge4683
  %t4643.not = icmp eq i64 %v91551482, 0
  %spec.select31 = select i1 %t4643.not, i64 0, i64 4
  br label %block6676

edge4703:                                         ; preds = %block6676
  %t4657.not = icmp eq i64 %v137736, 0
  br i1 %t4657.not, label %block2907.backedge, label %edge4721

edge4704:                                         ; preds = %block6676
  %v101908 = or i64 %v98262, %v35985
  %t4649.not = icmp eq i64 %v101908, 0
  br i1 %t4649.not, label %block34111, label %edge4705

edge4705:                                         ; preds = %edge4704
  %v101910 = call i64 @mech_compact_release_three(i64 %v0, i64 %v35985, i64 %v137836, i64 %v35997)
  %t4650.not = icmp eq i64 %v101910, 0
  br i1 %t4650.not, label %block34111, label %block34107

edge4709:                                         ; preds = %block34111
  %v101915 = call i64 @mech_compact_release_nullable(i64 %v0, i64 %v35973)
  %t4652.not = icmp eq i64 %v101915, 0
  br i1 %t4652.not, label %block34114, label %block34107

edge4713:                                         ; preds = %block34114
  %v101920 = call i64 @mech_compact_release_nullable(i64 %v0, i64 %v38132)
  %t4654.not = icmp eq i64 %v101920, 0
  br i1 %t4654.not, label %block34117, label %block34107

edge4717:                                         ; preds = %block34117
  %v101925 = call i64 @mech_compact_release_two(i64 %v0, i64 %v83284, i64 %v137737)
  %t4656.not = icmp eq i64 %v101925, 0
  br i1 %t4656.not, label %edge4727, label %block34107

edge4721:                                         ; preds = %edge4703
  %t4658 = inttoptr i64 %v137736 to ptr
  %v101927 = load i64, ptr %t4658, align 1
  %v101928 = add i64 %v101927, -1
  store i64 %v101928, ptr %t4658, align 1
  %t4660.not = icmp eq i64 %v101928, 0
  br i1 %t4660.not, label %edge4724, label %block2907.backedge

edge4724:                                         ; preds = %edge4721
  %v101929 = call i64 @mech_compact_free(i64 %v0, i64 %v137736)
  %t4661.not = icmp eq i64 %v101929, 0
  br i1 %t4661.not, label %block2907.backedge, label %block34107

block2907.backedge:                               ; preds = %edge4724, %edge4721, %edge4703
  br label %block2907

edge4727:                                         ; preds = %block34117, %edge4717
  %t4678.not = icmp eq i64 %v49365, 0
  br i1 %t4678.not, label %block6737, label %edge4754

edge4754:                                         ; preds = %edge4727
  %t4679 = inttoptr i64 %v49365 to ptr
  %v104232 = load i64, ptr %t4679, align 1
  %v104233 = add i64 %v104232, 1
  store i64 %v104233, ptr %t4679, align 1
  br label %block6737

edge4757:                                         ; preds = %block6737
  %v105121 = call i64 @mech_compact_unsigned_dot_product(i64 %v53387, i64 ptrtoint (ptr @mech_compact_table_22 to i64), i64 0, i64 320)
  %v105122 = add i64 %v105121, 10
  %t4683.not = icmp eq i64 %v53385, 0
  br i1 %t4683.not, label %edge4765, label %edge4760

edge4760:                                         ; preds = %edge4757
  %v105125 = call i64 @mech_compact_release_nullable(i64 %v0, i64 %v53385)
  %t4684.not = icmp eq i64 %v105125, 0
  br i1 %t4684.not, label %edge4765, label %edge4762

edge4762:                                         ; preds = %edge4760
  %t4685 = insertvalue { i64, i64 } poison, i64 %v105125, 0
  %t4686 = insertvalue { i64, i64 } %t4685, i64 6851, 1
  br label %common.ret

edge4765:                                         ; preds = %edge4757, %edge4760
  %t4687.not = icmp ugt i64 %v36030, -65535
  br i1 %t4687.not, label %block39122, label %edge4766

edge4766:                                         ; preds = %edge4765
  %v105909 = add nuw i64 %v36030, 65534
  %t4693.not = icmp eq i64 %v36030, 0
  br i1 %t4693.not, label %block39122, label %edge4777

edge4777:                                         ; preds = %edge4766
  %t4701 = icmp ult i64 %v36030, 2305843009213693952
  br i1 %t4701, label %edge4785, label %block39122

edge4785:                                         ; preds = %edge4777
  %v105930 = sub nsw i64 5, %v137797
  %v105934 = and i64 %v105930, 7
  %v105918 = udiv i64 %v105909, 65535
  %68 = mul nuw nsw i64 %v105918, 40
  %v106128 = add nsw i64 %v105934, -5
  %v106133 = add nsw i64 %v106128, %68
  %v106143 = shl nuw i64 %v36030, 3
  %v106148 = add i64 %v106133, %v106143
  %t4703.not = icmp ult i64 %v106148, %v106133
  br i1 %t4703.not, label %block39122, label %edge4789

edge4789:                                         ; preds = %edge4785
  %v106245 = call i64 @llvm.umin.i64(i64 %v104246, i64 %v105122)
  %t4711.not.not = icmp ugt i64 %v106148, %v106245
  br i1 %t4711.not.not, label %edge4818, label %edge4817

edge4817:                                         ; preds = %edge4789
  %v106535 = or i64 %v83296, %v83290
  %v106536 = or i64 %v106535, %v49365
  %v106537 = or i64 %v106536, %v83273
  %t4722.not = icmp eq i64 %v106537, 0
  br i1 %t4722.not, label %block6876, label %edge4819

edge4818:                                         ; preds = %edge4789
  %t4714.not.not = icmp ugt i64 %v105122, %v104246
  br i1 %t4714.not.not, label %edge4995, label %edge4927

edge4819:                                         ; preds = %edge4817
  %v106538 = call i64 @mech_compact_release_four(i64 %v0, i64 %v83273, i64 %v49365, i64 %v83290, i64 %v83296)
  %t4723.not = icmp eq i64 %v106538, 0
  br i1 %t4723.not, label %block6876, label %edge4821

edge4821:                                         ; preds = %edge4819
  %t4724 = insertvalue { i64, i64 } poison, i64 %v106538, 0
  %t4725 = insertvalue { i64, i64 } %t4724, i64 6986, 1
  br label %common.ret

edge4823:                                         ; preds = %block6876
  %v106615 = load i64, ptr %t386, align 1
  %v106616 = add i64 %v106615, 1
  store i64 %v106616, ptr %t386, align 1
  br label %block6878.preheader

edge4829:                                         ; preds = %block6878
  %v106678 = sub nuw i64 %v36007, %v106668
  %v107195 = call i64 @llvm.umin.i64(i64 %v106678, i64 65535)
  %t4734 = icmp ult i64 %v106678, 65536
  %v106857 = select i1 %t4734, i64 %v36010, i64 65536
  %v106859 = shl i64 %v106857, %v106654
  %v106863 = or i64 %v106859, %v106652
  %t4738 = icmp eq i64 %v106643, 1
  br i1 %t4738, label %edge4847, label %block34947

edge4847:                                         ; preds = %edge4829
  %t4740 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %v106641, i64 1)
  %v106880 = extractvalue { i64, i1 } %t4740, 0
  %t4741 = extractvalue { i64, i1 } %t4740, 1
  br i1 %t4741, label %block34947, label %edge4849

edge4849:                                         ; preds = %edge4847
  %t4744 = icmp ule i64 %v106880, %v106642
  %t4746 = icmp ne i64 %v106645, 0
  %or.cond32 = select i1 %t4744, i1 %t4746, i1 false
  br i1 %or.cond32, label %edge4853, label %block34962

edge4853:                                         ; preds = %edge4849
  %t4747 = inttoptr i64 %v106645 to ptr
  %v106916 = load i64, ptr %t4747, align 1
  %t4748 = icmp eq i64 %v106916, 1
  br i1 %t4748, label %block34961, label %block34962

edge4860:                                         ; preds = %block34961
  %t4757 = inttoptr i64 %v106915 to ptr
  %v106927 = load i64, ptr %t4757, align 1
  %v106928 = add i64 %v106927, 1
  store i64 %v106928, ptr %t4757, align 1
  br label %block34966

edge4863:                                         ; preds = %block34966
  %v106933 = call i64 @mech_compact_release_owner(i64 %v0, i64 %v106645)
  %t4761.not = icmp eq i64 %v106933, 0
  br i1 %t4761.not, label %block6915, label %block34947

edge4868:                                         ; preds = %block6915
  %t4767 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %v106880, i64 1)
  %v107018 = extractvalue { i64, i1 } %t4767, 0
  %t4768 = extractvalue { i64, i1 } %t4767, 1
  br i1 %t4768, label %block34998, label %edge4870

edge4870:                                         ; preds = %edge4868
  %t4771 = icmp ule i64 %v107018, %v106912
  %t4773 = icmp ne i64 %v106915, 0
  %or.cond33 = and i1 %t4771, %t4773
  br i1 %or.cond33, label %edge4874, label %block35013

edge4874:                                         ; preds = %edge4870
  %t4774 = inttoptr i64 %v106915 to ptr
  %v107054 = load i64, ptr %t4774, align 1
  %t4775 = icmp eq i64 %v107054, 1
  br i1 %t4775, label %block35012, label %block35013

edge4881:                                         ; preds = %block35012
  %t4784 = inttoptr i64 %v107053 to ptr
  %v107065 = load i64, ptr %t4784, align 1
  %v107066 = add i64 %v107065, 1
  store i64 %v107066, ptr %t4784, align 1
  br label %block35017

edge4884:                                         ; preds = %block35017
  %v107071 = call i64 @mech_compact_release_owner(i64 %v0, i64 %v106915)
  %t4788.not = icmp eq i64 %v107071, 0
  br i1 %t4788.not, label %edge4890, label %block34998

edge4890:                                         ; preds = %block6915, %block35017, %edge4884
  %v107092 = phi i64 [ %v107053, %block35017 ], [ %v107053, %edge4884 ], [ %v106915, %block6915 ]
  %v107095 = phi i64 [ %v107048, %block35017 ], [ %v107048, %edge4884 ], [ %v106910, %block6915 ]
  %v107096 = phi i64 [ %v107018, %block35017 ], [ %v107018, %edge4884 ], [ %v106880, %block6915 ]
  %v107097 = phi i64 [ %v107050, %block35017 ], [ %v107050, %edge4884 ], [ %v106912, %block6915 ]
  %t4791 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %v107096, i64 2)
  %v107104 = extractvalue { i64, i1 } %t4791, 0
  %t4792 = extractvalue { i64, i1 } %t4791, 1
  br i1 %t4792, label %block35034, label %edge4891

edge4891:                                         ; preds = %edge4890
  %t4795 = icmp ule i64 %v107104, %v107097
  %t4797 = icmp ne i64 %v107092, 0
  %or.cond34 = and i1 %t4797, %t4795
  br i1 %or.cond34, label %edge4895, label %block35050

edge4895:                                         ; preds = %edge4891
  %t4798 = inttoptr i64 %v107092 to ptr
  %v107140 = load i64, ptr %t4798, align 1
  %t4799 = icmp eq i64 %v107140, 1
  br i1 %t4799, label %edge4902, label %block35050

edge4902:                                         ; preds = %block35050, %edge4895
  %v107134 = phi i64 [ %v107095, %edge4895 ], [ %v137585, %block35050 ]
  %v107136 = phi i64 [ %v107097, %edge4895 ], [ %v137587, %block35050 ]
  %v107139 = phi i64 [ %v107092, %edge4895 ], [ %v137586, %block35050 ]
  %v107147 = trunc i64 %v107195 to i8
  %v107149 = add i64 %v107134, %v107096
  %t4804 = inttoptr i64 %v107149 to ptr
  store i8 %v107147, ptr %t4804, align 1
  %v107151 = lshr i64 %v107195, 8
  %v107152 = trunc nuw i64 %v107151 to i8
  %v107153 = add nuw i64 %v107096, 1
  %v107154 = add i64 %v107153, %v107134
  %t4805 = inttoptr i64 %v107154 to ptr
  store i8 %v107152, ptr %t4805, align 1
  %t4806 = icmp eq i64 %v107092, %v107139
  %t4808.not158 = icmp eq i64 %v107139, 0
  %t4808.not = or i1 %t4806, %t4808.not158
  br i1 %t4808.not, label %block35070, label %edge4905

edge4905:                                         ; preds = %edge4902
  %t4809 = inttoptr i64 %v107139 to ptr
  %v107187 = load i64, ptr %t4809, align 1
  %v107188 = add i64 %v107187, 1
  store i64 %v107188, ptr %t4809, align 1
  br label %block35070

edge4908:                                         ; preds = %block35070
  %v107193 = call i64 @mech_compact_release_owner(i64 %v0, i64 %v107092)
  %t4813.not = icmp eq i64 %v107193, 0
  br i1 %t4813.not, label %block6926, label %block35034

edge4913:                                         ; preds = %block6926
  %v138376 = extractvalue { i64, i64, i64, i64, i64, i64, i64, i64 } %t4816, 1
  %v138384 = add i64 %v138377, 7042
  %t4819 = insertvalue { i64, i64 } poison, i64 %v138376, 0
  %t4820 = insertvalue { i64, i64 } %t4819, i64 %v138384, 1
  br label %common.ret

edge4914:                                         ; preds = %block6926
  %v138382 = extractvalue { i64, i64, i64, i64, i64, i64, i64, i64 } %t4816, 7
  %v138381 = extractvalue { i64, i64, i64, i64, i64, i64, i64, i64 } %t4816, 6
  %v138380 = extractvalue { i64, i64, i64, i64, i64, i64, i64, i64 } %t4816, 5
  %v138379 = extractvalue { i64, i64, i64, i64, i64, i64, i64, i64 } %t4816, 4
  %v138378 = extractvalue { i64, i64, i64, i64, i64, i64, i64, i64 } %t4816, 3
  %t4821 = icmp eq i64 %v138378, %v36007
  br i1 %t4821, label %edge4916, label %block6878

edge4916:                                         ; preds = %edge4914
  br i1 %t23.not, label %edge5503, label %edge4918

edge4918:                                         ; preds = %edge4916
  %v107549 = load i64, ptr %t386, align 1
  %v107550 = add i64 %v107549, -1
  store i64 %v107550, ptr %t386, align 1
  %t4827.not = icmp eq i64 %v107550, 0
  br i1 %t4827.not, label %edge4921, label %edge5503

edge4921:                                         ; preds = %edge4918
  %v107551 = call i64 @mech_compact_free(i64 %v0, i64 %v1399)
  %t4828.not = icmp eq i64 %v107551, 0
  br i1 %t4828.not, label %edge5503, label %edge4922

edge4922:                                         ; preds = %edge4921
  %t4829 = insertvalue { i64, i64 } poison, i64 %v107551, 0
  %t4830 = insertvalue { i64, i64 } %t4829, i64 7046, 1
  br label %common.ret

edge4927:                                         ; preds = %edge4818
  %v107681 = or i64 %v83296, %v83290
  %t4834.not = icmp eq i64 %v107681, 0
  br i1 %t4834.not, label %edge4936, label %edge4929

edge4929:                                         ; preds = %edge4927
  %v107682 = call i64 @mech_compact_release_two(i64 %v0, i64 %v83290, i64 %v83296)
  %t4835.not = icmp eq i64 %v107682, 0
  br i1 %t4835.not, label %edge4936, label %edge4931

edge4931:                                         ; preds = %edge4929
  %t4836 = insertvalue { i64, i64 } poison, i64 %v107682, 0
  %t4837 = insertvalue { i64, i64 } %t4836, i64 7063, 1
  br label %common.ret

edge4936:                                         ; preds = %edge4927, %edge4929
  %69 = or i64 %v36010, 2
  %70 = shl i64 %69, %v137797
  %v107790 = or i64 %70, %v137796
  %v107794 = add nuw nsw i64 %v137797, 3
  %v107802 = lshr i64 %v107794, 3
  %t4845 = icmp eq i64 %v137794, 1
  br i1 %t4845, label %edge4949, label %block35264

edge4949:                                         ; preds = %edge4936
  %t4849 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %v137792, i64 %v107802)
  %v107820 = extractvalue { i64, i1 } %t4849, 0
  %t4850 = extractvalue { i64, i1 } %t4849, 1
  br i1 %t4850, label %block35264, label %edge4951

edge4951:                                         ; preds = %edge4949
  %t4853 = icmp ule i64 %v107820, %v137793
  %t4855 = icmp ne i64 %v137795, 0
  %or.cond35 = select i1 %t4853, i1 %t4855, i1 false
  br i1 %or.cond35, label %edge4955, label %block35280

edge4955:                                         ; preds = %edge4951
  %t4856 = inttoptr i64 %v137795 to ptr
  %v107856 = load i64, ptr %t4856, align 1
  %t4857 = icmp eq i64 %v107856, 1
  br i1 %t4857, label %block35279, label %block35280

edge4962:                                         ; preds = %block35279
  %v107863 = trunc i64 %v107790 to i8
  %v107865 = add i64 %v107850, %v137792
  %t4864 = inttoptr i64 %v107865 to ptr
  store i8 %v107863, ptr %t4864, align 1
  br label %block35298

edge4980:                                         ; preds = %block35298
  %t4883 = inttoptr i64 %v107855 to ptr
  %v107903 = load i64, ptr %t4883, align 1
  %v107904 = add i64 %v107903, 1
  store i64 %v107904, ptr %t4883, align 1
  br label %block35300

edge4983:                                         ; preds = %block35300
  %v107909 = call i64 @mech_compact_release_owner(i64 %v0, i64 %v137795)
  %t4887.not = icmp eq i64 %v107909, 0
  br i1 %t4887.not, label %block7285.thread, label %block35264

edge4995:                                         ; preds = %edge4818
  %t4898 = icmp ugt i64 %v83298, 256
  br i1 %t4898, label %edge5004, label %block39122

edge5004:                                         ; preds = %edge4995
  %t4903.not = icmp eq i64 %v83299, 0
  br i1 %t4903.not, label %block39122, label %edge5014

edge5014:                                         ; preds = %edge5004
  %t4908 = icmp ugt i64 %v83300, 3
  br i1 %t4908, label %edge5031, label %block39122

edge5031:                                         ; preds = %edge5014
  %v108038 = add nuw nsw i64 %v137797, 13
  %71 = or i64 %v36010, 4
  %72 = shl i64 %71, %v137797
  %v107992 = add i64 %v83298, -257
  %v107982 = add nuw nsw i64 %v137797, 3
  %v108002 = shl i64 %v107992, %v107982
  %v108020 = add i64 %v83299, -1
  %v108010 = add nuw nsw i64 %v137797, 8
  %v108030 = shl i64 %v108020, %v108010
  %v108066 = add nuw nsw i64 %v137797, 17
  %v108048 = add i64 %v83300, -4
  %v108058 = shl i64 %v108048, %v108038
  %v108627 = add i64 %v83285, 64
  %t4918 = inttoptr i64 %v108627 to ptr
  %t4919 = load i32, ptr %t4918, align 1
  %73 = lshr i32 %t4919, 16
  %v108650 = zext nneg i32 %73 to i64
  %v108659 = shl nuw nsw i64 %v108650, %v108066
  %74 = or i64 %72, %v108002
  %75 = or i64 %74, %v108030
  %76 = or i64 %75, %v108058
  %77 = or i64 %76, %v108659
  %v108663 = or i64 %77, %v137796
  %v108667 = add nuw nsw i64 %v137797, 20
  %t4925 = icmp eq i64 %v137794, 1
  br i1 %t4925, label %edge5049, label %block35488

edge5049:                                         ; preds = %edge5031
  %v108675 = lshr i64 %v108667, 3
  %t4929 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %v137792, i64 %v108675)
  %v108693 = extractvalue { i64, i1 } %t4929, 0
  %t4930 = extractvalue { i64, i1 } %t4929, 1
  br i1 %t4930, label %block35488, label %edge5051

edge5051:                                         ; preds = %edge5049
  %t4933 = icmp ule i64 %v108693, %v137793
  %t4935 = icmp ne i64 %v137795, 0
  %or.cond36 = select i1 %t4933, i1 %t4935, i1 false
  br i1 %or.cond36, label %edge5055, label %block35504

edge5055:                                         ; preds = %edge5051
  %t4936 = inttoptr i64 %v137795 to ptr
  %v108729 = load i64, ptr %t4936, align 1
  %t4937 = icmp eq i64 %v108729, 1
  br i1 %t4937, label %edge5062, label %block35504

edge5062:                                         ; preds = %edge5055, %block35504
  %v108723 = phi i64 [ %v137791, %edge5055 ], [ %v137597, %block35504 ]
  %v108725 = phi i64 [ %v137793, %edge5055 ], [ %v137599, %block35504 ]
  %v108728 = phi i64 [ %v137795, %edge5055 ], [ %v137598, %block35504 ]
  %v108736 = trunc i64 %v108663 to i8
  %v108738 = add i64 %v108723, %v137792
  %t4944 = inttoptr i64 %v108738 to ptr
  store i8 %v108736, ptr %t4944, align 1
  %v108740 = lshr i64 %v108663, 8
  %v108741 = trunc i64 %v108740 to i8
  %v108742 = add i64 %v137792, 1
  %v108743 = add i64 %v108742, %v108723
  %t4947 = inttoptr i64 %v108743 to ptr
  store i8 %v108741, ptr %t4947, align 1
  %t4948 = icmp ugt i64 %v137797, 3
  br i1 %t4948, label %edge5068, label %block35522

edge5068:                                         ; preds = %edge5062
  %v108745 = lshr i64 %v108663, 16
  %v108746 = trunc i64 %v108745 to i8
  %v108747 = add i64 %v137792, 2
  %v108748 = add i64 %v108747, %v108723
  %t4950 = inttoptr i64 %v108748 to ptr
  store i8 %v108746, ptr %t4950, align 1
  br label %block35522

edge5086:                                         ; preds = %block35522
  %t4969 = inttoptr i64 %v108728 to ptr
  %v108776 = load i64, ptr %t4969, align 1
  %v108777 = add i64 %v108776, 1
  store i64 %v108777, ptr %t4969, align 1
  br label %block35524

edge5089:                                         ; preds = %block35524
  %v108782 = call i64 @mech_compact_release_owner(i64 %v0, i64 %v137795)
  %t4973.not = icmp eq i64 %v108782, 0
  br i1 %t4973.not, label %block7048, label %block35488

edge5097:                                         ; preds = %block7048
  %t4979 = inttoptr i64 %v83290 to ptr
  %v108809 = load i64, ptr %t4979, align 1
  %v108810 = add i64 %v108809, 1
  store i64 %v108810, ptr %t4979, align 1
  br label %edge5100

edge5100:                                         ; preds = %block7048, %edge5097
  %78 = sub nuw nsw i64 -4, %v108801
  %79 = udiv i64 %78, 3
  %80 = add nuw nsw i64 %79, 2
  br label %block7059

edge5104:                                         ; preds = %block7059
  %t4984 = icmp samesign ult i64 %v108866, 19
  %v109076 = add i64 %v108866, ptrtoint (ptr @mech_compact_table_15 to i64)
  %v139165 = select i1 %t4984, i64 %v109076, i64 ptrtoint (ptr @mech_compact_llvm_anonymous_data_1 to i64)
  %t4987 = inttoptr i64 %v139165 to ptr
  %t4988 = load i8, ptr %t4987, align 1
  %v109077 = zext i8 %t4988 to i64
  %t4991 = icmp ugt i64 %v83286, %v109077
  %v109301 = shl nuw nsw i64 %v109077, 2
  %v109302 = add i64 %v109301, %v83285
  %v139166 = select i1 %t4991, i64 %v109302, i64 ptrtoint (ptr @mech_compact_llvm_anonymous_data_1 to i64)
  %t4994 = inttoptr i64 %v139166 to ptr
  %t4995 = load i32, ptr %t4994, align 1
  %81 = lshr i32 %t4995, 16
  %v109327 = zext nneg i32 %81 to i64
  %v109345 = and i64 %v108870, 63
  %v109346 = shl i64 %v109327, %v109345
  %v109350 = or i64 %v109346, %v108868
  %v109436 = add nuw nsw i64 %v108866, 1
  %v109444 = add nuw i64 %v108870, 3
  %exitcond19750 = icmp eq i64 %v108866, %80
  br i1 %exitcond19750, label %block39122, label %block7059

edge5124:                                         ; preds = %block7059
  br i1 %t4978.not, label %block7148, label %edge5125

edge5125:                                         ; preds = %edge5124
  %v109357 = call i64 @mech_compact_release_nullable(i64 %v0, i64 %v83290)
  %t5001.not = icmp eq i64 %v109357, 0
  br i1 %t5001.not, label %block7148, label %edge5127

edge5127:                                         ; preds = %edge5125
  %t5002 = insertvalue { i64, i64 } poison, i64 %v109357, 0
  %t5003 = insertvalue { i64, i64 } %t5002, i64 7251, 1
  br label %common.ret

edge5136:                                         ; preds = %block7148
  %v138469 = add i64 %v109484, %v108693
  %t5009 = icmp uge i64 %v138469, %v108693
  %t5010 = icmp ule i64 %v138469, %v108725
  %v138472148 = and i1 %t5009, %t5010
  %t5012 = icmp ne i64 %v108728, 0
  %or.cond37 = select i1 %v138472148, i1 %t5012, i1 false
  br i1 %or.cond37, label %edge5140, label %block39092

edge5140:                                         ; preds = %edge5136
  %t5013 = inttoptr i64 %v108728 to ptr
  %v138473 = load i64, ptr %t5013, align 1
  %t5014 = icmp eq i64 %v138473, 1
  br i1 %t5014, label %edge5142, label %block39092

edge5142:                                         ; preds = %edge5140
  %t5016.not = icmp eq i64 %v109484, 0
  br i1 %t5016.not, label %block39090, label %edge5144

edge5144:                                         ; preds = %edge5142
  %v138476 = trunc i64 %v108868 to i8
  %v138477 = add i64 %v108723, %v108693
  %t5017 = inttoptr i64 %v138477 to ptr
  store i8 %v138476, ptr %t5017, align 1
  br label %block39090

edge5149:                                         ; preds = %block39092
  %v138486 = extractvalue { i64, i64, i64, i64, i64, i64, i64 } %t5020, 1
  %v138337 = add i64 %v138487, 7271
  %t5023 = insertvalue { i64, i64 } poison, i64 %v138486, 0
  %t5024 = insertvalue { i64, i64 } %t5023, i64 %v138337, 1
  br label %common.ret

edge5156:                                         ; preds = %block7165
  %v110237 = add i64 %v110047, 1
  %t5028 = icmp ult i64 %v110047, 320
  %v110242 = shl i64 %v110047, 2
  %v110243 = add i64 %v110242, %v83291
  %v139167 = select i1 %t5028, i64 %v110243, i64 ptrtoint (ptr @mech_compact_llvm_anonymous_data_1 to i64)
  %t5031 = inttoptr i64 %v139167 to ptr
  %t5032 = load i32, ptr %t5031, align 1
  %v110244 = zext i32 %t5032 to i64
  %v110434 = and i64 %v110244, 31
  %t5033 = icmp ult i64 %v110434, %v83286
  %v110542 = shl nuw nsw i64 %v110434, 2
  %v110543 = add i64 %v110542, %v83285
  %v139168 = select i1 %t5033, i64 %v110543, i64 ptrtoint (ptr @mech_compact_llvm_anonymous_data_1 to i64)
  %t5036 = inttoptr i64 %v139168 to ptr
  %t5037 = load i32, ptr %t5036, align 1
  %v110544 = zext i32 %t5037 to i64
  %v110587 = lshr i64 %v110544, 16
  %v110591 = add nuw nsw i64 %v110587, %v110007
  %v110567 = and i64 %v110544, 65535
  %v110577 = shl nuw nsw i64 %v110567, %v110007
  %v110601 = lshr i64 %v110244, 5
  %v110609 = and i64 %v110591, 63
  %v110610 = shl i64 %v110601, %v110609
  %82 = or i64 %v110577, %v110610
  %v110614 = or i64 %82, %v110005
  %t5044 = icmp samesign ult i64 %v110434, 19
  %v110723 = add i64 %v110434, ptrtoint (ptr @mech_compact_table_14 to i64)
  %v139169 = select i1 %t5044, i64 %v110723, i64 ptrtoint (ptr @mech_compact_llvm_anonymous_data_1 to i64)
  %t5047 = inttoptr i64 %v139169 to ptr
  %t5048 = load i8, ptr %t5047, align 1
  %v110724 = zext i8 %t5048 to i64
  %v110746 = add nuw nsw i64 %v110591, %v110724
  %v110755 = lshr i64 %v110746, 3
  %v110759 = and i64 %v110755, 255
  %t5052 = icmp samesign ult i64 %v110759, 2
  br i1 %t5052, label %edge5185, label %block39101

edge5157:                                         ; preds = %block7165
  %v110917 = or i64 %v83296, %v83290
  %t5070.not = icmp eq i64 %v110917, 0
  br i1 %t5070.not, label %block7294, label %edge5203

edge5185:                                         ; preds = %edge5156
  %v138501 = add i64 %v110759, %v109994
  %t5054 = icmp uge i64 %v138501, %v109994
  %t5055 = icmp ule i64 %v138501, %v109995.ph908
  %v138504149 = and i1 %t5054, %t5055
  %or.cond38 = select i1 %v138504149, i1 %t5057, i1 false
  br i1 %or.cond38, label %edge5189, label %block39101

edge5189:                                         ; preds = %edge5185
  %v138505 = load i64, ptr %t5058, align 1
  %t5059 = icmp eq i64 %v138505, 1
  br i1 %t5059, label %edge5191, label %block39101

edge5191:                                         ; preds = %edge5189
  %t5061.not = icmp eq i64 %v110759, 0
  br i1 %t5061.not, label %block39099, label %edge5193

edge5193:                                         ; preds = %edge5191
  %v138508 = trunc i64 %v110614 to i8
  %v138509 = add i64 %v109994, %v109993.ph906
  %t5062 = inttoptr i64 %v138509 to ptr
  store i8 %v138508, ptr %t5062, align 1
  br label %block39099

edge5198:                                         ; preds = %block39101
  %v138518 = extractvalue { i64, i64, i64, i64, i64, i64, i64 } %t5065, 1
  %v138346 = add i64 %v138519, 7382
  %t5068 = insertvalue { i64, i64 } poison, i64 %v138518, 0
  %t5069 = insertvalue { i64, i64 } %t5068, i64 %v138346, 1
  br label %common.ret

edge5203:                                         ; preds = %edge5157
  %v110919 = call i64 @mech_compact_release_two(i64 %v0, i64 %v83296, i64 %v83290)
  %t5071.not = icmp eq i64 %v110919, 0
  br i1 %t5071.not, label %block7294, label %edge5205

edge5205:                                         ; preds = %edge5203
  %t5072 = insertvalue { i64, i64 } poison, i64 %v110919, 0
  %t5073 = insertvalue { i64, i64 } %t5072, i64 7393, 1
  br label %common.ret

edge5212:                                         ; preds = %block7285.thread
  %v111067 = call i64 @mech_compact_release_owner(i64 %v0, i64 %v83273)
  %t5077.not = icmp eq i64 %v111067, 0
  br i1 %t5077.not, label %block7294, label %edge5214

edge5214:                                         ; preds = %edge5212
  %t5078 = insertvalue { i64, i64 } poison, i64 %v111067, 0
  %t5079 = insertvalue { i64, i64 } %t5078, i64 7409, 1
  br label %common.ret

edge5220:                                         ; preds = %block7294
  %v112389 = load i64, ptr %t386, align 1
  %v112390 = add i64 %v112389, 1
  store i64 %v112390, ptr %t386, align 1
  br label %block36376

edge5223:                                         ; preds = %block36376
  %t5085 = inttoptr i64 %v138613 to ptr
  %v112391 = load i64, ptr %t5085, align 1
  %v112392 = add i64 %v112391, 1
  store i64 %v112392, ptr %t5085, align 1
  br label %edge5226

edge5226:                                         ; preds = %block36376, %edge5223
  %t5139.pre-phi = phi ptr [ %t5085, %edge5223 ], [ null, %block36376 ]
  %v114696 = or i64 %v138613, %v1399
  %t5165.not = icmp eq i64 %v114696, 0
  br label %block7301

edge5230:                                         ; preds = %block7301
  br i1 %t2151.not.not, label %edge5232, label %edge5233

edge5232:                                         ; preds = %edge5230
  %v112757 = add i64 %v112475, %v36006
  %v112761 = sub i64 %v36030, %v112475
  %t5092 = icmp ugt i64 %v112761, 3
  br i1 %t5092, label %edge5237, label %edge5238

edge5233:                                         ; preds = %edge5230
  %83 = xor i64 %v112475, -1
  %v114826 = add i64 %v49361, %83
  %t5169 = icmp ult i64 %v114826, %v49361
  br i1 %t5169, label %edge5358, label %edge5365.thread

edge5237:                                         ; preds = %edge5232
  %t5095.not = icmp ugt i64 %v112757, %v10075
  br i1 %t5095.not, label %edge5254, label %edge5241

edge5238:                                         ; preds = %edge5232
  br i1 %t23.not, label %block36958, label %edge5295

edge5241:                                         ; preds = %edge5237
  br i1 %v636946, label %edge5247.thread, label %edge5247

edge5247.thread:                                  ; preds = %edge5241
  %v113050 = add i64 %v112757, %v1394
  %t5101 = inttoptr i64 %v113050 to ptr
  %t5102 = load i32, ptr %t5101, align 1
  %v113051 = zext i32 %t5102 to i64
  br label %edge5254

edge5247:                                         ; preds = %edge5241
  %v113053 = call i64 @mech_compact_matrix_word(i64 %v1394, i64 %v112757, i64 %v1397, i64 %v1398, i64 4)
  %t5103 = icmp ult i64 %v113053, 4294967296
  br i1 %t5103, label %edge5254, label %block39122

edge5254:                                         ; preds = %edge5247.thread, %edge5247, %edge5237
  %v113236 = phi i64 [ %v113053, %edge5247 ], [ 0, %edge5237 ], [ %v113051, %edge5247.thread ]
  %v113256 = and i64 %v113236, 255
  %t5105 = icmp ult i64 %v113256, %v138612
  %v113381 = shl nuw nsw i64 %v113256, 2
  %v113382 = add i64 %v113381, %v138611
  %v139170 = select i1 %t5105, i64 %v113382, i64 ptrtoint (ptr @mech_compact_llvm_anonymous_data_1 to i64)
  %t5108 = inttoptr i64 %v139170 to ptr
  %t5109 = load i32, ptr %t5108, align 1
  %v113383 = zext i32 %t5109 to i64
  %v113414 = and i64 %v113383, 65535
  %v113424 = lshr i64 %v113383, 16
  %v113436 = lshr i64 %v113236, 8
  %v113440 = and i64 %v113436, 255
  %t5112 = icmp ult i64 %v113440, %v138612
  %v113553 = shl nuw nsw i64 %v113440, 2
  %v113554 = add i64 %v113553, %v138611
  %v139171 = select i1 %t5112, i64 %v113554, i64 ptrtoint (ptr @mech_compact_llvm_anonymous_data_1 to i64)
  %t5115 = inttoptr i64 %v139171 to ptr
  %t5116 = load i32, ptr %t5115, align 1
  %v113555 = zext i32 %t5116 to i64
  %v113576 = and i64 %v113555, 65535
  %v113584 = and i64 %v113424, 63
  %v113585 = shl i64 %v113576, %v113584
  %v113589 = or i64 %v113585, %v113414
  %v113594 = lshr i64 %v113555, 16
  %v113598 = add nuw nsw i64 %v113594, %v113424
  %v113603 = lshr i64 %v113236, 16
  %v113607 = and i64 %v113603, 255
  %t5120 = icmp ult i64 %v113607, %v138612
  %v113720 = shl nuw nsw i64 %v113607, 2
  %v113721 = add i64 %v113720, %v138611
  %v139172 = select i1 %t5120, i64 %v113721, i64 ptrtoint (ptr @mech_compact_llvm_anonymous_data_1 to i64)
  %t5123 = inttoptr i64 %v139172 to ptr
  %t5124 = load i32, ptr %t5123, align 1
  %v113722 = zext i32 %t5124 to i64
  %v113743 = and i64 %v113722, 65535
  %v113751 = and i64 %v113598, 63
  %v113752 = shl i64 %v113743, %v113751
  %v113756 = or i64 %v113589, %v113752
  %v113761 = lshr i64 %v113722, 16
  %v113765 = add nuw nsw i64 %v113598, %v113761
  %v113944 = lshr i64 %v113236, 24
  %t5128 = icmp ult i64 %v113944, %v138612
  %v114057 = shl nuw nsw i64 %v113944, 2
  %v114058 = add i64 %v114057, %v138611
  %v139173 = select i1 %t5128, i64 %v114058, i64 ptrtoint (ptr @mech_compact_llvm_anonymous_data_1 to i64)
  %t5131 = inttoptr i64 %v139173 to ptr
  %t5132 = load i32, ptr %t5131, align 1
  %v114059 = zext i32 %t5132 to i64
  %v114080 = and i64 %v114059, 65535
  %v114088 = and i64 %v113765, 63
  %v114089 = shl i64 %v114080, %v114088
  %v114093 = or i64 %v113756, %v114089
  %v114098 = lshr i64 %v114059, 16
  %v114102 = add nuw nsw i64 %v113765, %v114098
  %v114116 = add i64 %v112757, 4
  br label %edge5346

edge5295:                                         ; preds = %edge5238
  %v114126 = load i64, ptr %t386, align 1
  %v114127 = add i64 %v114126, 1
  store i64 %v114127, ptr %t386, align 1
  br label %block36958

edge5298:                                         ; preds = %block36958
  %v114128 = load i64, ptr %t5139.pre-phi, align 1
  %v114129 = add i64 %v114128, 1
  store i64 %v114129, ptr %t5139.pre-phi, align 1
  br label %block7494.preheader

edge5308:                                         ; preds = %block7494
  br i1 %v636946, label %edge5321.thread, label %edge5313

edge5313:                                         ; preds = %edge5308
  br i1 %t2056, label %trap5151, label %ok5151

edge5321:                                         ; preds = %block7494
  br i1 %t5141.not, label %edge5322, label %edge5338

edge5322:                                         ; preds = %edge5321.thread, %edge5321
  %v114427816 = phi i64 [ %v114399, %edge5321.thread ], [ 0, %edge5321 ]
  %t5156 = icmp ult i64 %v114427816, %v138612
  %v114629 = shl nuw nsw i64 %v114427816, 2
  %v114630 = add i64 %v114629, %v138611
  %v139174 = select i1 %t5156, i64 %v114630, i64 ptrtoint (ptr @mech_compact_llvm_anonymous_data_1 to i64)
  %t5159 = inttoptr i64 %v139174 to ptr
  %t5160 = load i32, ptr %t5159, align 1
  %v114631 = zext i32 %t5160 to i64
  %v114690 = add i64 %v114164, 1
  %v114682 = lshr i64 %v114631, 16
  %v114686 = add i64 %v114682, %v114150
  %v114662 = and i64 %v114631, 65535
  %v114671 = and i64 %v114150, 63
  %v114672 = shl i64 %v114662, %v114671
  %v114676 = or i64 %v114672, %v114148
  %v114783 = add nsw i64 %v114178, -1
  br label %block7494

edge5338:                                         ; preds = %edge5321
  br i1 %t5165.not, label %edge5346, label %edge5339

edge5339:                                         ; preds = %edge5338
  %v114697 = call i64 @mech_compact_release_two(i64 %v0, i64 %v1399, i64 %v138613)
  %t5166.not = icmp eq i64 %v114697, 0
  br i1 %t5166.not, label %edge5346, label %edge5341

edge5341:                                         ; preds = %edge5339
  %t5167 = insertvalue { i64, i64 } poison, i64 %v114697, 0
  %t5168 = insertvalue { i64, i64 } %t5167, i64 7701, 1
  br label %common.ret

edge5346:                                         ; preds = %edge5338, %edge5339, %edge5254
  %v114805 = phi i64 [ %v114093, %edge5254 ], [ %v114148, %edge5339 ], [ %v114148, %edge5338 ]
  %v114807 = phi i64 [ %v114102, %edge5254 ], [ %v114150, %edge5339 ], [ %v114150, %edge5338 ]
  %v114809 = phi i64 [ %v114116, %edge5254 ], [ %v114164, %edge5339 ], [ %v114164, %edge5338 ]
  %v114815 = sub i64 %v114809, %v112757
  br label %edge5430

edge5358:                                         ; preds = %edge5233
  %v114939 = shl i64 %v114826, 3
  %v114940 = add i64 %v114939, %v49360
  %t5172 = inttoptr i64 %v114940 to ptr
  %v114941 = load i64, ptr %t5172, align 1
  %v114941.fr = freeze i64 %v114941
  %84 = lshr i64 %v114941.fr, 32
  %v114980 = and i64 %84, 511
  %v114989 = lshr i64 %v114941.fr, 41
  %t5175 = icmp eq i64 %v114980, 1
  br i1 %t5175, label %edge5364, label %edge5365

edge5364:                                         ; preds = %edge5358
  %t5178 = icmp ult i64 %v114989, %v138612
  %v115192 = shl nuw nsw i64 %v114989, 2
  %v115193 = add i64 %v115192, %v138611
  %v139175 = select i1 %t5178, i64 %v115193, i64 ptrtoint (ptr @mech_compact_llvm_anonymous_data_1 to i64)
  %t5181 = inttoptr i64 %v139175 to ptr
  %t5182 = load i32, ptr %t5181, align 1
  %v115194 = zext i32 %t5182 to i64
  %v115215 = and i64 %v115194, 65535
  %v115220 = lshr i64 %v115194, 16
  br label %edge5430

edge5365:                                         ; preds = %edge5358
  %t5184 = icmp samesign ult i64 %v114980, 291
  %v115340 = shl nuw nsw i64 %v114980, 2
  %v115341 = add i64 %v115340, ptrtoint (ptr @mech_compact_table_20 to i64)
  %spec.select864 = select i1 %t5184, i64 %v115341, i64 ptrtoint (ptr @mech_compact_llvm_anonymous_data_1 to i64)
  %85 = inttoptr i64 %spec.select864 to ptr
  br label %edge5365.thread

edge5365.thread:                                  ; preds = %edge5365, %edge5233
  %v114980821832 = phi i64 [ %v114980, %edge5365 ], [ 0, %edge5233 ]
  %v114989822830 = phi i64 [ %v114989, %edge5365 ], [ 0, %edge5233 ]
  %t5187 = phi ptr [ %85, %edge5365 ], [ @mech_compact_table_20, %edge5233 ]
  %t5188 = load i32, ptr %t5187, align 1
  %v115342 = zext i32 %t5188 to i64
  %v115363 = and i64 %v115342, 511
  %v115538 = lshr i64 %v115342, 12
  %t5190 = icmp ult i64 %v115363, %v138612
  %v115651 = shl nuw nsw i64 %v115363, 2
  %v115652 = add i64 %v115651, %v138611
  %v139177 = select i1 %t5190, i64 %v115652, i64 ptrtoint (ptr @mech_compact_llvm_anonymous_data_1 to i64)
  %t5193 = inttoptr i64 %v139177 to ptr
  %t5194 = load i32, ptr %t5193, align 1
  %v115653 = zext i32 %t5194 to i64
  %v115675 = lshr i64 %v115653, 16
  %v115679 = and i64 %v115653, 65535
  %v115685 = and i64 %v115675, 31
  %v115690 = shl nuw nsw i64 %v115538, %v115685
  %v115690.masked = and i64 %v115690, 4294967295
  %v115698 = or i64 %v115690.masked, %v115679
  %v115709 = lshr i64 %v115342, 9
  %v115715 = and i64 %v115709, 7
  %v115719 = add nuw nsw i64 %v115675, %v115715
  %v115740 = sub nsw i64 256, %v114989822830
  %v115744 = lshr i64 %v115740, 29
  %v115753 = and i64 %v115744, 7
  %v115757 = add nsw i64 %v114989822830, -1
  %v115762 = lshr i64 %v115757, %v115753
  %t5200 = icmp ult i64 %v115762, 256
  %v115863 = add i64 %v115762, ptrtoint (ptr @mech_compact_table_18 to i64)
  %v139178 = select i1 %t5200, i64 %v115863, i64 ptrtoint (ptr @mech_compact_llvm_anonymous_data_1 to i64)
  %t5203 = inttoptr i64 %v139178 to ptr
  %t5204 = load i8, ptr %t5203, align 1
  %v115864 = zext i8 %t5204 to i64
  %v115881 = shl nuw nsw i64 %v115753, 1
  %v115885 = add nuw nsw i64 %v115881, %v115864
  %v115893 = add nuw nsw i64 %v115885, 288
  %t5206 = icmp ult i64 %v115893, %v138612
  %v116006 = shl nuw nsw i64 %v115893, 2
  %v116007 = add i64 %v116006, %v138611
  %v139179 = select i1 %t5206, i64 %v116007, i64 ptrtoint (ptr @mech_compact_llvm_anonymous_data_1 to i64)
  %t5209 = inttoptr i64 %v139179 to ptr
  %t5210 = load i32, ptr %t5209, align 1
  %v116008 = zext i32 %t5210 to i64
  %v116029 = and i64 %v116008, 65535
  %v116034 = lshr i64 %v116008, 16
  %v116045 = and i64 %v115719, 63
  %v116046 = shl i64 %v116029, %v116045
  %v116050 = or i64 %v115698, %v116046
  %v116054 = add nuw nsw i64 %v116034, %v115719
  %t5213 = icmp samesign ult i64 %v115885, 32
  %v116062 = shl nuw nsw i64 %v115885, 2
  %v116176 = add i64 %v116062, add (i64 ptrtoint (ptr @mech_compact_table_20 to i64), i64 1036)
  %v139180 = select i1 %t5213, i64 %v116176, i64 ptrtoint (ptr @mech_compact_llvm_anonymous_data_1 to i64)
  %t5216 = inttoptr i64 %v139180 to ptr
  %t5217 = load i32, ptr %t5216, align 1
  %v116177 = zext i32 %t5217 to i64
  %v116198 = and i64 %v116177, 65535
  %v116202 = sub nsw i64 %v114989822830, %v116198
  %v116210 = and i64 %v116054, 63
  %v116211 = shl i64 %v116202, %v116210
  %v116215 = or i64 %v116050, %v116211
  %v116220 = lshr i64 %v116177, 16
  %v116224 = add nuw nsw i64 %v116054, %v116220
  br label %edge5430

edge5430:                                         ; preds = %edge5364, %edge5365.thread, %edge5346
  %v116245 = phi i64 [ %v116215, %edge5365.thread ], [ %v114805, %edge5346 ], [ %v115215, %edge5364 ]
  %v116247 = phi i64 [ %v116224, %edge5365.thread ], [ %v114807, %edge5346 ], [ %v115220, %edge5364 ]
  %v116249 = phi i64 [ %v114980821832, %edge5365.thread ], [ %v114815, %edge5346 ], [ 1, %edge5364 ]
  %v116261 = shl i64 %v116245, %v112443
  %v116265 = or i64 %v116261, %v112441
  %v116357 = add i64 %v116247, %v112443
  %v116371 = lshr i64 %v116357, 3
  %v116375 = and i64 %v116371, 255
  %t5224 = icmp samesign ult i64 %v116375, 2
  br i1 %t5224, label %edge5435, label %block39110

edge5431:                                         ; preds = %block7301
  %v116548 = or i64 %v49365, %v1399
  %v116549 = or i64 %v116548, %v138613
  %t5242.not = icmp eq i64 %v116549, 0
  br i1 %t5242.not, label %block7835, label %edge5453

edge5435:                                         ; preds = %edge5430
  %v138533 = add i64 %v116375, %v112430
  %t5226 = icmp uge i64 %v138533, %v112430
  %t5227 = icmp ule i64 %v138533, %v112431
  %v138536153 = and i1 %t5226, %t5227
  %t5229 = icmp ne i64 %v112434, 0
  %or.cond39 = select i1 %v138536153, i1 %t5229, i1 false
  br i1 %or.cond39, label %edge5439, label %block39110

edge5439:                                         ; preds = %edge5435
  %t5230 = inttoptr i64 %v112434 to ptr
  %v138537 = load i64, ptr %t5230, align 1
  %t5231 = icmp eq i64 %v138537, 1
  br i1 %t5231, label %edge5441, label %block39110

edge5441:                                         ; preds = %edge5439
  %t5233.not = icmp eq i64 %v116375, 0
  br i1 %t5233.not, label %block39110.thread, label %edge5443

edge5443:                                         ; preds = %edge5441
  %v138540 = trunc i64 %v116265 to i8
  %v138541 = add i64 %v112430, %v112429
  %t5234 = inttoptr i64 %v138541 to ptr
  store i8 %v138540, ptr %t5234, align 1
  br label %block39110.thread

edge5448:                                         ; preds = %block39110
  %v138550 = extractvalue { i64, i64, i64, i64, i64, i64, i64 } %t5237, 1
  %v138355 = add i64 %v138551, 7940
  %t5240 = insertvalue { i64, i64 } poison, i64 %v138550, 0
  %t5241 = insertvalue { i64, i64 } %t5240, i64 %v138355, 1
  br label %common.ret

edge5449:                                         ; preds = %block39110.thread, %block39110
  %v138530543 = phi i64 [ %v112434, %block39110.thread ], [ %v138555, %block39110 ]
  %v138529542 = phi i64 [ %v112431, %block39110.thread ], [ %v138554, %block39110 ]
  %v138528541 = phi i64 [ %v112429, %block39110.thread ], [ %v138553, %block39110 ]
  %v138527540 = phi i64 [ %v138533, %block39110.thread ], [ %v138552, %block39110 ]
  %v138526539 = phi i64 [ %v138548, %block39110.thread ], [ %v138551, %block39110 ]
  %v116513 = and i64 %v116357, 7
  %v116679 = add i64 %v116249, %v112475
  br label %block7301

edge5453:                                         ; preds = %edge5431
  %v116551 = call i64 @mech_compact_release_three(i64 %v0, i64 %v1399, i64 %v49365, i64 %v138613)
  %t5243.not = icmp eq i64 %v116551, 0
  br i1 %t5243.not, label %block7835, label %edge5455

edge5455:                                         ; preds = %edge5453
  %t5244 = insertvalue { i64, i64 } poison, i64 %v116551, 0
  %t5245 = insertvalue { i64, i64 } %t5244, i64 7951, 1
  br label %common.ret

edge5460:                                         ; preds = %block7835
  %v117240 = add i64 %v138611, 1024
  %t5253 = inttoptr i64 %v117240 to ptr
  %t5254 = load i32, ptr %t5253, align 1
  br i1 %t5084.not, label %edge5474, label %edge5468

edge5461:                                         ; preds = %block7835
  br i1 %t5084.not, label %edge5474, label %edge5462

edge5462:                                         ; preds = %edge5461
  %v117164 = call i64 @mech_compact_release_owner(i64 %v0, i64 %v138613)
  %t5250.not = icmp eq i64 %v117164, 0
  br i1 %t5250.not, label %edge5474, label %edge5464

edge5464:                                         ; preds = %edge5462
  %t5251 = insertvalue { i64, i64 } poison, i64 %v117164, 0
  %t5252 = insertvalue { i64, i64 } %t5251, i64 7975, 1
  br label %common.ret

edge5468:                                         ; preds = %edge5460
  %v117245 = call i64 @mech_compact_release_owner(i64 %v0, i64 %v138613)
  %t5256.not = icmp eq i64 %v117245, 0
  br i1 %t5256.not, label %edge5474, label %edge5470

edge5470:                                         ; preds = %edge5468
  %t5257 = insertvalue { i64, i64 } poison, i64 %v117245, 0
  %t5258 = insertvalue { i64, i64 } %t5257, i64 7980, 1
  br label %common.ret

edge5474:                                         ; preds = %edge5461, %edge5462, %edge5460, %edge5468
  %v117255.shrunk = phi i32 [ %t5254, %edge5460 ], [ %t5254, %edge5468 ], [ 0, %edge5462 ], [ 0, %edge5461 ]
  %v117255 = zext i32 %v117255.shrunk to i64
  %v117262 = and i64 %v117255, 65535
  %v117273 = shl nuw nsw i64 %v117262, %v112443
  %v117277 = or i64 %v117273, %v112441
  %v117282 = lshr i64 %v117255, 16
  %v117293 = add nuw nsw i64 %v117282, %v112443
  %v117301 = lshr i64 %v117293, 3
  %v117305 = and i64 %v117301, 255
  %t5264 = icmp samesign ult i64 %v117305, 2
  br i1 %t5264, label %edge5486, label %block39119

edge5486:                                         ; preds = %edge5474
  %v138565 = add i64 %v117305, %v112430
  %t5266 = icmp uge i64 %v138565, %v112430
  %t5267 = icmp ule i64 %v138565, %v112431
  %v138568152 = and i1 %t5266, %t5267
  %t5269 = icmp ne i64 %v112434, 0
  %or.cond40 = select i1 %v138568152, i1 %t5269, i1 false
  br i1 %or.cond40, label %edge5490, label %block39119

edge5490:                                         ; preds = %edge5486
  %t5270 = inttoptr i64 %v112434 to ptr
  %v138569 = load i64, ptr %t5270, align 1
  %t5271 = icmp eq i64 %v138569, 1
  br i1 %t5271, label %edge5492, label %block39119

edge5492:                                         ; preds = %edge5490
  %t5273.not = icmp eq i64 %v117305, 0
  br i1 %t5273.not, label %block39119.thread, label %edge5494

edge5494:                                         ; preds = %edge5492
  %v138572 = trunc i64 %v117277 to i8
  %v138573 = add i64 %v112430, %v112429
  %t5274 = inttoptr i64 %v138573 to ptr
  store i8 %v138572, ptr %t5274, align 1
  br label %block39119.thread

edge5499:                                         ; preds = %block39119
  %v138582 = extractvalue { i64, i64, i64, i64, i64, i64, i64 } %t5277, 1
  %v138364 = add i64 %v138583, 8000
  %t5280 = insertvalue { i64, i64 } poison, i64 %v138582, 0
  %t5281 = insertvalue { i64, i64 } %t5280, i64 %v138364, 1
  br label %common.ret

edge5500:                                         ; preds = %block39119.thread, %block39119
  %v138562555 = phi i64 [ %v112434, %block39119.thread ], [ %v138587, %block39119 ]
  %v138561554 = phi i64 [ %v112431, %block39119.thread ], [ %v138586, %block39119 ]
  %v138560553 = phi i64 [ %v112429, %block39119.thread ], [ %v138585, %block39119 ]
  %v138559552 = phi i64 [ %v138565, %block39119.thread ], [ %v138584, %block39119 ]
  %v138558551 = phi i64 [ %v138580, %block39119.thread ], [ %v138583, %block39119 ]
  %v117427 = and i64 %v117293, 7
  br label %edge5503

edge5503:                                         ; preds = %edge4916, %edge4918, %edge4921, %edge5500
  %v125845 = phi i64 [ %v138560553, %edge5500 ], [ %v138380, %edge4921 ], [ %v138380, %edge4918 ], [ %v138380, %edge4916 ]
  %v125859 = phi i64 [ %v138559552, %edge5500 ], [ %v138379, %edge4921 ], [ %v138379, %edge4918 ], [ %v138379, %edge4916 ]
  %v125873 = phi i64 [ %v138561554, %edge5500 ], [ %v138381, %edge4921 ], [ %v138381, %edge4918 ], [ %v138381, %edge4916 ]
  %v125887 = phi i64 [ 1, %edge5500 ], [ %v138377, %edge4921 ], [ %v138377, %edge4918 ], [ %v138377, %edge4916 ]
  %v125915 = phi i64 [ %v138562555, %edge5500 ], [ %v138382, %edge4921 ], [ %v138382, %edge4918 ], [ %v138382, %edge4916 ]
  %v125935 = phi i64 [ %v138558551, %edge5500 ], [ 0, %edge4921 ], [ 0, %edge4918 ], [ 0, %edge4916 ]
  %v125950 = phi i64 [ %v117427, %edge5500 ], [ 0, %edge4921 ], [ 0, %edge4918 ], [ 0, %edge4916 ]
  %t5282 = icmp eq i64 %v36011, 1
  %t5283 = icmp eq i64 %v36013, 1
  %v117486160 = and i1 %t5282, %t5283
  br i1 %v117486160, label %block7887, label %edge5508

edge5508:                                         ; preds = %edge5503
  %v117493 = or i64 %v36003, %v35991
  %t5286.not = icmp eq i64 %v117493, 0
  br i1 %t5286.not, label %edge5576, label %edge5509

edge5509:                                         ; preds = %edge5508
  %v117494 = call i64 @mech_compact_release_two(i64 %v0, i64 %v35991, i64 %v36003)
  %t5287.not = icmp eq i64 %v117494, 0
  br i1 %t5287.not, label %edge5576, label %edge5511

edge5511:                                         ; preds = %edge5509
  %t5288 = insertvalue { i64, i64 } poison, i64 %v117494, 0
  %t5289 = insertvalue { i64, i64 } %t5288, i64 8020, 1
  br label %common.ret

edge5514:                                         ; preds = %block7887
  %t5291 = inttoptr i64 %v117575 to ptr
  %v117576 = load i64, ptr %t5291, align 1
  %t5292 = icmp eq i64 %v117576, 1
  br i1 %t5292, label %edge5516, label %block7896

edge5516:                                         ; preds = %edge5514
  %t5294 = zext i64 %v36008 to i128
  %t5295 = zext i64 %v36009 to i128
  %t5296 = shl nuw i128 %t5295, 64
  %v139094 = or disjoint i128 %t5296, %t5294
  store i128 %v139094, ptr %ss3, align 16
  %t5298 = zext i64 %v117598 to i128
  %t5299 = zext i64 %v117599 to i128
  %t5300 = shl nuw i128 %t5299, 64
  %v139096 = or disjoint i128 %t5300, %t5298
  store i128 %v139096, ptr %t403, align 16
  store i128 %v139098, ptr %t408, align 16
  %t5309 = zext i64 %v117575 to i128
  %t5310 = shl nuw i128 %t5309, 64
  %v139100 = or disjoint i128 %t5310, %t585
  store i128 %v139100, ptr %t413, align 16
  store i64 %v3132, ptr %t418, align 16
  %t5314 = call { i64, i64 } @mech_compact_numeric_8026(i64 %v0, i64 %v138697, i64 %v6374)
  %v117581 = extractvalue { i64, i64 } %t5314, 0
  %t5315.not = icmp eq i64 %v117581, 0
  br i1 %t5315.not, label %edge5552, label %edge5518

edge5518:                                         ; preds = %edge5516
  %v117582 = extractvalue { i64, i64 } %t5314, 1
  %t5316 = icmp eq i64 %v117581, 103169
  %v117585 = select i1 %t5316, i64 103425, i64 %v117581
  %t5318 = insertvalue { i64, i64 } poison, i64 %v117585, 0
  %t5319 = insertvalue { i64, i64 } %t5318, i64 %v117582, 1
  br label %common.ret

edge5523:                                         ; preds = %block7896
  %v117697 = add i64 %v117598, %v36008
  %t5323.not = icmp ult i64 %v117697, %v36008
  br i1 %t5323.not, label %block39122, label %edge5533

edge5533:                                         ; preds = %edge5523
  %t5325 = icmp ult i64 %v117697, %v3132
  %v117788 = shl i64 %v117697, 2
  %v117789 = add i64 %v117788, %v117599
  %v139181 = select i1 %t5325, i64 %v117789, i64 ptrtoint (ptr @mech_compact_llvm_anonymous_data_1 to i64)
  %t5328 = inttoptr i64 %v139181 to ptr
  %t5329 = load i32, ptr %t5328, align 1
  %v117887 = add i64 %v117598, 1
  %t5333 = zext i64 %v117887 to i128
  %v139102 = or disjoint i128 %t586, %t5333
  store i128 %v139102, ptr %ss6, align 16
  %t5337 = zext i64 %v117599 to i128
  %t5338 = zext i32 %t5329 to i128
  %t5339 = shl nuw nsw i128 %t5338, 64
  %v139104 = or disjoint i128 %t5339, %t5337
  store i128 %v139104, ptr %t931, align 16
  %t5342 = zext i64 %v117575 to i128
  %v139106 = or disjoint i128 %t934, %t5342
  store i128 %v139106, ptr %t936, align 16
  store i64 %v3132, ptr %t937, align 16
  %t5348 = call { i64, i64, i64, i64 } @mech_compact_checked_layout_16147(i64 %v138793)
  %v138101 = extractvalue { i64, i64, i64, i64 } %t5348, 0
  %t5349 = icmp ugt i64 %v138101, 1
  br i1 %t5349, label %edge5536, label %edge5541

edge5536:                                         ; preds = %edge5533
  %v138102 = extractvalue { i64, i64, i64, i64 } %t5348, 1
  %v138106 = add i64 %v138101, 8062
  %t5351 = insertvalue { i64, i64 } poison, i64 %v138102, 0
  %t5352 = insertvalue { i64, i64 } %t5351, i64 %v138106, 1
  br label %common.ret

edge5541:                                         ; preds = %edge5533
  %v138104 = extractvalue { i64, i64, i64, i64 } %t5348, 3
  %v138103 = extractvalue { i64, i64, i64, i64 } %t5348, 2
  br label %block7887

edge5549:                                         ; preds = %edge5555
  %t5359 = insertvalue { i64, i64 } poison, i64 %v119175, 0
  %t5360 = insertvalue { i64, i64 } %t5359, i64 8083, 1
  br label %common.ret

edge5552:                                         ; preds = %block7896, %edge5516
  %t5361 = call { i64, i64 } @mech_compact_allocate_backing(i64 %v0, i64 10, i64 4, i64 4, i64 1)
  %v119231 = extractvalue { i64, i64 } %t5361, 0
  %v119232 = extractvalue { i64, i64 } %t5361, 1
  %t5362.not = icmp eq i64 %v119231, 0
  br i1 %t5362.not, label %edge5554, label %edge5555

edge5554:                                         ; preds = %edge5552
  %t5364 = insertvalue { i64, i64 } poison, i64 %v119232, 0
  %t5365 = insertvalue { i64, i64 } %t5364, i64 8087, 1
  br label %common.ret

edge5555:                                         ; preds = %edge5552
  %t5363 = inttoptr i64 %v119232 to ptr
  store i64 2, ptr %t5363, align 1
  %v119175 = call i64 @mech_compact_release_owner(i64 %v0, i64 %v119232)
  %t5358.not = icmp eq i64 %v119175, 0
  br i1 %t5358.not, label %edge5565, label %edge5549

edge5565:                                         ; preds = %edge5555
  %t5374 = call { i64, i64 } @mech_compact_allocate_backing(i64 %v0, i64 259, i64 4, i64 4, i64 1)
  %v120486 = extractvalue { i64, i64 } %t5374, 0
  %v120487 = extractvalue { i64, i64 } %t5374, 1
  %t5375.not = icmp eq i64 %v120486, 0
  br i1 %t5375.not, label %edge5567, label %edge5617

edge5567:                                         ; preds = %edge5565
  %t5377 = insertvalue { i64, i64 } poison, i64 %v120487, 0
  %t5378 = insertvalue { i64, i64 } %t5377, i64 8100, 1
  br label %common.ret

edge5573:                                         ; preds = %edge5579
  %t5382 = insertvalue { i64, i64 } poison, i64 %v121724, 0
  %t5383 = insertvalue { i64, i64 } %t5382, i64 8113, 1
  br label %common.ret

edge5576:                                         ; preds = %edge5508, %edge5509
  %t5384 = call { i64, i64 } @mech_compact_allocate_backing(i64 %v0, i64 10, i64 4, i64 4, i64 1)
  %v121766 = extractvalue { i64, i64 } %t5384, 0
  %v121767 = extractvalue { i64, i64 } %t5384, 1
  %t5385.not = icmp eq i64 %v121766, 0
  br i1 %t5385.not, label %edge5578, label %edge5579

edge5578:                                         ; preds = %edge5576
  %t5387 = insertvalue { i64, i64 } poison, i64 %v121767, 0
  %t5388 = insertvalue { i64, i64 } %t5387, i64 8117, 1
  br label %common.ret

edge5579:                                         ; preds = %edge5576
  %t5386 = inttoptr i64 %v121767 to ptr
  store i64 2, ptr %t5386, align 1
  %v121724 = call i64 @mech_compact_release_owner(i64 %v0, i64 %v121767)
  %t5381.not = icmp eq i64 %v121724, 0
  br i1 %t5381.not, label %edge5587, label %edge5573

edge5584:                                         ; preds = %edge5590
  %t5392 = insertvalue { i64, i64 } poison, i64 %v122975, 0
  %t5393 = insertvalue { i64, i64 } %t5392, i64 8126, 1
  br label %common.ret

edge5587:                                         ; preds = %edge5579
  %t5394 = call { i64, i64 } @mech_compact_allocate_backing(i64 %v0, i64 10, i64 4, i64 4, i64 1)
  %v123017 = extractvalue { i64, i64 } %t5394, 0
  %v123018 = extractvalue { i64, i64 } %t5394, 1
  %t5395.not = icmp eq i64 %v123017, 0
  br i1 %t5395.not, label %edge5589, label %edge5590

edge5589:                                         ; preds = %edge5587
  %t5397 = insertvalue { i64, i64 } poison, i64 %v123018, 0
  %t5398 = insertvalue { i64, i64 } %t5397, i64 8130, 1
  br label %common.ret

edge5590:                                         ; preds = %edge5587
  %t5396 = inttoptr i64 %v123018 to ptr
  store i64 2, ptr %t5396, align 1
  %v122975 = call i64 @mech_compact_release_owner(i64 %v0, i64 %v123018)
  %t5391.not = icmp eq i64 %v122975, 0
  br i1 %t5391.not, label %edge5598, label %edge5584

edge5595:                                         ; preds = %edge5601
  %t5402 = insertvalue { i64, i64 } poison, i64 %v124238, 0
  %t5403 = insertvalue { i64, i64 } %t5402, i64 8139, 1
  br label %common.ret

edge5598:                                         ; preds = %edge5590
  %t5404 = call { i64, i64 } @mech_compact_allocate_backing(i64 %v0, i64 259, i64 4, i64 4, i64 1)
  %v124284 = extractvalue { i64, i64 } %t5404, 0
  %v124285 = extractvalue { i64, i64 } %t5404, 1
  %t5405.not = icmp eq i64 %v124284, 0
  br i1 %t5405.not, label %edge5600, label %edge5601

edge5600:                                         ; preds = %edge5598
  %t5407 = insertvalue { i64, i64 } poison, i64 %v124285, 0
  %t5408 = insertvalue { i64, i64 } %t5407, i64 8143, 1
  br label %common.ret

edge5601:                                         ; preds = %edge5598
  %t5406 = inttoptr i64 %v124285 to ptr
  store i64 2, ptr %t5406, align 1
  %v124238 = call i64 @mech_compact_release_owner(i64 %v0, i64 %v124285)
  %t5401.not = icmp eq i64 %v124238, 0
  br i1 %t5401.not, label %edge5611, label %edge5595

edge5611:                                         ; preds = %edge5601
  %t5417 = call { i64, i64 } @mech_compact_allocate_backing(i64 %v0, i64 259, i64 4, i64 4, i64 1)
  %v125559 = extractvalue { i64, i64 } %t5417, 0
  %v125560 = extractvalue { i64, i64 } %t5417, 1
  %t5418.not = icmp eq i64 %v125559, 0
  br i1 %t5418.not, label %edge5613, label %edge5617

edge5613:                                         ; preds = %edge5611
  %t5420 = insertvalue { i64, i64 } poison, i64 %v125560, 0
  %t5421 = insertvalue { i64, i64 } %t5420, i64 8156, 1
  br label %common.ret

edge5617:                                         ; preds = %edge5611, %edge5565
  %v125560.sink = phi i64 [ %v120487, %edge5565 ], [ %v125560, %edge5611 ]
  %v125725 = phi i64 [ %v117599, %edge5565 ], [ %v35968, %edge5611 ]
  %v125730 = phi i64 [ %v117575, %edge5565 ], [ %v35973, %edge5611 ]
  %v125761 = phi i64 [ %v36007, %edge5565 ], [ %v35976, %edge5611 ]
  %v125765 = phi i64 [ %v36009, %edge5565 ], [ 0, %edge5611 ]
  %v125767 = phi i64 [ %v120486, %edge5565 ], [ %v125559, %edge5611 ]
  %v125779 = phi i64 [ %v35986, %edge5565 ], [ %v124284, %edge5611 ]
  %v125784 = phi i64 [ %v35991, %edge5565 ], [ %v124285, %edge5611 ]
  %v125813 = phi i64 [ %v119231, %edge5565 ], [ %v123017, %edge5611 ]
  %v125818 = phi i64 [ %v119232, %edge5565 ], [ %v123018, %edge5611 ]
  %v125825 = phi i64 [ %v35998, %edge5565 ], [ %v121766, %edge5611 ]
  %v125830 = phi i64 [ %v36003, %edge5565 ], [ %v121767, %edge5611 ]
  %v125839 = phi i64 [ %v36005, %edge5565 ], [ 0, %edge5611 ]
  %t5419 = inttoptr i64 %v125560.sink to ptr
  store i64 1, ptr %t5419, align 1
  %t5422 = icmp eq i64 %v35976, %v1395
  br i1 %t5422, label %edge5619, label %edge5633

edge5619:                                         ; preds = %edge5617
  %v126006 = or i64 %v87729, %v1399
  %v126007 = or i64 %v126006, %v137736
  %t5425.not = icmp eq i64 %v126007, 0
  br i1 %t5425.not, label %block38800, label %edge5621

edge5621:                                         ; preds = %edge5619
  %v126008 = call i64 @mech_compact_release_three(i64 %v0, i64 %v1399, i64 %v87729, i64 %v137736)
  %t5426.not = icmp eq i64 %v126008, 0
  br i1 %t5426.not, label %block38800, label %block38785

edge5625:                                         ; preds = %block38800
  %v126013 = call i64 @mech_compact_release_four(i64 %v0, i64 %v35967, i64 %v125730, i64 %v49365, i64 %v125560.sink)
  %t5428.not = icmp eq i64 %v126013, 0
  br i1 %t5428.not, label %block38803, label %block38785

edge5629:                                         ; preds = %block38803
  %v126018 = call i64 @mech_compact_release_four(i64 %v0, i64 %v125784, i64 %v35997, i64 %v125818, i64 %v125830)
  %t5430.not = icmp eq i64 %v126018, 0
  br i1 %t5430.not, label %block8065, label %block38785

edge5633:                                         ; preds = %edge5617
  %t357.not = icmp ult i64 %v1395, %v125761
  br i1 %t357.not, label %block39122, label %block9353

edge5635:                                         ; preds = %block8065
  %t5436 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %v125859, i64 1)
  %v137434 = extractvalue { i64, i1 } %t5436, 0
  %t5437 = extractvalue { i64, i1 } %t5436, 1
  br i1 %t5437, label %block38917, label %edge5638

edge5638:                                         ; preds = %edge5635
  %t5440 = icmp ule i64 %v137434, %v125873
  %t5442 = icmp ne i64 %v125915, 0
  %or.cond41 = select i1 %t5440, i1 %t5442, i1 false
  br i1 %or.cond41, label %edge5642, label %block38932

edge5642:                                         ; preds = %edge5638
  %t5443 = inttoptr i64 %v125915 to ptr
  %v137470 = load i64, ptr %t5443, align 1
  %t5444 = icmp eq i64 %v137470, 1
  br i1 %t5444, label %block38931, label %block38932

edge5649:                                         ; preds = %block38931
  %t5453 = inttoptr i64 %v137469 to ptr
  %v137481 = load i64, ptr %t5453, align 1
  %v137482 = add i64 %v137481, 1
  store i64 %v137482, ptr %t5453, align 1
  br label %block38936

edge5652:                                         ; preds = %block38936
  %v137487 = call i64 @mech_compact_release_owner(i64 %v0, i64 %v125915)
  %t5457.not = icmp eq i64 %v137487, 0
  br i1 %t5457.not, label %edge5660, label %block38917

edge5660:                                         ; preds = %block8065, %block38936, %edge5652, %edge150, %edge152, %edge155, %block8224, %edge78, %edge81
  %v137525 = phi i64 [ %v138370, %edge150 ], [ %v1866, %block8224 ], [ %v1866, %edge81 ], [ %v1866, %edge78 ], [ %v138370, %edge155 ], [ %v138370, %edge152 ], [ %v137464, %block38936 ], [ %v137464, %edge5652 ], [ %v125845, %block8065 ]
  %v137526 = phi i64 [ %v138369, %edge150 ], [ %v1836, %block8224 ], [ %v1836, %edge81 ], [ %v1836, %edge78 ], [ %v138369, %edge155 ], [ %v138369, %edge152 ], [ %v137434, %block38936 ], [ %v137434, %edge5652 ], [ %v125859, %block8065 ]
  %v137527 = phi i64 [ %v138371, %edge150 ], [ %v1868, %block8224 ], [ %v1868, %edge81 ], [ %v1868, %edge78 ], [ %v138371, %edge155 ], [ %v138371, %edge152 ], [ %v137466, %block38936 ], [ %v137466, %edge5652 ], [ %v125873, %block8065 ]
  %v137528 = phi i64 [ %v138367, %edge150 ], [ 1, %block8224 ], [ 1, %edge81 ], [ 1, %edge78 ], [ %v138367, %edge155 ], [ %v138367, %edge152 ], [ 1, %block38936 ], [ 1, %edge5652 ], [ %v125887, %block8065 ]
  %v137530 = phi i64 [ %v138372, %edge150 ], [ %v1871, %block8224 ], [ %v1871, %edge81 ], [ %v1871, %edge78 ], [ %v138372, %edge155 ], [ %v138372, %edge152 ], [ %v137469, %block38936 ], [ %v137469, %edge5652 ], [ %v125915, %block8065 ]
  %t5460.not = icmp eq i64 %v137530, 0
  br i1 %t5460.not, label %block38973, label %edge5661

edge5661:                                         ; preds = %edge5660
  %t5461 = inttoptr i64 %v137530 to ptr
  %v137539 = load i64, ptr %t5461, align 1
  %v137540 = add i64 %v137539, 1
  store i64 %v137540, ptr %t5461, align 1
  %v137544 = call i64 @mech_compact_release_owner(i64 %v0, i64 %v137530)
  %t5463.not = icmp eq i64 %v137544, 0
  br i1 %t5463.not, label %block38973, label %edge5664

edge5664:                                         ; preds = %edge5661
  %t5477 = insertvalue { i64, i64 } poison, i64 %v137544, 0
  %t5478 = insertvalue { i64, i64 } %t5477, i64 8222, 1
  br label %common.ret
}

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.uadd.sat.i64(i64, i64) #5

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.usub.sat.i64(i64, i64) #5

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i64, i1 } @llvm.umul.with.overflow.i64(i64, i64) #5

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.umax.i32(i32, i32) #5

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.smax.i64(i64, i64) #5

attributes #0 = { "target-cpu"="apple-m1" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none) "target-cpu"="apple-m1" }
attributes #2 = { mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) "target-cpu"="apple-m1" }
attributes #3 = { cold noreturn nounwind memory(inaccessiblemem: write) "target-cpu"="apple-m1" }
attributes #4 = { noinline uwtable "frame-pointer"="all" "target-cpu"="apple-m1" }
attributes #5 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
