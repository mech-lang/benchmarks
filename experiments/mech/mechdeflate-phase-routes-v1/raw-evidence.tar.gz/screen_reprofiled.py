"""Suspend and resume this study's compiler construction around an exploratory clock."""
import os
from pathlib import Path
import signal
import subprocess
import sys

cargo = 9476
manifest = Path("compiler/compiler-driver/Cargo.toml").resolve()
command = subprocess.check_output(["ps", "-p", str(cargo), "-o", "command="], text=True)
assert str(manifest) in command and "cargo build" in command
suspended = []
def suspend(pid):
    os.kill(pid, signal.SIGSTOP)
    suspended.append(pid)
def descendants(parent):
    processes = [line.split() for line in
                 subprocess.check_output(["ps", "-Ao", "pid=,ppid="], text=True).splitlines()]
    return [int(pid) for pid, owner in processes if int(owner) == parent]

try:
    pending = [cargo]
    while pending:
        pid = pending.pop()
        suspend(pid)
        pending.extend(descendants(pid))
    for pid in suspended:
        assert subprocess.check_output(["ps", "-p", str(pid), "-o", "state="], text=True).strip().startswith("T")
    subprocess.run([sys.executable, "run_study.py", *sys.argv[1:]], check=True)
finally:
    for pid in reversed(suspended):
        os.kill(pid, signal.SIGCONT)
