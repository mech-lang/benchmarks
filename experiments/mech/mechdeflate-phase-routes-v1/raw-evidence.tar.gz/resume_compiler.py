from pathlib import Path
from runpy import run_path
import subprocess
import time
from run_study import sha, write

root = Path('/Users/coreymontella/.codex/worktrees/mechdeflate-64th/mech-shared-cold-epilogues.2L6obP')
out = Path('compiler-next').resolve()
target = Path('compiler-target').resolve()
wrapper = Path('rustc-ram-wrapper').resolve()
build = run_path('/private/tmp/mechdeflate-benchmarks-literal-pairs/experiments/mech/mechdeflate-masked-fields-v1/reproduce.py')
command = ['cargo','+nightly-2026-03-03','build','--locked','--release','--config',
           'profile.release.package.libmimalloc-sys.opt-level=1','--manifest-path',
           str(out/'compiler-driver/Cargo.toml'),'--target-dir',str(target),'--bin','compile_profile']
environment = {'CARGO_BUILD_JOBS':'1','CARGO_PROFILE_RELEASE_OPT_LEVEL':'3',
               'CARGO_PROFILE_RELEASE_DEBUG':'false','CARGO_PROFILE_RELEASE_LTO':'false',
               'CARGO_PROFILE_RELEASE_CODEGEN_UNITS':'16','CARGO_INCREMENTAL':'0',
               'CARGO_NET_OFFLINE':'true','RUSTC_WRAPPER':str(wrapper)}
start = time.monotonic()
with (out/'compiler-build.log').open('w') as stream:
    subprocess.run(command,cwd=root,env=build['clean_environment']()|environment,
                   stdout=stream,stderr=stream,check=True)
exe = out/'compile_profile'
subprocess.run(['/bin/cp','-c',target/'release/compile_profile',exe],check=True)
write(out/'compiler-build.json', {'compiler_sha256':sha(exe),'seconds':time.monotonic()-start,
                                 'command':command,'environment':environment,'wrapper_sha256':sha(wrapper),
                                 'failed_attempts':['compiler-build-disk-limited.log','compiler-build-ram-copy-limited.log']})
print(exe, flush=True)
