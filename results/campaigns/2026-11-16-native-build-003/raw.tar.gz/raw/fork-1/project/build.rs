use sha2::{Digest, Sha256};
use std::{collections::BTreeMap, fs, path::PathBuf};

const EXPECTED: &str = "{\"Cargo.toml\":\"9fb64debebc79102145096a581c6e9ba1741d4425ef0de1049a9ef580e94c266\",\"application.mec\":\"c8b535b8607fdcc6e1b13fb0151105981e4514136a88bac0e42edd68b1ba37bf\",\"factory-profile.json\":\"9994b6320a18983292d33048f7a7302a66bfead8e8f9ef5f99af6c12f7aa2dfb\",\"object-identity.bin\":\"0e5fb10691501478782c23ab3344e9a996050499b6e506a087620ca1e0d1b5a3\",\"program.mecb\":\"a651cdaf9c0b5d4babdfd31bca65f9b515099c482760993adc9d2fc4c1f5ed5c\",\"program.o\":\"755ffb169f0506fc30ebd748ba0c955e33bfcde50694a6ef80c43d8e895e6d26\",\"rust-toolchain.toml\":\"19219593d7dba33a75623287af94da940a93fac92eeef99e8fff9b7fd804fcf9\",\"src/main.rs\":\"970efc567dfc786479bbc27b190585a24c30f310c241cb854bb26d783b1e5a72\"}";
fn digest(bytes: &[u8]) -> String {
    Sha256::digest(bytes)
        .iter()
        .map(|byte| format!("{byte:02x}"))
        .collect()
}
fn main() {
    assert_eq!(
        std::env::var("HOST").unwrap(),
        std::env::var("TARGET").unwrap(),
        "canonical native object is host-only"
    );
    let root = PathBuf::from(std::env::var_os("CARGO_MANIFEST_DIR").unwrap());
    let expected: BTreeMap<String, String> = serde_json::from_str(EXPECTED).unwrap();
    let manifest_bytes = fs::read(root.join("linked-manifest.json")).unwrap();
    let manifest: serde_json::Value = serde_json::from_slice(&manifest_bytes).unwrap();
    assert_eq!(manifest["schema"], "mech.canonical-linked-application.v1");
    let mut pins: BTreeMap<String, String> =
        serde_json::from_value(manifest["pins"].clone()).unwrap();
    let script = pins.remove("build.rs").expect("build script pin");
    assert_eq!(
        digest(&fs::read(root.join("build.rs")).unwrap()),
        script,
        "build script changed"
    );
    assert_eq!(pins, expected, "manifest generated-input pins changed");
    for (name, hash) in expected {
        assert_eq!(
            digest(&fs::read(root.join(&name)).unwrap()),
            hash,
            "changed generated input {name}"
        );
        println!("cargo:rerun-if-changed={name}");
    }
    println!("cargo:rerun-if-changed=linked-manifest.json");
    println!("cargo:rerun-if-changed=build.rs");
    println!("cargo:rustc-link-arg={}", root.join("program.o").display());
}
